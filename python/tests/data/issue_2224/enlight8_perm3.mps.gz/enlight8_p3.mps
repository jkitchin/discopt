NAME        
ROWS
 N  Obj     
 E  r0      
 E  r1      
 E  r2      
 E  r3      
 E  r4      
 E  r5      
 E  r6      
 E  r7      
 E  r8      
 E  r9      
 E  r10     
 E  r11     
 E  r12     
 E  r13     
 E  r14     
 E  r15     
 E  r16     
 E  r17     
 E  r18     
 E  r19     
 E  r20     
 E  r21     
 E  r22     
 E  r23     
 E  r24     
 E  r25     
 E  r26     
 E  r27     
 E  r28     
 E  r29     
 E  r30     
 E  r31     
 E  r32     
 E  r33     
 E  r34     
 E  r35     
 E  r36     
 E  r37     
 E  r38     
 E  r39     
 E  r40     
 E  r41     
 E  r42     
 E  r43     
 E  r44     
 E  r45     
 E  r46     
 E  r47     
 E  r48     
 E  r49     
 E  r50     
 E  r51     
 E  r52     
 E  r53     
 E  r54     
 E  r55     
 E  r56     
 E  r57     
 E  r58     
 E  r59     
 E  r60     
 E  r61     
 E  r62     
 E  r63     
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    c0        Obj       1
    c0        r10       1
    c0        r11       1
    c0        r18       1
    c0        r28       1
    c0        r55       1
    c1        r12       -2
    c2        Obj       1
    c2        r22       1
    c2        r40       1
    c2        r41       1
    c2        r62       1
    c3        r58       -2
    c4        Obj       1
    c4        r1        1
    c4        r18       1
    c4        r36       1
    c4        r37       1
    c4        r55       1
    c5        Obj       1
    c5        r3        1
    c5        r21       1
    c5        r46       1
    c5        r49       1
    c6        r1        -2
    c7        r49       -2
    c8        Obj       1
    c8        r5        1
    c8        r11       1
    c8        r44       1
    c8        r53       1
    c8        r55       1
    c9        Obj       1
    c9        r13       1
    c9        r25       1
    c9        r29       1
    c9        r63       1
    c10       Obj       1
    c10       r10       1
    c10       r11       1
    c10       r23       1
    c10       r44       1
    c10       r51       1
    c11       Obj       1
    c11       r9        1
    c11       r38       1
    c11       r48       1
    c11       r59       1
    c12       Obj       1
    c12       r5        1
    c12       r28       1
    c12       r33       1
    c12       r37       1
    c12       r55       1
    c13       r54       -2
    c14       Obj       1
    c14       r17       1
    c14       r39       1
    c14       r45       1
    c14       r58       1
    c15       Obj       1
    c15       r5        1
    c15       r15       1
    c15       r53       1
    c15       r57       1
    c15       r60       1
    c16       r59       -2
    c17       Obj       1
    c17       r0        1
    c17       r18       1
    c17       r28       1
    c17       r37       1
    c17       r62       1
    c18       Obj       1
    c18       r9        1
    c18       r15       1
    c18       r39       1
    c18       r48       1
    c18       r60       1
    c19       r32       -2
    c20       r7        -2
    c21       Obj       1
    c21       r12       1
    c21       r21       1
    c21       r49       1
    c21       r51       1
    c21       r52       1
    c22       r30       -2
    c23       Obj       1
    c23       r31       1
    c23       r43       1
    c23       r46       1
    c23       r49       1
    c23       r52       1
    c24       Obj       1
    c24       r4        1
    c24       r24       1
    c24       r34       1
    c24       r35       1
    c25       r6        -2
    c26       r62       -2
    c27       r2        -2
    c28       Obj       1
    c28       r16       1
    c28       r20       1
    c28       r30       1
    c28       r34       1
    c28       r35       1
    c29       Obj       1
    c29       r0        1
    c29       r13       1
    c29       r25       1
    c29       r33       1
    c29       r37       1
    c30       r8        -2
    c31       Obj       1
    c31       r14       1
    c31       r19       1
    c31       r23       1
    c31       r32       1
    c31       r42       1
    c32       Obj       1
    c32       r21       1
    c32       r26       1
    c32       r46       1
    c32       r52       1
    c33       r26       -2
    c34       Obj       1
    c34       r10       1
    c34       r12       1
    c34       r30       1
    c34       r51       1
    c34       r56       1
    c35       r39       -2
    c36       r17       -2
    c37       Obj       1
    c37       r6        1
    c37       r16       1
    c37       r30       1
    c37       r36       1
    c37       r56       1
    c38       r13       -2
    c39       Obj       1
    c39       r14       1
    c39       r19       1
    c39       r27       1
    c39       r58       1
    c40       Obj       1
    c40       r27       1
    c40       r45       1
    c40       r57       1
    c40       r58       1
    c41       r52       -2
    c42       r28       -2
    c43       Obj       1
    c43       r7        1
    c43       r17       1
    c43       r45       1
    c44       r29       -2
    c45       r11       -2
    c46       Obj       1
    c46       r1        1
    c46       r18       1
    c46       r20       1
    c46       r22       1
    c46       r62       1
    c47       r33       -2
    c48       r14       -2
    c49       Obj       1
    c49       r2        1
    c49       r4        1
    c49       r24       1
    c50       r61       -2
    c51       r18       -2
    c52       r10       -2
    c53       Obj       1
    c53       r14       1
    c53       r27       1
    c53       r42       1
    c53       r53       1
    c53       r57       1
    c54       r5        -2
    c55       r37       -2
    c56       Obj       1
    c56       r8        1
    c56       r20       1
    c56       r22       1
    c56       r34       1
    c57       r56       -2
    c58       Obj       1
    c58       r10       1
    c58       r18       1
    c58       r20       1
    c58       r30       1
    c58       r36       1
    c59       Obj       1
    c59       r6        1
    c59       r12       1
    c59       r30       1
    c59       r35       1
    c59       r47       1
    c60       r38       -2
    c61       Obj       1
    c61       r3        1
    c61       r31       1
    c61       r46       1
    c61       r50       1
    c62       r42       -2
    c63       r53       -2
    c64       Obj       1
    c64       r19       1
    c64       r27       1
    c64       r42       1
    c64       r61       1
    c65       r19       -2
    c66       r47       -2
    c67       Obj       1
    c67       r0        1
    c67       r13       1
    c67       r40       1
    c67       r62       1
    c67       r63       1
    c68       r41       -2
    c69       Obj       1
    c69       r14       1
    c69       r39       1
    c69       r57       1
    c69       r58       1
    c69       r60       1
    c70       r50       -2
    c71       r27       -2
    c72       Obj       1
    c72       r6        1
    c72       r12       1
    c72       r26       1
    c72       r52       1
    c72       r56       1
    c73       r35       -2
    c74       Obj       1
    c74       r29       1
    c74       r40       1
    c74       r63       1
    c75       Obj       1
    c75       r2        1
    c75       r4        1
    c75       r35       1
    c75       r47       1
    c76       Obj       1
    c76       r5        1
    c76       r9        1
    c76       r15       1
    c76       r33       1
    c76       r38       1
    c77       r48       -2
    c78       Obj       1
    c78       r12       1
    c78       r21       1
    c78       r26       1
    c78       r47       1
    c79       r55       -2
    c80       Obj       1
    c80       r31       1
    c80       r50       1
    c80       r54       1
    c80       r61       1
    c81       Obj       1
    c81       r1        1
    c81       r8        1
    c81       r16       1
    c81       r20       1
    c81       r36       1
    c82       r45       -2
    c83       r34       -2
    c84       r22       -2
    c85       Obj       1
    c85       r8        1
    c85       r16       1
    c85       r24       1
    c85       r34       1
    c86       r24       -2
    c87       r31       -2
    c88       r9        -2
    c89       r4        -2
    c90       r57       -2
    c91       r25       -2
    c92       Obj       1
    c92       r31       1
    c92       r32       1
    c92       r42       1
    c92       r43       1
    c92       r61       1
    c93       r40       -2
    c94       Obj       1
    c94       r23       1
    c94       r32       1
    c94       r43       1
    c94       r49       1
    c94       r51       1
    c95       Obj       1
    c95       r23       1
    c95       r42       1
    c95       r43       1
    c95       r44       1
    c95       r53       1
    c96       r0        -2
    c97       r44       -2
    c98       Obj       1
    c98       r25       1
    c98       r33       1
    c98       r38       1
    c98       r59       1
    c99       r23       -2
    c100      r46       -2
    c101      r43       -2
    c102      r20       -2
    c103      Obj       1
    c103      r2        1
    c103      r6        1
    c103      r26       1
    c103      r47       1
    c104      r51       -2
    c105      r3        -2
    c106      Obj       1
    c106      r0        1
    c106      r25       1
    c106      r59       1
    c106      r63       1
    c107      r36       -2
    c108      Obj       1
    c108      r43       1
    c108      r44       1
    c108      r51       1
    c108      r52       1
    c108      r56       1
    c109      Obj       1
    c109      r7        1
    c109      r17       1
    c109      r39       1
    c109      r48       1
    c110      Obj       1
    c110      r7        1
    c110      r15       1
    c110      r39       1
    c110      r45       1
    c110      r57       1
    c111      Obj       1
    c111      r1        1
    c111      r13       1
    c111      r37       1
    c111      r41       1
    c111      r62       1
    c112      r15       -2
    c113      Obj       1
    c113      r0        1
    c113      r9        1
    c113      r28       1
    c113      r33       1
    c113      r59       1
    c114      Obj       1
    c114      r5        1
    c114      r9        1
    c114      r11       1
    c114      r28       1
    c114      r60       1
    c115      r16       -2
    c116      Obj       1
    c116      r1        1
    c116      r8        1
    c116      r22       1
    c116      r41       1
    c117      Obj       1
    c117      r3        1
    c117      r50       1
    c117      r54       1
    c118      Obj       1
    c118      r7        1
    c118      r15       1
    c118      r38       1
    c118      r48       1
    c119      Obj       1
    c119      r3        1
    c119      r31       1
    c119      r32       1
    c119      r49       1
    c119      r54       1
    c120      Obj       1
    c120      r13       1
    c120      r29       1
    c120      r40       1
    c120      r41       1
    c121      Obj       1
    c121      r10       1
    c121      r36       1
    c121      r44       1
    c121      r55       1
    c121      r56       1
    c122      r60       -2
    c123      Obj       1
    c123      r2        1
    c123      r6        1
    c123      r16       1
    c123      r24       1
    c123      r35       1
    c124      Obj       1
    c124      r19       1
    c124      r32       1
    c124      r54       1
    c124      r61       1
    c125      r63       -2
    c126      Obj       1
    c126      r11       1
    c126      r14       1
    c126      r23       1
    c126      r53       1
    c126      r60       1
    c127      r21       -2
    MARK0001  'MARKER'                 'INTEND'
RHS
    RHS_V     r17       -1
BOUNDS
 BV BOUND     c0      
 LI BOUND     c1        0
 BV BOUND     c2      
 LI BOUND     c3        0
 BV BOUND     c4      
 BV BOUND     c5      
 LI BOUND     c6        0
 LI BOUND     c7        0
 BV BOUND     c8      
 BV BOUND     c9      
 BV BOUND     c10     
 BV BOUND     c11     
 BV BOUND     c12     
 LI BOUND     c13       0
 BV BOUND     c14     
 BV BOUND     c15     
 LI BOUND     c16       0
 BV BOUND     c17     
 BV BOUND     c18     
 LI BOUND     c19       0
 LI BOUND     c20       0
 BV BOUND     c21     
 LI BOUND     c22       0
 BV BOUND     c23     
 BV BOUND     c24     
 LI BOUND     c25       0
 LI BOUND     c26       0
 LI BOUND     c27       0
 BV BOUND     c28     
 BV BOUND     c29     
 LI BOUND     c30       0
 BV BOUND     c31     
 BV BOUND     c32     
 LI BOUND     c33       0
 BV BOUND     c34     
 LI BOUND     c35       0
 LI BOUND     c36       0
 BV BOUND     c37     
 LI BOUND     c38       0
 BV BOUND     c39     
 BV BOUND     c40     
 LI BOUND     c41       0
 LI BOUND     c42       0
 BV BOUND     c43     
 LI BOUND     c44       0
 LI BOUND     c45       0
 BV BOUND     c46     
 LI BOUND     c47       0
 LI BOUND     c48       0
 BV BOUND     c49     
 LI BOUND     c50       0
 LI BOUND     c51       0
 LI BOUND     c52       0
 BV BOUND     c53     
 LI BOUND     c54       0
 LI BOUND     c55       0
 BV BOUND     c56     
 LI BOUND     c57       0
 BV BOUND     c58     
 BV BOUND     c59     
 LI BOUND     c60       0
 BV BOUND     c61     
 LI BOUND     c62       0
 LI BOUND     c63       0
 BV BOUND     c64     
 LI BOUND     c65       0
 LI BOUND     c66       0
 BV BOUND     c67     
 LI BOUND     c68       0
 BV BOUND     c69     
 LI BOUND     c70       0
 LI BOUND     c71       0
 BV BOUND     c72     
 LI BOUND     c73       0
 BV BOUND     c74     
 BV BOUND     c75     
 BV BOUND     c76     
 LI BOUND     c77       0
 BV BOUND     c78     
 LI BOUND     c79       0
 BV BOUND     c80     
 BV BOUND     c81     
 LI BOUND     c82       0
 LI BOUND     c83       0
 LI BOUND     c84       0
 BV BOUND     c85     
 LI BOUND     c86       0
 LI BOUND     c87       0
 LI BOUND     c88       0
 LI BOUND     c89       0
 LI BOUND     c90       0
 LI BOUND     c91       0
 BV BOUND     c92     
 LI BOUND     c93       0
 BV BOUND     c94     
 BV BOUND     c95     
 LI BOUND     c96       0
 LI BOUND     c97       0
 BV BOUND     c98     
 LI BOUND     c99       0
 LI BOUND     c100      0
 LI BOUND     c101      0
 LI BOUND     c102      0
 BV BOUND     c103    
 LI BOUND     c104      0
 LI BOUND     c105      0
 BV BOUND     c106    
 LI BOUND     c107      0
 BV BOUND     c108    
 BV BOUND     c109    
 BV BOUND     c110    
 BV BOUND     c111    
 LI BOUND     c112      0
 BV BOUND     c113    
 BV BOUND     c114    
 LI BOUND     c115      0
 BV BOUND     c116    
 BV BOUND     c117    
 BV BOUND     c118    
 BV BOUND     c119    
 BV BOUND     c120    
 BV BOUND     c121    
 LI BOUND     c122      0
 BV BOUND     c123    
 BV BOUND     c124    
 LI BOUND     c125      0
 BV BOUND     c126    
 LI BOUND     c127      0
ENDATA
