NAME        
ROWS
 N  Obj     
 L  r0      
 L  r1      
 L  r2      
 L  r3      
 L  r4      
 L  r5      
 L  r6      
 L  r7      
 L  r8      
 L  r9      
 L  r10     
 L  r11     
 L  r12     
 L  r13     
 L  r14     
 L  r15     
 L  r16     
 L  r17     
 L  r18     
 L  r19     
 L  r20     
 L  r21     
 L  r22     
 L  r23     
 L  r24     
 L  r25     
 L  r26     
 L  r27     
 L  r28     
 L  r29     
 L  r30     
 L  r31     
 L  r32     
 L  r33     
 L  r34     
 L  r35     
 L  r36     
 L  r37     
 L  r38     
 L  r39     
 L  r40     
 L  r41     
 L  r42     
 L  r43     
 L  r44     
 L  r45     
 L  r46     
 L  r47     
 L  r48     
 L  r49     
 L  r50     
 L  r51     
 L  r52     
 L  r53     
 L  r54     
 L  r55     
 L  r56     
 L  r57     
 L  r58     
 L  r59     
 L  r60     
 L  r61     
 L  r62     
 L  r63     
 L  r64     
 L  r65     
 L  r66     
 L  r67     
 L  r68     
 L  r69     
 L  r70     
 L  r71     
 L  r72     
 L  r73     
 L  r74     
 L  r75     
 L  r76     
 L  r77     
 L  r78     
 L  r79     
 L  r80     
 L  r81     
 L  r82     
 L  r83     
 L  r84     
 L  r85     
 L  r86     
 L  r87     
 L  r88     
 L  r89     
 L  r90     
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    c0        r0        -1
    c0        r14       -1
    c0        r15       -20
    c0        r75       1
    c1        r0        1
    c1        r1        -1
    c1        r11       -1
    c1        r16       -20
    c1        r76       1
    c2        r1        1
    c2        r2        -1
    c2        r17       -20
    c2        r77       1
    c3        r2        1
    c3        r3        -1
    c3        r8        -1
    c3        r18       -20
    c3        r78       1
    c4        r3        1
    c4        r4        -1
    c4        r5        -1
    c4        r19       -20
    c4        r79       1
    c5        r4        1
    c5        r20       -20
    c5        r80       1
    c6        r5        1
    c6        r6        -1
    c6        r21       -20
    c6        r81       1
    c7        r6        1
    c7        r7        -1
    c7        r82       1
    c8        r7        1
    c8        r22       -20
    c8        r83       1
    c9        r8        1
    c9        r9        -1
    c9        r23       -20
    c9        r84       1
    c10       r9        1
    c10       r10       -1
    c10       r24       -20
    c10       r85       1
    c11       r10       1
    c11       r25       -20
    c11       r86       1
    c12       r11       1
    c12       r12       -1
    c12       r26       -20
    c12       r87       1
    c13       r12       1
    c13       r13       -1
    c13       r27       -20
    c13       r88       1
    c14       r13       1
    c14       r89       1
    c15       r14       1
    c15       r28       -20
    c15       r90       1
    c16       Obj       43000
    c16       r15       1
    c16       r29       -672
    c17       Obj       43000
    c17       r16       1
    c17       r30       -672
    c18       Obj       43000
    c18       r17       1
    c18       r31       -672
    c19       Obj       43000
    c19       r18       1
    c19       r32       -672
    c20       Obj       43000
    c20       r19       1
    c20       r33       -672
    c21       Obj       43000
    c21       r20       1
    c21       r34       -672
    c22       Obj       43000
    c22       r21       1
    c22       r35       -672
    c23       Obj       43000
    c23       r22       1
    c23       r37       -672
    c24       Obj       43000
    c24       r23       1
    c24       r38       -672
    c25       Obj       43000
    c25       r24       1
    c25       r39       -672
    c26       Obj       43000
    c26       r25       1
    c26       r40       -672
    c27       Obj       43000
    c27       r26       1
    c27       r41       -672
    c28       Obj       43000
    c28       r27       1
    c28       r42       -672
    c29       Obj       43000
    c29       r28       1
    c29       r44       -672
    c30       Obj       58000
    c30       r15       1
    c30       r29       -1344
    c31       Obj       58000
    c31       r16       1
    c31       r30       -1344
    c32       Obj       58000
    c32       r17       1
    c32       r31       -1344
    c33       Obj       59000
    c33       r18       1
    c33       r32       -1344
    c34       Obj       59000
    c34       r19       1
    c34       r33       -1344
    c35       Obj       59000
    c35       r20       1
    c35       r34       -1344
    c36       Obj       59000
    c36       r21       1
    c36       r35       -1344
    c37       Obj       60000
    c37       r22       1
    c37       r37       -1344
    c38       Obj       59000
    c38       r23       1
    c38       r38       -1344
    c39       Obj       59000
    c39       r24       1
    c39       r39       -1344
    c40       Obj       59000
    c40       r25       1
    c40       r40       -1344
    c41       Obj       58000
    c41       r26       1
    c41       r41       -1344
    c42       Obj       58000
    c42       r27       1
    c42       r42       -1344
    c43       Obj       58000
    c43       r28       1
    c43       r44       -1344
    c44       Obj       10000
    c44       r45       -24
    c45       Obj       10000
    c45       r46       -24
    c46       Obj       10000
    c46       r47       -24
    c47       Obj       10000
    c47       r48       -24
    c48       Obj       10000
    c48       r49       -24
    c49       Obj       10000
    c49       r50       -24
    c50       Obj       10000
    c50       r51       -24
    c51       Obj       10000
    c51       r52       -24
    c52       Obj       10000
    c52       r53       -24
    c53       Obj       10000
    c53       r54       -24
    c54       Obj       10000
    c54       r55       -24
    c55       Obj       10000
    c55       r56       -24
    c56       Obj       10000
    c56       r57       -24
    c57       Obj       10000
    c57       r58       -24
    MARK0001  'MARKER'                 'INTEND'
    c58       Obj       24.564499999999999
    c58       r59       -1
    c58       r75       0.00083299999999999997
    c59       Obj       20.3962
    c59       r59       1
    c59       r60       -1
    c59       r76       0.00083299999999999997
    c60       Obj       14.1693
    c60       r60       1
    c60       r61       -1
    c60       r77       0.00083299999999999997
    c61       Obj       50.2605
    c61       r61       1
    c61       r62       -1
    c61       r78       0.00083299999999999997
    c62       Obj       58.042299999999997
    c62       r62       1
    c62       r63       -1
    c62       r79       0.00083299999999999997
    c63       Obj       36.609499999999997
    c63       r63       1
    c63       r64       -1
    c63       r80       0.00083299999999999997
    c64       Obj       39.201000000000001
    c64       r63       1
    c64       r65       -1
    c64       r81       0.00083299999999999997
    c65       Obj       48.033999999999999
    c65       r65       1
    c65       r66       -1
    c65       r82       0.00083299999999999997
    c66       Obj       29.433599999999998
    c66       r66       1
    c66       r67       -1
    c66       r83       0.00083299999999999997
    c67       Obj       36.0182
    c67       r62       1
    c67       r68       -1
    c67       r84       0.00083299999999999997
    c68       Obj       18.724499999999999
    c68       r68       1
    c68       r69       -1
    c68       r85       0.00083299999999999997
    c69       Obj       30.3169
    c69       r69       1
    c69       r70       -1
    c69       r86       0.00083299999999999997
    c70       Obj       5.3654999999999999
    c70       r60       1
    c70       r71       -1
    c70       r87       0.00083299999999999997
    c71       Obj       25.550000000000001
    c71       r71       1
    c71       r72       -1
    c71       r88       0.00083299999999999997
    c72       Obj       20.797699999999999
    c72       r72       1
    c72       r73       -1
    c72       r89       0.00083299999999999997
    c73       Obj       1.825
    c73       r59       1
    c73       r74       -1
    c73       r90       0.00083299999999999997
    c74       Obj       2.4564499999999998
    c74       r29       -1
    c74       r75       8.2999999999999998e-05
    c75       Obj       2.0396200000000002
    c75       r29       1
    c75       r30       -1
    c75       r76       8.2999999999999998e-05
    c76       Obj       1.41693
    c76       r30       1
    c76       r31       -1
    c76       r77       8.2999999999999998e-05
    c77       Obj       5.0260499999999997
    c77       r31       1
    c77       r32       -1
    c77       r78       8.2999999999999998e-05
    c78       Obj       5.8042299999999996
    c78       r32       1
    c78       r33       -1
    c78       r79       8.2999999999999998e-05
    c79       Obj       3.6609500000000001
    c79       r33       1
    c79       r34       -1
    c79       r80       8.2999999999999998e-05
    c80       Obj       3.9201000000000001
    c80       r33       1
    c80       r35       -1
    c80       r81       8.2999999999999998e-05
    c81       Obj       4.8033999999999999
    c81       r35       1
    c81       r36       -1
    c81       r82       8.2999999999999998e-05
    c82       Obj       2.9433600000000002
    c82       r36       1
    c82       r37       -1
    c82       r83       8.2999999999999998e-05
    c83       Obj       3.60182
    c83       r32       1
    c83       r38       -1
    c83       r84       8.2999999999999998e-05
    c84       Obj       1.8724499999999999
    c84       r38       1
    c84       r39       -1
    c84       r85       8.2999999999999998e-05
    c85       Obj       3.0316900000000002
    c85       r39       1
    c85       r40       -1
    c85       r86       8.2999999999999998e-05
    c86       Obj       0.53654999999999997
    c86       r30       1
    c86       r41       -1
    c86       r87       8.2999999999999998e-05
    c87       Obj       2.5550000000000002
    c87       r41       1
    c87       r42       -1
    c87       r88       8.2999999999999998e-05
    c88       Obj       2.0797699999999999
    c88       r42       1
    c88       r43       -1
    c88       r89       8.2999999999999998e-05
    c89       Obj       0.1825
    c89       r29       1
    c89       r44       -1
    c89       r90       8.2999999999999998e-05
    c90       r29       1
    c90       r45       1
    c90       r59       -1
    c91       r30       1
    c91       r46       1
    c91       r60       -1
    c92       r31       1
    c92       r47       1
    c92       r61       -1
    c93       r32       1
    c93       r48       1
    c93       r62       -1
    c94       r33       1
    c94       r49       1
    c94       r63       -1
    c95       r34       1
    c95       r50       1
    c95       r64       -1
    c96       r35       1
    c96       r51       1
    c96       r65       -1
    c97       r37       1
    c97       r52       1
    c97       r67       -1
    c98       r38       1
    c98       r53       1
    c98       r68       -1
    c99       r39       1
    c99       r54       1
    c99       r69       -1
    c100      r40       1
    c100      r55       1
    c100      r70       -1
    c101      r41       1
    c101      r56       1
    c101      r71       -1
    c102      r42       1
    c102      r57       1
    c102      r72       -1
    c103      r44       1
    c103      r58       1
    c103      r74       -1
RHS
    RHS_V     r59       -800
    RHS_V     r60       -3100
    RHS_V     r61       -50
    RHS_V     r62       -40
    RHS_V     r63       -900
    RHS_V     r64       -40
    RHS_V     r65       -7150
    RHS_V     r66       -4800
    RHS_V     r67       -3000
    RHS_V     r68       -250
    RHS_V     r69       -400
    RHS_V     r70       -1000
    RHS_V     r71       -4000
    RHS_V     r72       -90
    RHS_V     r73       -700
    RHS_V     r74       -24
    RHS_V     r75       8
    RHS_V     r76       8
    RHS_V     r77       8
    RHS_V     r78       8
    RHS_V     r79       1
    RHS_V     r80       1
    RHS_V     r81       13
    RHS_V     r82       13
    RHS_V     r83       1
    RHS_V     r84       1
    RHS_V     r85       13
    RHS_V     r86       13
    RHS_V     r87       8
    RHS_V     r88       8
    RHS_V     r89       2
    RHS_V     r90       2
BOUNDS
 BV BOUND     c0      
 BV BOUND     c1      
 BV BOUND     c2      
 BV BOUND     c3      
 BV BOUND     c4      
 BV BOUND     c5      
 BV BOUND     c6      
 BV BOUND     c7      
 BV BOUND     c8      
 BV BOUND     c9      
 BV BOUND     c10     
 BV BOUND     c11     
 BV BOUND     c12     
 BV BOUND     c13     
 BV BOUND     c14     
 BV BOUND     c15     
 BV BOUND     c16     
 BV BOUND     c17     
 BV BOUND     c18     
 BV BOUND     c19     
 BV BOUND     c20     
 BV BOUND     c21     
 BV BOUND     c22     
 BV BOUND     c23     
 BV BOUND     c24     
 BV BOUND     c25     
 BV BOUND     c26     
 BV BOUND     c27     
 BV BOUND     c28     
 BV BOUND     c29     
 UI BOUND     c30       10000
 UI BOUND     c31       10000
 UI BOUND     c32       10000
 UI BOUND     c33       10000
 UI BOUND     c34       10000
 UI BOUND     c35       10000
 UI BOUND     c36       10000
 UI BOUND     c37       10000
 UI BOUND     c38       1000
 UI BOUND     c39       1000
 UI BOUND     c40       1000
 UI BOUND     c41       1000
 UI BOUND     c42       1000
 UI BOUND     c43       1000
 UI BOUND     c44       1000
 UI BOUND     c45       1000
 UI BOUND     c46       1000
 UI BOUND     c47       1000
 UI BOUND     c48       1000
 UI BOUND     c49       1000
 UI BOUND     c50       1000
 UI BOUND     c51       1000
 UI BOUND     c52       100
 UI BOUND     c53       100
 UI BOUND     c54       100
 UI BOUND     c55       100
 UI BOUND     c56       100
 UI BOUND     c57       100
ENDATA
