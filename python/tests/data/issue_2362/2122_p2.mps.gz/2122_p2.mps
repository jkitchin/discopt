NAME        
OBJSENSE
  MAX
ROWS
 N  Obj     
 L  con909  
 L  con215  
 E  con313  
 E  con108  
 L  con653  
 E  con728  
 L  con443  
 L  con915  
 L  con829  
 E  con564  
 L  con30   
 L  con390  
 E  con128  
 L  con239  
 E  con107  
 L  con818  
 L  con622  
 E  con736  
 L  con857  
 L  con544  
 L  con53   
 L  con621  
 L  con879  
 L  con864  
 E  con977  
 L  con48   
 L  con94   
 L  con904  
 L  con613  
 E  con964  
 L  con507  
 L  con228  
 L  con464  
 L  con791  
 L  con799  
 E  con20   
 L  con703  
 E  con941  
 L  con387  
 L  con840  
 L  con541  
 E  con274  
 E  con295  
 E  con139  
 L  con665  
 L  con73   
 E  con487  
 L  con994  
 L  con628  
 L  con369  
 E  con962  
 L  con237  
 L  con223  
 L  con454  
 E  con21   
 L  con807  
 L  con373  
 E  con757  
 E  con122  
 L  con97   
 L  con78   
 E  con296  
 L  con998  
 L  con64   
 L  con462  
 E  con325  
 E  con301  
 E  con258  
 L  con849  
 E  con939  
 L  con871  
 E  con601  
 L  con883  
 L  con655  
 L  con1003 
 E  con748  
 E  con599  
 L  con1040 
 L  con523  
 L  con828  
 L  con55   
 E  con584  
 E  con334  
 E  con114  
 L  con385  
 L  con445  
 E  con280  
 L  con401  
 E  con337  
 E  con9    
 L  con1025 
 E  con717  
 L  con664  
 L  con772  
 L  con233  
 E  con330  
 L  con648  
 L  con706  
 E  con605  
 E  con164  
 E  con489  
 L  con926  
 L  con378  
 L  con104  
 L  con814  
 E  con731  
 E  con289  
 E  con152  
 E  con974  
 L  con528  
 L  con891  
 L  con452  
 L  con1055 
 E  con1    
 E  con306  
 E  con305  
 L  con548  
 L  con638  
 L  con397  
 E  con587  
 L  con651  
 L  con815  
 L  con1048 
 E  con24   
 L  con903  
 L  con530  
 E  con759  
 L  con437  
 L  con363  
 L  con365  
 E  con279  
 L  con553  
 L  con505  
 L  con200  
 E  con967  
 L  con992  
 E  con953  
 E  con135  
 L  con1060 
 E  con119  
 L  con402  
 E  con479  
 L  con375  
 E  con739  
 L  con709  
 L  con893  
 E  con719  
 L  con614  
 L  con687  
 E  con8    
 E  con156  
 L  con920  
 L  con623  
 E  con283  
 E  con115  
 L  con99   
 L  con806  
 E  con559  
 E  con955  
 L  con710  
 E  con588  
 E  con277  
 E  con353  
 L  con859  
 E  con338  
 L  con1010 
 L  con617  
 E  con946  
 L  con658  
 L  con447  
 E  con268  
 L  con88   
 L  con812  
 L  con793  
 L  con1013 
 L  con57   
 L  con1032 
 L  con830  
 L  con1046 
 E  con592  
 E  con727  
 L  con711  
 L  con625  
 L  con515  
 L  con826  
 L  con647  
 L  con821  
 L  con232  
 E  con354  
 E  con5    
 L  con901  
 E  con260  
 L  con235  
 L  con418  
 L  con667  
 L  con1006 
 L  con629  
 E  con105  
 E  con254  
 E  con150  
 L  con539  
 L  con853  
 L  con1022 
 E  con760  
 E  con166  
 L  con75   
 E  con572  
 L  con688  
 E  con145  
 L  con434  
 L  con862  
 L  con652  
 E  con595  
 L  con1029 
 E  con113  
 L  con1005 
 L  con549  
 L  con451  
 E  con149  
 E  con265  
 L  con681  
 L  con785  
 L  con837  
 L  con700  
 L  con666  
 L  con220  
 L  con467  
 L  con776  
 L  con876  
 L  con388  
 L  con67   
 L  con867  
 L  con1020 
 L  con455  
 E  con483  
 E  con586  
 L  con1030 
 L  con79   
 L  con160  
 E  con319  
 E  con302  
 E  con155  
 E  con737  
 L  con689  
 L  con855  
 E  con264  
 L  con1000 
 E  con488  
 E  con480  
 E  con303  
 E  con299  
 L  con993  
 E  con250  
 L  con1039 
 L  con683  
 E  con557  
 E  con186  
 L  con1031 
 E  con120  
 L  con881  
 E  con154  
 E  con331  
 L  con529  
 L  con202  
 L  con69   
 L  con469  
 L  con440  
 L  con773  
 E  con936  
 E  con718  
 L  con870  
 L  con657  
 E  con151  
 E  con754  
 E  con561  
 E  con606  
 E  con143  
 L  con198  
 L  con552  
 L  con398  
 E  con982  
 L  con366  
 E  con362  
 L  con693  
 E  con12   
 L  con411  
 E  con165  
 L  con618  
 L  con863  
 E  con343  
 L  con218  
 L  con690  
 E  con753  
 E  con318  
 L  con197  
 E  con293  
 L  con892  
 L  con449  
 L  con457  
 E  con127  
 E  con137  
 E  con562  
 E  con602  
 E  con744  
 L  con81   
 E  con158  
 L  con1015 
 L  con212  
 E  con177  
 E  con286  
 L  con403  
 E  con956  
 L  con887  
 L  con230  
 L  con381  
 L  con897  
 E  con766  
 L  con46   
 E  con940  
 E  con312  
 L  con91   
 L  con775  
 E  con311  
 L  con684  
 L  con661  
 L  con56   
 E  con262  
 E  con329  
 L  con525  
 E  con352  
 L  con456  
 L  con865  
 E  con355  
 L  con671  
 L  con872  
 L  con39   
 E  con958  
 L  con637  
 L  con1043 
 E  con276  
 L  con225  
 L  con707  
 L  con620  
 L  con1008 
 E  con124  
 L  con93   
 L  con803  
 E  con162  
 L  con34   
 L  con400  
 L  con394  
 L  con911  
 E  con298  
 L  con989  
 L  con847  
 L  con810  
 L  con712  
 L  con71   
 L  con784  
 E  con763  
 L  con636  
 E  con126  
 E  con972  
 L  con816  
 L  con986  
 L  con504  
 L  con1054 
 L  con1035 
 E  con740  
 L  con1021 
 L  con643  
 L  con395  
 L  con213  
 E  con948  
 L  con902  
 E  con938  
 L  con49   
 E  con146  
 L  con842  
 L  con33   
 L  con217  
 L  con428  
 L  con1059 
 E  con758  
 L  con696  
 L  con691  
 L  con189  
 L  con442  
 L  con367  
 L  con896  
 L  con660  
 L  con851  
 E  con944  
 E  con140  
 L  con372  
 E  con594  
 E  con328  
 L  con80   
 E  con575  
 L  con632  
 L  con72   
 E  con142  
 E  con580  
 L  con646  
 E  con980  
 L  con836  
 L  con412  
 L  con540  
 L  con831  
 E  con341  
 L  con238  
 L  con875  
 L  con85   
 L  con422  
 L  con848  
 E  con943  
 E  con475  
 L  con850  
 E  con148  
 E  con4    
 E  con316  
 L  con424  
 E  con252  
 L  con928  
 L  con894  
 E  con581  
 E  con11   
 E  con732  
 L  con32   
 L  con917  
 L  con513  
 L  con227  
 E  con951  
 L  con626  
 L  con417  
 L  con77   
 L  con51   
 E  con723  
 E  con248  
 E  con567  
 L  con377  
 L  con889  
 L  con808  
 L  con663  
 E  con975  
 E  con716  
 E  con596  
 L  con1056 
 E  con583  
 E  con270  
 L  con692  
 L  con423  
 L  con536  
 E  con973  
 L  con506  
 L  con25   
 E  con952  
 E  con339  
 L  con792  
 L  con242  
 E  con979  
 E  con350  
 L  con713  
 E  con472  
 L  con905  
 E  con563  
 L  con694  
 E  con361  
 E  con125  
 L  con459  
 E  con182  
 L  con698  
 L  con389  
 E  con603  
 E  con133  
 E  con485  
 E  con141  
 E  con181  
 E  con346  
 L  con210  
 E  con267  
 L  con234  
 L  con686  
 E  con764  
 L  con439  
 E  con746  
 L  con819  
 E  con356  
 L  con1016 
 L  con501  
 E  con167  
 E  con163  
 E  con15   
 L  con844  
 E  con271  
 L  con207  
 L  con783  
 L  con201  
 E  con168  
 L  con29   
 L  con432  
 L  con431  
 E  con945  
 L  con1038 
 L  con642  
 E  con722  
 L  con852  
 E  con183  
 L  con899  
 E  con959  
 E  con755  
 E  con251  
 E  con495  
 E  con138  
 E  con593  
 L  con874  
 E  con321  
 L  con809  
 L  con450  
 E  con724  
 E  con484  
 L  con429  
 L  con672  
 L  con860  
 E  con130  
 L  con1058 
 L  con787  
 L  con438  
 L  con545  
 E  con175  
 E  con600  
 E  con187  
 L  con396  
 L  con82   
 L  con236  
 E  con19   
 L  con27   
 E  con335  
 L  con906  
 E  con761  
 L  con913  
 L  con393  
 L  con216  
 L  con1052 
 E  con756  
 L  con384  
 L  con190  
 L  con66   
 L  con371  
 L  con796  
 L  con204  
 L  con416  
 L  con1018 
 L  con426  
 L  con54   
 L  con410  
 E  con6    
 L  con834  
 E  con491  
 E  con607  
 L  con1044 
 L  con649  
 E  con591  
 L  con1042 
 L  con708  
 L  con1034 
 L  con631  
 E  con494  
 L  con788  
 E  con273  
 E  con565  
 E  con243  
 L  con26   
 L  con219  
 L  con774  
 E  con604  
 L  con930  
 L  con524  
 E  con555  
 L  con425  
 L  con674  
 L  con500  
 E  con569  
 E  con7    
 L  con427  
 L  con805  
 L  con882  
 E  con304  
 L  con644  
 E  con307  
 L  con542  
 E  con937  
 L  con376  
 L  con222  
 E  con493  
 E  con742  
 E  con566  
 L  con697  
 L  con991  
 E  con769  
 L  con996  
 E  con729  
 E  con172  
 E  con934  
 L  con205  
 E  con968  
 L  con800  
 E  con474  
 L  con669  
 E  con178  
 E  con246  
 L  con211  
 E  con291  
 L  con997  
 E  con118  
 E  con144  
 L  con241  
 E  con309  
 E  con556  
 L  con682  
 L  con795  
 L  con984  
 L  con704  
 E  con482  
 L  con503  
 L  con611  
 L  con502  
 E  con294  
 L  con781  
 L  con195  
 L  con68   
 L  con87   
 L  con383  
 E  con147  
 L  con419  
 E  con725  
 L  con409  
 L  con677  
 E  con571  
 L  con1023 
 E  con249  
 L  con878  
 L  con90   
 L  con404  
 L  con98   
 E  con342  
 L  con813  
 E  con971  
 L  con877  
 L  con919  
 E  con161  
 E  con109  
 L  con392  
 L  con1027 
 L  con408  
 L  con102  
 L  con433  
 L  con929  
 E  con965  
 L  con370  
 L  con827  
 L  con519  
 L  con675  
 L  con1036 
 L  con537  
 E  con478  
 E  con573  
 L  con988  
 E  con106  
 L  con386  
 E  con574  
 L  con1011 
 L  con927  
 L  con835  
 L  con801  
 L  con1057 
 E  con184  
 L  con193  
 L  con526  
 L  con908  
 E  con136  
 E  con13   
 L  con43   
 E  con486  
 E  con360  
 E  con310  
 L  con670  
 L  con531  
 L  con508  
 L  con499  
 E  con110  
 E  con3    
 E  con751  
 E  con344  
 L  con885  
 E  con282  
 L  con159  
 L  con1007 
 L  con858  
 L  con453  
 L  con822  
 E  con750  
 L  con924  
 E  con589  
 L  con28   
 E  con257  
 E  con726  
 E  con272  
 L  con538  
 E  con121  
 L  con634  
 L  con907  
 L  con441  
 L  con639  
 L  con705  
 L  con83   
 L  con817  
 E  con570  
 L  con624  
 E  con735  
 E  con351  
 L  con405  
 E  con23   
 E  con112  
 L  con923  
 L  con214  
 L  con635  
 E  con954  
 L  con843  
 L  con52   
 E  con492  
 E  con179  
 L  con778  
 L  con987  
 E  con582  
 L  con627  
 E  con326  
 L  con463  
 L  con196  
 E  con255  
 E  con281  
 E  con323  
 L  con999  
 E  con324  
 L  con695  
 L  con780  
 E  con960  
 L  con76   
 E  con131  
 E  con720  
 L  con714  
 L  con36   
 L  con391  
 L  con41   
 L  con364  
 E  con10   
 E  con471  
 L  con797  
 L  con413  
 L  con517  
 E  con244  
 E  con315  
 L  con685  
 E  con733  
 L  con610  
 L  con42   
 E  con169  
 L  con895  
 L  con414  
 L  con1001 
 E  con129  
 L  con1002 
 E  con978  
 L  con866  
 L  con679  
 L  con203  
 E  con176  
 L  con466  
 L  con458  
 L  con884  
 L  con62   
 E  con578  
 L  con811  
 L  con37   
 L  con985  
 L  con615  
 L  con518  
 L  con546  
 L  con60   
 E  con327  
 E  con171  
 E  con932  
 L  con231  
 L  con510  
 L  con910  
 L  con407  
 L  con925  
 L  con820  
 E  con558  
 L  con880  
 L  con430  
 L  con861  
 L  con640  
 L  con890  
 E  con180  
 E  con245  
 E  con278  
 L  con551  
 E  con247  
 E  con738  
 L  con543  
 L  con470  
 L  con192  
 L  con782  
 L  con1009 
 L  con199  
 L  con1053 
 L  con789  
 L  con790  
 E  con560  
 E  con16   
 L  con96   
 L  con535  
 E  con598  
 E  con473  
 L  con678  
 E  con721  
 L  con898  
 L  con804  
 L  con40   
 L  con916  
 L  con512  
 E  con18   
 E  con966  
 L  con779  
 E  con983  
 E  con481  
 L  con1047 
 L  con668  
 E  con490  
 E  con741  
 L  con699  
 E  con292  
 L  con436  
 L  con191  
 L  con1051 
 E  con568  
 L  con444  
 E  con111  
 L  con379  
 L  con1033 
 E  con174  
 E  con117  
 E  con333  
 L  con380  
 L  con771  
 L  con406  
 E  con942  
 E  con185  
 L  con521  
 L  con873  
 L  con70   
 L  con869  
 E  con970  
 L  con856  
 L  con838  
 L  con1019 
 L  con435  
 L  con101  
 L  con368  
 L  con659  
 E  con963  
 E  con259  
 E  con266  
 L  con912  
 E  con284  
 L  con802  
 L  con74   
 E  con579  
 E  con477  
 E  con170  
 E  con359  
 L  con846  
 L  con656  
 E  con261  
 L  con527  
 E  con747  
 E  con173  
 L  con645  
 E  con332  
 L  con35   
 L  con633  
 L  con654  
 L  con465  
 L  con92   
 E  con768  
 L  con1024 
 L  con399  
 L  con900  
 E  con17   
 L  con1004 
 L  con1012 
 E  con14   
 L  con95   
 L  con382  
 E  con116  
 E  con123  
 E  con300  
 E  con745  
 L  con224  
 E  con957  
 E  con349  
 L  con825  
 E  con308  
 E  con317  
 L  con550  
 E  con577  
 L  con845  
 L  con84   
 E  con297  
 L  con61   
 L  con608  
 L  con58   
 L  con921  
 E  con950  
 E  con749  
 L  con839  
 L  con888  
 E  con933  
 L  con609  
 L  con498  
 E  con743  
 L  con240  
 L  con514  
 L  con931  
 L  con374  
 L  con630  
 L  con922  
 E  con2    
 L  con520  
 L  con823  
 L  con1037 
 E  con765  
 L  con914  
 E  con132  
 L  con794  
 L  con221  
 E  con597  
 L  con226  
 L  con31   
 E  con285  
 E  con767  
 L  con619  
 L  con832  
 E  con322  
 L  con1028 
 L  con886  
 L  con522  
 E  con134  
 L  con854  
 L  con448  
 L  con100  
 E  con762  
 E  con730  
 L  con45   
 L  con86   
 L  con532  
 E  con496  
 L  con1026 
 L  con461  
 L  con868  
 L  con511  
 L  con50   
 E  con752  
 E  con275  
 L  con446  
 E  con961  
 L  con918  
 L  con1049 
 L  con995  
 E  con22   
 E  con157  
 L  con990  
 E  con358  
 E  con949  
 E  con320  
 L  con1050 
 L  con206  
 L  con63   
 E  con253  
 L  con777  
 L  con89   
 L  con1041 
 E  con576  
 E  con263  
 L  con676  
 E  con947  
 L  con547  
 L  con798  
 E  con976  
 L  con509  
 L  con662  
 L  con468  
 E  con256  
 L  con534  
 E  con476  
 L  con650  
 L  con680  
 L  con702  
 E  con348  
 L  con1045 
 L  con103  
 E  con585  
 E  con314  
 L  con516  
 L  con833  
 E  con734  
 E  con336  
 L  con420  
 E  con188  
 E  con269  
 L  con673  
 L  con1014 
 E  con290  
 E  con935  
 L  con533  
 E  con347  
 L  con415  
 E  con554  
 L  con824  
 E  con153  
 L  con616  
 L  con44   
 L  con1017 
 L  con641  
 L  con701  
 E  con969  
 L  con59   
 L  con715  
 L  con209  
 L  con65   
 L  con208  
 L  con421  
 L  con47   
 E  con497  
 E  con590  
 E  con345  
 E  con981  
 L  con770  
 L  con460  
 L  con229  
 L  con786  
 E  con340  
 L  con38   
 E  con288  
 E  con287  
 L  con612  
 E  con357  
 L  con841  
 L  con194  
COLUMNS
    x29       Obj       -0.072609999999999994
    x29       con788    1
    x29       con790    1
    x29       con749    1
    x131      Obj       -10
    x131      con550    -1
    MARK0000  'MARKER'                 'INTORG'
    x425      con230    29000
    x425      con229    -29000
    MARK0001  'MARKER'                 'INTEND'
    x718      con754    -1
    x718      con885    1
    x718      con886    1
    x718      con969    1
    MARK0002  'MARKER'                 'INTORG'
    x748      con771    17400
    x748      con770    -17400
    MARK0003  'MARKER'                 'INTEND'
    x607      con567    -1
    x607      con756    -1.002874
    MARK0004  'MARKER'                 'INTORG'
    x752      con776    -29000
    x752      con777    29000
    MARK0005  'MARKER'                 'INTEND'
    x200      con114    -1
    x200      con71     1
    x200      con10     0.0083333333333333297
    x706      con748    -1
    x706      con867    1
    x706      con963    1
    x706      con868    1
    MARK0006  'MARKER'                 'INTORG'
    x556      con449    -14501
    x556      con450    14501
    x773      con1046   1
    x773      con808    -29000
    MARK0007  'MARKER'                 'INTEND'
    x738      con915    1
    x738      con979    1
    x738      con764    -1
    x738      con916    1
    x137      Obj       -0.01
    x137      con200    1
    x137      con299    -1
    x137      con167    1
    x137      con985    1
    x137      con1012   1
    x653      con748    1.002874
    x653      con640    1
    x653      con721    -1
    x653      con673    1
    x347      con301    1
    x347      con169    -1
    x347      con203    1
    x347      con990    1
    x165      con108    -1
    x165      con160    1
    x165      con106    1
    x165      con28     1
    x165      con2      -0.5
    x165      con134    1
    x234      con151    1
    x234      con125    -1
    x234      con19     -0.5
    x234      con123    1
    x234      con45     1
    x493      con316    1
    x493      con478    1
    x100      Obj       -10
    x100      con519    -1
    x54       Obj       -0.00042330287999999997
    x54       con666    1
    x54       con718    1
    x54       con610    1
    x54       con745    -1.02294058333333
    MARK0008  'MARKER'                 'INTORG'
    x297      con102    12000
    x297      con101    -12000
    MARK0009  'MARKER'                 'INTEND'
    x475      con286    -1
    x475      con492    1
    x327      con363    1
    x327      con162    1
    x327      con417    1
    x327      con716    -1
    x327      con243    -0.90000000000000002
    MARK0010  'MARKER'                 'INTORG'
    x776      con812    -29000
    x776      con813    29000
    x788      con830    -29000
    x788      con831    29000
    MARK0011  'MARKER'                 'INTEND'
    x583      con487    1
    x583      con515    -1
    x583      con488    -1
    x583      con543    1
    x179      con5      0.0083333333333333297
    x179      con66     1
    x179      con111    1
    x184      con6      0.0083333333333333297
    x184      con110    -1
    x184      con63     1
    MARK0012  'MARKER'                 'INTORG'
    x560      con457    -14501
    x560      con458    14501
    x806      con857    -29000
    x806      con858    29000
    x853      con1059   1
    x853      con928    -29000
    MARK0013  'MARKER'                 'INTEND'
    x66       Obj       -0.00042330287999999997
    x66       con622    1
    x66       con757    -1.0296860000000001
    x66       con690    1
    x66       con730    1
    MARK0014  'MARKER'                 'INTORG'
    x755      con781    -29000
    x755      con1037   1
    MARK0015  'MARKER'                 'INTEND'
    x110      Obj       -10
    x110      con529    -1
    x520      con343    1
    x520      con478    1
    MARK0016  'MARKER'                 'INTORG'
    x307      con139    -1000
    x409      con198    29000
    x409      con197    -29000
    x838      con905    -29000
    x838      con906    29000
    MARK0017  'MARKER'                 'INTEND'
    x214      con120    -1
    x214      con146    1
    x214      con118    1
    x214      con40     1
    x214      con14     -0.5
    MARK0018  'MARKER'                 'INTORG'
    x316      con148    -1000
    MARK0019  'MARKER'                 'INTEND'
    x348      con724    -1
    x348      con371    1
    x348      con433    1
    x348      con259    -0.90000000000000002
    x348      con170    1
    x522      con480    1
    x522      con345    1
    x391      con462    1
    x391      con412    1
    x391      con984    1
    x391      con184    -1
    x391      con738    1
    x391      con288    1
    x628      con588    -1
    x628      con750    1.0296860000000001
    x126      Obj       -10
    x126      con545    -1
    MARK0020  'MARKER'                 'INTORG'
    x431      con242    29000
    x431      con241    -29000
    x551      con440    14501
    x551      con439    -14501
    x842      con911    -29000
    x842      con912    29000
    MARK0021  'MARKER'                 'INTEND'
    x61       Obj       -0.00042330287999999997
    x61       con617    1
    x61       con725    1
    x61       con752    -1.0296860000000001
    x61       con680    1
    x396      con387    1
    x396      con186    1
    x396      con740    -1
    x396      con291    -0.90000000000000002
    x396      con465    1
    x466      con277    1
    x466      con488    -1
    MARK0022  'MARKER'                 'INTORG'
    x810      con864    29000
    x810      con863    -29000
    MARK0023  'MARKER'                 'INTEND'
    x14       Obj       0.096710000000000004
    x14       con816    1
    x14       con758    -1
    x14       con817    1
    x133      Obj       -10
    x133      con552    -1
    x471      con282    -1
    x471      con490    1
    MARK0024  'MARKER'                 'INTORG'
    x784      con825    29000
    x784      con824    -29000
    MARK0025  'MARKER'                 'INTEND'
    x232      con122    -1
    x232      con87     1
    x232      con18     0.0083333333333333297
    x357      con727    -1
    x357      con265    -0.90000000000000002
    x357      con439    1
    x357      con173    1
    x357      con374    1
    x88       Obj       -10
    x88       con507    -1
    MARK0026  'MARKER'                 'INTORG'
    x265      con41     -12000
    x265      con42     7000
    MARK0027  'MARKER'                 'INTEND'
    x167      con108    1
    x167      con60     1
    x167      con2      0.0083333333333333297
    x84       Obj       -10
    x84       con503    -1
    x153      Obj       -0.01
    x153      con232    1
    x153      con183    1
    x153      con985    1
    x153      con1028   1
    x705      con936    1
    x705      con863    1
    x705      con865    1
    x705      con747    1
    MARK0028  'MARKER'                 'INTORG'
    x781      con820    -29000
    x781      con1050   1
    x753      con1036   1
    x753      con778    -29000
    x318      con150    -1000
    MARK0029  'MARKER'                 'INTEND'
    x117      Obj       -10
    x117      con536    -1
    x44       Obj       -0.075670000000000001
    x44       con764    1
    x44       con835    1
    x44       con833    1
    x122      Obj       -10
    x122      con541    -1
    x523      con346    1
    x523      con481    1
    x449      con479    1
    x449      con260    -1
    MARK0030  'MARKER'                 'INTORG'
    x405      con189    -17400
    x405      con190    17400
    MARK0031  'MARKER'                 'INTEND'
    x616      con765    -1.002874
    x616      con576    -1
    MARK0032  'MARKER'                 'INTORG'
    x271      con51     -12000
    x271      con52     8000
    MARK0033  'MARKER'                 'INTEND'
    x209      con303    -1
    x209      con13     1
    x152      Obj       -0.01
    x152      con230    1
    x152      con182    1
    x152      con1027   1
    x152      con985    1
    x508      con331    1
    x508      con493    1
    x474      con492    -1
    x474      con285    1
    MARK0034  'MARKER'                 'INTORG'
    x823      con883    -29000
    x823      con1044   1
    MARK0035  'MARKER'                 'INTEND'
    x366      con445    1
    x366      con377    1
    x366      con271    -0.90000000000000002
    x366      con176    1
    x366      con730    -1
    x119      Obj       -10
    x119      con538    -1
    x55       Obj       -0.00042330287999999997
    x55       con719    1
    x55       con746    -1.0296860000000001
    x55       con611    1
    x55       con668    1
    x63       Obj       -0.00042330287999999997
    x63       con727    1
    x63       con754    -1.0296860000000001
    x63       con684    1
    x63       con619    1
    MARK0036  'MARKER'                 'INTORG'
    x324      con156    -1000
    MARK0037  'MARKER'                 'INTEND'
    x478      con289    1
    x478      con494    -1
    x210      con119    -1
    x210      con145    1
    x210      con39     1
    x210      con13     -0.5
    x210      con117    1
    x194      con9      -0.5
    x194      con115    -1
    x194      con113    1
    x194      con141    1
    x194      con35     1
    x252      con97     1
    x252      con127    -1
    x252      con23     0.0083333333333333297
    MARK0038  'MARKER'                 'INTORG'
    x676      con665    14501
    x676      con664    -14501
    MARK0039  'MARKER'                 'INTEND'
    x79       Obj       -10
    x79       con498    -1
    MARK0040  'MARKER'                 'INTORG'
    x290      con88     8000
    x290      con87     -8000
    MARK0041  'MARKER'                 'INTEND'
    x388      con737    1
    x388      con411    1
    x388      con286    1
    x388      con183    -1
    x388      con984    1
    x388      con460    1
    MARK0042  'MARKER'                 'INTORG'
    x780      con818    -29000
    x780      con819    29000
    x415      con210    29000
    x415      con209    -29000
    MARK0043  'MARKER'                 'INTEND'
    x611      con760    -1.002874
    x611      con571    -1
    x661      con648    1
    x661      con689    1
    x661      con756    1.002874
    x661      con729    -1
    x45       Obj       -0.038809999999999997
    x45       con836    1
    x45       con838    1
    x45       con765    1
    x68       Obj       -0.00042330287999999997
    x68       con759    -1.0296860000000001
    x68       con732    1
    x68       con694    1
    x68       con624    1
    x170      con107    1
    x170      con135    1
    x170      con29     1
    x170      con109    -1
    x170      con3      -0.5
    x609      con758    -1.002874
    x609      con569    -1
    MARK0044  'MARKER'                 'INTORG'
    x553      con443    -14501
    x553      con444    14501
    MARK0045  'MARKER'                 'INTEND'
    x510      con495    1
    x510      con333    1
    x735      con951    1
    x735      con908    1
    x735      con910    1
    x735      con762    1
    x467      con488    1
    x467      con278    -1
    x115      Obj       -10
    x115      con534    -1
    x8        Obj       0.050849999999999999
    x8        con799    1
    x8        con752    -1
    x8        con798    1
    x328      con390    1
    x328      con418    1
    x328      con162    -1
    x328      con716    1
    x328      con984    1
    x328      con244    1
    x703      con862    1
    x703      con746    1
    x703      con860    1
    x703      con935    1
    x148      Obj       -0.01
    x148      con222    1
    x148      con178    1
    x148      con1023   1
    x148      con985    1
    x201      con302    -1
    x201      con11     1
    x588      con548    1
    x588      con493    -1
    x588      con492    1
    x588      con520    -1
    MARK0046  'MARKER'                 'INTORG'
    x777      con814    -29000
    x777      con1048   1
    MARK0047  'MARKER'                 'INTEND'
    x9        Obj       0.050849999999999999
    x9        con753    -1
    x9        con801    1
    x9        con802    1
    x439      con250    -1
    x439      con474    1
    x87       Obj       -10
    x87       con506    -1
    x492      con315    1
    x492      con477    1
    MARK0048  'MARKER'                 'INTORG'
    x848      con920    -29000
    x848      con921    29000
    x782      con821    -29000
    x782      con822    29000
    x558      con454    14501
    x558      con453    -14501
    x749      con772    -17400
    x749      con1034   1
    MARK0049  'MARKER'                 'INTEND'
    x138      Obj       -0.01
    x138      con1013   1
    x138      con202    1
    x138      con168    1
    x138      con985    1
    x138      con300    -1
    MARK0050  'MARKER'                 'INTORG'
    x774      con810    29000
    x774      con809    -29000
    x326      con158    -1000
    MARK0051  'MARKER'                 'INTEND'
    x157      Obj       -0.01
    x157      con1032   1
    x157      con187    1
    x157      con985    1
    x157      con240    1
    x233      con306    -1
    x233      con19     1
    x83       Obj       -10
    x83       con502    -1
    x32       Obj       -0.050849999999999999
    x32       con799    1
    x32       con797    1
    x32       con752    1
    MARK0052  'MARKER'                 'INTORG'
    x285      con78     12000
    x285      con77     -12000
    MARK0053  'MARKER'                 'INTEND'
    x256      con128    -1
    x256      con24     0.0083333333333333297
    x256      con99     1
    x606      con755    -1.002874
    x606      con566    -1
    x637      con759    1.0296860000000001
    x637      con597    -1
    MARK0054  'MARKER'                 'INTORG'
    x421      con222    29000
    x421      con221    -29000
    MARK0055  'MARKER'                 'INTEND'
    x151      Obj       -0.01
    x151      con228    1
    x151      con181    1
    x151      con985    1
    x151      con1026   1
    x398      con237    1
    x398      con186    -1
    x398      con1007   1
    x181      con299    1
    x181      con6      1
    MARK0056  'MARKER'                 'INTORG'
    x540      con418    14501
    x540      con417    -14501
    MARK0057  'MARKER'                 'INTEND'
    x501      con486    1
    x501      con324    1
    MARK0058  'MARKER'                 'INTORG'
    x847      con1056   1
    x847      con919    -29000
    MARK0059  'MARKER'                 'INTEND'
    x199      con76     1
    x199      con10     0.0083333333333333297
    x199      con116    1
    MARK0060  'MARKER'                 'INTORG'
    x311      con143    -1000
    MARK0061  'MARKER'                 'INTEND'
    x163      con53     1
    x163      con1      0.0083333333333333297
    x163      con105    -1
    MARK0062  'MARKER'                 'INTORG'
    x685      con683    14501
    x685      con682    -14501
    x428      con235    -29000
    x428      con236    29000
    x565      con467    -14501
    x565      con468    14501
    MARK0063  'MARKER'                 'INTEND'
    x459      con270    -1
    x459      con484    1
    x714      con879    1
    x714      con967    1
    x714      con880    1
    x714      con752    -1
    MARK0064  'MARKER'                 'INTORG'
    x837      con904    -29000
    x837      con1051   1
    MARK0065  'MARKER'                 'INTEND'
    x380      con225    1
    x380      con1001   1
    x380      con180    -1
    x356      con993    1
    x356      con304    1
    x356      con172    -1
    x356      con209    1
    x619      con579    -1
    x619      con768    -1.002874
    x724      con757    -1
    x724      con972    1
    x724      con894    1
    x724      con895    1
    x598      con558    -1
    x598      con747    -1.002874
    MARK0066  'MARKER'                 'INTORG'
    x283      con73     -12000
    x283      con74     12000
    x686      con684    -14501
    x686      con685    14501
    MARK0067  'MARKER'                 'INTEND'
    x360      con728    -1
    x360      con375    1
    x360      con267    -0.90000000000000002
    x360      con441    1
    x360      con174    1
    x343      con168    -1
    x343      con722    1
    x343      con396    1
    x343      con984    1
    x343      con430    1
    x343      con256    1
    MARK0068  'MARKER'                 'INTORG'
    x542      con422    14501
    x542      con421    -14501
    x794      con840    29000
    x794      con839    -29000
    MARK0069  'MARKER'                 'INTEND'
    x670      con657    1
    x670      con707    1
    x670      con738    -1
    x670      con765    1.002874
    x38       Obj       -0.096710000000000004
    x38       con815    1
    x38       con758    1
    x38       con817    1
    MARK0070  'MARKER'                 'INTORG'
    x427      con233    -29000
    x427      con234    29000
    MARK0071  'MARKER'                 'INTEND'
    x337      con166    -1
    x337      con394    1
    x337      con252    1
    x337      con426    1
    x337      con984    1
    x337      con720    1
    x743      con920    1
    x743      con955    1
    x743      con766    1
    x743      con922    1
    x339      con167    1
    x339      con427    1
    x339      con721    -1
    x339      con368    1
    x339      con253    -0.90000000000000002
    x223      con122    1
    x223      con88     1
    x223      con16     0.0083333333333333297
    MARK0072  'MARKER'                 'INTORG'
    x411      con202    29000
    x411      con201    -29000
    MARK0073  'MARKER'                 'INTEND'
    x4        Obj       0.059119999999999999
    x4        con748    -1
    x4        con787    1
    x4        con786    1
    x206      con12     -0.5
    x206      con118    -1
    x206      con144    1
    x206      con116    1
    x206      con38     1
    x334      con719    1
    x334      con250    1
    x334      con165    -1
    x334      con424    1
    x334      con393    1
    x334      con984    1
    x81       Obj       -10
    x81       con500    -1
    x193      con301    -1
    x193      con9      1
    x130      Obj       -10
    x130      con549    -1
    x70       Obj       -0.00042330287999999997
    x70       con626    1
    x70       con698    1
    x70       con761    -1.0296860000000001
    x70       con734    1
    MARK0074  'MARKER'                 'INTORG'
    x308      con140    -1000
    MARK0075  'MARKER'                 'INTEND'
    x527      con350    1
    x527      con485    1
    x734      con909    1
    x734      con977    1
    x734      con910    1
    x734      con762    -1
    MARK0076  'MARKER'                 'INTORG'
    x764      con795    29000
    x764      con794    -29000
    MARK0077  'MARKER'                 'INTEND'
    x132      Obj       -10
    x132      con551    -1
    x205      con302    1
    x205      con12     1
    x495      con480    1
    x495      con318    1
    MARK0078  'MARKER'                 'INTORG'
    x274      con55     -8000
    x274      con56     8000
    MARK0079  'MARKER'                 'INTEND'
    x512      con335    1
    x512      con497    1
    MARK0080  'MARKER'                 'INTORG'
    x851      con1058   1
    x851      con925    -29000
    x690      con693    14501
    x690      con692    -14501
    MARK0081  'MARKER'                 'INTEND'
    x572      con504    -1
    x572      con477    -1
    x572      con532    1
    x572      con476    1
    MARK0082  'MARKER'                 'INTORG'
    x808      con860    -29000
    x808      con861    29000
    MARK0083  'MARKER'                 'INTEND'
    x374      con178    -1
    x374      con999    1
    x374      con221    1
    x216      con79     1
    x216      con118    -1
    x216      con14     0.0083333333333333297
    MARK0084  'MARKER'                 'INTORG'
    x750      con773    -29000
    x750      con774    29000
    MARK0085  'MARKER'                 'INTEND'
    x191      con114    1
    x191      con8      0.0083333333333333297
    x191      con72     1
    x231      con124    1
    x231      con18     0.0083333333333333297
    x231      con92     1
    x371      con998    1
    x371      con177    -1
    x371      con219    1
    MARK0086  'MARKER'                 'INTORG'
    x284      con75     -7000
    x284      con76     7000
    x770      con803    -29000
    x770      con804    29000
    MARK0087  'MARKER'                 'INTEND'
    x516      con339    1
    x516      con474    1
    x538      con361    1
    x538      con496    1
    x658      con683    1
    x658      con753    1.002874
    x658      con726    -1
    x658      con645    1
    MARK0088  'MARKER'                 'INTORG'
    x288      con83     -7000
    x288      con84     7000
    MARK0089  'MARKER'                 'INTEND'
    x725      con757    1
    x725      con893    1
    x725      con946    1
    x725      con895    1
    MARK0090  'MARKER'                 'INTORG'
    x554      con445    -14501
    x554      con446    14501
    x775      con811    -29000
    x775      con1047   1
    MARK0091  'MARKER'                 'INTEND'
    x332      con164    -1
    x332      con718    1
    x332      con422    1
    x332      con248    1
    x332      con984    1
    x332      con392    1
    x723      con892    1
    x723      con945    1
    x723      con756    1
    x723      con890    1
    x569      con529    1
    x569      con501    -1
    x569      con474    -1
    x569      con473    1
    x470      con281    1
    x470      con490    -1
    MARK0092  'MARKER'                 'INTORG'
    x828      con891    29000
    x828      con890    -29000
    MARK0093  'MARKER'                 'INTEND'
    x35       Obj       -0.079469999999999999
    x35       con806    1
    x35       con808    1
    x35       con755    1
    x71       Obj       -0.00042330287999999997
    x71       con700    1
    x71       con735    1
    x71       con627    1
    x71       con762    -1.0296860000000001
    x462      con273    1
    x462      con486    -1
    x500      con485    1
    x500      con323    1
    x534      con492    1
    x534      con357    1
    x160      con107    -1
    x160      con1      -0.5
    x160      con105    1
    x160      con133    1
    x160      con27     1
    x160      con159    1
    x239      con20     0.0083333333333333297
    x239      con126    1
    x239      con96     1
    x353      con992    1
    x353      con303    1
    x353      con207    1
    x353      con171    -1
    x726      con897    1
    x726      con758    -1
    x726      con973    1
    x726      con898    1
    x154      Obj       -0.01
    x154      con1029   1
    x154      con234    1
    x154      con184    1
    x154      con985    1
    x65       Obj       -0.00042330287999999997
    x65       con621    1
    x65       con688    1
    x65       con756    -1.0296860000000001
    x65       con729    1
    MARK0094  'MARKER'                 'INTORG'
    x309      con141    -1000
    MARK0095  'MARKER'                 'INTEND'
    x635      con757    1.0296860000000001
    x635      con595    -1
    x647      con607    -1
    x647      con769    1.0296860000000001
    x106      Obj       -10
    x106      con525    -1
    x340      con254    1
    x340      con395    1
    x340      con428    1
    x340      con167    -1
    x340      con984    1
    x340      con721    1
    MARK0096  'MARKER'                 'INTORG'
    x769      con1044   1
    x769      con802    -29000
    MARK0097  'MARKER'                 'INTEND'
    x567      con472    -1
    x567      con499    -1
    x567      con471    1
    x567      con527    1
    MARK0098  'MARKER'                 'INTORG'
    x559      con455    -14501
    x559      con456    14501
    x258      con27     -12000
    x258      con161    1
    x258      con28     7000
    MARK0099  'MARKER'                 'INTEND'
    x655      con723    -1
    x655      con642    1
    x655      con677    1
    x655      con750    1.002874
    MARK0100  'MARKER'                 'INTORG'
    x845      con1055   1
    x845      con916    -29000
    x321      con153    -1000
    MARK0101  'MARKER'                 'INTEND'
    x270      con51     1
    x270      con129    1
    x270      con157    1
    x634      con594    -1
    x634      con756    1.0296860000000001
    x238      con20     -0.5
    x238      con152    1
    x238      con46     1
    x238      con124    1
    x238      con126    -1
    x595      con744    -1.0228648314606701
    x595      con555    -1
    MARK0102  'MARKER'                 'INTORG'
    x795      con1057   1
    x795      con841    -29000
    MARK0103  'MARKER'                 'INTEND'
    x213      con303    1
    x213      con14     1
    x400      con187    -1
    x400      con984    1
    x400      con294    1
    x400      con741    1
    x400      con468    1
    x400      con415    1
    x349      con260    1
    x349      con434    1
    x349      con398    1
    x349      con724    1
    x349      con984    1
    x349      con170    -1
    x104      Obj       -10
    x104      con523    -1
    x92       Obj       -10
    x92       con511    -1
    x378      con279    -0.90000000000000002
    x378      con381    1
    x378      con453    1
    x378      con180    1
    x378      con734    -1
    x513      con471    1
    x513      con336    1
    x212      con77     1
    x212      con13     0.0083333333333333297
    x212      con117    -1
    MARK0104  'MARKER'                 'INTORG'
    x277      con62     12000
    x277      con61     -12000
    MARK0105  'MARKER'                 'INTEND'
    x333      con719    -1
    x333      con366    1
    x333      con165    1
    x333      con423    1
    x333      con249    -0.90000000000000002
    x532      con355    1
    x532      con490    1
    MARK0106  'MARKER'                 'INTORG'
    x809      con862    -29000
    x809      con1037   1
    x675      con663    14501
    x675      con662    -14501
    x855      con1060   1
    x855      con931    -29000
    MARK0107  'MARKER'                 'INTEND'
    x453      con264    -1
    x453      con481    1
    MARK0108  'MARKER'                 'INTORG'
    x697      con706    -14501
    x697      con707    14501
    MARK0109  'MARKER'                 'INTEND'
    x452      con481    -1
    x452      con263    1
    x624      con584    -1
    x624      con746    1.0296860000000001
    x505      con328    1
    x505      con490    1
    MARK0110  'MARKER'                 'INTORG'
    x276      con60     7000
    x276      con59     -7000
    MARK0111  'MARKER'                 'INTEND'
    x460      con485    -1
    x460      con271    1
    x402      con295    -0.90000000000000002
    x402      con469    1
    x402      con389    1
    x402      con742    -1
    x402      con188    1
    x447      con258    -1
    x447      con478    1
    x736      con763    -1
    x736      con913    1
    x736      con978    1
    x736      con912    1
    x221      con304    1
    x221      con16     1
    x524      con482    1
    x524      con347    1
    MARK0112  'MARKER'                 'INTORG'
    x826      con887    -29000
    x826      con888    29000
    MARK0113  'MARKER'                 'INTEND'
    x178      con5      -0.5
    x178      con137    1
    x178      con109    1
    x178      con111    -1
    x178      con31     1
    MARK0114  'MARKER'                 'INTORG'
    x811      con865    -29000
    x811      con1038   1
    MARK0115  'MARKER'                 'INTEND'
    x113      Obj       -10
    x113      con532    -1
    x582      con487    -1
    x582      con542    1
    x582      con486    1
    x582      con514    -1
    x659      con727    -1
    x659      con754    1.002874
    x659      con646    1
    x659      con685    1
    x728      con974    1
    x728      con759    -1
    x728      con901    1
    x728      con900    1
    x27       Obj       -0.068000000000000005
    x27       con784    1
    x27       con782    1
    x27       con747    1
    x93       Obj       -10
    x93       con512    -1
    x134      Obj       -10
    x134      con553    -1
    MARK0116  'MARKER'                 'INTORG'
    x802      con851    -17400
    x802      con852    17400
    MARK0117  'MARKER'                 'INTEND'
    x642      con602    -1
    x642      con764    1.0296860000000001
    x121      Obj       -10
    x121      con540    -1
    MARK0118  'MARKER'                 'INTORG'
    x306      con138    -1000
    MARK0119  'MARKER'                 'INTEND'
    x155      Obj       -0.01
    x155      con1030   1
    x155      con236    1
    x155      con985    1
    x155      con185    1
    MARK0120  'MARKER'                 'INTORG'
    x678      con669    14501
    x678      con668    -14501
    MARK0121  'MARKER'                 'INTEND'
    x662      con757    1.002874
    x662      con691    1
    x662      con649    1
    x662      con730    -1
    x440      con475    -1
    x440      con251    1
    x227      con90     1
    x227      con17     0.0083333333333333297
    x227      con123    1
    MARK0122  'MARKER'                 'INTORG'
    x261      con34     7000
    x261      con33     -12000
    MARK0123  'MARKER'                 'INTEND'
    x112      Obj       -10
    x112      con531    -1
    x190      con114    -1
    x190      con8      -0.5
    x190      con34     1
    x190      con140    1
    x190      con112    1
    MARK0124  'MARKER'                 'INTORG'
    x821      con1043   1
    x821      con880    -29000
    x323      con155    -1000
    x827      con1046   1
    x827      con889    -29000
    MARK0125  'MARKER'                 'INTEND'
    x39       Obj       -0.10135
    x39       con818    1
    x39       con759    1
    x39       con820    1
    MARK0126  'MARKER'                 'INTORG'
    x688      con688    -14501
    x688      con689    14501
    x418      con215    -29000
    x418      con216    29000
    MARK0127  'MARKER'                 'INTEND'
    x446      con478    -1
    x446      con257    1
    MARK0128  'MARKER'                 'INTORG'
    x423      con225    -29000
    x423      con226    29000
    MARK0129  'MARKER'                 'INTEND'
    x648      con663    1
    x648      con716    -1
    x648      con635    1
    x648      con743    1.01333353535354
    x171      con109    1
    x171      con3      0.0083333333333333297
    x171      con62     1
    x23       Obj       0.024250000000000001
    x23       con844    1
    x23       con843    1
    x23       con767    -1
    x368      con217    1
    x368      con997    1
    x368      con176    -1
    x368      con308    1
    x672      con711    1
    x672      con740    -1
    x672      con659    1
    x672      con767    1.002874
    x731      con904    1
    x731      con760    1
    x731      con902    1
    x731      con949    1
    x674      con661    1
    x674      con742    -1
    x674      con769    1.002874
    x674      con715    1
    x432      con243    1
    x432      con471    -1
    MARK0130  'MARKER'                 'INTORG'
    x563      con464    14501
    x563      con463    -14501
    MARK0131  'MARKER'                 'INTEND'
    x485      con296    -1
    x485      con497    1
    x41       Obj       -0.082839999999999997
    x41       con826    1
    x41       con761    1
    x41       con824    1
    x107      Obj       -10
    x107      con526    -1
    x586      con491    -1
    x586      con518    -1
    x586      con546    1
    x586      con490    1
    x455      con482    1
    x455      con266    -1
    x51       Obj       -0.025319999999999999
    x51       con769    1
    x51       con929    1
    x51       con931    1
    x237      con20     1
    x237      con306    1
    x105      Obj       -10
    x105      con524    -1
    x632      con592    -1
    x632      con754    1.0296860000000001
    x577      con482    -1
    x577      con537    1
    x577      con481    1
    x577      con509    -1
    x52       Obj       -0.00042330287999999997
    x52       con716    1
    x52       con608    1
    x52       con743    -1.01333353535354
    x52       con662    1
    MARK0132  'MARKER'                 'INTORG'
    x295      con97     -12000
    x295      con98     12000
    x566      con469    -14501
    x566      con470    14501
    x414      con207    -29000
    x414      con208    29000
    MARK0133  'MARKER'                 'INTEND'
    x602      con562    -1
    x602      con751    -1.002874
    x96       Obj       -10
    x96       con515    -1
    x218      con119    1
    x218      con15     -0.5
    x218      con147    1
    x218      con121    -1
    x218      con41     1
    x247      con128    1
    x247      con100    1
    x247      con22     0.0083333333333333297
    x272      con158    1
    x272      con130    1
    x272      con52     1
    x235      con94     1
    x235      con125    1
    x235      con19     0.0083333333333333297
    MARK0134  'MARKER'                 'INTORG'
    x564      con466    14501
    x564      con465    -14501
    x850      con924    29000
    x850      con923    -29000
    MARK0135  'MARKER'                 'INTEND'
    x31       Obj       -0.05509
    x31       con796    1
    x31       con751    1
    x31       con794    1
    x364      con403    1
    x364      con270    1
    x364      con175    -1
    x364      con729    1
    x364      con984    1
    x364      con444    1
    x208      con75     1
    x208      con12     0.0083333333333333297
    x208      con116    -1
    MARK0136  'MARKER'                 'INTORG'
    x259      con30     7000
    x259      con29     -12000
    MARK0137  'MARKER'                 'INTEND'
    x114      Obj       -10
    x114      con533    -1
    x608      con757    -1.002874
    x608      con568    -1
    MARK0138  'MARKER'                 'INTORG'
    x260      con32     7000
    x260      con31     -12000
    MARK0139  'MARKER'                 'INTEND'
    x594      con743    -1.01333353535354
    x594      con554    -1
    x578      con483    -1
    x578      con482    1
    x578      con538    1
    x578      con510    -1
    x476      con493    -1
    x476      con287    1
    x64       Obj       -0.00042330287999999997
    x64       con728    1
    x64       con620    1
    x64       con686    1
    x64       con755    -1.0296860000000001
    MARK0140  'MARKER'                 'INTORG'
    x268      con48     8000
    x268      con47     -12000
    x846      con917    -29000
    x846      con918    29000
    MARK0141  'MARKER'                 'INTEND'
    x395      con235    1
    x395      con1006   1
    x395      con185    -1
    x369      con378    1
    x369      con731    -1
    x369      con447    1
    x369      con177    1
    x369      con273    -0.90000000000000002
    x450      con480    -1
    x450      con261    1
    MARK0142  'MARKER'                 'INTORG'
    x839      con1052   1
    x839      con907    -29000
    MARK0143  'MARKER'                 'INTEND'
    x747      con926    1
    x747      con928    1
    x747      con768    1
    x747      con957    1
    x737      con911    1
    x737      con763    1
    x737      con952    1
    x737      con913    1
    MARK0144  'MARKER'                 'INTORG'
    x257      con25     -12000
    x257      con26     8000
    x257      con161    -1
    x275      con57     -12000
    x275      con58     12000
    MARK0145  'MARKER'                 'INTEND'
    x118      Obj       -10
    x118      con537    -1
    MARK0146  'MARKER'                 'INTORG'
    x801      con1060   1
    x801      con850    -29000
    x694      con700    -14501
    x694      con701    14501
    MARK0147  'MARKER'                 'INTEND'
    x159      con1      1
    x159      con297    -1
    MARK0148  'MARKER'                 'INTORG'
    x763      con793    -29000
    x763      con1041   1
    MARK0149  'MARKER'                 'INTEND'
    x346      con258    1
    x346      con397    1
    x346      con723    1
    x346      con432    1
    x346      con984    1
    x346      con169    -1
    x6        Obj       0.057209999999999997
    x6        con793    1
    x6        con792    1
    x6        con750    -1
    x392      con233    1
    x392      con1005   1
    x392      con184    -1
    x531      con489    1
    x531      con354    1
    x195      con9      0.0083333333333333297
    x195      con115    1
    x195      con74     1
    x664      con651    1
    x664      con759    1.002874
    x664      con732    -1
    x664      con695    1
    x719      con754    1
    x719      con943    1
    x719      con884    1
    x719      con886    1
    x580      con540    1
    x580      con485    -1
    x580      con484    1
    x580      con512    -1
    MARK0150  'MARKER'                 'INTORG'
    x696      con704    -14501
    x696      con705    14501
    MARK0151  'MARKER'                 'INTEND'
    x97       Obj       -10
    x97       con516    -1
    MARK0152  'MARKER'                 'INTORG'
    x785      con826    -29000
    x785      con1052   1
    x293      con94     12000
    x293      con93     -12000
    MARK0153  'MARKER'                 'INTEND'
    x15       Obj       0.10135
    x15       con759    -1
    x15       con819    1
    x15       con820    1
    x587      con491    1
    x587      con519    -1
    x587      con492    -1
    x587      con547    1
    MARK0154  'MARKER'                 'INTORG'
    x849      con1057   1
    x849      con922    -29000
    MARK0155  'MARKER'                 'INTEND'
    x245      con307    1
    x245      con22     1
    MARK0156  'MARKER'                 'INTORG'
    x701      con714    -14501
    x701      con715    14501
    MARK0157  'MARKER'                 'INTEND'
    x646      con606    -1
    x646      con768    1.0296860000000001
    x574      con479    -1
    x574      con506    -1
    x574      con478    1
    x574      con534    1
    x601      con561    -1
    x601      con750    -1.002874
    MARK0158  'MARKER'                 'INTORG'
    x772      con807    29000
    x772      con806    -29000
    x264      con39     -12000
    x264      con40     7000
    MARK0159  'MARKER'                 'INTEND'
    x243      con21     0.0083333333333333297
    x243      con127    1
    x243      con98     1
    x376      con452    1
    x376      con984    1
    x376      con179    -1
    x376      con733    1
    x376      con407    1
    x376      con278    1
    x176      con108    -1
    x176      con4      0.0083333333333333297
    x176      con59     1
    x183      con6      0.0083333333333333297
    x183      con68     1
    x183      con112    1
    MARK0160  'MARKER'                 'INTORG'
    x266      con43     -12000
    x266      con44     8000
    MARK0161  'MARKER'                 'INTEND'
    x612      con572    -1
    x612      con761    -1.002874
    MARK0162  'MARKER'                 'INTORG'
    x793      con1056   1
    x793      con838    -29000
    MARK0163  'MARKER'                 'INTEND'
    x108      Obj       -10
    x108      con527    -1
    x94       Obj       -10
    x94       con513    -1
    x50       Obj       0.025319999999999999
    x50       con930    1
    x50       con769    -1
    x50       con931    1
    x610      con759    -1.002874
    x610      con570    -1
    MARK0164  'MARKER'                 'INTORG'
    x304      con136    -1000
    MARK0165  'MARKER'                 'INTEND'
    x666      con653    1
    x666      con761    1.002874
    x666      con699    1
    x666      con734    -1
    MARK0166  'MARKER'                 'INTORG'
    x289      con85     -12000
    x289      con86     12000
    MARK0167  'MARKER'                 'INTEND'
    x18       Obj       0.07707
    x18       con829    1
    x18       con828    1
    x18       con762    -1
    x570      con530    1
    x570      con475    -1
    x570      con474    1
    x570      con502    -1
    x629      con751    1.0296860000000001
    x629      con589    -1
    x717      con883    1
    x717      con881    1
    x717      con753    1
    x717      con942    1
    MARK0168  'MARKER'                 'INTORG'
    x834      con899    -29000
    x834      con900    29000
    MARK0169  'MARKER'                 'INTEND'
    x76       Obj       -0.00042330287999999997
    x76       con710    1
    x76       con740    1
    x76       con632    1
    x76       con767    -1.0296860000000001
    x657      con681    1
    x657      con644    1
    x657      con725    -1
    x657      con752    1.002874
    MARK0170  'MARKER'                 'INTORG'
    x844      con915    29000
    x844      con914    -29000
    MARK0171  'MARKER'                 'INTEND'
    x363      con443    1
    x363      con175    1
    x363      con376    1
    x363      con729    -1
    x363      con269    -0.90000000000000002
    MARK0172  'MARKER'                 'INTORG'
    x756      con783    29000
    x756      con782    -29000
    MARK0173  'MARKER'                 'INTEND'
    x614      con763    -1.002874
    x614      con574    -1
    x445      con477    1
    x445      con256    -1
    x667      con735    -1
    x667      con654    1
    x667      con762    1.002874
    x667      con701    1
    x229      con305    1
    x229      con18     1
    x244      con21     0.0083333333333333297
    x244      con93     1
    x244      con125    -1
    x613      con573    -1
    x613      con762    -1.002874
    x605      con754    -1.002874
    x605      con565    -1
    x652      con671    1
    x652      con639    1
    x652      con720    -1
    x652      con747    1.002874
    x663      con731    -1
    x663      con693    1
    x663      con758    1.002874
    x663      con650    1
    x174      con108    1
    x174      con30     1
    x174      con4      -0.5
    x174      con136    1
    x174      con110    -1
    x465      con487    1
    x465      con276    -1
    MARK0174  'MARKER'                 'INTORG'
    x543      con424    14501
    x543      con423    -14501
    x424      con228    29000
    x424      con227    -29000
    x680      con672    -14501
    x680      con673    14501
    MARK0175  'MARKER'                 'INTEND'
    x13       Obj       0.099210000000000007
    x13       con757    -1
    x13       con814    1
    x13       con813    1
    x42       Obj       -0.07707
    x42       con829    1
    x42       con827    1
    x42       con762    1
    MARK0176  'MARKER'                 'INTORG'
    x314      con146    -1000
    MARK0177  'MARKER'                 'INTEND'
    x109      Obj       -10
    x109      con528    -1
    x483      con294    -1
    x483      con496    1
    x354      con373    1
    x354      con437    1
    x354      con172    1
    x354      con726    -1
    x354      con263    -0.90000000000000002
    x394      con464    1
    x394      con739    1
    x394      con984    1
    x394      con413    1
    x394      con185    -1
    x394      con290    1
    x669      con737    -1
    x669      con764    1.002874
    x669      con705    1
    x669      con656    1
    x463      con274    -1
    x463      con486    1
    x720      con889    1
    x720      con755    -1
    x720      con970    1
    x720      con888    1
    MARK0178  'MARKER'                 'INTORG'
    x292      con91     -8000
    x292      con92     8000
    MARK0179  'MARKER'                 'INTEND'
    x86       Obj       -10
    x86       con505    -1
    x704      con864    1
    x704      con962    1
    x704      con865    1
    x704      con747    -1
    MARK0180  'MARKER'                 'INTORG'
    x555      con447    -14501
    x555      con448    14501
    x412      con204    29000
    x412      con203    -29000
    MARK0181  'MARKER'                 'INTEND'
    x384      con736    -1
    x384      con283    -0.90000000000000002
    x384      con457    1
    x384      con182    1
    x384      con383    1
    x48       Obj       -0.049959999999999997
    x48       con847    1
    x48       con768    1
    x48       con845    1
    MARK0182  'MARKER'                 'INTORG'
    x262      con36     7000
    x262      con35     -12000
    x416      con212    29000
    x416      con211    -29000
    x786      con828    29000
    x786      con827    -29000
    MARK0183  'MARKER'                 'INTEND'
    x67       Obj       -0.00042330287999999997
    x67       con731    1
    x67       con623    1
    x67       con758    -1.0296860000000001
    x67       con692    1
    x352      con262    1
    x352      con984    1
    x352      con725    1
    x352      con171    -1
    x352      con436    1
    x352      con399    1
    x433      con471    1
    x433      con244    -1
    MARK0184  'MARKER'                 'INTORG'
    x302      con134    -1000
    MARK0185  'MARKER'                 'INTEND'
    x53       Obj       -0.00042330287999999997
    x53       con717    1
    x53       con664    1
    x53       con744    -1.0228648314606701
    x53       con609    1
    MARK0186  'MARKER'                 'INTORG'
    x831      con1048   1
    x831      con895    -29000
    MARK0187  'MARKER'                 'INTEND'
    x242      con21     -0.5
    x242      con127    -1
    x242      con125    1
    x242      con153    1
    x242      con47     1
    MARK0188  'MARKER'                 'INTORG'
    x799      con847    -29000
    x799      con1059   1
    MARK0189  'MARKER'                 'INTEND'
    x222      con122    -1
    x222      con120    1
    x222      con148    1
    x222      con42     1
    x222      con16     -0.5
    MARK0190  'MARKER'                 'INTORG'
    x550      con437    -14501
    x550      con438    14501
    MARK0191  'MARKER'                 'INTEND'
    x535      con493    1
    x535      con358    1
    x215      con120    1
    x215      con14     0.0083333333333333297
    x215      con84     1
    MARK0192  'MARKER'                 'INTORG'
    x406      con192    29000
    x406      con191    -29000
    x778      con815    -29000
    x778      con816    29000
    MARK0193  'MARKER'                 'INTEND'
    x139      Obj       -0.01
    x139      con301    -1
    x139      con204    1
    x139      con169    1
    x139      con985    1
    x139      con1014   1
    MARK0194  'MARKER'                 'INTORG'
    x804      con855    29000
    x804      con854    -29000
    MARK0195  'MARKER'                 'INTEND'
    x645      con605    -1
    x645      con767    1.0296860000000001
    MARK0196  'MARKER'                 'INTORG'
    x313      con145    -1000
    MARK0197  'MARKER'                 'INTEND'
    x444      con255    1
    x444      con477    -1
    x144      Obj       -0.01
    x144      con306    -1
    x144      con214    1
    x144      con985    1
    x144      con174    1
    x144      con1019   1
    MARK0198  'MARKER'                 'INTORG'
    x278      con64     7000
    x278      con63     -7000
    x819      con1042   1
    x819      con877    -29000
    x822      con881    -29000
    x822      con882    29000
    MARK0199  'MARKER'                 'INTEND'
    x715      con941    1
    x715      con878    1
    x715      con880    1
    x715      con752    1
    MARK0200  'MARKER'                 'INTORG'
    x300      con132    -1000
    x557      con452    14501
    x557      con451    -14501
    MARK0201  'MARKER'                 'INTEND'
    x49       Obj       -0.025319999999999999
    x49       con848    1
    x49       con850    1
    x49       con769    1
    x59       Obj       -0.00042330287999999997
    x59       con723    1
    x59       con750    -1.0296860000000001
    x59       con615    1
    x59       con676    1
    x482      con293    1
    x482      con496    -1
    x78       Obj       -0.00042330287999999997
    x78       con742    1
    x78       con769    -1.0296860000000001
    x78       con634    1
    x78       con714    1
    x362      con306    1
    x362      con213    1
    x362      con174    -1
    x362      con995    1
    x24       Obj       0.049959999999999997
    x24       con847    1
    x24       con846    1
    x24       con768    -1
    MARK0202  'MARKER'                 'INTORG'
    x407      con193    -29000
    x407      con194    29000
    MARK0203  'MARKER'                 'INTEND'
    x99       Obj       -10
    x99       con518    -1
    x397      con186    -1
    x397      con740    1
    x397      con984    1
    x397      con414    1
    x397      con466    1
    x397      con292    1
    x727      con758    1
    x727      con896    1
    x727      con898    1
    x727      con947    1
    x345      con723    -1
    x345      con431    1
    x345      con370    1
    x345      con257    -0.90000000000000002
    x345      con169    1
    x469      con280    -1
    x469      con489    1
    x182      con32     1
    x182      con138    1
    x182      con6      -0.5
    x182      con110    1
    x182      con112    -1
    MARK0204  'MARKER'                 'INTORG'
    x758      con785    -29000
    x758      con786    29000
    MARK0205  'MARKER'                 'INTEND'
    x623      con583    -1
    x623      con745    1.02294058333333
    x529      con487    1
    x529      con352    1
    x185      con7      1
    x185      con300    -1
    x740      con980    1
    x740      con919    1
    x740      con765    -1
    x740      con918    1
    MARK0206  'MARKER'                 'INTORG'
    x267      con46     8000
    x267      con45     -12000
    x684      con681    14501
    x684      con680    -14501
    MARK0207  'MARKER'                 'INTEND'
    x707      con748    1
    x707      con937    1
    x707      con866    1
    x707      con868    1
    x124      Obj       -10
    x124      con543    -1
    x739      con953    1
    x739      con764    1
    x739      con916    1
    x739      con914    1
    x248      con126    -1
    x248      con95     1
    x248      con22     0.0083333333333333297
    x330      con717    1
    x330      con163    -1
    x330      con246    1
    x330      con984    1
    x330      con391    1
    x330      con420    1
    x11       Obj       0.079469999999999999
    x11       con807    1
    x11       con808    1
    x11       con755    -1
    x240      con20     0.0083333333333333297
    x240      con91     1
    x240      con124    -1
    x617      con766    -1.002874
    x617      con577    -1
    x146      Obj       -0.01
    x146      con218    1
    x146      con1021   1
    x146      con176    1
    x146      con985    1
    x146      con308    -1
    x230      con122    1
    x230      con150    1
    x230      con124    -1
    x230      con18     -0.5
    x230      con44     1
    MARK0208  'MARKER'                 'INTORG'
    x803      con853    -17400
    x803      con1034   1
    MARK0209  'MARKER'                 'INTEND'
    x399      con467    1
    x399      con388    1
    x399      con293    -0.90000000000000002
    x399      con187    1
    x399      con741    -1
    x336      con166    1
    x336      con367    1
    x336      con251    -0.90000000000000002
    x336      con425    1
    x336      con720    -1
    x494      con479    1
    x494      con317    1
    x228      con85     1
    x228      con121    -1
    x228      con17     0.0083333333333333297
    x732      con906    1
    x732      con761    -1
    x732      con907    1
    x732      con976    1
    x589      con549    1
    x589      con494    -1
    x589      con493    1
    x589      con521    -1
    MARK0210  'MARKER'                 'INTORG'
    x779      con817    -29000
    x779      con1049   1
    MARK0211  'MARKER'                 'INTEND'
    x456      con483    -1
    x456      con267    1
    MARK0212  'MARKER'                 'INTORG'
    x783      con1051   1
    x783      con823    -29000
    x287      con81     -12000
    x287      con82     12000
    MARK0213  'MARKER'                 'INTEND'
    x204      con73     1
    x204      con115    -1
    x204      con11     0.0083333333333333297
    x671      con739    -1
    x671      con709    1
    x671      con658    1
    x671      con766    1.002874
    x622      con744    1.0228648314606701
    x622      con582    -1
    x434      con472    -1
    x434      con245    1
    x381      con455    1
    x381      con181    1
    x381      con735    -1
    x381      con281    -0.90000000000000002
    x381      con382    1
    x98       Obj       -10
    x98       con517    -1
    x173      con298    1
    x173      con4      1
    x401      con239    1
    x401      con1008   1
    x401      con187    -1
    x568      con528    1
    x568      con472    1
    x568      con500    -1
    x568      con473    -1
    x331      con164    1
    x331      con365    1
    x331      con718    -1
    x331      con247    -0.90000000000000002
    x331      con421    1
    x40       Obj       -0.09307
    x40       con821    1
    x40       con760    1
    x40       con823    1
    x385      con736    1
    x385      con182    -1
    x385      con410    1
    x385      con984    1
    x385      con458    1
    x385      con284    1
    x329      con717    -1
    x329      con163    1
    x329      con419    1
    x329      con364    1
    x329      con245    -0.90000000000000002
    x641      con601    -1
    x641      con763    1.0296860000000001
    x56       Obj       -0.00042330287999999997
    x56       con670    1
    x56       con720    1
    x56       con747    -1.0296860000000001
    x56       con612    1
    x710      con874    1
    x710      con965    1
    x710      con750    -1
    x710      con873    1
    x744      con982    1
    x744      con924    1
    x744      con925    1
    x744      con767    -1
    MARK0214  'MARKER'                 'INTORG'
    x679      con671    14501
    x679      con670    -14501
    MARK0215  'MARKER'                 'INTEND'
    x393      con289    -0.90000000000000002
    x393      con739    -1
    x393      con386    1
    x393      con463    1
    x393      con185    1
    x361      con728    1
    x361      con402    1
    x361      con268    1
    x361      con442    1
    x361      con984    1
    x361      con174    -1
    x101      Obj       -10
    x101      con520    -1
    MARK0216  'MARKER'                 'INTORG'
    x322      con154    -1000
    x294      con96     8000
    x294      con95     -8000
    MARK0217  'MARKER'                 'INTEND'
    x217      con15     1
    x217      con304    -1
    x377      con223    1
    x377      con1000   1
    x377      con179    -1
    MARK0218  'MARKER'                 'INTORG'
    x420      con220    29000
    x420      con219    -29000
    MARK0219  'MARKER'                 'INTEND'
    x91       Obj       -10
    x91       con510    -1
    MARK0220  'MARKER'                 'INTORG'
    x296      con99     -8000
    x296      con100    8000
    MARK0221  'MARKER'                 'INTEND'
    x603      con563    -1
    x603      con752    -1.002874
    MARK0222  'MARKER'                 'INTORG'
    x691      con694    -14501
    x691      con695    14501
    MARK0223  'MARKER'                 'INTEND'
    x342      con369    1
    x342      con168    1
    x342      con722    -1
    x342      con429    1
    x342      con255    -0.90000000000000002
    MARK0224  'MARKER'                 'INTORG'
    x692      con696    -14501
    x692      con697    14501
    MARK0225  'MARKER'                 'INTEND'
    x458      con484    -1
    x458      con269    1
    MARK0226  'MARKER'                 'INTORG'
    x325      con157    -1000
    MARK0227  'MARKER'                 'INTEND'
    x521      con479    1
    x521      con344    1
    MARK0228  'MARKER'                 'INTORG'
    x410      con200    29000
    x410      con199    -29000
    MARK0229  'MARKER'                 'INTEND'
    x164      con297    1
    x164      con2      1
    x651      con638    1
    x651      con719    -1
    x651      con746    1.002874
    x651      con669    1
    x255      con104    1
    x255      con24     0.0083333333333333297
    x255      con130    1
    x498      con483    1
    x498      con321    1
    x37       Obj       -0.099210000000000007
    x37       con757    1
    x37       con814    1
    x37       con812    1
    x197      con301    1
    x197      con10     1
    x250      con155    1
    x250      con127    1
    x250      con49     1
    x250      con23     -0.5
    x250      con129    -1
    x526      con484    1
    x526      con349    1
    x630      con752    1.0296860000000001
    x630      con590    -1
    MARK0230  'MARKER'                 'INTORG'
    x698      con709    14501
    x698      con708    -14501
    MARK0231  'MARKER'                 'INTEND'
    x103      Obj       -10
    x103      con522    -1
    x236      con19     0.0083333333333333297
    x236      con123    -1
    x236      con89     1
    x436      con247    1
    x436      con473    -1
    MARK0232  'MARKER'                 'INTORG'
    x430      con239    -29000
    x430      con240    29000
    MARK0233  'MARKER'                 'INTEND'
    x17       Obj       0.082839999999999997
    x17       con826    1
    x17       con761    -1
    x17       con825    1
    x579      con539    1
    x579      con483    1
    x579      con484    -1
    x579      con511    -1
    MARK0234  'MARKER'                 'INTORG'
    x760      con788    -29000
    x760      con789    29000
    MARK0235  'MARKER'                 'INTEND'
    x21       Obj       0.038809999999999997
    x21       con837    1
    x21       con838    1
    x21       con765    -1
    x341      con299    1
    x341      con167    -1
    x341      con988    1
    x341      con199    1
    x172      con107    -1
    x172      con57     1
    x172      con3      0.0083333333333333297
    x188      con7      0.0083333333333333297
    x188      con111    -1
    x188      con65     1
    x136      Obj       -0.01
    x136      con166    1
    x136      con198    1
    x136      con298    -1
    x136      con1011   1
    x136      con985    1
    x571      con475    1
    x571      con503    -1
    x571      con531    1
    x571      con476    -1
    x590      con495    -1
    x590      con494    1
    x590      con550    1
    x590      con522    -1
    MARK0236  'MARKER'                 'INTORG'
    x766      con797    -29000
    x766      con798    29000
    MARK0237  'MARKER'                 'INTEND'
    x591      con523    -1
    x591      con495    1
    x591      con551    1
    x591      con496    -1
    x404      con241    1
    x404      con1009   1
    x404      con188    -1
    MARK0238  'MARKER'                 'INTORG'
    x796      con842    -29000
    x796      con843    29000
    MARK0239  'MARKER'                 'INTEND'
    x644      con766    1.0296860000000001
    x644      con604    -1
    x499      con484    1
    x499      con322    1
    MARK0240  'MARKER'                 'INTORG'
    x807      con859    -29000
    x807      con1036   1
    MARK0241  'MARKER'                 'INTEND'
    x597      con557    -1
    x597      con746    -1.002874
    MARK0242  'MARKER'                 'INTORG'
    x683      con679    14501
    x683      con678    -14501
    MARK0243  'MARKER'                 'INTEND'
    x30       Obj       -0.057209999999999997
    x30       con791    1
    x30       con793    1
    x30       con750    1
    x175      con64     1
    x175      con4      0.0083333333333333297
    x175      con110    1
    x631      con753    1.0296860000000001
    x631      con591    -1
    x709      con871    1
    x709      con938    1
    x709      con869    1
    x709      con749    1
    x2        Obj       0.076999999999999999
    x2        con746    -1
    x2        con781    1
    x2        con780    1
    x373      con276    1
    x373      con732    1
    x373      con450    1
    x373      con178    -1
    x373      con984    1
    x373      con406    1
    x158      Obj       -0.01
    x158      con242    1
    x158      con985    1
    x158      con1033   1
    x158      con188    1
    MARK0244  'MARKER'                 'INTORG'
    x817      con874    -29000
    x817      con1041   1
    MARK0245  'MARKER'                 'INTEND'
    x640      con600    -1
    x640      con762    1.0296860000000001
    MARK0246  'MARKER'                 'INTORG'
    x263      con37     -12000
    x263      con38     7000
    x299      con131    -1000
    MARK0247  'MARKER'                 'INTEND'
    x403      con296    1
    x403      con416    1
    x403      con742    1
    x403      con984    1
    x403      con470    1
    x403      con188    -1
    MARK0248  'MARKER'                 'INTORG'
    x320      con152    -1000
    MARK0249  'MARKER'                 'INTEND'
    x25       Obj       0.025319999999999999
    x25       con849    1
    x25       con850    1
    x25       con769    -1
    x69       Obj       -0.00042330287999999997
    x69       con625    1
    x69       con760    -1.0296860000000001
    x69       con696    1
    x69       con733    1
    MARK0250  'MARKER'                 'INTORG'
    x687      con687    14501
    x687      con686    -14501
    MARK0251  'MARKER'                 'INTEND'
    x633      con755    1.0296860000000001
    x633      con593    -1
    x464      con487    -1
    x464      con275    1
    x487      con472    1
    x487      con310    1
    x33       Obj       -0.050849999999999999
    x33       con753    1
    x33       con800    1
    x33       con802    1
    x515      con338    1
    x515      con473    1
    MARK0252  'MARKER'                 'INTORG'
    x312      con144    -1000
    x682      con677    14501
    x682      con676    -14501
    MARK0253  'MARKER'                 'INTEND'
    x85       Obj       -10
    x85       con504    -1
    x442      con253    1
    x442      con476    -1
    MARK0254  'MARKER'                 'INTORG'
    x771      con805    -29000
    x771      con1045   1
    MARK0255  'MARKER'                 'INTEND'
    x387      con737    -1
    x387      con459    1
    x387      con183    1
    x387      con384    1
    x387      con285    -0.90000000000000002
    x438      con474    -1
    x438      con249    1
    x712      con876    1
    x712      con877    1
    x712      con751    -1
    x712      con966    1
    x643      con603    -1
    x643      con765    1.0296860000000001
    MARK0256  'MARKER'                 'INTORG'
    x792      con837    29000
    x792      con836    -29000
    x305      con137    -1000
    MARK0257  'MARKER'                 'INTEND'
    x448      con479    -1
    x448      con259    1
    x575      con507    -1
    x575      con479    1
    x575      con480    -1
    x575      con535    1
    x627      con587    -1
    x627      con749    1.0296860000000001
    x338      con166    -1
    x338      con197    1
    x338      con298    1
    x338      con987    1
    MARK0258  'MARKER'                 'INTORG'
    x824      con885    29000
    x824      con884    -29000
    MARK0259  'MARKER'                 'INTEND'
    x355      con264    1
    x355      con400    1
    x355      con438    1
    x355      con172    -1
    x355      con984    1
    x355      con726    1
    MARK0260  'MARKER'                 'INTORG'
    x841      con910    -29000
    x841      con1053   1
    MARK0261  'MARKER'                 'INTEND'
    x435      con472    1
    x435      con246    -1
    x72       Obj       -0.00042330287999999997
    x72       con736    1
    x72       con628    1
    x72       con763    -1.0296860000000001
    x72       con702    1
    x251      con102    1
    x251      con23     0.0083333333333333297
    x251      con129    1
    x519      con342    1
    x519      con477    1
    MARK0262  'MARKER'                 'INTORG'
    x273      con53     -12000
    x273      con54     12000
    MARK0263  'MARKER'                 'INTEND'
    x472      con283    1
    x472      con491    -1
    x10       Obj       0.064420000000000005
    x10       con754    -1
    x10       con805    1
    x10       con804    1
    MARK0264  'MARKER'                 'INTORG'
    x854      con930    29000
    x854      con929    -29000
    MARK0265  'MARKER'                 'INTEND'
    x668      con736    -1
    x668      con703    1
    x668      con655    1
    x668      con763    1.002874
    x358      con401    1
    x358      con727    1
    x358      con440    1
    x358      con984    1
    x358      con266    1
    x358      con173    -1
    x19       Obj       0.054330000000000003
    x19       con763    -1
    x19       con831    1
    x19       con832    1
    MARK0266  'MARKER'                 'INTORG'
    x689      con690    -14501
    x689      con691    14501
    MARK0267  'MARKER'                 'INTEND'
    x745      con956    1
    x745      con923    1
    x745      con925    1
    x745      con767    1
    MARK0268  'MARKER'                 'INTORG'
    x549      con436    14501
    x549      con435    -14501
    MARK0269  'MARKER'                 'INTEND'
    x162      con107    1
    x162      con1      0.0083333333333333297
    x162      con58     1
    MARK0270  'MARKER'                 'INTORG'
    x816      con872    -29000
    x816      con873    29000
    MARK0271  'MARKER'                 'INTEND'
    x702      con862    1
    x702      con746    -1
    x702      con861    1
    x702      con961    1
    x350      con302    1
    x350      con991    1
    x350      con205    1
    x350      con170    -1
    x390      con385    1
    x390      con184    1
    x390      con738    -1
    x390      con461    1
    x390      con287    -0.90000000000000002
    MARK0272  'MARKER'                 'INTORG'
    x751      con775    -29000
    x751      con1035   1
    MARK0273  'MARKER'                 'INTEND'
    x518      con341    1
    x518      con476    1
    MARK0274  'MARKER'                 'INTORG'
    x767      con799    -29000
    x767      con1043   1
    MARK0275  'MARKER'                 'INTEND'
    x22       Obj       0.062579999999999997
    x22       con840    1
    x22       con766    -1
    x22       con841    1
    x592      con552    1
    x592      con524    -1
    x592      con496    1
    x592      con497    -1
    x636      con758    1.0296860000000001
    x636      con596    -1
    x654      con722    -1
    x654      con675    1
    x654      con749    1.002874
    x654      con641    1
    x196      con9      0.0083333333333333297
    x196      con113    -1
    x196      con69     1
    MARK0276  'MARKER'                 'INTORG'
    x833      con898    -29000
    x833      con1049   1
    x815      con871    -29000
    x815      con1040   1
    MARK0277  'MARKER'                 'INTEND'
    x437      con248    -1
    x437      con473    1
    x57       Obj       -0.00042330287999999997
    x57       con613    1
    x57       con748    -1.0296860000000001
    x57       con672    1
    x57       con721    1
    x12       Obj       0.086929999999999993
    x12       con810    1
    x12       con756    -1
    x12       con811    1
    x530      con353    1
    x530      con488    1
    x502      con487    1
    x502      con325    1
    x249      con23     1
    x249      con308    -1
    x344      con989    1
    x344      con201    1
    x344      con168    -1
    x344      con300    1
    MARK0278  'MARKER'                 'INTORG'
    x545      con428    14501
    x545      con427    -14501
    MARK0279  'MARKER'                 'INTEND'
    x650      con667    1
    x650      con718    -1
    x650      con637    1
    x650      con745    1.02294058333333
    x596      con556    -1
    x596      con745    -1.02294058333333
    x722      con891    1
    x722      con892    1
    x722      con756    -1
    x722      con971    1
    x7        Obj       0.05509
    x7        con796    1
    x7        con795    1
    x7        con751    -1
    x116      Obj       -10
    x116      con535    -1
    MARK0280  'MARKER'                 'INTORG'
    x695      con703    14501
    x695      con702    -14501
    MARK0281  'MARKER'                 'INTEND'
    x375      con277    -0.90000000000000002
    x375      con451    1
    x375      con179    1
    x375      con733    -1
    x375      con380    1
    MARK0282  'MARKER'                 'INTORG'
    x413      con205    -29000
    x413      con206    29000
    MARK0283  'MARKER'                 'INTEND'
    x36       Obj       -0.086929999999999993
    x36       con809    1
    x36       con756    1
    x36       con811    1
    MARK0284  'MARKER'                 'INTORG'
    x552      con442    14501
    x552      con441    -14501
    MARK0285  'MARKER'                 'INTEND'
    x573      con505    -1
    x573      con478    -1
    x573      con477    1
    x573      con533    1
    x600      con560    -1
    x600      con749    -1.002874
    x746      con928    1
    x746      con927    1
    x746      con983    1
    x746      con768    -1
    x581      con541    1
    x581      con513    -1
    x581      con485    1
    x581      con486    -1
    MARK0286  'MARKER'                 'INTORG'
    x301      con133    -1000
    MARK0287  'MARKER'                 'INTEND'
    x649      con665    1
    x649      con717    -1
    x649      con744    1.0228648314606701
    x649      con636    1
    x187      con113    1
    x187      con7      0.0083333333333333297
    x187      con70     1
    x533      con356    1
    x533      con491    1
    x177      con5      1
    x177      con299    -1
    MARK0288  'MARKER'                 'INTORG'
    x417      con213    -29000
    x417      con214    29000
    MARK0289  'MARKER'                 'INTEND'
    x89       Obj       -10
    x89       con508    -1
    MARK0290  'MARKER'                 'INTORG'
    x681      con674    -14501
    x681      con675    14501
    MARK0291  'MARKER'                 'INTEND'
    x111      Obj       -10
    x111      con530    -1
    x351      con372    1
    x351      con725    -1
    x351      con171    1
    x351      con435    1
    x351      con261    -0.90000000000000002
    x189      con8      1
    x189      con300    1
    MARK0292  'MARKER'                 'INTORG'
    x814      con870    29000
    x814      con869    -29000
    MARK0293  'MARKER'                 'INTEND'
    x60       Obj       -0.00042330287999999997
    x60       con724    1
    x60       con751    -1.0296860000000001
    x60       con678    1
    x60       con616    1
    MARK0294  'MARKER'                 'INTORG'
    x317      con149    -1000
    MARK0295  'MARKER'                 'INTEND'
    x638      con760    1.0296860000000001
    x638      con598    -1
    x95       Obj       -10
    x95       con514    -1
    MARK0296  'MARKER'                 'INTORG'
    x797      con844    -29000
    x797      con1058   1
    MARK0297  'MARKER'                 'INTEND'
    x147      Obj       -0.01
    x147      con1022   1
    x147      con220    1
    x147      con177    1
    x147      con985    1
    x141      Obj       -0.01
    x141      con303    -1
    x141      con1016   1
    x141      con985    1
    x141      con171    1
    x141      con208    1
    x514      con337    1
    x514      con472    1
    MARK0298  'MARKER'                 'INTORG'
    x820      con879    29000
    x820      con878    -29000
    x286      con79     -7000
    x286      con80     7000
    MARK0299  'MARKER'                 'INTEND'
    x254      con128    1
    x254      con24     -0.5
    x254      con156    1
    x254      con130    -1
    x254      con50     1
    x169      con298    -1
    x169      con3      1
    MARK0300  'MARKER'                 'INTORG'
    x310      con142    -1000
    MARK0301  'MARKER'                 'INTEND'
    x599      con748    -1.002874
    x599      con559    -1
    MARK0302  'MARKER'                 'INTORG'
    x813      con1039   1
    x813      con868    -29000
    MARK0303  'MARKER'                 'INTEND'
    x128      Obj       -10
    x128      con547    -1
    x192      con8      0.0083333333333333297
    x192      con67     1
    x192      con112    -1
    MARK0304  'MARKER'                 'INTORG'
    x291      con90     12000
    x291      con89     -12000
    MARK0305  'MARKER'                 'INTEND'
    x143      Obj       -0.01
    x143      con305    -1
    x143      con212    1
    x143      con1018   1
    x143      con985    1
    x143      con173    1
    x733      con905    1
    x733      con761    1
    x733      con907    1
    x733      con950    1
    x721      con887    1
    x721      con944    1
    x721      con889    1
    x721      con755    1
    x386      con1003   1
    x386      con182    -1
    x386      con229    1
    x539      con362    1
    x539      con497    1
    x220      con119    -1
    x220      con81     1
    x220      con15     0.0083333333333333297
    MARK0306  'MARKER'                 'INTORG'
    x759      con1039   1
    x759      con787    -29000
    MARK0307  'MARKER'                 'INTEND'
    x129      Obj       -10
    x129      con548    -1
    x576      con480    1
    x576      con536    1
    x576      con508    -1
    x576      con481    -1
    x491      con476    1
    x491      con314    1
    x75       Obj       -0.00042330287999999997
    x75       con739    1
    x75       con766    -1.0296860000000001
    x75       con708    1
    x75       con631    1
    MARK0308  'MARKER'                 'INTORG'
    x419      con218    29000
    x419      con217    -29000
    MARK0309  'MARKER'                 'INTEND'
    x16       Obj       0.09307
    x16       con760    -1
    x16       con822    1
    x16       con823    1
    MARK0310  'MARKER'                 'INTORG'
    x544      con426    14501
    x544      con425    -14501
    MARK0311  'MARKER'                 'INTEND'
    x125      Obj       -10
    x125      con544    -1
    x716      con883    1
    x716      con753    -1
    x716      con882    1
    x716      con968    1
    MARK0312  'MARKER'                 'INTORG'
    x269      con49     -12000
    x269      con50     8000
    MARK0313  'MARKER'                 'INTEND'
    x253      con24     1
    x253      con308    1
    x620      con580    -1
    x620      con769    -1.002874
    x479      con494    1
    x479      con290    -1
    MARK0314  'MARKER'                 'INTORG'
    x812      con867    29000
    x812      con866    -29000
    MARK0315  'MARKER'                 'INTEND'
    x43       Obj       -0.054330000000000003
    x43       con830    1
    x43       con763    1
    x43       con832    1
    MARK0316  'MARKER'                 'INTORG'
    x754      con780    29000
    x754      con779    -29000
    MARK0317  'MARKER'                 'INTEND'
    x379      con454    1
    x379      con280    1
    x379      con984    1
    x379      con408    1
    x379      con180    -1
    x379      con734    1
    x202      con115    1
    x202      con143    1
    x202      con11     -0.5
    x202      con37     1
    x202      con117    -1
    x26       Obj       -0.076999999999999999
    x26       con746    1
    x26       con781    1
    x26       con779    1
    MARK0318  'MARKER'                 'INTORG'
    x547      con432    14501
    x547      con431    -14501
    x787      con829    -29000
    x787      con1053   1
    MARK0319  'MARKER'                 'INTEND'
    x477      con493    1
    x477      con288    -1
    x517      con475    1
    x517      con340    1
    MARK0320  'MARKER'                 'INTORG'
    x790      con834    29000
    x790      con833    -29000
    MARK0321  'MARKER'                 'INTEND'
    x142      Obj       -0.01
    x142      con210    1
    x142      con304    -1
    x142      con172    1
    x142      con985    1
    x142      con1017   1
    x123      Obj       -10
    x123      con542    -1
    x34       Obj       -0.064420000000000005
    x34       con754    1
    x34       con803    1
    x34       con805    1
    MARK0322  'MARKER'                 'INTORG'
    x832      con897    29000
    x832      con896    -29000
    MARK0323  'MARKER'                 'INTEND'
    x207      con12     0.0083333333333333297
    x207      con80     1
    x207      con118    1
    x486      con309    1
    x486      con471    1
    x507      con330    1
    x507      con492    1
    x120      Obj       -10
    x120      con539    -1
    x473      con491    1
    x473      con284    -1
    x102      Obj       -10
    x102      con521    -1
    x621      con581    -1
    x621      con743    1.01333353535354
    MARK0324  'MARKER'                 'INTORG'
    x835      con901    -29000
    x835      con1050   1
    MARK0325  'MARKER'                 'INTEND'
    x73       Obj       -0.00042330287999999997
    x73       con629    1
    x73       con737    1
    x73       con764    -1.0296860000000001
    x73       con704    1
    x3        Obj       0.068000000000000005
    x3        con784    1
    x3        con783    1
    x3        con747    -1
    x58       Obj       -0.00042330287999999997
    x58       con614    1
    x58       con722    1
    x58       con674    1
    x58       con749    -1.0296860000000001
    MARK0326  'MARKER'                 'INTORG'
    x315      con147    -1000
    MARK0327  'MARKER'                 'INTEND'
    x711      con939    1
    x711      con872    1
    x711      con874    1
    x711      con750    1
    x468      con489    -1
    x468      con279    1
    x461      con485    1
    x461      con272    -1
    MARK0328  'MARKER'                 'INTORG'
    x303      con135    -1000
    MARK0329  'MARKER'                 'INTEND'
    x625      con747    1.0296860000000001
    x625      con585    -1
    x673      con660    1
    x673      con713    1
    x673      con741    -1
    x673      con768    1.002874
    x367      con984    1
    x367      con404    1
    x367      con272    1
    x367      con176    -1
    x367      con730    1
    x367      con446    1
    x497      con482    1
    x497      con320    1
    x74       Obj       -0.00042330287999999997
    x74       con706    1
    x74       con738    1
    x74       con630    1
    x74       con765    -1.0296860000000001
    MARK0330  'MARKER'                 'INTORG'
    x789      con1054   1
    x789      con832    -29000
    MARK0331  'MARKER'                 'INTEND'
    x639      con599    -1
    x639      con761    1.0296860000000001
    x140      Obj       -0.01
    x140      con302    -1
    x140      con1015   1
    x140      con985    1
    x140      con170    1
    x140      con206    1
    x226      con149    1
    x226      con43     1
    x226      con121    1
    x226      con17     -0.5
    x226      con123    -1
    MARK0332  'MARKER'                 'INTORG'
    x281      con69     -12000
    x281      con70     12000
    x677      con667    14501
    x677      con666    -14501
    MARK0333  'MARKER'                 'INTEND'
    x389      con183    -1
    x389      con231    1
    x389      con1004   1
    x186      con139    1
    x186      con113    -1
    x186      con33     1
    x186      con7      -0.5
    x186      con111    1
    x383      con227    1
    x383      con181    -1
    x383      con1002   1
    MARK0334  'MARKER'                 'INTORG'
    x280      con67     -7000
    x280      con68     7000
    x426      con232    29000
    x426      con231    -29000
    MARK0335  'MARKER'                 'INTEND'
    x511      con334    1
    x511      con496    1
    x660      con728    -1
    x660      con687    1
    x660      con647    1
    x660      con755    1.002874
    x46       Obj       -0.062579999999999997
    x46       con766    1
    x46       con839    1
    x46       con841    1
    x145      Obj       -0.01
    x145      con1020   1
    x145      con175    1
    x145      con216    1
    x145      con307    -1
    x145      con985    1
    x730      con904    1
    x730      con903    1
    x730      con760    -1
    x730      con975    1
    x509      con494    1
    x509      con332    1
    MARK0336  'MARKER'                 'INTORG'
    x541      con419    -14501
    x541      con420    14501
    x693      con698    -14501
    x693      con699    14501
    MARK0337  'MARKER'                 'INTEND'
    x626      con748    1.0296860000000001
    x626      con586    -1
    x359      con994    1
    x359      con305    1
    x359      con211    1
    x359      con173    -1
    x593      con553    1
    x593      con525    -1
    x593      con497    1
    x382      con456    1
    x382      con181    -1
    x382      con984    1
    x382      con409    1
    x382      con282    1
    x382      con735    1
    x665      con760    1.002874
    x665      con652    1
    x665      con697    1
    x665      con733    -1
    x47       Obj       -0.024250000000000001
    x47       con842    1
    x47       con844    1
    x47       con767    1
    MARK0338  'MARKER'                 'INTORG'
    x768      con800    -29000
    x768      con801    29000
    MARK0339  'MARKER'                 'INTEND'
    x488      con311    1
    x488      con473    1
    MARK0340  'MARKER'                 'INTORG'
    x561      con459    -14501
    x561      con460    14501
    MARK0341  'MARKER'                 'INTEND'
    x480      con495    -1
    x480      con291    1
    x536      con494    1
    x536      con359    1
    MARK0342  'MARKER'                 'INTORG'
    x800      con849    29000
    x800      con848    -29000
    MARK0343  'MARKER'                 'INTEND'
    x150      Obj       -0.01
    x150      con1025   1
    x150      con985    1
    x150      con180    1
    x150      con226    1
    x246      con128    -1
    x246      con48     1
    x246      con154    1
    x246      con126    1
    x246      con22     -0.5
    x180      con5      0.0083333333333333297
    x180      con109    -1
    x180      con61     1
    MARK0344  'MARKER'                 'INTORG'
    x791      con1055   1
    x791      con835    -29000
    x818      con876    29000
    x818      con875    -29000
    x546      con429    -14501
    x546      con430    14501
    x562      con462    14501
    x562      con461    -14501
    MARK0345  'MARKER'                 'INTEND'
    x372      con449    1
    x372      con732    -1
    x372      con178    1
    x372      con379    1
    x372      con275    -0.90000000000000002
    x370      con274    1
    x370      con731    1
    x370      con177    -1
    x370      con984    1
    x370      con405    1
    x370      con448    1
    x615      con575    -1
    x615      con764    -1.002874
    x161      con1      -0.0083333333333333297
    x161      con105    1
    x161      con54     1
    x161      con159    1
    x149      Obj       -0.01
    x149      con179    1
    x149      con985    1
    x149      con1024   1
    x149      con224    1
    MARK0346  'MARKER'                 'INTORG'
    x836      con903    29000
    x836      con902    -29000
    MARK0347  'MARKER'                 'INTEND'
    x503      con488    1
    x503      con326    1
    x20       Obj       0.075670000000000001
    x20       con764    -1
    x20       con834    1
    x20       con835    1
    x504      con489    1
    x504      con327    1
    MARK0348  'MARKER'                 'INTORG'
    x319      con151    -1000
    MARK0349  'MARKER'                 'INTEND'
    x656      con643    1
    x656      con724    -1
    x656      con751    1.002874
    x656      con679    1
    x225      con305    -1
    x225      con17     1
    x80       Obj       -10
    x80       con499    -1
    MARK0350  'MARKER'                 'INTORG'
    x825      con886    -29000
    x825      con1045   1
    MARK0351  'MARKER'                 'INTEND'
    x729      con759    1
    x729      con901    1
    x729      con948    1
    x729      con899    1
    x90       Obj       -10
    x90       con509    -1
    x451      con480    1
    x451      con262    -1
    x741      con917    1
    x741      con919    1
    x741      con954    1
    x741      con765    1
    x742      con766    -1
    x742      con921    1
    x742      con922    1
    x742      con981    1
    MARK0352  'MARKER'                 'INTORG'
    x408      con195    -29000
    x408      con196    29000
    MARK0353  'MARKER'                 'INTEND'
    x496      con319    1
    x496      con481    1
    x28       Obj       -0.059119999999999999
    x28       con748    1
    x28       con785    1
    x28       con787    1
    x481      con495    1
    x481      con292    -1
    x528      con486    1
    x528      con351    1
    x77       Obj       -0.00042330287999999997
    x77       con712    1
    x77       con741    1
    x77       con633    1
    x77       con768    -1.0296860000000001
    x241      con21     1
    x241      con307    -1
    x713      con940    1
    x713      con875    1
    x713      con877    1
    x713      con751    1
    x441      con475    1
    x441      con252    -1
    MARK0354  'MARKER'                 'INTORG'
    x762      con791    -29000
    x762      con792    29000
    MARK0355  'MARKER'                 'INTEND'
    x604      con564    -1
    x604      con753    -1.002874
    x457      con268    -1
    x457      con483    1
    x224      con120    -1
    x224      con83     1
    x224      con16     0.0083333333333333297
    MARK0356  'MARKER'                 'INTORG'
    x700      con712    -14501
    x700      con713    14501
    x852      con926    -29000
    x852      con927    29000
    x699      con710    -14501
    x699      con711    14501
    MARK0357  'MARKER'                 'INTEND'
    x484      con295    1
    x484      con497    -1
    x135      Obj       -0.01
    x135      con1010   1
    x135      con165    1
    x135      con196    1
    x135      con985    1
    x135      con297    -1
    MARK0358  'MARKER'                 'INTORG'
    x805      con1035   1
    x805      con856    -29000
    MARK0359  'MARKER'                 'INTEND'
    x1        Obj       -1050.09490748148
    x62       Obj       -0.00042330287999999997
    x62       con618    1
    x62       con753    -1.0296860000000001
    x62       con682    1
    x62       con726    1
    MARK0360  'MARKER'                 'INTORG'
    x429      con237    -29000
    x429      con238    29000
    x798      con846    29000
    x798      con845    -29000
    MARK0361  'MARKER'                 'INTEND'
    x708      con964    1
    x708      con871    1
    x708      con870    1
    x708      con749    -1
    x618      con578    -1
    x618      con767    -1.002874
    x211      con119    1
    x211      con82     1
    x211      con13     0.0083333333333333297
    MARK0362  'MARKER'                 'INTORG'
    x765      con796    -29000
    x765      con1042   1
    MARK0363  'MARKER'                 'INTEND'
    x443      con254    -1
    x443      con476    1
    x127      Obj       -10
    x127      con546    -1
    x335      con165    -1
    x335      con986    1
    x335      con195    1
    x335      con297    1
    MARK0364  'MARKER'                 'INTORG'
    x282      con71     -7000
    x282      con72     7000
    MARK0365  'MARKER'                 'INTEND'
    x219      con15     0.0083333333333333297
    x219      con121    1
    x219      con86     1
    x525      con483    1
    x525      con348    1
    MARK0366  'MARKER'                 'INTORG'
    x829      con892    -29000
    x829      con1047   1
    MARK0367  'MARKER'                 'INTEND'
    x168      con55     1
    x168      con106    -1
    x168      con2      0.0083333333333333297
    x198      con114    1
    x198      con142    1
    x198      con36     1
    x198      con10     -0.5
    x198      con116    -1
    MARK0368  'MARKER'                 'INTORG'
    x279      con66     12000
    x279      con65     -12000
    MARK0369  'MARKER'                 'INTEND'
    x5        Obj       0.072609999999999994
    x5        con789    1
    x5        con790    1
    x5        con749    -1
    x489      con312    1
    x489      con474    1
    x585      con489    1
    x585      con545    1
    x585      con517    -1
    x585      con490    -1
    x454      con265    1
    x454      con482    -1
    MARK0370  'MARKER'                 'INTORG'
    x761      con1040   1
    x761      con790    -29000
    x830      con893    -29000
    x830      con894    29000
    x757      con784    -29000
    x757      con1038   1
    x298      con104    8000
    x298      con103    -8000
    MARK0371  'MARKER'                 'INTEND'
    x365      con215    1
    x365      con175    -1
    x365      con307    1
    x365      con996    1
    x537      con495    1
    x537      con360    1
    MARK0372  'MARKER'                 'INTORG'
    x548      con434    14501
    x548      con433    -14501
    x840      con909    29000
    x840      con908    -29000
    MARK0373  'MARKER'                 'INTEND'
    x156      Obj       -0.01
    x156      con186    1
    x156      con1031   1
    x156      con238    1
    x156      con985    1
    x82       Obj       -10
    x82       con501    -1
    x203      con78     1
    x203      con11     0.0083333333333333297
    x203      con117    1
    x490      con313    1
    x490      con475    1
    x506      con329    1
    x506      con491    1
    MARK0374  'MARKER'                 'INTORG'
    x422      con223    -29000
    x422      con224    29000
    MARK0375  'MARKER'                 'INTEND'
    x584      con544    1
    x584      con489    -1
    x584      con488    1
    x584      con516    -1
    MARK0376  'MARKER'                 'INTORG'
    x843      con1054   1
    x843      con913    -29000
    MARK0377  'MARKER'                 'INTEND'
    x166      con160    1
    x166      con56     1
    x166      con106    1
    x166      con2      -0.0083333333333333297
RHS
    RHS_V     con909    29000
    RHS_V     con653    14500
    RHS_V     con915    29000
    RHS_V     con564    -1583.9390000000001
    RHS_V     con30     7000
    RHS_V     con390    8700
    RHS_V     con622    14500
    RHS_V     con544    22857.628917999999
    RHS_V     con621    14500
    RHS_V     con879    29000
    RHS_V     con864    29000
    RHS_V     con48     8000
    RHS_V     con94     12000
    RHS_V     con613    14500
    RHS_V     con507    -14081.143184
    RHS_V     con228    29000
    RHS_V     con464    14501
    RHS_V     con703    14501
    RHS_V     con387    14500
    RHS_V     con840    29000
    RHS_V     con541    22857.628917999999
    RHS_V     con665    14501
    RHS_V     con994    6000
    RHS_V     con628    14500
    RHS_V     con369    14500
    RHS_V     con454    14501
    RHS_V     con807    29000
    RHS_V     con373    14500
    RHS_V     con78     12000
    RHS_V     con998    6000
    RHS_V     con64     7000
    RHS_V     con462    14501
    RHS_V     con849    29000
    RHS_V     con655    14500
    RHS_V     con1003   6000
    RHS_V     con1040   1
    RHS_V     con523    -14081.143184
    RHS_V     con828    29000
    RHS_V     con385    14500
    RHS_V     con401    14500
    RHS_V     con1025   4000
    RHS_V     con772    -1511.5558569023599
    RHS_V     con648    14500
    RHS_V     con164    4490.5429999999997
    RHS_V     con378    14500
    RHS_V     con104    8000
    RHS_V     con528    22857.628917999999
    RHS_V     con891    29000
    RHS_V     con452    14501
    RHS_V     con1055   1
    RHS_V     con548    22634.182676
    RHS_V     con638    14500
    RHS_V     con397    14500
    RHS_V     con651    14500
    RHS_V     con1048   1
    RHS_V     con903    29000
    RHS_V     con530    22634.182676
    RHS_V     con363    8700
    RHS_V     con365    14500
    RHS_V     con553    14081.143184
    RHS_V     con505    -14081.143184
    RHS_V     con200    29000
    RHS_V     con992    6000
    RHS_V     con1060   1
    RHS_V     con402    14500
    RHS_V     con375    14500
    RHS_V     con709    14501
    RHS_V     con614    14500
    RHS_V     con687    14501
    RHS_V     con623    14500
    RHS_V     con559    -1583.9390000000001
    RHS_V     con1010   3500
    RHS_V     con617    14500
    RHS_V     con658    14500
    RHS_V     con88     8000
    RHS_V     con1013   3500
    RHS_V     con1032   3500
    RHS_V     con1046   1
    RHS_V     con711    14501
    RHS_V     con625    14500
    RHS_V     con515    -13507.000312
    RHS_V     con647    14500
    RHS_V     con232    29000
    RHS_V     con418    14501
    RHS_V     con667    14501
    RHS_V     con1006   6000
    RHS_V     con629    14500
    RHS_V     con105    12000
    RHS_V     con539    22857.628917999999
    RHS_V     con1022   4000
    RHS_V     con166    -1583.9390000000001
    RHS_V     con572    -1509.4570000000001
    RHS_V     con434    14501
    RHS_V     con652    14500
    RHS_V     con1029   3500
    RHS_V     con1005   6000
    RHS_V     con549    22634.182676
    RHS_V     con681    14501
    RHS_V     con837    29000
    RHS_V     con220    29000
    RHS_V     con776    -6137.6435000000001
    RHS_V     con876    29000
    RHS_V     con388    14500
    RHS_V     con867    29000
    RHS_V     con1020   4000
    RHS_V     con1030   3500
    RHS_V     con160    7000
    RHS_V     con689    14501
    RHS_V     con855    29000
    RHS_V     con1000   6000
    RHS_V     con993    6000
    RHS_V     con1039   1
    RHS_V     con683    14501
    RHS_V     con557    -1583.9390000000001
    RHS_V     con186    -1583.9390000000001
    RHS_V     con1031   3500
    RHS_V     con529    22634.182676
    RHS_V     con202    29000
    RHS_V     con440    14501
    RHS_V     con773    -6068.9979999999996
    RHS_V     con870    29000
    RHS_V     con657    14500
    RHS_V     con561    -1583.9390000000001
    RHS_V     con198    29000
    RHS_V     con552    22634.182676
    RHS_V     con398    14500
    RHS_V     con366    14500
    RHS_V     con693    14501
    RHS_V     con411    14500
    RHS_V     con165    -1583.9390000000001
    RHS_V     con618    14500
    RHS_V     con218    29000
    RHS_V     con562    -1583.9390000000001
    RHS_V     con744    -6068.9979999999996
    RHS_V     con1015   3500
    RHS_V     con212    29000
    RHS_V     con177    -1509.4570000000001
    RHS_V     con403    14500
    RHS_V     con230    29000
    RHS_V     con381    14500
    RHS_V     con897    29000
    RHS_V     con46     8000
    RHS_V     con775    -6068.9979999999996
    RHS_V     con661    14500
    RHS_V     con56     8000
    RHS_V     con525    -14081.143184
    RHS_V     con456    14501
    RHS_V     con671    14501
    RHS_V     con637    14500
    RHS_V     con1043   1
    RHS_V     con707    14501
    RHS_V     con620    14500
    RHS_V     con1008   6000
    RHS_V     con162    -222.34033332999999
    RHS_V     con34     7000
    RHS_V     con400    14500
    RHS_V     con394    14500
    RHS_V     con989    6000
    RHS_V     con810    29000
    RHS_V     con636    14500
    RHS_V     con816    29000
    RHS_V     con986    6000
    RHS_V     con504    -14081.143184
    RHS_V     con1054   1
    RHS_V     con1035   2
    RHS_V     con1021   4000
    RHS_V     con643    14500
    RHS_V     con395    14500
    RHS_V     con428    14501
    RHS_V     con1059   1
    RHS_V     con691    14501
    RHS_V     con189    -1491.66666667
    RHS_V     con442    14501
    RHS_V     con367    14500
    RHS_V     con660    14500
    RHS_V     con372    14500
    RHS_V     con80     7000
    RHS_V     con575    -1583.9390000000001
    RHS_V     con632    14500
    RHS_V     con72     7000
    RHS_V     con580    -1583.9390000000001
    RHS_V     con646    14500
    RHS_V     con412    14500
    RHS_V     con540    22857.628917999999
    RHS_V     con831    29000
    RHS_V     con238    29000
    RHS_V     con422    14501
    RHS_V     con424    14501
    RHS_V     con894    29000
    RHS_V     con32     7000
    RHS_V     con513    -13507.000312
    RHS_V     con626    14500
    RHS_V     con567    -1509.4570000000001
    RHS_V     con377    14500
    RHS_V     con663    14501
    RHS_V     con1056   1
    RHS_V     con536    22634.182676
    RHS_V     con506    -14081.143184
    RHS_V     con25     -12000
    RHS_V     con792    29000
    RHS_V     con242    29000
    RHS_V     con713    14501
    RHS_V     con563    -1583.9390000000001
    RHS_V     con182    -1583.9390000000001
    RHS_V     con389    14500
    RHS_V     con181    -1583.9390000000001
    RHS_V     con210    29000
    RHS_V     con234    29000
    RHS_V     con819    29000
    RHS_V     con1016   3500
    RHS_V     con501    -14081.143184
    RHS_V     con167    -1583.9390000000001
    RHS_V     con163    4423.87633333333
    RHS_V     con783    29000
    RHS_V     con168    -1583.9390000000001
    RHS_V     con432    14501
    RHS_V     con1038   1
    RHS_V     con642    14500
    RHS_V     con852    17400
    RHS_V     con183    -1583.9390000000001
    RHS_V     con450    14501
    RHS_V     con1058   1
    RHS_V     con438    14501
    RHS_V     con545    22634.182676
    RHS_V     con175    -1509.4570000000001
    RHS_V     con187    -1583.9390000000001
    RHS_V     con396    14500
    RHS_V     con82     12000
    RHS_V     con236    29000
    RHS_V     con906    29000
    RHS_V     con393    14500
    RHS_V     con216    29000
    RHS_V     con1052   1
    RHS_V     con384    14500
    RHS_V     con190    17400
    RHS_V     con66     12000
    RHS_V     con371    14500
    RHS_V     con204    29000
    RHS_V     con416    14500
    RHS_V     con1018   4000
    RHS_V     con426    14501
    RHS_V     con54     12000
    RHS_V     con410    14500
    RHS_V     con834    29000
    RHS_V     con1044   1
    RHS_V     con649    14500
    RHS_V     con1042   1
    RHS_V     con1034   2
    RHS_V     con631    14500
    RHS_V     con565    -1509.4570000000001
    RHS_V     con26     8000
    RHS_V     con774    29000
    RHS_V     con930    29000
    RHS_V     con524    -14081.143184
    RHS_V     con555    -1509.4570000000001
    RHS_V     con500    -13507.000312
    RHS_V     con569    -1509.4570000000001
    RHS_V     con882    29000
    RHS_V     con644    14500
    RHS_V     con542    22857.628917999999
    RHS_V     con376    14500
    RHS_V     con222    29000
    RHS_V     con566    -1509.4570000000001
    RHS_V     con697    14501
    RHS_V     con991    6000
    RHS_V     con996    6000
    RHS_V     con172    -1583.9390000000001
    RHS_V     con669    14501
    RHS_V     con178    -1509.4570000000001
    RHS_V     con997    6000
    RHS_V     con556    -1509.4570000000001
    RHS_V     con795    29000
    RHS_V     con984    20970.557000000001
    RHS_V     con503    -14081.143184
    RHS_V     con611    14500
    RHS_V     con502    -14081.143184
    RHS_V     con68     7000
    RHS_V     con383    14500
    RHS_V     con409    14500
    RHS_V     con677    14501
    RHS_V     con571    -1509.4570000000001
    RHS_V     con1023   4000
    RHS_V     con90     12000
    RHS_V     con404    14500
    RHS_V     con98     12000
    RHS_V     con813    29000
    RHS_V     con392    14500
    RHS_V     con1027   3500
    RHS_V     con408    14500
    RHS_V     con102    12000
    RHS_V     con370    14500
    RHS_V     con519    -14081.143184
    RHS_V     con675    14501
    RHS_V     con1036   2
    RHS_V     con537    22634.182676
    RHS_V     con573    -1583.9390000000001
    RHS_V     con988    6000
    RHS_V     con386    14500
    RHS_V     con574    -1583.9390000000001
    RHS_V     con1011   3500
    RHS_V     con927    29000
    RHS_V     con801    29000
    RHS_V     con1057   1
    RHS_V     con184    -1583.9390000000001
    RHS_V     con193    -6000
    RHS_V     con531    22634.182676
    RHS_V     con508    -14081.143184
    RHS_V     con499    -13507.000312
    RHS_V     con885    29000
    RHS_V     con159    12000
    RHS_V     con1007   6000
    RHS_V     con858    29000
    RHS_V     con822    29000
    RHS_V     con924    29000
    RHS_V     con28     7000
    RHS_V     con538    22857.628917999999
    RHS_V     con634    14500
    RHS_V     con639    14500
    RHS_V     con705    14501
    RHS_V     con570    -1509.4570000000001
    RHS_V     con624    14500
    RHS_V     con405    14500
    RHS_V     con214    29000
    RHS_V     con635    8700
    RHS_V     con843    29000
    RHS_V     con52     8000
    RHS_V     con179    -1509.4570000000001
    RHS_V     con778    -6137.6435000000001
    RHS_V     con987    6000
    RHS_V     con627    14500
    RHS_V     con196    29000
    RHS_V     con999    6000
    RHS_V     con695    14501
    RHS_V     con780    29000
    RHS_V     con76     7000
    RHS_V     con131    -12000
    RHS_V     con36     7000
    RHS_V     con391    14500
    RHS_V     con364    14500
    RHS_V     con471    3776
    RHS_V     con413    14500
    RHS_V     con517    -14081.143184
    RHS_V     con685    14501
    RHS_V     con610    14500
    RHS_V     con42     7000
    RHS_V     con169    -1583.9390000000001
    RHS_V     con414    14500
    RHS_V     con1001   6000
    RHS_V     con1002   6000
    RHS_V     con679    14501
    RHS_V     con176    -1509.4570000000001
    RHS_V     con466    14501
    RHS_V     con458    14501
    RHS_V     con62     12000
    RHS_V     con578    -1583.9390000000001
    RHS_V     con985    20970.557000000001
    RHS_V     con615    14500
    RHS_V     con518    -14081.143184
    RHS_V     con546    22634.182676
    RHS_V     con60     7000
    RHS_V     con171    -1583.9390000000001
    RHS_V     con510    -13507.000312
    RHS_V     con407    14500
    RHS_V     con558    -1583.9390000000001
    RHS_V     con430    14501
    RHS_V     con861    29000
    RHS_V     con640    14500
    RHS_V     con180    -1509.4570000000001
    RHS_V     con551    22634.182676
    RHS_V     con543    22857.628917999999
    RHS_V     con470    14501
    RHS_V     con192    29000
    RHS_V     con1009   6000
    RHS_V     con1053   1
    RHS_V     con789    29000
    RHS_V     con560    -1583.9390000000001
    RHS_V     con96     8000
    RHS_V     con535    22634.182676
    RHS_V     con804    29000
    RHS_V     con40     7000
    RHS_V     con512    -13507.000312
    RHS_V     con1047   1
    RHS_V     con699    14501
    RHS_V     con436    14501
    RHS_V     con191    -5933.3333333333303
    RHS_V     con1051   1
    RHS_V     con568    -1509.4570000000001
    RHS_V     con444    14501
    RHS_V     con379    14500
    RHS_V     con1033   3500
    RHS_V     con174    -1509.4570000000001
    RHS_V     con380    14500
    RHS_V     con771    17400
    RHS_V     con406    14500
    RHS_V     con185    -1583.9390000000001
    RHS_V     con521    -14081.143184
    RHS_V     con873    29000
    RHS_V     con70     12000
    RHS_V     con1019   4000
    RHS_V     con368    14500
    RHS_V     con659    14500
    RHS_V     con912    29000
    RHS_V     con74     12000
    RHS_V     con579    -1583.9390000000001
    RHS_V     con170    -1583.9390000000001
    RHS_V     con846    29000
    RHS_V     con656    14500
    RHS_V     con527    22857.628917999999
    RHS_V     con173    -1509.4570000000001
    RHS_V     con645    14500
    RHS_V     con633    14500
    RHS_V     con654    14500
    RHS_V     con92     8000
    RHS_V     con1024   4000
    RHS_V     con399    14500
    RHS_V     con900    29000
    RHS_V     con1004   6000
    RHS_V     con1012   3500
    RHS_V     con382    14500
    RHS_V     con745    -6137.6435000000001
    RHS_V     con224    29000
    RHS_V     con825    29000
    RHS_V     con550    22634.182676
    RHS_V     con577    -1583.9390000000001
    RHS_V     con84     7000
    RHS_V     con608    8700
    RHS_V     con58     12000
    RHS_V     con921    29000
    RHS_V     con888    29000
    RHS_V     con609    14500
    RHS_V     con743    -1511.5558569023599
    RHS_V     con240    29000
    RHS_V     con514    -13507.000312
    RHS_V     con374    14500
    RHS_V     con630    14500
    RHS_V     con520    -14081.143184
    RHS_V     con1037   1
    RHS_V     con226    29000
    RHS_V     con619    14500
    RHS_V     con1028   3500
    RHS_V     con522    -14081.143184
    RHS_V     con448    14501
    RHS_V     con100    8000
    RHS_V     con86     12000
    RHS_V     con532    22634.182676
    RHS_V     con1026   3500
    RHS_V     con511    -13507.000312
    RHS_V     con50     8000
    RHS_V     con446    14501
    RHS_V     con918    29000
    RHS_V     con1049   1
    RHS_V     con995    6000
    RHS_V     con990    6000
    RHS_V     con1050   1
    RHS_V     con206    29000
    RHS_V     con777    29000
    RHS_V     con1041   1
    RHS_V     con576    -1583.9390000000001
    RHS_V     con547    22634.182676
    RHS_V     con798    29000
    RHS_V     con509    -14081.143184
    RHS_V     con468    14501
    RHS_V     con534    22634.182676
    RHS_V     con650    14500
    RHS_V     con1045   1
    RHS_V     con516    -13507.000312
    RHS_V     con420    14501
    RHS_V     con188    -1583.9390000000001
    RHS_V     con673    14501
    RHS_V     con1014   3500
    RHS_V     con533    22634.182676
    RHS_V     con415    14500
    RHS_V     con554    -1714.0070000000001
    RHS_V     con616    14500
    RHS_V     con44     8000
    RHS_V     con1017   3500
    RHS_V     con641    14500
    RHS_V     con701    14501
    RHS_V     con715    14501
    RHS_V     con208    29000
    RHS_V     con770    -1511.5558569023599
    RHS_V     con460    14501
    RHS_V     con786    29000
    RHS_V     con38     7000
    RHS_V     con612    14500
    RHS_V     con194    29000
BOUNDS
 BV BOUND     x425    
 BV BOUND     x748    
 BV BOUND     x752    
 UP BOUND     x200      7000
 BV BOUND     x556    
 BV BOUND     x773    
 UP BOUND     x653      14500
 UP BOUND     x165      7000
 UP BOUND     x234      12000
 UP BOUND     x54       14500
 BV BOUND     x297    
 UP BOUND     x327      8700
 BV BOUND     x776    
 BV BOUND     x788    
 UP BOUND     x583      29000
 UP BOUND     x179      12000
 UP BOUND     x184      7000
 BV BOUND     x560    
 BV BOUND     x806    
 BV BOUND     x853    
 UP BOUND     x66       14500
 BV BOUND     x755    
 UI BOUND     x307      12
 BV BOUND     x409    
 BV BOUND     x838    
 UP BOUND     x214      7000
 UI BOUND     x316      7
 UP BOUND     x348      14500
 UP BOUND     x391      14500
 BV BOUND     x431    
 BV BOUND     x551    
 BV BOUND     x842    
 UP BOUND     x61       14500
 UP BOUND     x396      14500
 BV BOUND     x810    
 BV BOUND     x784    
 UP BOUND     x232      8000
 UP BOUND     x357      14500
 BV BOUND     x265    
 UP BOUND     x167      7000
 BV BOUND     x781    
 BV BOUND     x753    
 UI BOUND     x318      8
 BV BOUND     x405    
 BV BOUND     x271    
 UP BOUND     x209      6000
 BV BOUND     x823    
 UP BOUND     x366      14500
 UP BOUND     x55       14500
 UP BOUND     x63       14500
 UI BOUND     x324      8
 UP BOUND     x210      12000
 UP BOUND     x194      12000
 UP BOUND     x252      12000
 BV BOUND     x676    
 BV BOUND     x290    
 UP BOUND     x388      14500
 BV BOUND     x780    
 BV BOUND     x415    
 UP BOUND     x661      14500
 UP BOUND     x68       14500
 UP BOUND     x170      12000
 BV BOUND     x553    
 UP BOUND     x328      8700
 UP BOUND     x201      6000
 UP BOUND     x588      29000
 BV BOUND     x777    
 BV BOUND     x848    
 BV BOUND     x782    
 BV BOUND     x558    
 BV BOUND     x749    
 BV BOUND     x774    
 UI BOUND     x326      8
 UP BOUND     x233      6000
 BV BOUND     x285    
 UP BOUND     x256      8000
 BV BOUND     x421    
 UP BOUND     x181      3500
 BV BOUND     x540    
 BV BOUND     x847    
 UP BOUND     x199      7000
 UI BOUND     x311      12
 UP BOUND     x163      12000
 BV BOUND     x685    
 BV BOUND     x428    
 BV BOUND     x565    
 BV BOUND     x837    
 BV BOUND     x283    
 BV BOUND     x686    
 UP BOUND     x360      14500
 UP BOUND     x343      14500
 BV BOUND     x542    
 BV BOUND     x794    
 UP BOUND     x670      14500
 BV BOUND     x427    
 UP BOUND     x337      14500
 UP BOUND     x339      14500
 UP BOUND     x223      8000
 BV BOUND     x411    
 UP BOUND     x206      7000
 UP BOUND     x334      14500
 UP BOUND     x193      6000
 UP BOUND     x70       14500
 UI BOUND     x308      7
 BV BOUND     x764    
 UP BOUND     x205      3500
 BV BOUND     x274    
 BV BOUND     x851    
 BV BOUND     x690    
 UP BOUND     x572      29000
 BV BOUND     x808    
 UP BOUND     x216      7000
 BV BOUND     x750    
 UP BOUND     x191      7000
 UP BOUND     x231      8000
 BV BOUND     x284    
 BV BOUND     x770    
 UP BOUND     x658      14500
 BV BOUND     x288    
 BV BOUND     x554    
 BV BOUND     x775    
 UP BOUND     x332      14500
 UP BOUND     x569      29000
 BV BOUND     x828    
 UP BOUND     x71       14500
 UP BOUND     x160      12000
 UP BOUND     x239      8000
 UP BOUND     x65       14500
 UI BOUND     x309      12
 UP BOUND     x340      14500
 BV BOUND     x769    
 UP BOUND     x567      29000
 BV BOUND     x559    
 BV BOUND     x258    
 UP BOUND     x655      14500
 BV BOUND     x845    
 UI BOUND     x321      12
 UP BOUND     x270      12000
 UP BOUND     x238      8000
 BV BOUND     x795    
 UP BOUND     x213      3500
 UP BOUND     x400      14500
 UP BOUND     x349      14500
 UP BOUND     x378      14500
 UP BOUND     x212      12000
 BV BOUND     x277    
 UP BOUND     x333      14500
 BV BOUND     x809    
 BV BOUND     x675    
 BV BOUND     x855    
 BV BOUND     x697    
 BV BOUND     x276    
 UP BOUND     x402      14500
 UP BOUND     x221      3500
 BV BOUND     x826    
 UP BOUND     x178      12000
 BV BOUND     x811    
 UP BOUND     x582      29000
 UP BOUND     x659      14500
 BV BOUND     x802    
 UI BOUND     x306      7
 BV BOUND     x678    
 UP BOUND     x662      14500
 UP BOUND     x227      12000
 BV BOUND     x261    
 UP BOUND     x190      7000
 BV BOUND     x821    
 UI BOUND     x323      12
 BV BOUND     x827    
 BV BOUND     x688    
 BV BOUND     x418    
 BV BOUND     x423    
 UP BOUND     x648      8700
 UP BOUND     x171      12000
 UP BOUND     x672      14500
 UP BOUND     x674      14500
 BV BOUND     x563    
 UP BOUND     x586      29000
 UP BOUND     x237      4000
 UP BOUND     x577      29000
 UP BOUND     x52       8700
 BV BOUND     x295    
 BV BOUND     x566    
 BV BOUND     x414    
 UP BOUND     x218      12000
 UP BOUND     x247      8000
 UP BOUND     x272      8000
 UP BOUND     x235      12000
 BV BOUND     x564    
 BV BOUND     x850    
 UP BOUND     x364      14500
 UP BOUND     x208      7000
 BV BOUND     x259    
 BV BOUND     x260    
 UP BOUND     x578      29000
 UP BOUND     x64       14500
 BV BOUND     x268    
 BV BOUND     x846    
 UP BOUND     x369      14500
 BV BOUND     x839    
 BV BOUND     x257    
 BV BOUND     x275    
 BV BOUND     x801    
 BV BOUND     x694    
 UP BOUND     x159      6000
 BV BOUND     x763    
 UP BOUND     x346      14500
 UP BOUND     x195      12000
 UP BOUND     x664      14500
 UP BOUND     x580      29000
 BV BOUND     x696    
 BV BOUND     x785    
 BV BOUND     x293    
 UP BOUND     x587      29000
 BV BOUND     x849    
 UP BOUND     x245      4000
 BV BOUND     x701    
 UP BOUND     x574      29000
 BV BOUND     x772    
 BV BOUND     x264    
 UP BOUND     x243      12000
 UP BOUND     x376      14500
 UP BOUND     x176      7000
 UP BOUND     x183      7000
 BV BOUND     x266    
 BV BOUND     x793    
 UI BOUND     x304      7
 UP BOUND     x666      14500
 BV BOUND     x289    
 UP BOUND     x570      29000
 BV BOUND     x834    
 UP BOUND     x76       14500
 UP BOUND     x657      14500
 BV BOUND     x844    
 UP BOUND     x363      14500
 BV BOUND     x756    
 UP BOUND     x667      14500
 UP BOUND     x229      4000
 UP BOUND     x244      12000
 UP BOUND     x652      14500
 UP BOUND     x663      14500
 UP BOUND     x174      7000
 BV BOUND     x543    
 BV BOUND     x424    
 BV BOUND     x680    
 UI BOUND     x314      7
 UP BOUND     x354      14500
 UP BOUND     x394      14500
 UP BOUND     x669      14500
 BV BOUND     x292    
 BV BOUND     x555    
 BV BOUND     x412    
 UP BOUND     x384      14500
 BV BOUND     x262    
 BV BOUND     x416    
 BV BOUND     x786    
 UP BOUND     x67       14500
 UP BOUND     x352      14500
 UI BOUND     x302      7
 UP BOUND     x53       14500
 BV BOUND     x831    
 UP BOUND     x242      12000
 BV BOUND     x799    
 UP BOUND     x222      7000
 BV BOUND     x550    
 UP BOUND     x215      7000
 BV BOUND     x406    
 BV BOUND     x778    
 BV BOUND     x804    
 UI BOUND     x313      12
 BV BOUND     x278    
 BV BOUND     x819    
 BV BOUND     x822    
 UI BOUND     x300      8
 BV BOUND     x557    
 UP BOUND     x59       14500
 UP BOUND     x78       14500
 BV BOUND     x407    
 UP BOUND     x397      14500
 UP BOUND     x345      14500
 UP BOUND     x182      7000
 BV BOUND     x758    
 UP BOUND     x185      6000
 BV BOUND     x267    
 BV BOUND     x684    
 UP BOUND     x248      8000
 UP BOUND     x330      14500
 UP BOUND     x240      8000
 UP BOUND     x230      8000
 BV BOUND     x803    
 UP BOUND     x399      14500
 UP BOUND     x336      14500
 UP BOUND     x228      12000
 UP BOUND     x589      29000
 BV BOUND     x779    
 BV BOUND     x783    
 BV BOUND     x287    
 UP BOUND     x204      12000
 UP BOUND     x671      14500
 UP BOUND     x381      14500
 UP BOUND     x173      3500
 UP BOUND     x568      29000
 UP BOUND     x331      14500
 UP BOUND     x385      14500
 UP BOUND     x329      14500
 UP BOUND     x56       14500
 BV BOUND     x679    
 UP BOUND     x393      14500
 UP BOUND     x361      14500
 UI BOUND     x322      8
 BV BOUND     x294    
 UP BOUND     x217      6000
 BV BOUND     x420    
 BV BOUND     x296    
 BV BOUND     x691    
 UP BOUND     x342      14500
 BV BOUND     x692    
 UI BOUND     x325      12
 BV BOUND     x410    
 UP BOUND     x164      3500
 UP BOUND     x651      14500
 UP BOUND     x255      8000
 UP BOUND     x197      3500
 UP BOUND     x250      12000
 BV BOUND     x698    
 UP BOUND     x236      12000
 BV BOUND     x430    
 UP BOUND     x579      29000
 BV BOUND     x760    
 UP BOUND     x172      12000
 UP BOUND     x188      12000
 UP BOUND     x571      29000
 UP BOUND     x590      29000
 BV BOUND     x766    
 UP BOUND     x591      29000
 BV BOUND     x796    
 BV BOUND     x807    
 BV BOUND     x683    
 UP BOUND     x175      7000
 UP BOUND     x373      14500
 BV BOUND     x817    
 BV BOUND     x263    
 UI BOUND     x299      12
 UP BOUND     x403      14500
 UI BOUND     x320      8
 UP BOUND     x69       14500
 BV BOUND     x687    
 UI BOUND     x312      7
 BV BOUND     x682    
 BV BOUND     x771    
 UP BOUND     x387      14500
 BV BOUND     x792    
 UI BOUND     x305      12
 UP BOUND     x575      29000
 BV BOUND     x824    
 UP BOUND     x355      14500
 BV BOUND     x841    
 UP BOUND     x72       14500
 UP BOUND     x251      12000
 BV BOUND     x273    
 BV BOUND     x854    
 UP BOUND     x668      14500
 UP BOUND     x358      14500
 BV BOUND     x689    
 BV BOUND     x549    
 UP BOUND     x162      12000
 BV BOUND     x816    
 UP BOUND     x390      14500
 BV BOUND     x751    
 BV BOUND     x767    
 UP BOUND     x592      29000
 UP BOUND     x654      14500
 UP BOUND     x196      12000
 BV BOUND     x833    
 BV BOUND     x815    
 UP BOUND     x57       14500
 UP BOUND     x249      6000
 BV BOUND     x545    
 UP BOUND     x650      14500
 BV BOUND     x695    
 UP BOUND     x375      14500
 BV BOUND     x413    
 BV BOUND     x552    
 UP BOUND     x573      29000
 UP BOUND     x581      29000
 UI BOUND     x301      12
 UP BOUND     x649      14500
 UP BOUND     x187      12000
 UP BOUND     x177      6000
 BV BOUND     x417    
 BV BOUND     x681    
 UP BOUND     x351      14500
 UP BOUND     x189      3500
 BV BOUND     x814    
 UP BOUND     x60       14500
 UI BOUND     x317      12
 BV BOUND     x797    
 BV BOUND     x820    
 BV BOUND     x286    
 UP BOUND     x254      8000
 UP BOUND     x169      6000
 UI BOUND     x310      7
 BV BOUND     x813    
 UP BOUND     x192      7000
 BV BOUND     x291    
 UP BOUND     x220      12000
 BV BOUND     x759    
 UP BOUND     x576      29000
 UP BOUND     x75       14500
 BV BOUND     x419    
 BV BOUND     x544    
 BV BOUND     x269    
 UP BOUND     x253      4000
 BV BOUND     x812    
 BV BOUND     x754    
 UP BOUND     x379      14500
 UP BOUND     x202      12000
 BV BOUND     x547    
 BV BOUND     x787    
 BV BOUND     x790    
 BV BOUND     x832    
 UP BOUND     x207      7000
 BV BOUND     x835    
 UP BOUND     x73       14500
 UP BOUND     x58       14500
 UI BOUND     x315      12
 UI BOUND     x303      12
 UP BOUND     x673      14500
 UP BOUND     x367      14500
 UP BOUND     x74       14500
 BV BOUND     x789    
 UP BOUND     x226      12000
 BV BOUND     x281    
 BV BOUND     x677    
 UP BOUND     x186      12000
 BV BOUND     x280    
 BV BOUND     x426    
 UP BOUND     x660      14500
 BV BOUND     x541    
 BV BOUND     x693    
 UP BOUND     x593      29000
 UP BOUND     x382      14500
 UP BOUND     x665      14500
 BV BOUND     x768    
 BV BOUND     x561    
 BV BOUND     x800    
 UP BOUND     x246      8000
 UP BOUND     x180      12000
 BV BOUND     x791    
 BV BOUND     x818    
 BV BOUND     x546    
 BV BOUND     x562    
 UP BOUND     x372      14500
 UP BOUND     x370      14500
 UP BOUND     x161      12000
 BV BOUND     x836    
 UI BOUND     x319      12
 UP BOUND     x656      14500
 UP BOUND     x225      6000
 BV BOUND     x825    
 BV BOUND     x408    
 UP BOUND     x77       14500
 UP BOUND     x241      6000
 BV BOUND     x762    
 UP BOUND     x224      7000
 BV BOUND     x700    
 BV BOUND     x852    
 BV BOUND     x699    
 BV BOUND     x805    
 FX BOUND     x1        1
 UP BOUND     x62       14500
 BV BOUND     x429    
 BV BOUND     x798    
 UP BOUND     x211      12000
 BV BOUND     x765    
 BV BOUND     x282    
 UP BOUND     x219      12000
 BV BOUND     x829    
 UP BOUND     x168      8000
 UP BOUND     x198      7000
 BV BOUND     x279    
 UP BOUND     x585      29000
 BV BOUND     x761    
 BV BOUND     x830    
 BV BOUND     x757    
 BV BOUND     x298    
 BV BOUND     x548    
 BV BOUND     x840    
 UP BOUND     x203      12000
 BV BOUND     x422    
 UP BOUND     x584      29000
 BV BOUND     x843    
 UP BOUND     x166      8000
ENDATA
