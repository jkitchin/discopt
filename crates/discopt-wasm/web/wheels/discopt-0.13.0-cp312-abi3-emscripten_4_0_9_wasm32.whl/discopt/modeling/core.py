"""
discopt Modeling API

A clean, expressive Python API for formulating Mixed-Integer Nonlinear Programs.
Designed for:

- Readability: models look like the math
- JAX compatibility: expressions are traceable and JIT-compilable
- Rust interop: expression graphs map to the Rust DAG for structure detection
- LLM integration: the API doubles as the tool-calling schema for the formulation agent

Example::

    import discopt.modeling as dm

    m = dm.Model("blending")
    x = m.continuous("flow", shape=(3,), lb=0, ub=100)
    y = m.binary("active", shape=(2,))

    m.minimize(cost @ x + fixed_cost @ y)
    m.subject_to(A @ x <= b, name="mass_balance")
    m.subject_to(x[0] * x[1] <= 50 * y[0], name="bilinear_coupling")

    result = m.solve()
"""

from __future__ import annotations

import builtins as _builtins
import contextlib as _contextlib
import contextvars as _contextvars
import copy as _copy
import copyreg as _copyreg
import functools as _functools
import gc
import itertools as _itertools
import math
import os as _os
import re
import sys as _sys
import threading as _threading
import time as _time
import warnings
import warnings as _warnings
import weakref
from dataclasses import dataclass, field
from dataclasses import replace as _dc_replace
from enum import Enum
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Iterator,
    NamedTuple,
    Optional,
    Sequence,
    Union,
    cast,
    overload,
)

import numpy as np

from discopt.constants import SENTINEL_THRESHOLD as _SENTINEL_THRESHOLD


def _lp_spatial_fallback_enabled() -> bool:
    """#844 no-incumbent fallback to the LP-per-node spatial engine.

    **Default ON**; opt out with ``DISCOPT_LP_SPATIAL_FALLBACK=0``. It only ever fills
    in an incumbent the default path failed to find, on models the engine provably
    serves (pure-integer, minimize), so it cannot alter a solve that already produced
    one.

    **Graduation panel.** Load-gated idle machine (load 2.64, no process above 50%
    CPU), 60 s budget, interleaved off/on, 2 reps — byte-identical across reps:

    ==============  ===========  ====================  ==========
    instance        off          on                    wall ratio
    ==============  ===========  ====================  ==========
    tln4            no incumbent 19.6 (opt 8.3)        1.00x
    tln5            no incumbent 32.8 (opt 10.3)       1.00x
    tln6            no incumbent 50.4 (opt 15.3)       1.00x
    ball_mk2_30     no incumbent no incumbent          0.65x
    nvs04/06/09/15  certified    identical, certified  ~0.00x
    ==============  ===========  ====================  ==========

    ``gains=3  lost_incumbents=0  cert_regressions=0  overshoots=0  unsound=0
    false_primals=0``. Evidence: ``scratchpad/844_final_panel.log``.

    **What closed the overshoot.** The engine used to overrun by 1.38-1.67x here, and
    only when it ran *after* a primary solve in the same process — in isolation it
    honoured its budget to 1.00x. Phase-timing both contexts found the cause:
    ``model._solve_deadline`` is written once per ``solve_model`` and never cleared,
    so by the time this fallback runs (necessarily *after* a primary that spent its
    whole budget) that stash is in the past, and ``IncrementalMcCormickLP``'s #654
    guard declined to build the structure at all. The engine then silently degraded to
    the per-node cold build — no cuts, no feasibility pump — whose nodes are slow
    enough that a single one runs past the top-of-loop deadline poll. On tln5 at a
    21 s budget: 5 nodes in 43.8 s (2.08x, slowest node 42.4 s) versus 13158 nodes in
    21.0 s (1.00x, slowest node 0.04 s) once the engine passes its own deadline.
    A model whose structure declines for a genuine structural reason — e.g. an odd
    power over a root box straddling zero, whose envelope changes facet count across
    the sign change — makes the fallback refuse to run at all
    (``require_incremental``) rather than spend a whole reserve on a single root LP
    for nothing; measured at 61 s against a 21 s reserve on ball_mk2_30 back when its
    ``x_0**2`` monomial also declined. #861 has since admitted the even powers, so
    ball_mk2_30 now runs this path and produces a sound bound but still no incumbent —
    the remaining gap there is primal, not relaxation coverage.

    **Known cost.** The incumbents are *worse* than the ones the degraded cold path
    happened to report (tln4 19.6 vs 8.7, tln5 32.8 vs 15.1) — its slower, full-
    fidelity per-node relaxation gave its root dive better points. Those numbers came
    from runs that overran the budget by 1.38-1.67x, so they were never a legitimate
    baseline; against the actual default path all three are gains from *no incumbent*.
    Closing the remaining gap to the reference optima is primal-quality work, not a
    budget bug.

    **Incumbent quality is now measured (#862).** The panel above scored whether an
    incumbent *exists*, is sound and stays in budget — never how good it is, so
    nothing would have caught a change that halved incumbent quality. It does now:
    ``discopt_benchmarks/scripts/issue844_primal_quality_panel.py`` re-runs this exact
    OFF/ON differential and adds the primal gap to the reference optimum per instance,
    the corpus aggregate, and quality regressions ON vs OFF. The quality gap itself is
    still open: see ``docs/dev/lp-node-primal-quality.md`` for the measurement and for
    the two primal levers it falsified (a rounding flip, and a narrowing dive), whose
    common root cause is that the McCormick relaxation on this family is ~250x loose
    at the root, so no rounding-based heuristic reading it can do better.
    """
    import os as _os

    return _os.environ.get("DISCOPT_LP_SPATIAL_FALLBACK", "1") not in (
        "0",
        "",
        "false",
        "False",
        "off",
    )


def _lp_spatial_reserve_extension_enabled() -> bool:
    """#917: let the primary reclaim the #844 reserve once it holds an incumbent.

    The reserve above is deducted from the caller's ``time_limit`` for *every* model
    the fallback could serve, and spent only when the primary returns nothing. A
    primary that finds an incumbent and then hits its reduced deadline forfeits the
    slice outright — nobody spends it, and the caller is told ``time_limit`` at 65%
    of the limit they stated.

    **Entry measurement** (in-repo corpus, 19 in-scope instances, 60 s budget, each
    in an isolated subprocess; ``scratchpad/issue917_entry_panel_T60.json``):

    ===============  ===  =======================================================
    class            n    what happens
    ===============  ===  =======================================================
    certified        15   primary certifies inside 39 s; reserve never taken
    reserve-spent     1   nvs24: no incumbent — the #844 case, reserve is spent
    **forfeited**     3   nvs17/nvs19/nvs23: incumbent at ~39 s, 21 s discarded
    ===============  ===  =======================================================

    ``nvs18`` certifies at **38.9 s** of the 39 s primary budget — 0.1 s of margin —
    so the reserve is a latent certification regression on this whole family, not
    only a wall-clock waste.

    **Why the extension and not a bound merge.** The issue's other candidate was to
    spend the residual on the fallback anyway and keep the tighter of the two dual
    bounds. Its stated kill criterion — "if the merged bound is no tighter on a
    corpus panel, this buys nothing" — is met, on every instance of the class:

    ==========  =================  ================  =========
    instance    primary bound      reserve bound     tighter?
    ==========  =================  ================  =========
    nvs17       -1105.89           -5838.02          no
    nvs19       -1104.24           -16377.19         no
    nvs23       -1130.70           -57328.53         no
    ==========  =================  ================  =========

    The reserve's primal is worse too on every one (-1068.8 vs -1100.4, -931.2 vs
    -1097.6, none vs -1124.8). That is the documented ~250x root looseness of the
    McCormick relaxation on this family (see ``_lp_spatial_fallback_enabled`` and
    ``docs/dev/lp-node-primal-quality.md``), so the merge is dead on arrival and the
    budget belongs to the primary. Candidate 1 is recorded as falsified, not shipped.

    **Graduation panel** — every in-scope instance in both in-repo corpora across a
    uniform budget grid (6/9/13/20/30/45/60 s), OFF and ON run back-to-back per cell
    in isolated subprocesses. 133 cells; the extension fired in 15.
    ``discopt_benchmarks/scripts/issue917_reserve_extension_panel.py``, results in
    ``discopt_benchmarks/results/issue917_reserve_extension_panel.json``.

    *Cert-clean*: ``cert_regressions=0  lost_incumbents=0  unsound=0
    false_primals=0``. *Net-positive* (3-rep re-run of the cells where it fires):
    nvs18@45 s uncertified 0/3 -> **certified 3/3**; nvs18@30 s closed 92% of its dual
    gap (-783.8528 -> -778.8359 against an incumbent of -778.4), zero spread; nvs13@9 s
    certified 1/3. That panel graduated the flag default-ON.

    **RETRACTED 2026-08-01 — back to default OFF.** That graduation is void on the
    current tree, and the reason is not a flaw in the measurement but a change beneath
    it: #919 re-graduated the **#764 native spatial kernel to default-ON**, and the
    kernel now certifies exactly the instances the case rested on, long before the
    reduced budget can bind:

    ==========  =========================  =============================
    cell        pre-#919 (the case)        post-#919 (both arms)
    ==========  =========================  =============================
    nvs18@45 s  uncertified 0/3 -> 3/3     certifies in **5.4 s**
    nvs18@30 s  bound -783.85 -> -778.84   certifies in **5.2 s**
    nvs13@9 s   certified 1/3              certifies in **2.4 s**
    ==========  =========================  =============================

    Re-running the identical panel on the new base: **133 cells, the extension fired
    0 times** (``…_panel_postkernel.json``). It is inert, so ON vs OFF is a no-op — and
    a bound-changing flag with no measurable benefit defaults OFF (CLAUDE.md §5 bar 2).

    **Then the kernel was given its own reclaim point, and it re-graduated.** The gap
    above was that the kernel is one uninterruptible Rust call that never enters the
    Python node loops where ``_extend_budget_for_incumbent`` lives, so a kernel-routed
    solve forfeited the reserve outright — nvs17 at a 60 s budget spent 39.4 s in both
    arms, the 0.65xT signature exactly. ``SpatialTreeConfig.incumbent_time_extension``
    now mirrors that guard inside ``discopt-core``: the spatial tree pushes its own
    deadline out ONCE, and only while it already holds an incumbent.

    **Graduation panel, post-#919** (the same 133 cells — 19 in-scope instances across
    a 6/9/13/20/30/45/60 s grid, OFF/ON interleaved per cell in isolated subprocesses;
    ``…_panel_kernel.json``). The extension fired in **27** cells, and this time the
    probe could see it: the kernel now reports the reclaimed seconds through
    ``solver_stats``, without which the panel scored 0 firings on a run where the
    mechanism was demonstrably working.

    *Cert-clean*: ``cert_regressions=0  lost_incumbents=0  lost_bound=0  looser_bound=0
    worse_objective=0  unsound=0  false_primals=0``; no ON-arm bound above a reference
    optimum.

    *Net-positive*: **every one of the 27 firing cells improves the bound**, and six
    produce a bound where OFF had none at all (nvs19@6 s, nvs23@9/13 s, nvs24@9/13/20 s
    — scored as certification gains). Representative magnitudes:

    ==========  =====================  =====================
    cell        bound OFF              bound ON
    ==========  =====================  =====================
    nvs17@60 s  -1136.00               **-1100.40** (onto its incumbent)
    nvs19@60 s  -3838.44               **-2289.47** (40% tighter)
    nvs23@60 s  -23757.40              **-19262.40** (19% tighter)
    nvs24@60 s  -138238.27             **-111833.39** (19% tighter)
    nvs24@20 s  none                   **-174436.22**
    ==========  =====================  =====================

    Budget utilisation across the panel rises 0.176 -> 0.241: the caller's stated limit
    is actually spent rather than abandoned at 65%.

    **Honest cost.** Six cells overshoot where OFF did not, all at the two smallest
    budgets and all small (6.4 s of 6 s, 9.5 s of 9 s — 6-8%). That is the post-loop
    tail that always existed, now measured against the full limit instead of 0.65xT.

    **Default ON** after that panel; opt out with
    ``DISCOPT_LP_SPATIAL_RESERVE_EXTENSION=0``.
    """
    import os as _os

    return _os.environ.get("DISCOPT_LP_SPATIAL_RESERVE_EXTENSION", "1") not in (
        "0",
        "",
        "false",
        "False",
        "off",
    )


if TYPE_CHECKING:
    from discopt.modeling.indexed import IndexedParam, IndexedVar
    from discopt.modeling.sets import _SetBase
    from discopt.solver_tuning import SolverTuning

builtins_sum = _builtins.sum

# ─────────────────────────────────────────────────────────────
# Disjunction semantics
# ─────────────────────────────────────────────────────────────


class SelectorActivation(Enum):
    """How a disjunction's selector binary relates to its disjunct's predicate.

    This is the axis that decides whether an *unselected* disjunct's predicate
    may still happen to be true, and it is the axis every continuous /
    complementarity lowering has to dispatch on (issue #1123).

    Attributes
    ----------
    ONE_WAY : str
        ``y_k = 1 => x in S_k``. Nothing is asserted when ``y_k = 0``, so a
        deselected predicate may be true. The projection onto ``x`` is the
        union of the disjuncts.
    REIFIED : str
        ``y_k = 1 <=> x in S_k``. The selector *is* the truth value of the
        predicate, so ``y_k = 0`` forces ``x not in S_k`` — a strict complement,
        which needs an explicit negation policy (an epsilon or an exact open-set
        encoding) and changes the feasible set.
    """

    ONE_WAY = "one_way"
    REIFIED = "reified"


class SelectorCardinality(Enum):
    """How many of a disjunction's selectors may be active at once."""

    AT_LEAST_ONE = "at_least_one"  # sum_k y_k >= 1
    EXACTLY_ONE = "exactly_one"  # sum_k y_k == 1
    AT_MOST_ONE = "at_most_one"  # sum_k y_k <= 1


class DisjunctionSemantics(Enum):
    """The declared meaning of a disjunction.

    Each member is defined as the ``(activation, cardinality)`` pair it stands
    for, and every lowering branches on that pair rather than on the member
    name — so a new combination (e.g. an optional-mode disjunction, which is
    ``(ONE_WAY, AT_MOST_ONE)``) is an added member and not a redefinition of
    what the enum means.

    The member's ``value`` **is** that pair, so the axes are carried by the
    member itself rather than by a side table that could drift out of sync. A
    lowering asks ``(sem.activation, sem.cardinality)`` what it must emit; it
    never asks which member it was handed.

    Attributes
    ----------
    SELECT_ONE : tuple
        ``(ONE_WAY, EXACTLY_ONE)``. Exactly one disjunct is *selected*; an
        unselected disjunct's predicate may nonetheless be true. This is the
        default meaning of :meth:`Model.either_or`, implemented by every lowering.
    OR : tuple
        ``(ONE_WAY, AT_LEAST_ONE)``. At least one disjunct is selected. Its
        projection onto ``x`` equals ``SELECT_ONE``'s; the two differ only in
        the selector space. Lowered by big-M (and ``auto``, which routes it
        there) and by ``add_disjunction``; hull and mbigm refuse it (#1775 G1.4).
    EXACTLY_ONE_TRUE : tuple
        ``(REIFIED, EXACTLY_ONE)``. Exactly one *predicate* is true, which
        requires full reification of every selector. Deliberately **not**
        called ``XOR``: over three or more operands XOR is odd parity, not
        "exactly one true", and this codebase already uses ``xor`` for the
        pairwise Boolean operator (the GAMS ``boolxor`` opcode).

    Notes
    -----
    ``SELECT_ONE`` and ``EXACTLY_ONE_TRUE`` are a *semantic* distinction, not a
    convexity one: with ``S_1 = {x <= 1}`` and ``S_2 = {x >= 0}``, the point
    ``x = 1/2`` is feasible under ``SELECT_ONE`` and infeasible under
    ``EXACTLY_ONE_TRUE`` — and the same holds verbatim for nonconvex ``S_k``.

    The lowercase spelling (``"select_one"``) is accepted wherever a semantics
    is passed, and is what :attr:`label` returns; it is a *coercion alias*, not
    the member's value.
    """

    SELECT_ONE = (SelectorActivation.ONE_WAY, SelectorCardinality.EXACTLY_ONE)
    OR = (SelectorActivation.ONE_WAY, SelectorCardinality.AT_LEAST_ONE)
    EXACTLY_ONE_TRUE = (SelectorActivation.REIFIED, SelectorCardinality.EXACTLY_ONE)

    @property
    def activation(self) -> SelectorActivation:
        """The selector/predicate activation direction this semantics implies."""
        return self.value[0]

    @property
    def cardinality(self) -> SelectorCardinality:
        """The selector cardinality this semantics implies."""
        return self.value[1]

    @property
    def label(self) -> str:
        """The lowercase string spelling accepted by the ``semantics=`` argument."""
        return self.name.lower()


def _coerce_disjunction_semantics(value) -> DisjunctionSemantics:
    """Accept a :class:`DisjunctionSemantics` or its string name.

    Rejects ``"xor"`` explicitly: Pyomo.GDP spells select-one semantics
    ``Disjunction(xor=True)``, which is precisely the ambiguity this enum
    exists to remove, so the spelling is refused rather than silently mapped.
    """
    if isinstance(value, DisjunctionSemantics):
        return value
    if isinstance(value, str):
        key = value.strip().lower()
        if key in ("xor", "truth_xor"):
            raise ValueError(
                f"semantics={value!r} is ambiguous and is not accepted. Over three or "
                "more disjuncts 'xor' means odd parity, not 'exactly one true'; and "
                "Pyomo.GDP's Disjunction(xor=True) means select-one. Use "
                "DisjunctionSemantics.SELECT_ONE (exactly one disjunct *selected*, the "
                "default) or DisjunctionSemantics.EXACTLY_ONE_TRUE (exactly one "
                "*predicate* true, requiring full reification)."
            )
        try:
            # Members are keyed by name: the value is the (activation,
            # cardinality) pair, so the string spelling is a coercion alias.
            return DisjunctionSemantics[key.upper()]
        except KeyError:
            pass
    allowed = ", ".join(repr(s.label) for s in DisjunctionSemantics)
    raise ValueError(f"unknown disjunction semantics {value!r}; use one of: {allowed}")


# ── Pair-based dispatch, shared by every lowering ──
#
# A lowering never asks *which member* it was handed; it declares the
# ``(activation, cardinality)`` its rows encode and serves a disjunction iff the
# declared semantics carries that pair. Keeping one predicate here means the
# immediate lowerings in this module and the GDP pass in ``_relax`` cannot drift
# apart on what "supported" means.

# The pair emitted by one-way activation under ``sum_k y_k == 1`` — what
# ``Model.add_disjunction`` (``if_then`` + ``exactly(1)``) and every
# reformulation in ``_relax.gdp_reformulate`` actually build.
_SELECT_ONE_ROWS: frozenset[tuple[SelectorActivation, SelectorCardinality]] = frozenset(
    {(SelectorActivation.ONE_WAY, SelectorCardinality.EXACTLY_ONE)}
)

# #1775 G1.4: ``add_disjunction`` also emits OR -- the same one-way rows under
# ``sum_k y_k >= 1`` (``at_least(1)``), or ``>= parent`` with ``y_k <= parent``
# when nested in a Disjunct.
_BLOCK_ROWS: frozenset[tuple[SelectorActivation, SelectorCardinality]] = (
    _SELECT_ONE_ROWS | frozenset({(SelectorActivation.ONE_WAY, SelectorCardinality.AT_LEAST_ONE)})
)


def _semantics_pair(
    semantics: DisjunctionSemantics,
) -> tuple[SelectorActivation, SelectorCardinality]:
    """The ``(activation, cardinality)`` pair *semantics* stands for."""
    return (semantics.activation, semantics.cardinality)


def _semantics_supported_by(
    semantics: DisjunctionSemantics,
    supported: frozenset[tuple[SelectorActivation, SelectorCardinality]],
) -> bool:
    """True when rows encoding one of *supported* mean exactly *semantics*."""
    return _semantics_pair(semantics) in supported


def _require_semantics_supported(
    semantics: DisjunctionSemantics,
    supported: frozenset[tuple[SelectorActivation, SelectorCardinality]],
    where: str,
) -> None:
    """Refuse a declared semantics whose pair *where* does not emit.

    Substituting a different pair would hand back a different feasible set than
    the model declares and then certify it, so this refuses rather than
    approximating (issue #1124).
    """
    if _semantics_supported_by(semantics, supported):
        return
    emitted = ", ".join(sorted(f"({a.value}, {c.value})" for a, c in supported))
    raise NotImplementedError(
        f"{where} declares DisjunctionSemantics.{semantics.name} "
        f"({semantics.activation.value}, {semantics.cardinality.value}), which is not "
        f"implemented. This path emits {emitted} only; that is not a valid "
        "substitute, since a different (activation, cardinality) pair has a "
        "different feasible set. Tracking issue: "
        "https://github.com/jkitchin/discopt/issues/1124"
    )


# Reserved namespace for compiler-generated existential auxiliaries. A user
# Boolean identity may never take it (see ``Model._check_name``) and the GDP
# pass allocates only inside it, so the two kinds of Boolean stay separable by
# name — which is what AC-5 of issue #1124 requires and what name-based result
# mapping relies on.
GDP_AUX_PREFIX = "_gdp_aux_"


# ─────────────────────────────────────────────────────────────
# Variable Types
# ─────────────────────────────────────────────────────────────


class VarType(Enum):
    """
    Variable domain type.

    Attributes
    ----------
    CONTINUOUS : str
        Real-valued variable (default bounds: ``[-9.999e19, 9.999e19]``).
    BINARY : str
        Binary variable restricted to ``{0, 1}``.
    INTEGER : str
        General integer variable. A user-supplied ``lb``/``ub`` is never
        replaced by a default; a fractional one is stored as the integer range
        it admits (#2252, see :meth:`Model.integer`). An *unspecified* bound
        falls back to the finite defaults
        ``[0, 1e6]`` and emits a ``UserWarning`` (see :meth:`Model.integer`),
        because a silent default box can cut a true optimum that lies below 0
        or above 1e6 (correctness issue C-6).
    """

    CONTINUOUS = "continuous"
    BINARY = "binary"
    INTEGER = "integer"


# Finite fallback bounds for a general-integer variable whose lb/ub is left
# unspecified. B&B requires a bounded integer domain, so we substitute these —
# but LOUDLY (a UserWarning names the variable and the imposed range) rather
# than silently truncating the user's problem (correctness issue C-6). A
# user-provided bound is always honored exactly and never replaced by these.
_INTEGER_DEFAULT_LB = 0.0
_INTEGER_DEFAULT_UB = 1e6
#: The ``discopt`` package directory, with a trailing separator: a bound written
#: from a file under it is discopt's own write, not the caller's (#2281,
#: ``Variable._caller_wrote_side``).
_DISCOPT_PACKAGE_DIR = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))) + _os.sep


# ─────────────────────────────────────────────────────────────
# Expression System
#
# All operations on Variables produce Expression objects that
# build a DAG. This DAG is later compiled to:
#   (1) A Rust-side expression graph for structure detection
#   (2) A JAX-traceable function for evaluation and autodiff
# ─────────────────────────────────────────────────────────────


# Sentinel for "static shape not yet computed" on a composite node, so a cached
# ``None`` ("computed, but unknowable") is distinguishable from "never computed"
# (M8 shape inference). A unique object, never a valid shape.
_UNSET_SHAPE: Any = object()


#: Per-thread count of open children-first pickling scopes. A scope opens when a
#: model (``Model.__getstate__``) or a top-level expression starts listing its nodes
#: children-first, and closes when the pickler reaches the ``_ChildrenFirstEnd``
#: sentinel at the end of that list -- by then every listed node has been written.
#: While one is open, nodes reduce plainly: their children are already memoised.
#:
#: A pickle that raises partway never reaches its sentinel. The sentinel then
#: closes the scope when it is freed (``_ChildrenFirstEnd.__del__``), which is when
#: the pickler drops the list on unwinding; so does a reduce result that is built
#: and discarded unpickled. Before that, a raised pickle left its scope open on the
#: thread for good, and every later expression on that thread pickled the plain
#: recursive way -- a ``RecursionError`` past a few thousand nested nodes. Under
#: xdist that made deep-pickle tests fail whenever an earlier test on the same
#: worker had pickled something unpicklable on purpose. (A per-node record, tried
#: first -- a weakref per node -- made every model pickle about 50% slower.)
#:
#: The count lives in a per-thread ``_ScopeCount`` cell that each sentinel holds, so
#: a sentinel freed on another thread closes the scope of the thread that opened it.
_PICKLE_SCOPES = _threading.local()


class _ScopeCount:
    """One thread's number of open children-first pickling scopes."""

    __slots__ = ("n",)

    def __init__(self) -> None:
        self.n = 0


def _scope_count() -> _ScopeCount:
    c = getattr(_PICKLE_SCOPES, "count", None)
    if c is None:
        c = _PICKLE_SCOPES.count = _ScopeCount()
    return c


#: Layout of what ``Model.__getstate__`` writes and ``Model.__setstate__`` reads.
#: Bump it with any change to either; an unpickle across a different value is
#: refused (see the pickling notes on ``Model``).
_MODEL_PICKLE_FORMAT = 1


def _children_first_scope_open() -> bool:
    c = getattr(_PICKLE_SCOPES, "count", None)
    return c is not None and c.n > 0


def _open_children_first_scopes() -> int:
    """Children-first pickling scopes open on this thread (0 between pickles)."""
    c = getattr(_PICKLE_SCOPES, "count", None)
    return 0 if c is None else c.n


def _open_children_first_scope() -> "_ChildrenFirstEnd":
    c = _scope_count()
    c.n += 1
    return _ChildrenFirstEnd(c)


def _unpickled_scope_end() -> None:
    return None


#: The state key a top-level expression's children-first list rode in before WP-7
#: (#1804). A lone expression pickled by that code still unpickles with the list
#: in its root's ``__dict__`` -- the per-node ``__setstate__`` that stripped it is
#: gone -- so the copy and pickle paths drop it from the state they hand on, and
#: the residue lasts only until the node's next copy or pickle.
_LEGACY_CHILDREN_FIRST_KEY = "_pickle_children_first"


def _without_legacy_children_first(rv: tuple) -> tuple:
    """*rv* (an ``object.__reduce_ex__`` result) with the pre-WP-7 key left out of
    its state. Only called when the key is present; the node is not modified."""
    state = {k: v for k, v in rv[2].items() if k != _LEGACY_CHILDREN_FIRST_KEY}
    return (rv[0], rv[1], state, *rv[3:])


def _new_after_children(cls: "type[Expression]", _children_first: list) -> "Expression":
    """Unpickle side of ``Expression.__reduce_ex__``: the argument list held the
    node's descendants, already rebuilt and memoised; the node itself starts empty
    and receives its state the default way."""
    return cls.__new__(cls)


class _ChildrenFirstEnd:
    """Last item of a children-first node list; closes its scope when pickled, or
    when freed unpickled (the pickle raised, or the reduce result was discarded).
    Closes at most once."""

    __slots__ = ("_count",)

    def __init__(self, count: _ScopeCount) -> None:
        self._count: Optional[_ScopeCount] = count

    def _close(self) -> None:
        c = self._count
        if c is not None:
            self._count = None
            c.n = max(0, c.n - 1)

    def __reduce__(self):
        self._close()
        return (_unpickled_scope_end, ())

    def __del__(self) -> None:
        self._close()


def _descendants_children_first(root: "Expression", skip: "Optional[dict]" = None) -> list:
    """Every expression node below *root* (and *root* last), children before parents.

    A node whose ``id`` is in *skip* (a deepcopy memo) is left out with its subtree.
    """
    from discopt.serialize import _children  # serialize imports this module

    order: list = []
    pending: set[int] = set()
    stack: list = [(root, False)]
    while stack:
        node, expanded = stack.pop()
        if expanded:
            order.append(node)
            continue
        if not isinstance(node, Expression) or id(node) in pending:
            continue
        if skip is not None and id(node) in skip:
            continue
        pending.add(id(node))
        stack.append((node, True))
        stack.extend((ch, False) for ch in reversed(_children(node)))
    return order


def _copy_node_into_memo(node: "Expression", memo: dict) -> None:
    """Deep-copy one node whose children are already in *memo*, by the default mechanism.

    This is ``copy.deepcopy``'s own path for an object without ``__deepcopy__``
    (``object.__reduce_ex__`` + ``copy._reconstruct``). A caller that has already
    visited the nodes children-first (``Model.__deepcopy__``) calls it directly
    rather than ``copy.deepcopy(node, memo)``, which would dispatch to
    ``Expression.__deepcopy__`` and re-walk each node's (all memo-hit) children
    once per node (#1822).
    """
    rv = object.__reduce_ex__(node, 4)
    if type(rv[2]) is dict and _LEGACY_CHILDREN_FIRST_KEY in rv[2]:
        rv = _without_legacy_children_first(rv)
    y = _copy._reconstruct(node, memo, *rv)
    if y is not node:
        memo[id(node)] = y
        _copy._keep_alive(node, memo)


class Expression:
    """
    Base class for all mathematical expressions in a discopt model.

    Supports standard arithmetic (``+``, ``-``, ``*``, ``/``, ``**``),
    comparison operators (``<=``, ``>=``, ``==``) that produce
    :class:`Constraint` objects, and mathematical functions via the
    ``discopt.modeling`` namespace (``dm.exp``, ``dm.log``, ``dm.sin``, etc.).

    Expressions are lazy -- they build a directed acyclic graph (DAG) that
    is later compiled to a JAX-traceable function for evaluation and autodiff,
    and to a Rust-side expression graph for structure detection.

    Notes
    -----
    Do not instantiate ``Expression`` directly. Expressions are created by
    declaring variables with :meth:`Model.continuous`, :meth:`Model.binary`,
    or :meth:`Model.integer`, and then combining them with arithmetic
    operators and math functions.
    """

    # Tell NumPy to defer to our __matmul__/__rmatmul__ (and other dunder
    # operators) when any Expression appears alongside an ndarray. Without
    # this, ``A @ x`` and ``c @ (xp - xm)`` route through numpy's matmul
    # gufunc, which sees the Expression as a 0-d object and raises
    # ``ValueError: Input operand 1 does not have enough dimensions``.
    __array_ufunc__ = None

    # ``copy.deepcopy`` and ``pickle`` walk an object graph recursively, a few
    # interpreter frames per level, so an expression a loop built (``e = e + x[i]``)
    # -- a chain as deep as the loop is long -- raised ``RecursionError`` at a few
    # thousand terms when copied or pickled on its own. Both memoise, so the fix is
    # to visit the nodes children-first: every node then meets its children as memo
    # hits and the nesting never exceeds one level. Each node is still copied or
    # pickled by the default mechanism (``object.__reduce_ex__``), so the result is
    # the same object graph the default produced -- only the order differs.
    # ``Model.__deepcopy__`` / ``Model.__getstate__`` do the same for a whole model.

    def __deepcopy__(self, memo: dict) -> "Expression":
        for node in _descendants_children_first(self, skip=memo):
            if id(node) not in memo:
                _copy_node_into_memo(node, memo)
        return cast("Expression", memo[id(self)])

    # The default shallow copy, spelled out so it does not go through the
    # children-first ``__reduce_ex__`` below (which walks the whole subtree).
    def __copy__(self) -> "Expression":
        rv = object.__reduce_ex__(self, 4)
        if type(rv[2]) is dict and _LEGACY_CHILDREN_FIRST_KEY in rv[2]:
            rv = _without_legacy_children_first(rv)
        return cast("Expression", _copy._reconstruct(self, None, *rv))

    # Pickling: the pickler has no memo to pre-fill, so the outermost expression
    # carries its descendants, children first, in the *arguments* of its
    # constructor call; the pickler writes those before the node, and so before
    # anything that refers to them. Inside such a scope -- this one, or a model's
    # (``Model.__getstate__``) -- nodes reduce plainly, so the walk happens once per
    # pickle, not once per node. (The list rode in the node's state until WP-7;
    # stripping it back out took a Python ``__setstate__`` call on every node of
    # every unpickle, where the arguments are simply dropped.)
    def __reduce_ex__(self, protocol: int):  # type: ignore[override]
        rv = object.__reduce_ex__(self, protocol)
        if len(rv) > 2 and type(rv[2]) is dict and _LEGACY_CHILDREN_FIRST_KEY in rv[2]:
            rv = _without_legacy_children_first(rv)
        if _children_first_scope_open():
            return rv
        if not isinstance(rv, tuple) or len(rv) < 3:
            return rv
        # Protocol >= 2 builds the node with ``copyreg.__newobj__(cls)``, 0 and 1
        # with ``copyreg._reconstructor(cls, object, None)``; either is
        # ``cls.__new__(cls)``, which is what replaces it below.
        plain = (rv[0] is _copyreg.__newobj__ and rv[1] == (type(self),)) or (
            rv[0] is _copyreg._reconstructor and rv[1] == (type(self), object, None)
        )
        if not plain:
            return rv
        below = _descendants_children_first(self)[:-1]
        if not below:
            return rv
        args = (type(self), [*below, _open_children_first_scope()])
        return (_new_after_children, args, *rv[2:])

    # Cached static shape for composite nodes (populated at construction by
    # ``BinaryOp``/``UnaryOp`` where inferable; see M8). Class default of the
    # ``_UNSET_SHAPE`` sentinel means "not computed" so a cached ``None``
    # ("computed, unknown") is distinguishable. Leaf nodes (Variable/Constant/
    # Parameter) carry their own ``.shape`` and are handled in ``_known_shape``.
    #
    # NOT slotted, deliberately. Slotting these classes was measured (#1215) and
    # is a dead end: retained memory moved 144.9 -> 143.1 MB (1.2%) on the
    # 200 000-row panel with no time change, because CPython 3.12 already gives
    # same-shape instances a key-sharing dict, so the per-node ``__dict__`` an
    # earlier reading blamed for ~104 B/node costs almost nothing. Slots would
    # buy that 1% at the price of forbidding attribute assignment on any
    # Expression subclass, including in plugins.
    _shape: Any = _UNSET_SHAPE

    # Each operator inlines ``_wrap``'s Expression check rather than calling it.
    # Measured (#1215): ``_wrap`` was 750 000 calls on a 200 000-row build, and in
    # the common ``x[i] * y[i]`` shape the operand is *already* an Expression, so
    # the call did nothing but an ``isinstance``. A Python-level call is the
    # expensive part; ``isinstance`` is a C call. Construction is 35 function
    # calls per row and that count is the budget, so the duplication is worth it
    # here -- and only here.

    # An object-dtype ndarray operand takes the elementwise branch (issue #1234).
    # ``__array_ufunc__ = None`` sends ``arr * x`` here instead of letting numpy
    # loop, and ``_wrap`` then tried to build ONE ``Constant`` out of an array of
    # Expressions -- which surfaced as numpy's ``ValueError: setting an array
    # element with a sequence``, naming neither the operand nor the fix.
    #
    # The dispatch is an EXCEPTION, not an ``isinstance`` test here, and the cost
    # is why. The obvious spelling -- a third branch reading
    # ``isinstance(other, np.ndarray) and other.dtype == object`` before calling
    # ``_wrap`` -- was written first and measured: +2.7% on ``x[i] * 2.0`` at 3.0
    # sigma over 20 interleaved reps, and +9.9% at 3.6 sigma on ``x * ndarray``.
    # Small, but real, and on the path #1215 spent its budget on: a scalar literal
    # operand is ~3 of the 35 calls per row and pays that test on every one.
    # Moving the test into ``_wrap``'s Constant fallback puts it where only a
    # genuine array operand reaches it -- an interned literal returns before it --
    # and CPython 3.11+ exception tables make an untaken ``except`` free.
    #
    # Measured three ways in one container, 20 interleaved reps each, warm-up
    # dropped, loadavg 0.21-0.26 at every arm (ratio against the pre-fix tree):
    #
    #     arm                     explicit test      this version
    #     x[i] * y[i]             0.989 (-2.3 sd)    1.007 (+0.8 sd)
    #     x[i] * 2.0              1.022 (+3.3 sd)    0.990 (-1.3 sd)
    #     x * ndarray             1.127 (+2.8 sd)    1.148 (+3.9 sd)
    #
    # So this version buys the scalar-literal path back and makes the genuine
    # array operand ~15% slower instead. That is the right way round and not a
    # close call: the literal is ~3 of the 35 calls PER ROW, while an array
    # operand appears once per constraint FORM -- 40 of them against 200 000 rows
    # on the #1215 panel, and ~0.2 us each, so ~8 us total. Whole-model wall
    # cannot resolve either effect; do not try to re-measure this there.
    #
    # The narrow ``try`` is deliberate: it wraps ONLY ``_wrap``, never the
    # ``BinaryOp`` construction after it, because ``BinaryOp`` legitimately raises
    # ``ValueError`` on a shape mismatch (``_broadcast_shapes``) and swallowing
    # that into the elementwise branch would turn a rejected model into a silently
    # reshaped one.

    def __add__(self, other):
        if isinstance(other, Expression):
            return BinaryOp("+", self, other)
        try:
            rhs = _wrap(other)
        except _ObjectArrayOperand:
            return _object_array_binop("+", self, other)
        return BinaryOp("+", self, rhs)

    def __radd__(self, other):
        if isinstance(other, Expression):
            return BinaryOp("+", other, self)
        try:
            lhs = _wrap(other)
        except _ObjectArrayOperand:
            return _object_array_binop("+", other, self)
        return BinaryOp("+", lhs, self)

    def __sub__(self, other):
        if isinstance(other, Expression):
            return BinaryOp("-", self, other)
        try:
            rhs = _wrap(other)
        except _ObjectArrayOperand:
            return _object_array_binop("-", self, other)
        return BinaryOp("-", self, rhs)

    def __rsub__(self, other):
        if isinstance(other, Expression):
            return BinaryOp("-", other, self)
        try:
            lhs = _wrap(other)
        except _ObjectArrayOperand:
            return _object_array_binop("-", other, self)
        return BinaryOp("-", lhs, self)

    def __mul__(self, other):
        if isinstance(other, Expression):
            return BinaryOp("*", self, other)
        try:
            rhs = _wrap(other)
        except _ObjectArrayOperand:
            return _object_array_binop("*", self, other)
        return BinaryOp("*", self, rhs)

    def __rmul__(self, other):
        if isinstance(other, Expression):
            return BinaryOp("*", other, self)
        try:
            lhs = _wrap(other)
        except _ObjectArrayOperand:
            return _object_array_binop("*", other, self)
        return BinaryOp("*", lhs, self)

    def __truediv__(self, other):
        if isinstance(other, Expression):
            return BinaryOp("/", self, other)
        try:
            rhs = _wrap(other)
        except _ObjectArrayOperand:
            return _object_array_binop("/", self, other)
        return BinaryOp("/", self, rhs)

    def __rtruediv__(self, other):
        if isinstance(other, Expression):
            return BinaryOp("/", other, self)
        try:
            lhs = _wrap(other)
        except _ObjectArrayOperand:
            return _object_array_binop("/", other, self)
        return BinaryOp("/", lhs, self)

    def __pow__(self, other):
        if isinstance(other, Expression):
            return BinaryOp("**", self, other)
        try:
            rhs = _wrap(other)
        except _ObjectArrayOperand:
            return _object_array_binop("**", self, other)
        return BinaryOp("**", self, rhs)

    def __rpow__(self, other):
        if isinstance(other, Expression):
            return BinaryOp("**", other, self)
        try:
            lhs = _wrap(other)
        except _ObjectArrayOperand:
            return _object_array_binop("**", other, self)
        return BinaryOp("**", lhs, self)

    def __neg__(self):
        return UnaryOp("neg", self)

    def __abs__(self):
        return UnaryOp("abs", self)

    # ── Reductions over a shaped expression (issue #1235) ──
    #
    # Each emits ONE n-ary node, so the DAG *as constructed* is a constant depth
    # independent of ``len(xs)``, and carries one node where the builtin
    # ``sum(xs)`` -- the only route before -- carries ``n-1`` ``BinaryOp`` objects
    # nested ``n`` deep. ``np.sum(xs)`` cannot serve instead: it reduces through
    # ``np.add.reduce``, which ``__array_ufunc__ = None`` refuses by design, so
    # defining ``.sum`` is also what makes numpy's reduction protocol reach us.
    #
    # What this does NOT claim: a left-deep fold can still appear *downstream*,
    # because the array scalarizer expands a reduction into one (performance-plan
    # §54, where depth-n folds raised ``RecursionError`` out of the LP/MPS/GAMS
    # writers for n >= 1000). This removes the depth the modeling layer builds;
    # it does not change what scalarization later produces.
    #
    # These are plain methods on the class, so they cost a model build nothing:
    # no per-instance state, nothing on the construction path.
    #
    # Deliberately NOT added: ``.reshape`` / ``.flatten`` / ``.T``. "``Variable``
    # has no ``.reshape``, so declare the shape you want" is a documented
    # position in ``docs/notebooks/modeling_guide.ipynb`` pinned by
    # ``test_variable_has_no_reshape_so_the_guide_says_declare_the_shape``;
    # reversing it is a design change, not a bug fix.

    def sum(self, axis: Optional[int] = None, dtype=None, out=None, **kwargs) -> "Expression":
        """Sum over this expression's elements as a single n-ary node.

        Parameters
        ----------
        axis : int or tuple of int, optional
            Axis (or axes) to reduce. ``None`` (default) is a full reduction to a
            scalar; an ``axis=k`` reduction leaves the other axes standing, so the
            node stays array-valued and stands for one row per surviving element.
        dtype, out, ``**kwargs``
            Accepted only so ``np.sum(expr)`` dispatches here (numpy's reduction
            protocol calls ``expr.sum(axis=..., out=...)``). Anything but the
            default is refused; see :meth:`_reject_numpy_reduction_kwargs`.

        Examples
        --------
        >>> xs = m.continuous("xs", shape=(200,), lb=0, ub=1)
        >>> xs.sum()                 # one node, not a 200-deep chain
        >>> X.sum(axis=1)            # one row sum per row of a 2-D family
        """
        self._reject_numpy_reduction_kwargs("sum", dtype, out, kwargs)
        return SumExpression(self, axis=axis)

    def prod(self, axis: Optional[int] = None, dtype=None, out=None, **kwargs) -> "Expression":
        """Product over **all** of this expression's elements, as a single node.

        ``axis`` exists only to accept ``np.prod(expr)``'s call and must be
        ``None``: the ``prod`` node the evaluator, the relaxation layer and the
        ``.nl`` writer implement is a full reduction (``jnp.prod`` over the
        flattened operand). An ``axis`` keyword that silently ignored the axis
        would fold rows together that belong apart -- the failure mode issue
        #1160 fixed for ``sum`` -- so it is refused instead.
        """
        self._reject_numpy_reduction_kwargs("prod", dtype, out, kwargs)
        if axis is not None:
            raise NotImplementedError(
                f"prod(axis={axis!r}) is not supported: the `prod` node is a full "
                "reduction over every element, so an axis argument could not be "
                "honoured and would silently collapse rows that belong apart. "
                "Build the per-axis product explicitly from the elements you want."
            )
        return FunctionCall("prod", self)

    def mean(self, axis: Optional[int] = None, dtype=None, out=None, **kwargs) -> "Expression":
        """Arithmetic mean over this expression's elements.

        ``self.sum(axis) / n``, where ``n`` is the number of elements reduced.
        Requires a statically known shape, since ``n`` has to be a literal in the
        DAG; raises :class:`TypeError` rather than guessing when the shape is not
        known (a matmul result, a custom call, an indexed container).
        """
        self._reject_numpy_reduction_kwargs("mean", dtype, out, kwargs)
        shape = _known_shape(self)
        if shape is None:
            raise TypeError(
                f"mean() needs a statically known shape to divide by, and a "
                f"{type(self).__name__} does not carry one. Use "
                f"`expr.sum({'' if axis is None else f'axis={axis}'}) / n` with the "
                f"count you intend, or take the mean of a shaped variable directly."
            )
        if axis is None:
            n = 1
            for d in shape:
                n *= int(d)
        else:
            nd = len(shape)
            axes = axis if isinstance(axis, tuple) else (axis,)
            n = 1
            seen: set[int] = set()
            for a in axes:
                a = int(a)
                if not -nd <= a < nd:
                    raise np.exceptions.AxisError(
                        f"axis {a} is out of bounds for an expression of shape {shape}"
                    )
                if a % nd in seen:
                    raise ValueError(f"duplicate axis {a} in mean(axis={axis!r})")
                seen.add(a % nd)
                n *= int(shape[a % nd])
        if n == 0:
            raise ValueError(f"mean() of an empty reduction (shape {shape}, axis={axis!r})")
        return BinaryOp("/", SumExpression(self, axis=axis), _wrap(float(n)))

    # ── min / max over a shaped expression (issue #1238) ──
    #
    # These do NOT follow ``.sum()``'s one-n-ary-node shape, and the difference is
    # measured rather than stylistic. ``sum`` has ``SumExpression``, a node every
    # consumer reduces over. ``min``/``max`` have ``MathFunc::Min``/``Max``, which
    # look n-ary (``FunctionCall`` takes ``*args``) but are read as strictly
    # BINARY by four consumers -- ``expr.rs``'s two evaluators, ``fbbt.rs``'s
    # forward interval, ``dag_compiler``/``differentiable``
    # -- each of which indexes ``args[0], args[1]`` and would silently DROP
    # ``args[2:]``. A dropped argument in the FBBT interval is not a loose bound,
    # it is a wrong one (``min`` over a subset is too high), i.e. a false
    # certificate. ``nl_parser.rs`` already reached this conclusion for the
    # ``.nl`` ``o11``/``o12`` minlist/maxlist opcodes and folds them to binary for
    # exactly this reason (C-8), so emitting n-ary here would be re-opening a hole
    # the parser deliberately closed.
    #
    # #1238 proposed lifting all four consumers to n-ary, on the hypothesis that a
    # single n-ary envelope would be TIGHTER than the fold. Measured first
    # (CLAUDE.md §4), and falsified: over 300 fixed-box comparisons through
    # ``build_uniform_relaxation`` -- the default per-node engine since #632 --
    # spanning ``min``/``max``, both objective senses, n = 3..8, and affine /
    # square / bilinear / exp / variable-sharing arguments, the n-ary bound equals
    # the balanced fold's bound EXACTLY in 300/300 cases, with 0 unsound bounds.
    # It has to: ``uniform_relax._build_multivar`` emits the exact convex-hull
    # facets ``w >= a_i`` (resp. ``w <= a_i``), and a fold's intermediate auxes
    # project straight back out of that system. The issue's own kill criterion
    # ("if the n-ary envelope is not tighter than the balanced binary fold, ship
    # only the balanced fold") therefore fires. Recorded in
    # ``docs/dev/performance-plan.md`` §64.
    #
    # What the fold IS for is the depth, which is the part of #1238 that is a real
    # defect: ``dm.minimum(dm.minimum(a, b), c)`` -- the only spelling there was --
    # grows depth 1:1 with the element count, and performance-plan §54 records
    # depth-n folds raising ``RecursionError`` out of the LP/MPS/GAMS writers at
    # n >= 1000. A balanced fold is ``ceil(log2(n))`` deep instead: 7 for n = 100,
    # 10 for n = 1000. Same nodes, same math, same bound -- only the nesting
    # changes.

    def min(self, axis: Optional[int] = None, out=None, **kwargs) -> "Expression":
        """Smallest element of this expression, as a balanced binary fold.

        Requires a statically known shape, since the elements have to be indexed
        out one at a time to be folded -- raises :class:`TypeError` rather than
        guessing when the shape is not known (a matmul result, a custom call).

        Parameters
        ----------
        axis : None
            Accepted only so ``np.min(expr)`` dispatches here (numpy's reduction
            protocol calls ``expr.min(axis=..., out=...)``). Must be ``None``.
        out, ``**kwargs``
            Refused; see :meth:`_reject_numpy_reduction_kwargs`.

        Examples
        --------
        >>> xs = m.continuous("xs", shape=(200,), lb=0, ub=1)
        >>> xs.min()                 # ceil(log2(200)) = 8 levels of min, not 199
        >>> m.subject_to(xs.max() <= 0.9, name="bottleneck")
        """
        return self._minmax_reduction("min", axis, out, kwargs)

    def max(self, axis: Optional[int] = None, out=None, **kwargs) -> "Expression":
        """Largest element of this expression, as a balanced binary fold.

        The ``max`` counterpart of :meth:`min`; see it for the parameters and for
        why this is a fold rather than one n-ary node.
        """
        return self._minmax_reduction("max", axis, out, kwargs)

    def _minmax_reduction(self, fname: str, axis, out, kwargs) -> "Expression":
        """Shared body of :meth:`min` / :meth:`max`."""
        # numpy's ``np.min``/``np.max`` pass ``axis`` and ``out`` only -- unlike
        # ``np.sum``/``np.prod`` there is no ``dtype`` to accumulate in -- so
        # ``dtype`` is hardwired ``None`` here rather than exposed as a parameter
        # nobody can reach.
        self._reject_numpy_reduction_kwargs(fname, None, out, kwargs)
        if axis is not None:
            # An axis reduction has to stay array-valued, and this layer has no
            # array-valued min/max node to return: ``SumExpression(axis=k)`` is
            # what makes ``.sum(axis=k)`` possible and ``min``/``max`` have no
            # equivalent. The one thing that could be returned instead -- an
            # object ndarray of scalar folds -- is a trap: ``arr <= 0.8`` on it
            # makes numpy loop into ``Expression.__le__`` per element and then try
            # to pack the resulting Constraints into a bool array, which raises
            # "A Constraint has no truth value" from a line the user did not
            # write. Refuse instead of returning something that breaks one
            # operator later (CLAUDE.md §3).
            raise NotImplementedError(
                f"{fname}(axis={axis!r}) is not supported: an axis reduction has to "
                f"stay array-valued and there is no array-valued {fname} node to "
                f"carry it (`sum` has `SumExpression`; `{fname}` does not). Reduce "
                f"one slice at a time -- `X[i, :].{fname}()` for each row, or "
                f"`dm.{'minimum' if fname == 'min' else 'maximum'}(*X[i, :])`."
            )
        return _balanced_minmax_fold(fname, self._flat_elements(fname))

    def _flat_elements(self, caller: str) -> list["Expression"]:
        """This expression's elements in C order, as scalar expressions.

        The reduction helpers fold over these. A statically known shape is
        required: without one there is no element count to index over, and
        guessing would build a model over the wrong number of terms.
        """
        shape = _known_shape(self)
        if shape is None:
            raise TypeError(
                f"{caller}() needs a statically known shape to reduce over, and a "
                f"{type(self).__name__} does not carry one. Fold the elements you "
                f"mean explicitly with "
                f"`dm.{'minimum' if caller == 'min' else 'maximum'}(*terms)`, or "
                f"take the {caller} of a shaped variable directly."
            )
        if shape == ():
            # A scalar is its own min and max. Returning ``self`` keeps the DAG
            # unchanged rather than wrapping it in a one-argument call no
            # consumer would relax.
            return [self]
        n = 1
        for d in shape:
            n *= int(d)
        if n == 0:
            raise ValueError(
                f"{caller}() of an empty reduction (shape {shape}): the minimum of "
                "no elements is undefined."
            )
        if len(shape) == 1:
            return [self[i] for i in range(int(shape[0]))]
        # ``np.ndindex`` yields C order, matching ``.flatten()`` and the order
        # ``.sum()`` reduces in. Order does not change a min/max, but it does
        # decide which pairs meet in the fold, so keeping it canonical keeps the
        # built DAG reproducible across runs.
        return [self[idx] for idx in np.ndindex(*shape)]

    @staticmethod
    def _reject_numpy_reduction_kwargs(name: str, dtype, out, kwargs) -> None:
        """Refuse the numpy reduction keywords this layer cannot honour.

        ``np.sum(expr)`` reaches :meth:`sum` because numpy's ``_wrapreduction``
        looks for a same-named method on any non-ndarray and calls it as
        ``expr.sum(axis=..., out=...)``. Accepting those parameters is what makes
        ``np.sum`` / ``np.prod`` / ``np.mean`` work on a shaped expression at all
        -- without them numpy's call raises ``unexpected keyword argument 'out'``,
        which says nothing about the real constraint.

        Accepting them *silently* would be worse than refusing: ``out=`` asks for
        a write into a preallocated buffer and ``dtype=`` for an accumulation
        type, and an expression is a DAG node with no storage and no dtype, so
        either one can only be ignored -- and a caller who passed ``out=`` and got
        an unwritten buffer back has a wrong answer, not a slow one. They are
        refused by name instead.
        """
        if dtype is not None:
            raise TypeError(
                f"{name}(dtype={dtype!r}) is not supported: an expression is a DAG "
                "node, not an array, and carries no accumulation dtype. The model "
                "is evaluated in float64."
            )
        if out is not None:
            raise TypeError(
                f"{name}(out=...) is not supported: an expression is a DAG node "
                "with no storage to write into. Use the returned expression."
            )
        # ``keepdims`` / ``initial`` / ``where`` only reach here when the caller
        # passed them explicitly -- numpy strips its own ``_NoValue`` defaults.
        if kwargs:
            unsupported = ", ".join(sorted(kwargs))
            raise TypeError(
                f"{name}() got unsupported keyword argument(s): {unsupported}. "
                "Expression reductions accept only `axis`."
            )

    # ── Comparison operators produce Constraints, not booleans ──

    # ``self - _wrap(other)`` routed through ``__sub__``, which called ``_wrap``
    # a SECOND time on an operand it had just wrapped. Building the ``BinaryOp``
    # here removes both calls per comparison -- 150 000 ``__sub__`` and 150 000
    # redundant ``_wrap`` calls on a 200 000-row build. The node built is
    # identical, which is what the normalisation contract on ``Constraint``
    # depends on: body ``sense`` 0.

    def __le__(self, other):
        rhs = other if isinstance(other, Expression) else _wrap(other)
        return Constraint(BinaryOp("-", self, rhs), sense="<=", rhs=0.0)

    def __ge__(self, other):
        lhs = other if isinstance(other, Expression) else _wrap(other)
        return Constraint(BinaryOp("-", lhs, self), sense="<=", rhs=0.0)

    def __eq__(self, other):
        rhs = other if isinstance(other, Expression) else _wrap(other)
        return Constraint(BinaryOp("-", self, rhs), sense="==", rhs=0.0)

    def __ne__(self, other):
        # ``!=`` is not a valid optimization-constraint operator. Because
        # ``__eq__`` is overridden to build a Constraint, Python's default
        # ``__ne__`` would evaluate ``not <truthy Constraint>`` → ``False``
        # *silently*, mis-encoding the user's intent (correctness issue C-11).
        # Refuse loudly instead of silently transforming the model (CLAUDE.md §3).
        raise TypeError(
            "'!=' is not a valid constraint operator on modeling expressions. "
            "Use '==', '<=', or '>=' to build a constraint."
        )

    # ── Hashing / boolean context (M4) ──
    #
    # ``__eq__`` is overloaded to *build a Constraint* (the modeling DSL —
    # ``x == 5`` yields ``x - 5 == 0``), which is intentional and matches
    # Pyomo/cvxpy. But that overload has two silent, dangerous consequences we
    # must neutralize:
    #
    #   1. Defining ``__eq__`` makes every ``Expression`` subclass unhashable by
    #      default (Python sets ``__hash__`` to ``None``), so ``{u + v: 1}`` and
    #      ``expr in some_set`` blow up or misbehave. We restore **identity
    #      hashing** (``id(self)``) so expressions behave sanely as set/dict keys
    #      — two syntactically identical expressions are distinct objects, which
    #      is the only sound choice given value-equality is unavailable.
    #   2. ``expr in [other]`` / ``if expr:`` route through ``__eq__``/``__bool__``
    #      and would evaluate the truthiness of the *Constraint* returned by
    #      ``==``, which is always truthy — so ``u in [v]`` is silently ``True``
    #      for any expressions. Making membership sound requires the container to
    #      short-circuit on identity, which Python's ``in`` does *before* calling
    #      ``__eq__`` only when the objects are identical; for distinct objects it
    #      still calls ``__eq__``. We therefore also raise in ``Constraint.__bool__``
    #      (below) so ``if x == 5:`` / ``u in [v]`` fail loudly instead of lying.
    #
    # NOTE: identity hashing does NOT change the ``==``-builds-a-Constraint
    # overload — that remains the modeling API. It only fixes set/dict/`in`
    # semantics for expressions used as keys.
    __hash__ = object.__hash__

    # ── Indexing for array variables ──

    def __getitem__(self, idx):
        # Out-of-bounds guard (issue #816) lives on the *operator*, not on the
        # ``IndexExpression`` constructor: the expression-graph machinery (GAMS
        # import, NL export resolver, signomial/sign-domain pattern matching)
        # deliberately builds ``IndexExpression(base, idx)`` with out-of-range,
        # non-integer, or too-many-index values as lazy nodes that it resolves
        # conservatively later, and must never raise on construction. User-facing
        # ``x[i]`` typos, by contrast, should fail loudly — but only for the
        # unambiguous integer cases (a plain int, or a full-arity all-int tuple);
        # slices, ellipsis, wrong-arity, and non-integer indices stay lenient.
        base_shape = _known_shape(self)
        if base_shape is not None and len(base_shape) >= 1:
            err = _integer_index_out_of_range(base_shape, idx)
            if err is not None:
                raise err
        return IndexExpression(self, idx)

    # ── Shape / length / iteration for array-valued expressions (issue #816) ──

    @property
    def shape(self) -> tuple[int, ...]:
        """Static numpy-style shape of this expression.

        Inferred from the operands for the nodes whose shape follows
        unambiguously from numpy broadcasting: leaf ``Variable``/``Parameter``/
        ``Constant``, their element-wise ``+ - * / **`` / ``neg`` / ``abs``
        compositions, indexing/slicing, and element-wise function calls
        (``exp``, ``sqrt``, ``sin``, …). Raises :class:`AttributeError` when the
        shape is not statically known (reductions, matmul, custom calls, …) so
        that ``getattr(expr, "shape", default)`` and ``hasattr(expr, "shape")``
        keep their pre-existing behaviour for shape-unknown nodes.
        """
        s = _known_shape(self)
        if s is None:
            raise AttributeError(f"{type(self).__name__} has no statically known shape")
        return s

    @shape.setter
    def shape(self, value: tuple[int, ...]) -> None:
        # Leaf nodes (Variable/Parameter) store their declared shape here; the
        # getter then surfaces it through the same ``_known_shape`` path used for
        # composite nodes, keeping a single source of truth.
        #
        # Normalised to a tuple on the way in (a caller may pass a list), so
        # every reader can compare ``_shape`` values directly instead of
        # re-converting. ``BinaryOp.__init__`` relies on that.
        self._shape = None if value is None else tuple(value)

    @property
    def ndim(self):
        """Not defined: always raises :class:`AttributeError` with guidance.

        A discopt expression is not an array, so ``hasattr(expr, "ndim")`` stays
        False. The property exists for its message. ``scipy_sparse @ expr`` reads
        ``expr.ndim`` inside scipy's matmul dispatch, and without the property the
        user saw only ``'Variable' object has no attribute 'ndim'``, which does not
        say that a scipy sparse matrix cannot multiply a discopt expression.
        """
        raise AttributeError(
            f"{type(self).__name__} has no 'ndim': a discopt expression is not an "
            f"array. {_SPARSE_OPERAND_HINT}"
        )

    def __len__(self) -> int:
        """Length along the leading axis (``shape[0]``) for array expressions.

        Raises ``TypeError`` for scalar or shape-unknown expressions, matching
        numpy's behaviour for 0-d arrays. Defining ``__len__`` alongside
        ``__iter__`` stops Python from falling back to the legacy
        sequence-iteration protocol that — because out-of-range indexing now
        raises ``IndexError`` — used to loop forever (issue #816).
        """
        s = _known_shape(self)
        if s is None:
            raise TypeError(
                f"object of type '{type(self).__name__}' has no len(): its "
                "shape is not statically known"
            )
        if len(s) == 0:
            raise TypeError(f"len() of unsized scalar {type(self).__name__}")
        return int(s[0])

    def __iter__(self) -> "Iterator[Expression]":
        """Yield the leading-axis elements (``expr[0]``, ``expr[1]``, …).

        Raises ``TypeError`` for scalar or shape-unknown expressions instead of
        hanging, so ``list(x)``, ``sum(x)``, ``np.array(x)`` and unpacking
        behave like numpy for shaped variables (issue #816).
        """
        s = _known_shape(self)
        if s is None:
            raise TypeError(
                f"cannot iterate over {type(self).__name__} with unknown shape; "
                "index it explicitly instead"
            )
        if len(s) == 0:
            raise TypeError(f"cannot iterate over scalar {type(self).__name__}")
        return (self[i] for i in range(int(s[0])))

    # ── Matrix operations ──

    def __matmul__(self, other):
        return MatMulExpression(self, _wrap(other))

    def __rmatmul__(self, other):
        return MatMulExpression(_wrap(other), self)

    def _repr_latex_(self):
        """Jupyter/IPython LaTeX rendering."""
        # Render the expression DAG as real math rather than wrapping the plain
        # repr in $...$ (which shows broken math in Jupyter) (L8).
        try:
            from discopt.modeling.latex import expr_to_latex

            return f"${expr_to_latex(self)}$"
        except Exception:
            return f"${self}$"


def _non_numeric_constant_message(value) -> str:
    """The refusal for a ``None``/string operand (#1628), naming what was passed."""
    if value is None:
        return (
            "cannot use None as a numeric constant in an expression. A helper that "
            "builds an expression most likely forgot its `return`."
        )
    if isinstance(value, np.ndarray):
        return (
            f"cannot use a numpy array of dtype {value.dtype} (text) as a numeric "
            f"constant in an expression; convert it to numbers first."
        )
    return (
        f"cannot use {type(value).__name__} {value!r} as a numeric constant in an "
        f"expression; pass a number (float/int/numpy array), not text."
    )


class Constant(Expression):
    """A numeric constant in the expression DAG."""

    def __init__(self, value: Union[float, int, np.ndarray]):
        if isinstance(value, np.ndarray):
            if value.dtype.kind in "US":
                raise TypeError(_non_numeric_constant_message(value))
            self.value = value.astype(np.float64)
        elif type(value) is float:
            # A Python float is already float64, so the `dtype=` kwarg only makes
            # numpy re-check it: measured 0.222 -> 0.155 us without it, on a call
            # made once per row (#1215). Restricted to an exact `float` so nothing
            # else can slip through with the wrong dtype.
            self.value = np.asarray(value)
        else:
            # ``np.asarray(None, dtype=float64)`` is ``nan`` and
            # ``np.asarray("1.5", dtype=float64)`` is ``1.5``: neither raises, so a
            # ``None`` (a helper that forgot its ``return``) or a string used as an
            # operand became a silent NaN / parsed number in the DAG, and a
            # ``minimize(None)`` solve reported ``feasible`` with ``objective=nan``
            # (#1628). Refuse both here, where every operand is wrapped.
            if value is None or isinstance(value, (str, bytes)):
                raise TypeError(_non_numeric_constant_message(value))
            self.value = np.asarray(value, dtype=np.float64)

    def __repr__(self):
        if self.value.ndim == 0:
            return f"{float(self.value):.6g}"
        return f"Constant({self.value.shape})"


_FLOAT64 = np.dtype(np.float64)


def _bound_is_owned_frozen(arr) -> bool:
    """Is *arr* a box this module already built and froze?

    True exactly for the shape :func:`_readonly_bound` returns: a read-only
    view over a read-only base. Nothing writable aliases such an array, so it
    can be installed again with no copy -- which is what keeps the node loop's
    ``v.lb, v.ub = v._bound_stack.pop()`` and ``saved_bounds`` restores free of
    a per-node allocation.
    """
    if type(arr) is not np.ndarray or arr.dtype != _FLOAT64:
        return False
    base = arr.base
    # The base check alone settles it: numpy will not let a view over a
    # read-only base be writable, so ``base is frozen`` implies ``arr is
    # frozen``. Checking ``arr.flags`` as well would double the cost of the
    # hot path -- `.flags` builds a new flagsobj on every access -- for an
    # answer already implied.
    #
    # The base must be an ndarray: an array numpy rebuilt from a pickle can be a
    # view over the raw ``bytes`` it was read from, which has no ``.flags`` --
    # unpickling a model then raised ``AttributeError`` here. Such a box is not
    # one this module froze, so it takes the copying path like any foreign array.
    return type(base) is np.ndarray and not base.flags.writeable


def _bound_context(what: Optional[str], name: Optional[str], side: str) -> str:
    """The "who is complaining" prefix of a bound error, built ONLY on failure.

    ``lb``/``ub`` are assigned once per variable per branch-and-bound node, so
    formatting this eagerly cost more than the whole fast path it guards
    (measured: 0.75 us per reinstall against 0.15 us with it deferred).
    """
    if what is not None:
        return what
    return f"variable {name!r}: {side}" if name is not None else side


def _readonly_bound(
    value,
    shape: Optional[tuple[int, ...]] = None,
    *,
    var_type: "Optional[VarType]" = None,
    what: Optional[str] = None,
    name: Optional[str] = None,
    side: str = "bound",
) -> np.ndarray:
    """*value*, validated, copied and frozen into a box array of *shape*.

    The single choke point for :attr:`Variable.lb` / :attr:`Variable.ub`; see
    the note on those properties for why the invariant lives here and not at
    each writer.

    **It copies.** #1321 froze what was installed but installed a read-only
    *view over the caller's buffer*, so the caller's own array stayed writable
    and aliased the model: ``lo = np.zeros(2); x = m.continuous('x', lb=lo);
    lo[:] = 5`` silently moved ``x``'s declared lower bound and the solve
    answered 20.0 where 12.0 is correct, with no warning (#1332). A box is part
    of the problem statement, so it is owned, not borrowed. The copy is skipped
    for an array that is already one of ours (:func:`_bound_is_owned_frozen`),
    which is the case on every hot restore path.

    What is returned is a read-only VIEW over a read-only base. Both halves
    matter: a read-only array that owns its data can have ``writeable`` set
    back to True (numpy allows it for an owner), so an owner alone would leave
    ``x.lb.flags.writeable = True`` working. Re-enabling the flag on the base
    is still possible -- numpy offers no permanently-immutable array -- but
    that is two deliberate steps past the API.

    *shape*, when given, is the variable's shape: a scalar broadcasts to it and
    anything not broadcastable is refused here rather than at solve time, where
    it surfaced as an unrelated ``IndexError`` (#1332 item 5).
    """
    # The fast path FIRST: an array this module already built and froze is
    # neither None nor complex, so the validation below has nothing to say
    # about it, and this is the branch every node-loop restore takes.
    if _bound_is_owned_frozen(value) and (shape is None or value.shape == shape):
        # Already validated and clipped by the setter that built it -- except
        # for the domain, which belongs to the variable being assigned, not the
        # one the box came from.
        if var_type is VarType.BINARY:
            _refuse_bound_outside_unit_box(value, what, name, side)
        # An INTEGER box built by this module is already integral (#2252), but
        # a frozen box can come from a variable of another type; only a
        # fractional one needs the slow path's snap.
        if var_type is not VarType.INTEGER or _is_integral_box(value):
            # `_bound_is_owned_frozen` has just established the ndarray-ness
            # that `value: Any` cannot carry through.
            return cast(np.ndarray, value)

    if value is None:
        raise ValueError(
            f"{_bound_context(what, name, side)}: None is not a bound; use the "
            "default (or +/- an explicit value)"
        )
    if np.iscomplexobj(value):
        # np.asarray(..., dtype=float64) drops the imaginary part with only a
        # ComplexWarning, so a complex bound became a silently different box.
        raise TypeError(
            f"{_bound_context(what, name, side)}: complex values are not valid "
            f"bounds, got {value!r}"
        )

    try:
        base = np.array(value, dtype=np.float64)
    except (TypeError, ValueError) as exc:
        raise TypeError(
            f"{_bound_context(what, name, side)}: cannot be read as a float array ({exc})"
        ) from exc
    if np.isnan(base).any():
        # `np.asarray(None, dtype=float)` is NaN, and a NaN bound compares False
        # against everything, so downstream it read as an empty box and a
        # feasible model was certified infeasible (#1294).
        raise ValueError(
            f"{_bound_context(what, name, side)}: contains NaN (a None entry in an "
            "array bound converts to NaN); use the default for no bound"
        )
    if shape is not None and base.shape != shape:
        expected = int(np.prod(shape)) if shape else 1
        try:
            base = np.array(np.broadcast_to(base, shape), dtype=np.float64)
        except ValueError as exc:
            # A size-matching array that does not *broadcast* is still the box
            # the caller means -- `x.lb = np.array([0.5])` on a scalar `x`, and
            # a flat vector for a 2-D variable. Reshape those; refuse only when
            # the element counts genuinely disagree, which is the case that
            # failed later with an unrelated IndexError (#1332 item 5).
            if base.size != expected:
                raise ValueError(
                    f"{_bound_context(what, name, side)}: shape {base.shape} does not "
                    f"broadcast to the variable's shape {shape} ({exc})"
                ) from exc
            base = np.array(base.reshape(shape), dtype=np.float64)
    if var_type is not None:
        base = _validated_discrete_bound(base, var_type, _bound_context(what, name, side), side)
    base.flags.writeable = False
    frozen: np.ndarray = np.broadcast_to(base, base.shape)
    return frozen


#: How far outside its declared domain a discrete bound may land before it is a
#: refusal rather than a rounding artifact. FBBT and the LP engines return
#: bounds that can sit an ulp or two outside [0, 1]; snapping those back is
#: exact for an integral variable, while a bound genuinely outside the domain
#: (``b.ub = 5`` on a binary) is a different problem and is refused.
_DISCRETE_BOUND_SLACK = 1e-9


#: How far a bound may sit from an integer and still *be* that integer, for an
#: INTEGER variable (#2252). It is the absolute feasibility tolerance (1e-6, the
#: ``abs`` tolerance of the benchmark harness and the absolute part of
#: :func:`discopt.validation.feasibility.verify_point`'s bound check): a point
#: that violates the declared bound by no more than this is feasible, so the
#: integer it rounds to belongs to the variable's range. It also absorbs the
#: rounding noise that FBBT and the LP engines leave on a derived bound, which a
#: tighter snap would turn into a cut-off integer (``ceil(2.0000005) = 3``).
_INTEGER_BOUND_TOL = 1e-6


def _raw_unless_snapped(value, stored: np.ndarray, var_type) -> Optional[np.ndarray]:
    """The caller's bound when the INTEGER snap changed it, else ``None``.

    ``None`` on every path where nothing was snapped -- any other variable type, or
    a box installed as-is (the no-copy restore path hands back ``stored`` itself) --
    so the node loop's bound restores pay one identity test.
    """
    if var_type is not VarType.INTEGER or value is stored:
        return None
    raw = np.array(value, dtype=np.float64)
    if raw.shape != stored.shape:
        try:
            raw = np.array(np.broadcast_to(raw, stored.shape), dtype=np.float64)
        except ValueError:
            raw = raw.reshape(stored.shape)
    if np.array_equal(raw, stored):
        return None
    raw.flags.writeable = False
    return raw


def _is_integral_box(arr: np.ndarray) -> bool:
    """Is every entry of *arr* an integer (or +/-inf)?

    On the node-loop restore path, once per INTEGER variable per node, so a
    one-element box (the common scalar variable) takes a Python-float test
    rather than three numpy calls. No NaN reaches here (the setter refuses it),
    and ``floor(inf) == inf``, so an infinite bound counts as integral.
    """
    if arr.size == 1:
        v = arr.item()
        return v.is_integer() or v in (_POS_INF, _NEG_INF)
    return bool((np.floor(arr) == arr).all())


_POS_INF = float("inf")
_NEG_INF = float("-inf")


def _snap_integer_bound(base: np.ndarray, side: str) -> np.ndarray:
    """*base* (writable, owned) snapped in place to the integer range it admits.

    The single rule for an INTEGER variable's range (#2252): a bound within
    :data:`_INTEGER_BOUND_TOL` of an integer is that integer; otherwise a lower
    bound rounds up and an upper bound rounds down. Before this, each solve
    route rounded the raw bound with its own tolerance (``ceil(lb - 1e-9)`` in
    one place, ``ceil(lb - 1e-6)`` in another, none at all on the NLP route), so
    ``lb = 1.000001`` admitted ``x = 1`` on one route and excluded it on another,
    and one route certified a bound above a point ``verify_point`` accepted.
    Snapping here, where every box is installed, means every route and
    ``verify_point`` read the same integral box.

    The distance test is ``|b - round(b)|``, not ``ceil(b - tol)``: the latter
    is decided by the binary64 rounding of the subtraction at the boundary
    (``1.000001 - 1e-6`` is ``0.9999999999999999``).
    """
    if side not in ("lb", "ub"):
        raise ValueError(f"integer bound side must be 'lb' or 'ub', got {side!r}")
    finite = np.isfinite(base)
    if not finite.any():
        return base
    vals = base[finite]
    nearest = np.round(vals)
    directed = np.ceil(vals) if side == "lb" else np.floor(vals)
    # A few ulps of slack, so ``k + 1e-6`` and ``k - 1e-6`` both count as within
    # the tolerance however binary64 rounds the decimal (``0.999999`` sits
    # 1.00000000003e-6 below 1, ``1.000001`` 9.9999999992e-7 above it).
    slack = _INTEGER_BOUND_TOL + 4.0 * np.spacing(np.maximum(1.0, np.abs(nearest)))
    base[finite] = np.where(np.abs(vals - nearest) <= slack, nearest, directed)
    return base


def _validated_discrete_bound(
    base: np.ndarray, var_type: "VarType", what: str, side: str = "bound"
) -> np.ndarray:
    """Refuse a box that puts a discrete variable outside its declared domain.

    #1332 item 3: ``loads()`` and ``x.ub = ...`` accepted ``ub = 5.0`` on a
    BINARY, and the solve returned ``b = 5.0`` as ``optimal`` with
    ``gap_certified=True`` -- a certificate for a model the user never wrote.
    The ``.nl`` reader already clipped binaries to [0, 1]; these two doors did
    not.

    An INTEGER box is snapped to the integer range it admits
    (:func:`_snap_integer_bound`, #2252); *side* (``"lb"``/``"ub"``) says
    which way a fractional bound rounds.
    """
    if var_type is VarType.INTEGER:
        return _snap_integer_bound(base, side)
    if var_type is not VarType.BINARY:
        return base
    _refuse_bound_outside_unit_box(base, what)
    # Snap the ulp-scale excursions the refusal above tolerates. Exact for an
    # integral variable, and `out=base` keeps this a 0-d ARRAY rather than the
    # numpy scalar `np.clip` would otherwise return for a scalar bound (whose
    # flags cannot be set).
    np.clip(base, 0.0, 1.0, out=base)
    return base


def _refuse_bound_outside_unit_box(
    base: np.ndarray,
    what: Optional[str] = None,
    name: Optional[str] = None,
    side: str = "bound",
) -> None:
    """Raise when a BINARY box leaves [0, 1] by more than a rounding artifact.

    The message is built only on failure, for the reason :func:`_bound_context`
    gives: this runs on every binary box a node installs.
    """
    if np.any(base < -_DISCRETE_BOUND_SLACK) or np.any(base > 1.0 + _DISCRETE_BOUND_SLACK):
        raise ValueError(
            f"{_bound_context(what, name, side)}: a binary variable's box must "
            "lie within [0, 1], got "
            f"{float(np.min(base))!r}..{float(np.max(base))!r}. Declare it as "
            "m.integer(name, lb=..., ub=...) if that is the domain you want."
        )


class VarBlock:
    """Several variables' elements as the columns of one fast-API linear block.

    ``Model.add_linear_constraints(A, [x, y, ...], ...)`` takes the columns of ``A``
    as the elements of ``x`` (flat, in order), then of ``y``, and so on: one block
    whose rows may mix variables of different types -- a MILP read from a file, whose
    integer and continuous columns share rows. A single :class:`Variable` is the
    one-variable case and stays a plain ``Variable`` in the block record.

    Read the columns through :meth:`columns`; consumers of
    ``model._builder_linear_blocks`` go through
    :func:`discopt.export._common.block_columns`, which accepts either.
    """

    __slots__ = ("vars", "size", "name", "_cols", "_checked")

    def __init__(self, variables):
        vs = tuple(variables)
        if not vs or not all(isinstance(v, Variable) for v in vs):
            raise TypeError("a VarBlock is a non-empty sequence of Variables")
        if len({id(v) for v in vs}) != len(vs):
            raise ValueError("a VarBlock lists each variable at most once")
        self.vars = vs
        sizes = np.fromiter((int(v.size) for v in vs), dtype=np.int64, count=len(vs))
        self.size = int(sizes.sum())
        self.name = "[" + ", ".join(v.name for v in vs) + "]"
        # Vectorized: a file's model has one block over thousands of scalar variables,
        # and a Python loop per variable here cost O(n) per block (304 blocks on
        # piperout-d27).
        pos = np.repeat(np.arange(len(vs), dtype=np.int64), sizes)
        starts = np.concatenate([[0], np.cumsum(sizes)[:-1]])
        local = np.arange(self.size, dtype=np.int64) - np.repeat(starts, sizes)
        self._cols: tuple[np.ndarray, np.ndarray] = (pos, local)
        # (id(model), its variable count, builder indices) once checked for a model.
        self._checked = None

    def columns(self) -> tuple[np.ndarray, np.ndarray]:
        """``(position, local)`` per column: column ``k`` is element ``local[k]``
        (flat) of ``self.vars[position[k]]``."""
        return self._cols

    def __repr__(self) -> str:
        return f"VarBlock({self.name})"


class Variable(Expression):
    """
    A decision variable in the optimization problem.

    Variables are created through :meth:`Model.continuous`,
    :meth:`Model.binary`, or :meth:`Model.integer` -- not directly.

    Attributes
    ----------
    name : str
        Unique variable name within the model.
    var_type : VarType
        One of CONTINUOUS, BINARY, or INTEGER.
    shape : tuple of int
        Shape of the variable (``()`` for scalar).
    lb : numpy.ndarray
        Element-wise lower bounds.
    ub : numpy.ndarray
        Element-wise upper bounds.
    """

    # __array_ufunc__ = None is inherited from Expression.

    # #2281: the sides of an INTEGER variable that ``Model.integer`` filled with
    # the finite fallback (``0`` / ``1e6``) because the caller wrote none, read by
    # ``Model._withhold_default_box_certificate``. A side leaves the record when
    # the CALLER assigns it (``x.lb = 0``, even to the default value); discopt's
    # own writes through the same setters never clear it (``_caller_wrote_side``).
    # A scoped pin (``fix``/``unfix``/``saved_bounds``) is such a write -- it is
    # undone on exit and the default comes back -- and the guard skips an entry
    # while it is pinned (``lb == ub``).
    _int_default_sides: frozenset = frozenset()

    def __init__(
        self,
        name: str,
        var_type: VarType,
        shape: tuple[int, ...],
        lb: Union[float, np.ndarray],
        ub: Union[float, np.ndarray],
        model: "Model",
    ):
        self.name = name
        self.var_type = var_type
        self.shape = shape
        # Validation, the copy and the freeze all happen in the `lb`/`ub`
        # setters -- the one choke point -- so declaration and a later
        # `x.lb = ...` cannot drift apart (#1332).
        self.lb = lb
        self.ub = ub
        self.model = model
        self._index = len(model._variables)  # Position in flat variable vector
        # ``size`` is a hot property on the convexity / AD walkers (called
        # once per leaf, per node visited). ``shape`` is immutable after
        # construction, so cache the product once instead of recomputing
        # ``int(np.prod(shape))`` on every access.
        self._size = int(np.prod(shape)) if shape else 1
        # Canonical `x[i]` handles -- see `__getitem__`.
        self._elem_cache: dict = {}
        # Boxes saved by `fix()`, popped by `unfix()`. A STACK, not a slot:
        # fixes nest (a primal heuristic fixes integers inside a solve whose
        # node loop is already overriding boxes), and a single slot would
        # restore the wrong box on the inner unfix.
        self._bound_stack: list[tuple[np.ndarray, np.ndarray]] = []
        # One `(token, depth)` pair per currently-open `fixed()` scope on this
        # variable (pushed by `Variable.fixed`/`Model.fixed`, never by a raw
        # `fix()`). The token detects two such scopes closing out of LIFO order
        # (#1311) -- e.g. one held open across a callback boundary while another
        # opens and closes inside it -- which `_bound_stack`'s depth alone
        # cannot distinguish from an ordinary leaked inner `fix()`. The depth is
        # the `_bound_stack` length the scope was entered at, which is what lets
        # `Model.saved_bounds` see that its restore would pop a scope that is
        # still open (#1321).
        self._fix_scope_tokens: list[tuple[object, int]] = []

    @property
    def size(self) -> int:
        return self._size

    def __getitem__(self, idx):
        """``x[i]`` -- the SAME node object every time, for a plain-integer index.

        Measured (#1215): indexing alone cost 1.99 us against Pyomo's 0.18 us
        (11.3x), because every ``x[i]`` allocated a fresh ``IndexExpression``
        while Pyomo hands back the one canonical ``VarData`` for that element.
        With expression-node creation at 96% of a model build, and two index
        nodes in a typical eight-node row, that is a first-order construction
        cost -- and the duplicates are pure waste: an index node over a variable
        is immutable and fully determined by ``(variable, index)``.

        Canonicalising also makes the DAG *smaller* rather than merely cheaper.
        Expressions hash by identity (see ``Expression.__hash__``), so the
        ``id()``-keyed memos that every walker, relaxation and tape lowering
        carries now HIT across rows that share an element instead of re-walking
        a structurally identical node once per occurrence.

        Only an exact ``int`` (or a tuple of exact ints) is cached, and the
        raw index is the key. A key that normalised ``np.int64(0)``, ``0`` and
        ``(0,)`` together would hand back a node whose ``.index`` has a different
        *type* than the caller wrote, and consumers do branch on that
        (``_resolve_var_index`` treats ``int`` and ``tuple`` differently), so
        those forms stay uncached rather than aliased. Slices and ellipsis are
        uncached too: they are rare and not always hashable.
        """
        if type(idx) is int or (type(idx) is tuple and all(type(v) is int for v in idx)):
            node = self._elem_cache.get(idx)
            if node is not None:
                return node
            shape = self._shape
            if type(idx) is int and type(shape) is tuple and len(shape) == 1:
                # THE construction hot path: a plain int into a 1-D variable,
                # which is what every `x[i]` in an indexed family is. The general
                # route below re-derives an answer that is fixed for this shape --
                # `_known_shape` twice (a tuple copy each), `_pure_integer_index`,
                # `_index_result_shape` and `_integer_index_out_of_range`, ~40% of
                # a family build's wall (#1215). Here the result shape is `()` for
                # every in-range index, and the only real work is the bounds test.
                #
                # Identical to the general path by construction, not by luck:
                # the range accepted (`-n <= i < n`) and the IndexError message
                # are `_integer_index_out_of_range`'s verbatim, and `()` is what
                # `_index_result_shape` returns for `base_shape[1:]`.
                # `test_1215_index_fast_path_equivalence.py` asserts the grid.
                n = shape[0]
                if idx < -n or idx >= n:
                    raise IndexError(f"index {idx} is out of bounds for axis 0 with size {n}")
                node = IndexExpression(self, idx, shape_hint=())
            else:
                # Through the base implementation, so the out-of-range guard on
                # the `[]` operator still runs before anything is cached.
                node = Expression.__getitem__(self, idx)
            self._elem_cache[idx] = node
            return node
        return Expression.__getitem__(self, idx)

    # ── Bound storage: every box this variable ever holds is read-only ──
    #
    # `Model.saved_bounds(copy=False)` snapshots boxes BY REFERENCE, once per
    # branch-and-bound node. That is only sound while no one writes into a box
    # array in place: an in-place write would reach through the snapshot and
    # silently redefine the problem the restore puts back, and a fixed column
    # is just `lb == ub`, so a corrupted box returns `status="optimal"` for a
    # different model with no other symptom.
    #
    # The invariant used to be maintained per call site -- declaration got a
    # read-only `broadcast_to` view, `fix()` froze the box it pushed (#1311) --
    # and it leaked on every site that was missed: `loads()` rebuilt the fix
    # stack writable, `fix()` handed back writable `new_lb`/`new_ub` for the
    # live box, and the GAMS reader stored plain writable arrays (#1321). Each
    # leak turned a would-be `ValueError` into a wrong answer.
    #
    # So it is enforced HERE, at the one place every box passes through, rather
    # than at each writer. A writer that needs to edit a box builds its own
    # writable array and assigns it; it cannot mutate one already installed.
    @property
    def lb(self) -> np.ndarray:
        """Lower bound array (read-only; rebind to change it)."""
        return self._lb

    @lb.setter
    def lb(self, value) -> None:
        self._lb = _readonly_bound(
            value, self.shape, var_type=self.var_type, name=self.name, side="lb"
        )
        if self._int_default_sides:  # empty for every variable but a defaulted integer
            self._caller_wrote_side("lb")
        # Inline test first: the node loop's restores (any type, value IS the box)
        # must not pay a call.
        self._raw_lb = (
            None
            if value is self._lb or self.var_type is not VarType.INTEGER
            else _raw_unless_snapped(value, self._lb, self.var_type)
        )

    @property
    def ub(self) -> np.ndarray:
        """Upper bound array (read-only; rebind to change it)."""
        return self._ub

    @ub.setter
    def ub(self, value) -> None:
        self._ub = _readonly_bound(
            value, self.shape, var_type=self.var_type, name=self.name, side="ub"
        )
        if self._int_default_sides:
            self._caller_wrote_side("ub")
        # Inline test first: the node loop's restores (any type, value IS the box)
        # must not pay a call.
        self._raw_ub = (
            None
            if value is self._ub or self.var_type is not VarType.INTEGER
            else _raw_unless_snapped(value, self._ub, self.var_type)
        )

    def _caller_wrote_side(self, side: str) -> None:
        """#2281: *side* of a defaulted integer was assigned. It leaves the record
        only when the CALLER wrote it: outside a solve, from code outside the
        ``discopt`` package (a script, notebook, test). discopt's own writes -- the
        solver's node reductions and heuristic fixes, ``fix``/``unfix``/
        ``saved_bounds``, a diagnostic's probe-and-restore (``conflict``,
        ``infeasibility``, AMP's snapshot/restore) -- all go through these setters
        too and never clear it, so a missed or future internal writer cannot drop
        the record and let a point on the invented box be certified. Frame 2 is the
        assigning frame (0 is this method, 1 the setter)."""
        if side not in self._int_default_sides or _SOLVE_DEPTH.get() != 0:
            return
        writer = _sys._getframe(2).f_code.co_filename
        if _os.path.abspath(writer).startswith(_DISCOPT_PACKAGE_DIR):
            return
        self._int_default_sides = self._int_default_sides - {side}

    def _declared_bound(self, side: str) -> np.ndarray:
        """The ``lb``/``ub`` the caller last assigned, before the INTEGER snap.

        The stored box is the integer range it admits (#2252); this is what was
        written, kept only when the snap changed it. ``validate`` decides a crossed
        box on it, and the serializer writes it, so a reload re-snaps to the same box.
        """
        raw = getattr(self, "_raw_" + side, None)
        return cast(np.ndarray, getattr(self, "_" + side) if raw is None else raw)

    # ── Copying: a copy's boxes must be as read-only as the original's ──
    #
    # #1332 item 2: `copy.deepcopy` and `pickle` rebuild `__dict__` directly,
    # so `_lb`, `_ub` and every `_bound_stack` entry came back WRITABLE. An
    # in-place write on the copy then persisted into a solve (objective -6
    # reported "optimal" against the correct -4), and a corrupted
    # `_bound_stack[0]` is the declared domain `fix()` validates against and
    # `unfix()` restores. `__setstate__` is the one hook both paths take.
    def __setstate__(self, state: dict) -> None:
        self.__dict__.update(state)
        for side in ("_lb", "_ub"):
            arr = self.__dict__.get(side)
            if arr is not None:
                self.__dict__[side] = _readonly_bound(arr)
        # The bounds as written (#2252) decide ``validate`` and are what ``dumps``
        # writes, so a writable copy would let an in-place write change both
        # (review of #2257). Frozen like the boxes; no var_type, nothing re-snapped.
        for side in ("_raw_lb", "_raw_ub"):
            arr = self.__dict__.get(side)
            if arr is not None:
                self.__dict__[side] = _readonly_bound(arr)
        stack = self.__dict__.get("_bound_stack")
        if stack:
            self.__dict__["_bound_stack"] = [
                (_readonly_bound(entry_lb), _readonly_bound(entry_ub))
                for entry_lb, entry_ub in stack
            ]

    # ── Fixing: bounds are the fixing route ──────────────────────────
    #
    # There is no separate "fixed" flag anywhere in the stack. ``lb == ub`` IS
    # how a fixed column is expressed, and the Rust lowering re-reads both from
    # the live Python object on every solve (C-41, ``expr_bindings.rs``). That
    # makes fixing cheap and makes a *leaked* fix dangerous in a specific way:
    # a stale ``lb == ub`` does not raise, it silently redefines the problem and
    # still returns ``status="optimal"``. Hence the stack + the context managers
    # below -- the point of the API is that ``unfix`` cannot be forgotten.

    @property
    def fix_depth(self) -> int:
        """How many :meth:`fix` frames are currently stacked on this variable."""
        return len(self._bound_stack)

    @property
    def is_fixed(self) -> bool:
        """True when *every* element is pinned (``lb == ub`` elementwise).

        Reports the variable's actual mathematical state, not whether
        :meth:`fix` is what produced it: a variable declared
        ``m.continuous("c", lb=3, ub=3)`` is fixed and says so. A partial fix
        (see ``where``) is therefore ``False`` -- some elements are still free.
        """
        return bool(np.all(np.asarray(self.lb) == np.asarray(self.ub)))

    def fix(self, value, *, where=None) -> "Variable":
        """Pin this variable at *value* by setting ``lb = ub = value``.

        Re-entrant: each call pushes the box it replaced onto a stack and
        :meth:`unfix` pops exactly one frame, so nested fixes unwind in LIFO
        order. A single saved slot would break here — the primal heuristics fix
        integers inside a solve whose node loop is already overriding boxes —
        so the stack is load-bearing, not defensive.

        Parameters
        ----------
        value : float or array_like
            The value(s) to pin at, broadcast to this variable's shape.
        where : array_like of bool, optional
            Elementwise mask; only elements where it is true are pinned, the
            rest keep their current box. This is the multi-experiment case:
            one design block free while the blocks carrying observed data stay
            at their measured conditions.

        Raises
        ------
        ValueError
            If *value* is outside this variable's *declared* box (the one it
            had before any ``fix``), or is not finite.
            Both are refused rather than accommodated: pinning outside the
            declared domain yields a silently infeasible model, and pinning at
            NaN/inf yields a model whose relaxation is meaningless. Widen the
            declared bounds first if the wider box is what you meant.

        Examples
        --------
        >>> k.fix(0.7965)                       # scalar
        >>> F.fix(F_data, where=[False, True, True])   # pin all but block 0
        """
        prev_lb = np.array(self.lb, dtype=np.float64, copy=True)
        prev_ub = np.array(self.ub, dtype=np.float64, copy=True)
        # Read-only, to match the invariant the ORIGINAL declared bounds carry
        # (a `broadcast_to` view). `unfix()` restores exactly these arrays, so
        # without this a single fix()/unfix() cycle would silently turn a
        # read-only declared-bounds array into a plain writable one -- which
        # breaks `Model.saved_bounds(copy=False)`'s documented aliasing
        # invariant that an in-place bound write raises rather than silently
        # corrupting its by-reference snapshot (#1311). A box being pushed
        # here is, by construction, no longer the live/mutable one -- ``fix()``
        # is about to replace it with ``new_lb``/``new_ub`` below -- so nothing
        # should ever write into it in place.
        prev_lb.flags.writeable = False
        prev_ub.flags.writeable = False
        target = np.broadcast_to(np.asarray(value, dtype=np.float64), self.shape)

        if where is None:
            pinned = np.ones(self.shape, dtype=bool) if self.shape else np.array(True)
            new_lb = np.array(target, dtype=np.float64)
            new_ub = np.array(target, dtype=np.float64)
        else:
            pinned = np.broadcast_to(np.asarray(where, dtype=bool), self.shape)
            new_lb = np.where(pinned, target, prev_lb)
            new_ub = np.where(pinned, target, prev_ub)

        # A non-finite pin makes every relaxation built from this column
        # meaningless; refuse rather than propagate it (development philosophy
        # §3 -- refuse loudly over a silent approximation).
        bad = np.asarray(pinned & ~np.isfinite(target))
        if bad.any():
            i = int(np.argmax(bad.ravel()))
            raise ValueError(
                f"Variable {self.name!r}: cannot fix element {i} at "
                f"{float(np.asarray(target).ravel()[i])!r} -- a fixed value must be finite."
            )
        # Outside the DECLARED domain: the model becomes infeasible with no other
        # symptom, since a fixed column is just a degenerate box.
        #
        # Checked against the declared domain -- the bottom of the stack, i.e.
        # the box before any fix -- and deliberately NOT against the box this
        # call replaces. Against the latter, every nested re-fix would be
        # refused: once ``fix(4.0)`` has made the box ``[4, 4]``, an inner
        # ``fix(5.0)`` is "outside" it, which would make the stack useless for
        # the override case it exists to serve. Narrowings that did not come
        # from ``fix`` (a branch-and-bound node box, a presolve tightening) are
        # likewise not the domain: pinning outside one of those legitimately
        # means "this node is infeasible", which is an ordinary search outcome
        # rather than a modeling error.
        domain_lb, domain_ub = self._bound_stack[0] if self._bound_stack else (prev_lb, prev_ub)
        outside = np.asarray(pinned & ((target < domain_lb) | (target > domain_ub)))
        if outside.any():
            i = int(np.argmax(outside.ravel()))
            raise ValueError(
                f"Variable {self.name!r}: cannot fix element {i} at "
                f"{float(np.asarray(target).ravel()[i])!r}, which is outside its "
                f"declared bounds [{float(np.asarray(domain_lb).ravel()[i])!r}, "
                f"{float(np.asarray(domain_ub).ravel()[i])!r}]. Fixing there would make "
                f"the model infeasible with no other symptom; widen the declared bounds "
                f"first if that is what you meant."
            )

        if self._int_default_sides:
            # #2281: ``unfix`` restores the box, so it restores the record with it.
            self.__dict__.setdefault("_int_default_record_at", {})[len(self._bound_stack)] = (
                self._int_default_sides
            )
        self._bound_stack.append((prev_lb, prev_ub))
        self.lb = new_lb
        self.ub = new_ub
        return self

    def unfix(self) -> "Variable":
        """Undo the most recent :meth:`fix`, restoring the box it replaced."""
        if not self._bound_stack:
            raise ValueError(
                f"Variable {self.name!r} has no fix() to undo (fix_depth is 0). "
                "unfix() restores the box a fix() saved; it is not a way to clear "
                "bounds set at declaration time."
            )
        self.lb, self.ub = self._bound_stack.pop()
        record = self.__dict__.get("_int_default_record_at", {}).pop(len(self._bound_stack), None)
        if record is not None:
            self._int_default_sides = record
        return self

    @_contextlib.contextmanager
    def fixed(self, value, *, where=None) -> "Iterator[Variable]":
        """Scoped :meth:`fix` — restores the previous box on exit, exceptions included.

        Prefer this to a bare ``fix``/``unfix`` pair whenever the fix is
        temporary: an exception between the two leaves ``lb == ub`` behind, and
        because bounds are read live, the *next* solve then reports
        ``status="optimal"`` for a different problem.

        >>> with k.fixed(0.7965):
        ...     m.maximize(profit)
        ...     result = m.solve()
        """
        depth_before = len(self._bound_stack)
        self.fix(value, where=where)
        token = object()
        self._fix_scope_tokens.append((token, depth_before))
        completed = False
        try:
            yield self
            completed = True
        finally:
            # #1311: two `fixed()` scopes on the same variable, held open
            # across a callback/generator boundary rather than nested in a
            # single ``with`` block, can close out of LIFO order. Popping
            # blindly to ``depth_before`` in that case would silently discard
            # the OTHER scope's still-open fix and restore the wrong box, with
            # no error until that other scope's own (now out-of-sync) exit --
            # by which point a solve run in between may already have seen the
            # wrong box. Detect the divergence right here, before unwinding
            # anything.
            if not self._fix_scope_tokens or self._fix_scope_tokens[-1][0] is not token:
                raise RuntimeError(
                    f"Variable {self.name!r}: fixed() scopes were closed out of "
                    "order -- another fixed() (or Model.fixed()) scope on this "
                    "variable is still open. Close nested scopes in the reverse "
                    "order they were entered (a plain ``with`` block already "
                    "guarantees this; only overlapping/stored context managers "
                    "can violate it)."
                )
            self._fix_scope_tokens.pop()
            while len(self._bound_stack) > depth_before:
                self.unfix()
            if completed and len(self._bound_stack) != depth_before:
                raise RuntimeError(
                    f"Variable {self.name!r}: the body of fixed() called unfix() more "
                    f"often than fix(), leaving the stack below the depth this scope "
                    f"entered at ({len(self._bound_stack)} < {depth_before}); the box "
                    "restored on exit is therefore not the one this scope saved."
                )

    def __hash__(self):
        return id(self)

    def __repr__(self):
        if self.shape == () or self.shape == (1,):
            return self.name
        return f"{self.name}{list(self.shape)}"


def _pure_integer_index(index) -> Optional[tuple[int, ...]]:
    """*index* as a tuple of plain ints when it is pure-integer indexing, else ``None``.

    ``bool`` is deliberately excluded even though ``isinstance(True, int)`` holds:
    numpy treats a scalar boolean as a *mask*, not an index, and adds an axis
    (``zeros((5,))[True].shape == (1, 5)``). Letting a bool through here would
    hand back ``()`` and silently mis-shape the node. ``np.bool_`` is not an
    ``np.integer`` subclass, so it falls out on its own.
    """
    if isinstance(index, bool):
        return None
    if isinstance(index, (int, np.integer)):
        return (int(index),)
    if isinstance(index, tuple):
        out = []
        for i in index:
            if isinstance(i, bool) or not isinstance(i, (int, np.integer)):
                return None
            out.append(int(i))
        return tuple(out)
    return None


def _index_result_shape(base_shape: tuple[int, ...], index) -> Optional[tuple[int, ...]]:
    """Numpy result shape of ``base_shape[index]``, or ``None`` when static
    inference is not possible (issue #816).

    Builds a zero-storage broadcast *view* of the base shape (no allocation, even
    for large variables) and applies the *same* index the JAX compiler applies at
    evaluation time (``base[index]`` — see ``dag_compiler._compile_node``). This
    is a pure *best-effort shape query*: it NEVER raises. Any index numpy cannot
    resolve against the shape (out of range, too many indices, a symbolic/exotic
    index object) yields ``None`` = "unknown". The out-of-bounds *guard* that
    surfaces user typos lives in :meth:`Expression.__getitem__`, so that internal
    lazy ``IndexExpression`` construction stays conservative.

    Pure-integer indexing -- a plain int, or an all-int tuple of arity <= ndim,
    which is what ``x[i]`` produces on every element of every indexed family --
    is answered arithmetically instead: consuming ``k`` integer axes leaves
    ``base_shape[k:]``. That is the construction hot path: the numpy probe below
    ran once per ``x[i]`` purely to re-derive ``()``. Interleaved A/B in one
    process, 9 reps, 20k-instance bilinear family: 18.49 -> 9.64 us/instance
    (1.92x, pooled sd 0.016 s); on a 40-form x 5,000 = 200k-instance model,
    27.92 -> 21.21 us/instance (1.32x, 5 reps). Bound-neutral per CLAUDE.md §5 --
    paired LP/MILP/NLP/MINLP solves are bit-identical on status, objective and
    node_count. The fast path reproduces the probe's contract exactly, including
    returning ``None`` for an out-of-range axis (where numpy raises) rather than
    guessing a shape; ``test_index_shape_fast_path.py`` is the equivalence grid.
    """
    ints = _pure_integer_index(index)
    if ints is not None and len(ints) <= len(base_shape):
        for i, n in zip(ints, base_shape):
            if i < -n or i >= n:
                return None  # numpy would raise IndexError -> "unknown"
        return tuple(base_shape[len(ints) :])
    try:
        probe = np.broadcast_to(np.zeros((), dtype=np.int8), base_shape)
        return tuple(int(d) for d in np.shape(probe[index]))
    except Exception:
        return None


def _integer_index_out_of_range(base_shape: tuple[int, ...], idx):
    """Return an ``IndexError`` to raise if *idx* is pure-integer indexing that is
    out of range for *base_shape*, else ``None`` (issue #816).

    Only a plain integer or a full-arity all-integer tuple is checked — exactly
    the ``x[99]`` / ``X[i, j]`` typo the issue calls out. Slices, ellipsis,
    ``newaxis``, non-integer keys, and wrong-arity (too-many / too-few) tuples
    are left to the lenient path: those are the lazy forms the expression-graph
    machinery constructs and resolves downstream, so tightening them here would
    be a false rejection.
    """
    if isinstance(idx, (int, np.integer)):
        idx_tuple: tuple = (int(idx),)
    elif (
        isinstance(idx, tuple)
        and len(idx) == len(base_shape)
        and all(isinstance(i, (int, np.integer)) for i in idx)
    ):
        idx_tuple = tuple(int(i) for i in idx)
    else:
        return None
    for axis, (i, n) in enumerate(zip(idx_tuple, base_shape)):
        if i < -n or i >= n:
            return IndexError(f"index {i} is out of bounds for axis {axis} with size {n}")
    return None


class IndexExpression(Expression):
    """Result of indexing into an array variable: x[i] or x[0, 1]."""

    def __init__(self, base: Expression, index, *, shape_hint=_UNSET_SHAPE):
        self.base = base
        self.index = index
        # `shape_hint` is the construction fast path (#1215 candidate 4): a
        # caller that has already established the result shape passes it here
        # instead of making this constructor re-derive it. `Variable.__getitem__`
        # is the only user -- for a plain `int` into a 1-D variable the answer is
        # always `()`, and deriving it cost TWO `_known_shape` calls (each
        # copying a tuple), `_pure_integer_index`, and a range scan that
        # `__getitem__` had just run. Everything else still goes through the
        # inference below, unchanged.
        if shape_hint is not _UNSET_SHAPE:
            self._shape = shape_hint
            return
        # Best-effort static shape inference only (issue #816). Construction is
        # intentionally non-raising: the out-of-bounds guard lives on the ``[]``
        # operator (:meth:`Expression.__getitem__`) so that direct
        # ``IndexExpression(base, idx)`` construction by the expression-graph
        # machinery — which uses out-of-range / non-integer / too-many-index
        # forms as lazy nodes — stays conservative. A shaped (ndim >= 1) base
        # with a statically resolvable index gets a concrete shape; everything
        # else (scalar base, unknown base, or an index numpy cannot resolve)
        # stays shape-unknown.
        base_shape = _known_shape(base)
        if base_shape is not None and len(base_shape) >= 1:
            self._shape = _index_result_shape(base_shape, index)
        else:
            self._shape = None

    def __repr__(self):
        return f"{self.base}[{self.index}]"


def _known_shape(node: "Expression") -> Optional[tuple[int, ...]]:
    """Best-effort static shape of an expression, or ``None`` when unknown (M8).

    Deliberately *conservative*: it returns a concrete shape only for the nodes
    whose shape follows unambiguously from numpy rules — leaves
    (``Variable``/``Constant``/``Parameter``), element-wise ``BinaryOp`` /
    ``UnaryOp`` compositions, indexing/slicing (``IndexExpression``), and
    element-wise ``FunctionCall`` (all of which cache their shape at
    construction). For every other node (matmul, reductions, custom calls,
    indexed containers, …) it returns ``None`` = "don't know", so the caller must
    treat ``None`` as "cannot check" and never raise. This guarantees the M8
    shape guard only ever fires on a *provably* incompatible pair and never
    rejects a valid model (cert-baseline neutral).
    """
    cached = getattr(node, "_shape", _UNSET_SHAPE)
    if cached is not _UNSET_SHAPE:
        # ``cached`` is either a concrete shape tuple or ``None`` (computed-unknown).
        # Variable/Parameter store their declared shape here via the ``shape``
        # setter, so they are covered by this branch too.
        return None if cached is None else tuple(cached)
    if isinstance(node, Constant):
        return tuple(node.value.shape)
    return None


def _broadcast_shapes(
    op: str, s_left: tuple[int, ...], s_right: tuple[int, ...]
) -> tuple[int, ...]:
    """Numpy broadcast of two *known* shapes, raising a clear error on mismatch.

    Only called when both operand shapes are known (M8). A broadcast failure is a
    genuine build-time error — the same operation would blow up deep in the JAX
    NLPEvaluator with an opaque traceback, or (worse) be silently mis-extracted —
    so raise here with both operand shapes named.
    """
    # Hot path: building a large McCormick relaxation constructs millions of
    # element-wise ``BinaryOp`` nodes (~1.5M for a single qap node), the vast
    # majority on identical shapes — scalars ``() op ()`` or matched arrays. Equal
    # shapes broadcast to themselves, and a scalar broadcasts to the other operand;
    # both are exact and skip the ~10x-slower ``numpy.broadcast_shapes`` machinery
    # (profiled ~2.5s of a 12.6s 4-node build). Result is identical to the numpy
    # path, so this is bound-neutral. Differing non-scalar shapes still defer to
    # numpy, which additionally validates broadcast-compatibility.
    if s_left == s_right or s_right == ():
        return s_left
    if s_left == ():
        return s_right
    try:
        return tuple(int(d) for d in np.broadcast_shapes(s_left, s_right))
    except ValueError:
        raise ValueError(
            f"Incompatible operand shapes for '{op}': {s_left} and {s_right} do "
            f"not broadcast (numpy broadcasting rules). Check the shapes of the "
            f"two operands — a shaped variable/parameter must broadcast against "
            f"the other side of the operation."
        ) from None


class BinaryOp(Expression):
    """Binary operation: a op b."""

    def __init__(self, op: str, left: Expression, right: Expression):
        self.op = op
        self.left = left
        self.right = right
        # Static shape inference + build-time shape check (M8). When BOTH operand
        # shapes are statically known, verify they broadcast and cache the result
        # so compositions stay O(1). If either is unknown, the shape is unknown
        # (``None``) and we do not check — conservative, never a false rejection.
        #
        # ``_known_shape`` and ``_broadcast_shapes``' equal/scalar cases are
        # INLINED here, and only here. This constructor is the inner loop of the
        # whole modelling layer -- 100 000 calls for 50 000 rows -- and the two
        # ``_known_shape`` calls per node were 220 000 calls and 13% of a build's
        # profile (#1215) to do a ``getattr`` and a comparison. The semantics are
        # unchanged: ``_shape`` is the same single source of truth (normalised to
        # a tuple by the ``shape`` setter), ``Constant`` is the one leaf that
        # keeps its shape on ``value`` instead, and anything else is "unknown".
        # NOTE the sentinel: ``_shape``'s class default is ``_UNSET_SHAPE``
        # ("not computed"), which is deliberately distinct from a cached ``None``
        # ("computed, unknown"). Testing against ``None`` instead silently let the
        # sentinel through into ``np.broadcast_shapes``.
        sl = getattr(left, "_shape", _UNSET_SHAPE)
        if sl is _UNSET_SHAPE:
            sl = left.value.shape if type(left) is Constant else None
        sr = getattr(right, "_shape", _UNSET_SHAPE)
        if sr is _UNSET_SHAPE:
            sr = right.value.shape if type(right) is Constant else None
        if sl is None or sr is None:
            self._shape = None
        elif sl == sr or sr == ():
            self._shape = sl
        elif sl == ():
            self._shape = sr
        else:
            self._shape = _broadcast_shapes(op, sl, sr)

    def __repr__(self):
        return f"({self.left} {self.op} {self.right})"


class UnaryOp(Expression):
    """Unary operation: op(a)."""

    def __init__(self, op: str, operand: Expression):
        self.op = op
        self.operand = operand
        # ``neg``/``abs`` are element-wise and shape-preserving: propagate the
        # operand's known shape so it flows into a subsequent BinaryOp check (M8).
        self._shape = _known_shape(operand)

    def __repr__(self):
        return f"{self.op}({self.operand})"


# Named functions that are element-wise: their output shape is the numpy
# broadcast of their argument shapes. Reductions (``prod``) and any other
# non-element-wise name are deliberately excluded so their shape is reported as
# unknown (``None``) rather than mis-inferred (issue #816). Kept in sync with the
# ``FunctionCall``-producing helpers below and the JAX/Rust evaluators, which
# apply these functions element-wise.
_ELEMENTWISE_FUNCS: frozenset = frozenset(
    {
        "exp",
        "log",
        "log2",
        "log10",
        "log1p",
        "sqrt",
        "sin",
        "cos",
        "tan",
        "atan",
        "atan2",
        "asin",
        "acos",
        "sinh",
        "cosh",
        "asinh",
        "acosh",
        "atanh",
        "erf",
        "tanh",
        "sigmoid",
        "softplus",
        "entropy",
        "abs",
        "sign",
        "min",
        "max",
    }
)


class DiscontinuousIntrinsicError(NotImplementedError):
    """Raised for an intrinsic that is recognised but has no node in the IR.

    ``floor``, ``ceil``, ``round``, ``trunc`` and ``intdiv`` are *step*
    functions. Unlike every intrinsic the modeling layer does export, they are
    discontinuous in their argument, so representing one soundly is not a matter
    of adding a name to a table -- it needs, at minimum:

    * an ``ExprNode``/``MathFunc`` variant in the Rust IR,
    * forward and backward FBBT rules for a step function
      (``crates/discopt-core/src/presolve/fbbt.rs``),
    * a convex/concave envelope in the relaxation layer, and
    * an integrality reformulation (``floor(x) = z`` with ``z`` integer and
      ``z <= x <= z + 1 - eps``), which changes the model's *variable set*
      rather than just its expression DAG -- so the AD tape has something
      differentiable to work with.

    Until that exists, discopt refuses rather than substituting a different
    operator. This mirrors the ``.nl`` parser's C-5 policy
    (``NlParseError::UnsupportedOpcode`` for opcodes o13/o14/o55/o57/o58):
    silently rewriting ``floor(x)`` to ``x`` makes the solver *certify the
    optimum of a different problem than the user posed*, which is a false
    certificate, not a slow answer (CLAUDE.md §1).

    Why ``sign`` is exported and these are not, although it is discontinuous
    too: ``sign`` has the IR and FBBT pieces listed above -- an IR variant
    (``MathFunc::Sign``) and the interval rule ``sign(x) in [-1, 1]``
    (``fbbt.rs``) -- and needs no integrality reformulation, because its range
    is a bounded, fixed, three-point set that needs no auxiliary variable. (It
    has no envelope in the default relaxation engine: its only one,
    ``relax_sign``, lived in the McCormick-"nlp" route retired in #1873, so a
    model with ``sign`` gets no dual bound and is reported uncertified.) A step function
    with an unbounded range does not fit that treatment; it needs the integer
    reformulation above. So the difference is not "``sign`` is smoother", it is
    "``sign`` was implemented and these were not".

    See https://github.com/jkitchin/discopt/issues/1237.
    """


class Atan2BranchCutError(ValueError):
    """Raised when ``dm.atan2``'s box may touch the branch cut ``{y = 0, x <= 0}``.

    Distinct from :class:`DiscontinuousIntrinsicError`, and deliberately not a
    subclass of it: that error says *the operator* is unimplemented, whereas
    ``atan2`` is fully implemented — just not on this **box**. Bound either
    argument away from zero and the same model builds, relaxes and certifies.
    It is a ``ValueError`` because the defect is in the bounds the caller
    supplied, not in discopt's coverage.

    See :mod:`discopt.modeling._atan2` for why the cut is a hard obstacle rather
    than a missing envelope: the jump across it does not shrink under branching,
    so a relaxation over a cut-straddling box can never close a gap.
    """


#: Intrinsics that are *recognised but unimplemented*, mapped to the note shown
#: to the user. Membership here is the single source of truth: every doorway into
#: the IR (:class:`FunctionCall`, the GAMS parser, the public ``dm.floor`` /
#: ``dm.ceil`` / ``dm.round_`` / ``dm.trunc`` shims) refuses the same set with the
#: same message, so a name can never be unrepresentable at one door and accepted
#: at another. Keep in sync with the ``.nl`` parser's C-5 opcode refusals
#: (``crates/discopt-core/src/nl_parser.rs``).
_UNREPRESENTABLE_INTRINSICS: dict = {
    "floor": "floor(x) -- the greatest integer <= x",
    "ceil": "ceil(x) -- the least integer >= x",
    "round": "round(x) -- x rounded to the nearest integer",
    "trunc": "trunc(x) -- x truncated toward zero",
    "intdiv": "intdiv(a, b) -- integer (truncating) division",
}


def _unrepresentable_intrinsic_message(name: str, *, where: str = "") -> str:
    """Build the refusal text for an unimplemented discontinuous intrinsic."""
    what = _UNREPRESENTABLE_INTRINSICS[name]
    prefix = f"{where}: " if where else ""
    return (
        f"{prefix}{name!r} is not implemented: {what} is a discontinuous step "
        "function, and discopt's expression IR has no node for it. Modeling it "
        "soundly requires an integrality reformulation that adds variables (for "
        f"{name!r}: an integer z with z <= x <= z + 1 - eps), plus FBBT and "
        "relaxation rules for a step function -- not just an expression node."
        "\n\n"
        "discopt refuses here rather than substituting a different operator "
        "(e.g. the identity), because that would make the solver certify the "
        "optimum of a different problem than the one posed -- a false "
        "certificate rather than a slow answer. The .nl parser refuses the "
        "matching opcodes for the same reason (correctness issue C-5)."
        "\n\n"
        "Reformulate the model explicitly instead. For y = floor(x) with "
        "l <= x <= u, declare an integer variable and bound it:\n"
        "    z = m.integer('z', lb=math.floor(l), ub=math.floor(u))\n"
        "    m.subject_to(z <= x)\n"
        "    m.subject_to(x <= z + 1 - eps)\n"
        "and use z in place of floor(x). Track native support at "
        "https://github.com/jkitchin/discopt/issues/1237."
    )


class FunctionCall(Expression):
    """Named function call: exp(x), log(x), sin(x), etc."""

    def __init__(self, func_name: str, *args: Expression):
        # Refuse an intrinsic that has no IR node AT CONSTRUCTION, not at solve
        # time. This is the single choke point every doorway funnels through
        # (the GAMS parser's function mapper, `serialize.loads`, user code), so
        # guarding it here means such a name can never reach a node. Without it
        # the model builds happily and the first symptom is the
        # incumbent-verification snapshot failing -- which *disables the
        # false-primal guard for that solve* -- followed by an opaque
        # "Unknown function: 'ceil'" from the DAG compiler. See
        # `serialize._known_funcs` for the same argument at the read doorway.
        if func_name in _UNREPRESENTABLE_INTRINSICS:
            raise DiscontinuousIntrinsicError(_unrepresentable_intrinsic_message(func_name))
        self.func_name = func_name
        self.args = args
        # Element-wise functions preserve / broadcast their argument shapes, so
        # cache the result shape to let it flow through subsequent element-wise
        # ops (issue #816). Non-element-wise names (e.g. the reduction ``prod``)
        # keep an unknown shape.
        if func_name in _ELEMENTWISE_FUNCS:
            shp: Optional[tuple[int, ...]] = ()
            for a in args:
                s = _known_shape(a)
                if s is None:
                    shp = None
                    break
                shp = _broadcast_shapes(func_name, shp, s)
            self._shape = shp
        else:
            self._shape = None

    def __repr__(self):
        arg_str = ", ".join(str(a) for a in self.args)
        return f"{self.func_name}({arg_str})"


class CustomCall(Expression):
    """Opaque, AD-only user function wrapping a JAX-traceable callable.

    Unlike :class:`FunctionCall` -- whose ``func_name`` is dispatched to a known
    value / relaxation / interval / ``.nl`` rule -- a ``CustomCall`` carries an
    arbitrary Python callable that discopt evaluates by *tracing it through JAX*.
    discopt can therefore autodifferentiate it for the local NLP path, but it
    CANNOT build the rigorous convex/concave relaxations and interval rules that
    global spatial branch-and-bound, the Rust presolve, and ``.nl`` export
    require.

    Consequences (enforced by the solver and the export/relaxation layers):

    - If the opaque body traces soundly through discopt's reduced-space McCormick
      type (``MCBox`` -- arithmetic ``+ - * / **`` and the ``discopt._relax.mcbox``
      intrinsic namespace), a **continuous** model is now solved **globally with a
      certificate** via the reduced-space engine, branching only on the original
      degrees of freedom while the callable's internal intermediates stay hidden
      (MAiNGO-parity plan P3.1, #713). A body that uses raw ``jnp`` intrinsics on
      its arguments (e.g. ``jnp.exp(x)`` rather than an ``MCBox``-aware op), a
      non-affine hidden division, a non-scalar leaf, or an unbounded box is **not**
      reduced-relaxable and falls back to the **local NLP path only** -- sound-or-
      refuse. That path proves a feasible point, not a global optimum, so it
      reports ``status="feasible"`` with ``gap_certified=False`` and
      ``bound``/``gap``/``root_bound``/``root_gap`` all ``None``: a local NLP's
      objective is not a valid dual bound on a nonconvex body (#998).
    - Integer/binary variables are supported **when the body is MCBox-relaxable**
      (plan P3.2): the model is branched over the integer + continuous DOF with
      reduced-space node bounds and certified globally. A **non**-MCBox-relaxable
      body together with integers has no valid node relaxation, so the solver
      **raises** (sound-or-refuse).
    - Rust presolve/FBBT does not run on a hidden model (the Rust IR has no opaque
      node); interval bounds on the ``CustomCall`` output come from the ``MCBox``
      ``lo/hi`` propagated during the reduced-space trace (Python interval only).
    - Relaxation compilation (the *lifted* McCormick compiler, which has no
      auxiliary column for an opaque node) and ``.nl`` export **raise** a clear
      error; the reduced-space path is the sound relaxation route.

    Built via :func:`custom`; do not instantiate directly in user code.
    """

    #: How many ``CustomCall`` nodes this process has ever created. Counted in
    #: ``__new__``, which construction, ``copy`` and unpickling all go through, so
    #: zero means no model in the process can contain one and the whole-model
    #: "is there an opaque node?" walk can answer without walking. Measured on
    #: ``telecomsp_nor_sun`` (21,270 rows): ~5 s per walk, four walks per solve.
    _instances_created: int = 0

    def __new__(cls, *args, **kwargs):
        CustomCall._instances_created += 1
        return super().__new__(cls)

    def __init__(self, fn: Callable, *args: Expression, name: Optional[str] = None):
        self.fn = fn
        self.args = tuple(args)
        self.name = name or getattr(fn, "__name__", "custom")

    def __repr__(self):
        arg_str = ", ".join(str(a) for a in self.args)
        return f"custom:{self.name}({arg_str})"


class MatMulExpression(Expression):
    """Matrix multiplication: A @ x."""

    def __init__(self, left: Expression, right: Expression):
        self.left = left
        self.right = right

    def __repr__(self):
        return f"({self.left} @ {self.right})"


class SumExpression(Expression):
    """Summation over expressions."""

    def __init__(self, operand: Expression, axis: Optional[int] = None):
        self.operand = operand
        self.axis = axis

    def __repr__(self):
        if self.axis is not None:
            return f"sum({self.operand}, axis={self.axis})"
        return f"sum({self.operand})"


class SumOverExpression(Expression):
    """Sum of expr(i) for i in index_set — the indexed summation pattern."""

    def __init__(self, terms: list[Expression]):
        self.terms = terms

    def __repr__(self):
        return f"Σ[{len(self.terms)} terms]"


#: Interned scalar :class:`Constant` nodes, keyed by value (see :func:`_wrap`).
#:
#: Weak, so a literal that appears only in a model that has since been dropped
#: does not pin its node forever -- a strong cache here would be an unbounded
#: leak for a data-driven model whose coefficients are all distinct (a fitting
#: model carrying one literal per measurement, say).
_SCALAR_CONSTS: "weakref.WeakValueDictionary[float, Constant]" = weakref.WeakValueDictionary()

#: ``0.0`` and ``-0.0`` are equal and hash equal, so one dict cannot hold both --
#: and the sign of zero is not cosmetic in IEEE (``1/-0.0`` is ``-inf``). They get
#: their own strong singletons instead: two objects, held for the process.
_ZERO_CONST: "Constant" = Constant(0.0)
_NEG_ZERO_CONST: "Constant" = Constant(-0.0)


#: Multiplier applied to the gen-0 GC threshold during a bulk build. 100 was
#: measured against 1000 with no difference (#1215), so the smaller transient is
#: preferred: it bounds how much cyclic garbage can accumulate before a
#: collection runs.
_BULK_GC_MULTIPLIER = 100


@_contextlib.contextmanager
def bulk_construction_gc() -> "Iterator[None]":
    """Raise CPython's gen-0 GC threshold for the duration of a bulk build.

    Measured (#1215): building 200 000 rows spends **~40% of its wall in garbage
    collection**, not in constructing anything. A model under construction is
    ~1.6M live, GC-tracked container objects that are *all reachable* -- nothing
    built so far is garbage -- so every collection triggered by the allocation of
    the next row traverses the whole model and frees nothing. Raising the gen-0
    threshold makes those sweeps proportionally rarer.

    ==========================  ======  =========
    arm                         µs/row  speed-up
    ==========================  ======  =========
    default thresholds            6.39  1.00×
    raised, scoped per call       4.24  **1.51×**
    raised for the whole build    4.33  1.48×
    GC disabled entirely          3.66  1.73×
    ==========================  ======  =========

    The saving is real rather than deferred: every arm above was timed with a
    full ``gc.collect()`` *inside* the timed region, so postponed traversal is
    paid for and counted. ``gc.freeze()`` was also tried and is not the mechanism
    (1.08×).

    Scoped per call and restored in ``finally``, so a library caller never
    inherits mutated interpreter state -- and the measurement shows that scoping
    costs nothing against tuning the whole build. Raising a threshold cannot
    change behaviour, only the moment reclamation happens; GC is deliberately
    *not* disabled, which is faster still but leaves an unbounded window in which
    genuine cyclic garbage from a user's rule function accumulates.

    Public, because the biggest models are built by user loops that never reach
    :meth:`Model.constraint`::

        with dm.bulk_construction_gc():
            for i, j in arcs:
                m.subject_to(flow[i, j] <= cap[i, j], name=f"cap_{i}_{j}")
    """
    old = gc.get_threshold()
    gc.set_threshold(old[0] * _BULK_GC_MULTIPLIER, old[1], old[2])
    try:
        yield
    finally:
        gc.set_threshold(*old)


def _wrap(x) -> Expression:
    """Convert a Python scalar or numpy array to a Constant expression.

    Scalar literals are **interned**: ``x[i] * y[i] <= 4.0`` written across
    200 000 rows builds one ``Constant`` for ``4.0``, not 200 000. Measured
    (#1215) at 0.076 us for a cache hit against 0.461 us to construct, on a path
    called three times per row -- and the duplicates were pure waste, since a
    ``Constant`` is immutable by contract and carries no per-use state.

    Like the canonical ``x[i]`` handles, the win is not only the allocation:
    expressions hash by identity, so sharing the literal lets the ``id()``-keyed
    memos in the walkers, the relaxation layer and the tape lowering hit across
    rows.

    ``bool``/``int``/``float`` share one key space on purpose -- ``4``, ``4.0``
    and ``True``/``1`` all produce a node whose value is the same ``float64`` --
    so the sharing is sound. ``np.float64`` and other numpy scalars are NOT
    interned: they are not ``float``, and admitting them would make the key type
    depend on how the caller spelled the literal for no measured gain.
    """
    if isinstance(x, Expression):
        return x
    if type(x) is float or type(x) is int or type(x) is bool:
        if x == 0:
            return _ZERO_CONST if math.copysign(1.0, x) > 0 else _NEG_ZERO_CONST
        node = _SCALAR_CONSTS.get(x)
        if node is None:
            node = Constant(x)
            _SCALAR_CONSTS[x] = node
        return node
    if isinstance(x, np.ndarray) and x.dtype == object:
        # Reached only by the ``Constant`` fallback -- an interned scalar literal
        # returns above and never pays this test. See ``_ObjectArrayOperand``.
        raise _ObjectArrayOperand(
            f"cannot build a single Constant from an object-dtype array of shape "
            f"{x.shape}; its elements are expressions, not numbers"
        )
    if type(x).__module__.startswith("scipy.sparse"):
        # ``x @ A`` / ``x + A`` with a scipy sparse ``A``: ``Constant`` would call
        # ``np.asarray`` on it, which raises an unrelated ``ValueError`` (or, for
        # other entry points, builds a 0-d object array). Refuse by name instead.
        raise TypeError(
            f"cannot use a scipy sparse {type(x).__name__} as a discopt operand. "
            f"{_SPARSE_OPERAND_HINT}"
        )
    return Constant(x)


#: How to get a sparse matrix into a model; shared by ``_wrap`` and ``Expression.ndim``.
_SPARSE_OPERAND_HINT = (
    "A scipy sparse matrix cannot multiply or combine with a discopt expression "
    "directly. For linear constraints use Model.add_linear_constraints(A, x, sense, b), "
    "which reads A sparsely; for a small matrix, A.toarray() @ x builds a dense "
    "expression."
)


class _ObjectArrayOperand(ValueError):
    """``_wrap`` was handed an object-dtype ndarray (issue #1234).

    The signal the arithmetic dunders catch to route to
    :func:`_object_array_binop`. Raising from ``_wrap``'s ``Constant`` fallback --
    rather than testing for the array in each operator -- keeps the test off the
    scalar-literal path, which is ~3 of the 35 calls a constraint row makes and
    where an extra ``isinstance`` measured +2.7% at 3.0 sigma.

    Subclasses :class:`ValueError` on purpose. ``_wrap`` has many callers besides
    the operators (``dm.sum``, ``dm.prod``, ``Constraint`` bodies), and an
    uncaught escape from one of those should still read as the ``ValueError`` that
    numpy used to raise there -- just with a message that names the operand
    instead of ``setting an array element with a sequence``.
    """


#: Elementwise fallbacks for an object-dtype ndarray operand (issue #1234), keyed
#: by the same operator spelling ``BinaryOp`` uses. Comparisons are deliberately
#: absent: ``arr <= 1.0`` cannot work either, because numpy coerces each element
#: result to ``bool`` and a :class:`Constraint` has no truth value, so there is no
#: working neighbour for ``arr <= x`` to be inconsistent with.
_OBJECT_ARRAY_OPS: "dict[str, Callable[[Any, Any], Any]]" = {
    "+": lambda a, b: a + b,
    "-": lambda a, b: a - b,
    "*": lambda a, b: a * b,
    "/": lambda a, b: a / b,
    "**": lambda a, b: a**b,
}


def _object_array_binop(op: str, left, right) -> np.ndarray:
    """``left <op> right`` elementwise when exactly one side is an object ndarray.

    The cold half of the arithmetic dunders (issue #1234). An object-dtype array
    of expressions -- what a comprehension like ``np.array([f(i) for i in ...],
    dtype=object)`` produces -- combined with a scalar :class:`Expression` used to
    die inside numpy with ``ValueError: setting an array element with a
    sequence``, while every neighbouring case (``arr * arr``, ``arr + 1.0``,
    ``A @ arr``, ``x * np.array([1.0, 2.0])``) worked.

    The scalar operand is broadcast against the array: element ``i`` of the
    result is ``arr[i] <op> scalar`` (or ``scalar <op> arr[i]``), which is what
    numpy itself would have produced had ``__array_ufunc__`` not been set to
    ``None``, and what ``arr * arr`` already does. The result is an object
    ndarray of scalar expressions -- the same contract :func:`concatenate` and
    :func:`stack` return, so it supports indexing, iteration, ``.shape`` and
    further elementwise arithmetic.

    A **shaped** expression operand is refused rather than broadcast. ``arr * xs``
    with both of length 3 reads as elementwise pairing, but treating ``xs`` as one
    scalar operand would give a length-3 array whose every element is itself
    length-3 -- a model with nine rows where the author meant three, and no error
    to say so. The two readings cannot be told apart from the expression, so this
    refuses and names both supported spellings (§3: refuse loudly rather than
    approximate). Only a scalar expression, which is what issue #1234 reported,
    goes through.
    """
    fn = _OBJECT_ARRAY_OPS[op]
    if isinstance(left, np.ndarray):
        arr, scalar, arr_on_left = left, right, True
    else:
        arr, scalar, arr_on_left = right, left, False
    scalar_shape = _object_operand_shape(scalar) if isinstance(scalar, Expression) else ()
    if scalar_shape is None:
        raise TypeError(
            f"cannot combine an object-dtype array of shape {arr.shape} with a "
            f"{type(scalar).__name__} whose shape cannot be determined before the "
            f"solve: if it is array-valued, `{op}` would broadcast each element "
            f"against the whole operand rather than pair them, and nothing would "
            f"say so. Index it to scalars and put them in an object array of the "
            f"same shape for elementwise pairing, or use shaped variables directly "
            f"(`m.continuous(..., shape=...)`), which support `{op}` without an "
            f"object array. If the operand is scalar and its shape simply cannot "
            f"be read statically — a `dm.custom(...)` call is opaque by "
            f"construction — spell the combination out elementwise instead: "
            f"`np.array([e {op} s for e in arr], dtype=object)`, which pairs them "
            f"explicitly and needs no shape."
        )
    if scalar_shape != ():
        raise TypeError(
            f"cannot combine an object-dtype array of shape {arr.shape} with a "
            f"{type(scalar).__name__} of shape {scalar_shape} elementwise: it is "
            f"ambiguous whether you mean to pair them element by element or to "
            f"broadcast each element against the whole operand. For elementwise "
            f"pairing put both sides in object arrays of the same shape; for a "
            f"vectorized model body use shaped variables directly "
            f"(`m.continuous(..., shape=...)`), which support `{op}` without an "
            f"object array."
        )
    out = np.empty(arr.shape, dtype=object)
    # ``np.ndindex(())`` yields the single empty index, so a 0-d array needs no
    # special case -- it goes round the loop once and writes ``out[()]``.
    for idx in np.ndindex(arr.shape):
        out[idx] = fn(arr[idx], scalar) if arr_on_left else fn(scalar, arr[idx])
    return out


_SCALAR_REDUCTION_RE = re.compile(r"norm(inf|[0-9.]+)")


def _object_operand_shape(expr: "Expression") -> Optional[tuple[int, ...]]:
    """Static shape of the expression operand of :func:`_object_array_binop`.

    ``None`` means "cannot tell", and the caller refuses on it (#1289): the
    construction-time :func:`_known_shape` is ``None`` for every matmul and
    reduction, so ``arr * (np.eye(3) @ xs)`` -- a 3-vector -- used to slip past the
    ambiguity refusal and broadcast into nine rows. This adds the shapes
    :func:`discopt._relax.scalarize.static_shape` resolves (matmul, axis sums,
    compositions over them) and the full reductions ``prod`` and ``norm*``, which
    are scalar whatever their operand.
    """
    shape = _known_shape(expr)
    if shape is not None:
        return shape
    if isinstance(expr, FunctionCall) and len(expr.args) == 1:
        if expr.func_name == "prod" or _SCALAR_REDUCTION_RE.fullmatch(expr.func_name):
            return ()
    if isinstance(expr, UnaryOp):
        return _object_operand_shape(expr.operand)
    if isinstance(expr, BinaryOp) and expr.op in ("+", "-", "*", "/", "**"):
        ls = _object_operand_shape(expr.left)
        rs = _object_operand_shape(expr.right)
        if ls is None or rs is None:
            return None
        try:
            return tuple(int(d) for d in np.broadcast_shapes(ls, rs))
        except ValueError:
            return None
    from discopt._relax.scalarize import static_shape

    return static_shape(expr)


def _is_term_iterable(x) -> bool:
    """True for a generator/iterable of terms (not a scalar Expression/array/str).

    Indexed containers (:class:`IndexedVar` / :class:`IndexedParam`) are excluded
    even though they are iterable: their iterator yields index *keys*, not term
    expressions, so treating them as a term-iterable would silently fold the keys
    in as constants. ``sum``/``prod`` expand them explicitly instead.
    """
    if isinstance(x, (Expression, np.ndarray, str, bytes)):
        return False
    if getattr(x, "_is_indexed_container", False):
        return False
    return hasattr(x, "__iter__")


def _expand_indexed_container(x):
    """If *x* is an IndexedVar/IndexedParam, return its element expressions."""
    if getattr(x, "_is_indexed_container", False):
        return [x[k] for k in x.index_set]
    return x


def _call_over(fn: Callable, member, over):
    """Call ``fn`` on a set member, unpacking tuple members for ``dimen > 1`` sets."""
    if getattr(over, "dimen", 1) > 1 and isinstance(member, tuple):
        return fn(*member)
    return fn(member)


# ─────────────────────────────────────────────────────────────
# Mathematical Functions (dm.exp, dm.log, dm.sin, etc.)
# ─────────────────────────────────────────────────────────────


def exp(x: Union[Expression, float]) -> Expression:
    """
    Exponential function.

    Parameters
    ----------
    x : Expression or float
        Input expression.

    Returns
    -------
    Expression
        Expression representing ``e**x``.
    """
    return FunctionCall("exp", _wrap(x))


def log(x: Union[Expression, float]) -> Expression:
    """
    Natural logarithm.

    Parameters
    ----------
    x : Expression or float
        Input expression (must be positive at evaluation).

    Returns
    -------
    Expression
        Expression representing ``ln(x)``.
    """
    return FunctionCall("log", _wrap(x))


def log2(x: Union[Expression, float]) -> Expression:
    """
    Base-2 logarithm.

    Parameters
    ----------
    x : Expression or float
        Input expression (must be positive at evaluation).

    Returns
    -------
    Expression
    """
    return FunctionCall("log2", _wrap(x))


def log10(x: Union[Expression, float]) -> Expression:
    """
    Base-10 logarithm.

    Parameters
    ----------
    x : Expression or float
        Input expression (must be positive at evaluation).

    Returns
    -------
    Expression
    """
    return FunctionCall("log10", _wrap(x))


def sqrt(x: Union[Expression, float]) -> Expression:
    """
    Square root.

    Parameters
    ----------
    x : Expression or float
        Input expression (must be non-negative at evaluation).

    Returns
    -------
    Expression
    """
    return FunctionCall("sqrt", _wrap(x))


def sin(x: Union[Expression, float]) -> Expression:
    """
    Sine.

    Parameters
    ----------
    x : Expression or float
        Input expression (radians).

    Returns
    -------
    Expression
    """
    return FunctionCall("sin", _wrap(x))


def cos(x: Union[Expression, float]) -> Expression:
    """
    Cosine.

    Parameters
    ----------
    x : Expression or float
        Input expression (radians).

    Returns
    -------
    Expression
    """
    return FunctionCall("cos", _wrap(x))


def tan(x: Union[Expression, float]) -> Expression:
    """
    Tangent.

    Parameters
    ----------
    x : Expression or float
        Input expression (radians).

    Returns
    -------
    Expression
    """
    return FunctionCall("tan", _wrap(x))


def atan(x: Union[Expression, float]) -> Expression:
    """Inverse tangent (arctan); image in (-π/2, π/2)."""
    return FunctionCall("atan", _wrap(x))


def atan2(y: Union[Expression, float], x: Union[Expression, float]) -> Expression:
    """Two-argument arctangent: the angle of the point ``(x, y)``, in ``(-π, π]``.

    Argument order follows :func:`math.atan2` / :func:`numpy.arctan2` / GAMS
    ``arctan2`` — the **ordinate first**.

    ``atan2`` is not an atom in discopt, and this builder does not create one.
    It is discontinuous across the branch cut ``{y = 0, x <= 0}``, and that jump
    does not shrink under branching (refining a box onto the cut drives the
    range of ``atan2`` toward ``2π``), so no rigorous relaxation over a
    cut-straddling box can ever certify a bound. Instead this rewrites ``atan2``
    **exactly**, using the declared bounds of *x* and *y*, into ``atan`` over a
    sign-definite ratio::

        x > 0:   atan(y / x)
        y > 0:   π/2 - atan(x / y)
        y < 0:   -π/2 - atan(x / y)

    The result is an ordinary smooth expression over atoms discopt already
    relaxes rigorously, so it propagates, relaxes and certifies like any other
    model — no new IR node, no new envelope. The last two identities cover the
    left half-plane as well, so the only refused region is the cut itself.

    Parameters
    ----------
    y : Expression or float
        Ordinate.
    x : Expression or float
        Abscissa.

    Returns
    -------
    Expression
        The rewritten expression — never a ``FunctionCall("atan2", ...)``.

    Raises
    ------
    Atan2BranchCutError
        When the declared bounds do not place the whole box strictly inside one
        of the three half-planes. The message names the enclosures it read and
        the bound to add.

    Examples
    --------
    >>> import discopt.modeling as dm
    >>> m = dm.Model()
    >>> x = m.continuous("x", lb=0.5, ub=2.0)
    >>> y = m.continuous("y", lb=0.5, ub=2.0)
    >>> m.minimize(dm.atan2(y, x))
    """
    from discopt.modeling._atan2 import (
        branch_cut_message,
        build_rewrite,
        classify_atan2,
    )

    yw, xw = _wrap(y), _wrap(x)
    cls = classify_atan2(yw, xw)
    rewritten = build_rewrite(cls, yw, xw)
    if rewritten is None:
        raise Atan2BranchCutError(branch_cut_message(cls))
    # `build_rewrite` has recorded the sign this identity assumed, so
    # `validate()` can refuse a model whose bounds were widened out from under
    # it before the solve certifies the wrong function.
    return rewritten


def asin(x: Union[Expression, float]) -> Expression:
    """Inverse sine (arcsin); domain [-1, 1]."""
    return FunctionCall("asin", _wrap(x))


def acos(x: Union[Expression, float]) -> Expression:
    """Inverse cosine (arccos); domain [-1, 1]."""
    return FunctionCall("acos", _wrap(x))


def sinh(x: Union[Expression, float]) -> Expression:
    """Hyperbolic sine."""
    return FunctionCall("sinh", _wrap(x))


def cosh(x: Union[Expression, float]) -> Expression:
    """Hyperbolic cosine."""
    return FunctionCall("cosh", _wrap(x))


def asinh(x: Union[Expression, float]) -> Expression:
    """Inverse hyperbolic sine."""
    return FunctionCall("asinh", _wrap(x))


def acosh(x: Union[Expression, float]) -> Expression:
    """Inverse hyperbolic cosine (x >= 1)."""
    return FunctionCall("acosh", _wrap(x))


def atanh(x: Union[Expression, float]) -> Expression:
    """Inverse hyperbolic tangent (-1 < x < 1)."""
    return FunctionCall("atanh", _wrap(x))


def erf(x: Union[Expression, float]) -> Expression:
    """Gauss error function."""
    return FunctionCall("erf", _wrap(x))


def log1p(x: Union[Expression, float]) -> Expression:
    """Numerically stable log(1 + x) (x > -1)."""
    return FunctionCall("log1p", _wrap(x))


def tanh(x: Union[Expression, float]) -> Expression:
    """
    Hyperbolic tangent.

    Parameters
    ----------
    x : Expression or float
        Input expression.

    Returns
    -------
    Expression
        Expression representing ``tanh(x)``.
    """
    return FunctionCall("tanh", _wrap(x))


def sigmoid(x: Union[Expression, float]) -> Expression:
    """
    Logistic sigmoid: ``1 / (1 + exp(-x))``.

    Parameters
    ----------
    x : Expression or float
        Input expression.

    Returns
    -------
    Expression
        Expression representing ``sigmoid(x)``, valued in ``(0, 1)``.
    """
    return FunctionCall("sigmoid", _wrap(x))


def softplus(x: Union[Expression, float]) -> Expression:
    """
    Softplus: ``log(1 + exp(x))``.

    A smooth approximation of ReLU.

    Parameters
    ----------
    x : Expression or float
        Input expression.

    Returns
    -------
    Expression
        Expression representing ``softplus(x)``, always positive.
    """
    return FunctionCall("softplus", _wrap(x))


def xlogx(x: Union[Expression, float]) -> Expression:
    r"""
    Negative-entropy term :math:`x \log x`, extended by continuity to ``x = 0``.

    This is the ideal-mixing / Shannon-entropy atom: a sum
    :math:`\sum_i x_i \log x_i` over a simplex is the (negative) entropy of the
    distribution ``x``. Building it with this helper rather than as the raw
    product ``x * dm.log(x)`` matters for a *global* solve: the atom carries a
    dedicated convex underestimator, an exact interval rule and a convexity
    profile, whereas the raw product is relaxed factorably (``x`` times a
    ``log``) and its bound does not tighten to the true convex envelope.

    Values and derivatives at the endpoints of the domain:

    - ``xlogx(0) = 0``. The mathematical limit :math:`x \log x \to 0` as
      :math:`x \to 0^+` is taken as the *value*, so the atom is continuous and
      finite on the closed domain ``[0, inf)`` — which is what makes it usable
      on a site-fraction / mole-fraction box that starts at 0.
    - The true derivative ``log(x) + 1`` diverges to ``-inf`` at ``x = 0``.
      Evaluators deliberately report a large finite number there instead (the
      argument is floored at ``1e-300``, giving a slope near ``-689.8``), so a
      box pinned at ``[0, 0]`` cannot propagate a non-finite into a bound. The
      *symbolic* derivative (:func:`discopt.bilevel.symbolic_diff.diff`) is the
      exact ``log(x) + 1`` and is therefore unbounded at 0.
    - ``x < 0`` is outside the domain. The interval rule abstains (returns
      ``[-inf, inf]``) rather than guessing. One case is not a genuine dip:
      interval evaluation rounds OUTWARD, so an affine argument that reaches 0
      exactly (``1 - y`` over ``y in [0, 1]``, ``K - K*y``) arrives with a lower
      bound a rounding error below 0 (``-2.2e-16``; ``O(K * eps)`` in general).
      The relaxation reads such a box as starting at the closed edge 0 and
      envelopes it over ``[0, hi]`` (#1242; ``DISCOPT_CLOSED_EDGE_ENVELOPES=0``
      opts out), which removes only argument values where the atom is
      undefined. A box reaching further below 0 than the argument's own
      rounding scale gets no envelope, only the interval floor.

    Parameters
    ----------
    x : Expression or float
        Input expression. The relaxation and interval rules require a
        nonnegative (up to outward rounding, see above), finite box on ``x``.

    Returns
    -------
    Expression
        Expression representing ``x * log(x)``, convex on ``x >= 0``, with
        minimum ``-1/e`` at ``x = 1/e``.

    Examples
    --------
    >>> import discopt.modeling as dm
    >>> m = dm.Model()
    >>> y = m.continuous("y", lb=0.0, ub=1.0)
    >>> m.minimize(dm.xlogx(y) + dm.xlogx(1 - y))   # binary entropy
    """
    return FunctionCall("entropy", _wrap(x))


def abs_(x: Union[Expression, float]) -> Expression:
    """
    Absolute value.

    Exported as ``dm.abs`` in the ``discopt.modeling`` namespace.

    Parameters
    ----------
    x : Expression or float
        Input expression.

    Returns
    -------
    Expression
    """
    return FunctionCall("abs", _wrap(x))


def sign(x: Union[Expression, float]) -> Expression:
    """
    Sign function: returns -1, 0, or +1.

    Parameters
    ----------
    x : Expression or float
        Input expression.

    Returns
    -------
    Expression
    """
    return FunctionCall("sign", _wrap(x))


def _refuse_unrepresentable(name: str):
    """Build a public shim for an intrinsic discopt recognises but cannot model.

    The name is exported so that ``dm.floor`` reads as a *deliberate exclusion
    with an explanation* rather than as an oversight: before this, the only
    signal was ``AttributeError: module 'discopt.modeling' has no attribute
    'floor'``, which is indistinguishable from a name someone forgot to export
    (issue #1237).
    """

    def shim(*args, **kwargs):
        raise DiscontinuousIntrinsicError(_unrepresentable_intrinsic_message(name))

    shim.__name__ = name
    shim.__qualname__ = name
    shim.__doc__ = (
        f"Not implemented: ``{name}`` is a discontinuous step function with no "
        "node in discopt's expression IR.\n\n"
        f"Calling this raises :class:`DiscontinuousIntrinsicError` (a "
        "``NotImplementedError``) explaining how to reformulate the model with "
        "an explicit integer variable. It exists so the refusal is explicit and "
        "documented rather than an ``AttributeError`` from a missing name.\n\n"
        "See :class:`DiscontinuousIntrinsicError` for why ``sign`` is supported "
        "and this is not, and https://github.com/jkitchin/discopt/issues/1237 "
        "to track native support."
    )
    return shim


floor = _refuse_unrepresentable("floor")
ceil = _refuse_unrepresentable("ceil")
#: ``round`` shadows a builtin, so it carries the trailing-underscore spelling
#: the modeling layer already uses for ``abs_``. ``trunc`` shadows nothing in
#: builtins (only ``math.trunc``), so it keeps its plain name.
round_ = _refuse_unrepresentable("round")
trunc = _refuse_unrepresentable("trunc")


def _balanced_minmax_fold(fname: str, terms: Sequence[Expression]) -> Expression:
    """Fold ``terms`` into a ``ceil(log2(n))``-deep tree of binary ``min``/``max``.

    ``min``/``max`` are associative, so every parenthesisation of the same terms
    is the same function; the fold shape is free, and pairing adjacent terms is
    what makes the depth logarithmic instead of linear. The left-deep fold this
    replaces -- ``dm.minimum(dm.minimum(a, b), c)``, which was the only spelling
    available before #1238 -- is ``n - 1`` deep, and performance-plan §54 records
    depth-n folds raising ``RecursionError`` out of the LP/MPS/GAMS writers at
    n >= 1000.

    Node *count* is unchanged at ``n - 1``; only the nesting differs. The bound is
    unchanged too, measured: see the ``Expression.min`` comment and
    performance-plan §64.

    A single term folds to itself -- ``min(a)`` is ``a`` -- rather than to a
    one-argument ``FunctionCall("min", a)``, which no consumer relaxes (they all
    read ``args[0], args[1]``).
    """
    if not terms:
        raise ValueError(f"{fname}() of no terms is undefined")
    current: list[Expression] = list(terms)
    while len(current) > 1:
        paired: list[Expression] = [
            FunctionCall(fname, current[i], current[i + 1]) for i in range(0, len(current) - 1, 2)
        ]
        if len(current) % 2:
            # Odd term out rides to the next level untouched; it meets a partner
            # one round later. This keeps the tree balanced to within one level.
            paired.append(current[-1])
        current = paired
    return current[0]


def _minmax_operands(fname: str, args: tuple) -> list[Expression]:
    """Validate and wrap the operands of ``minimum`` / ``maximum``."""
    if len(args) >= 2:
        return [_wrap(a) for a in args]
    # One operand is the interesting error. ``minimum`` is the ELEMENT-WISE op
    # (numpy's ``np.minimum``), and numpy refuses ``np.minimum(xs)`` too -- so
    # quietly re-reading it as the reduction ``np.min(xs)`` would make one name
    # mean two different things depending on how many arguments it got, and would
    # silently collapse a shaped model row to a scalar. Name the reduction
    # spelling instead (CLAUDE.md §3).
    reducer = "min" if fname == "min" else "max"
    public = "minimum" if fname == "min" else "maximum"
    if len(args) == 1:
        raise TypeError(
            f"{public}() needs at least two operands: it is the ELEMENT-WISE "
            f"{reducer}imum of its arguments (numpy's `np.{public}`), not a "
            f"reduction over one shaped operand. For the smallest/largest element "
            f"of a vector use `xs.{reducer}()` (or `np.{reducer}(xs)`); to reduce "
            f"a list of separate terms use `{public}(*terms)`."
        )
    raise TypeError(
        f"{public}() needs at least two operands; none were given. "
        f"For the {reducer} over a shaped expression use `xs.{reducer}()`."
    )


def minimum(*args: Union[Expression, float]) -> Expression:
    r"""
    Element-wise minimum of two or more expressions.

    Parameters
    ----------
    \*args : Expression or float
        Two or more operands, broadcast against each other element-wise. Three or
        more are folded into a balanced tree of binary ``min`` nodes (issue
        #1238), which is ``ceil(log2(n))`` deep rather than ``n - 1``; the two
        operand call is one node, exactly as before.

    Returns
    -------
    Expression

    See Also
    --------
    Expression.min : the smallest element *of one shaped expression*.

    Examples
    --------
    >>> dm.minimum(x, y)
    >>> dm.minimum(x, y, z, w)          # one balanced tree, 2 deep
    >>> dm.minimum(*[c[i] * x[i] for i in range(n)])
    """
    return _balanced_minmax_fold("min", _minmax_operands("min", args))


def maximum(*args: Union[Expression, float]) -> Expression:
    """
    Element-wise maximum of two or more expressions.

    The ``max`` counterpart of :func:`minimum`; see it for the parameters and for
    the balanced fold three or more operands are built into.

    Returns
    -------
    Expression

    See Also
    --------
    Expression.max : the largest element *of one shaped expression*.
    """
    return _balanced_minmax_fold("max", _minmax_operands("max", args))


def _find_owning_model(*exprs: Expression) -> Optional["Model"]:
    """Walk expression DAGs and return the first owning Model found."""
    stack = list(exprs)
    while stack:
        node = stack.pop()
        if isinstance(node, Variable):
            return node.model
        if isinstance(node, IndexExpression):
            stack.append(node.base)
        elif isinstance(node, BinaryOp):
            stack.extend((node.left, node.right))
        elif isinstance(node, UnaryOp):
            stack.append(node.operand)
        elif isinstance(node, FunctionCall):
            stack.extend(node.args)
        elif isinstance(node, MatMulExpression):
            stack.extend((node.left, node.right))
        elif isinstance(node, SumExpression):
            stack.append(node.operand)
        elif isinstance(node, SumOverExpression):
            stack.extend(node.terms)
    return None


def _iter_model_leaves(*exprs: Expression):
    """Yield every ``Variable`` / ``Parameter`` leaf reachable from *exprs*.

    Walks the expression DAG(s) and surfaces the model-owning leaf nodes
    (``Variable`` and ``Parameter``, both of which carry a ``.model`` back-
    reference). ``Constant`` leaves — scalars, numpy arrays, broadcasts — carry
    no model and are simply not yielded, so an ownership check built on this
    walker never trips on legitimate constants. Used by the cross-model
    ownership guard (finding M3) to detect a variable/parameter that belongs to
    a different :class:`Model` than the one it is being solved in.

    Each node is expanded once (by identity): a DAG that reuses a subexpression
    has exponentially many root-to-leaf paths but only linearly many nodes.
    """
    stack = list(exprs)
    seen: set[int] = set()
    while stack:
        node = stack.pop()
        if id(node) in seen:
            continue
        seen.add(id(node))
        if isinstance(node, (Variable, Parameter)):
            yield node
        elif isinstance(node, IndexExpression):
            stack.append(node.base)
        elif isinstance(node, BinaryOp):
            stack.extend((node.left, node.right))
        elif isinstance(node, UnaryOp):
            stack.append(node.operand)
        elif isinstance(node, FunctionCall):
            stack.extend(node.args)
        elif isinstance(node, CustomCall):
            stack.extend(node.args)
        elif isinstance(node, MatMulExpression):
            stack.extend((node.left, node.right))
        elif isinstance(node, SumExpression):
            stack.append(node.operand)
        elif isinstance(node, SumOverExpression):
            stack.extend(node.terms)
        # Constant (and anything without children) contributes no owning leaf.


def _logical_backing_vars(expr) -> list:
    """Collect the backing ``Variable`` objects under a ``LogicalExpression`` tree.

    ``BooleanVar`` wraps a binary ``Variable`` (``.variable``); the composite
    logical nodes (``LogicalAnd``/``LogicalOr``/…) hold child logical
    expressions. Returns the flat list of backing variables so the ownership
    guard can check them too.
    """
    out: list = []
    stack = [expr]
    while stack:
        node = stack.pop()
        if isinstance(node, BooleanVar):
            if isinstance(node.variable, Variable):
                out.append(node.variable)
            else:
                # Indexed BooleanVar wraps an IndexExpression over a Variable.
                out.extend(_iter_model_leaves(node.variable))
        elif isinstance(node, (LogicalAnd, LogicalOr, LogicalEquivalent)):
            stack.extend((node.left, node.right))
        elif isinstance(node, LogicalNot):
            stack.append(node.operand)
        elif isinstance(node, LogicalImplies):
            stack.extend((node.antecedent, node.consequent))
        elif isinstance(node, (LogicalAtLeast, LogicalAtMost, LogicalExactly)):
            stack.extend(node.operands)
    return out


def if_else(
    condition: "Constraint",
    then_value: Union[Expression, float],
    else_value: Union[Expression, float],
    *,
    name: Optional[str] = None,
) -> Variable:
    """Piecewise conditional expression (free-function form of :meth:`Model.if_else`).

    Discovers the owning :class:`Model` from the variables appearing in
    *condition* / *then_value* / *else_value* and delegates to
    :meth:`Model.if_else`. See that method for the full contract.

    Parameters
    ----------
    condition : Constraint
        An inequality constraint (e.g. ``x >= 0``).
    then_value, else_value : Expression or float
        Branch values.
    name : str, optional
        Base name for the auxiliary variable.

    Returns
    -------
    Variable
        Auxiliary variable standing for the conditional value.

    Examples
    --------
    >>> import discopt.modeling as dm
    >>> w = dm.if_else(x >= 0, dm.maximum(0.25, dm.exp(x) - 1), dm.log(-x + 3))
    """
    if not isinstance(condition, Constraint):
        raise TypeError(
            f"if_else() condition must be a Constraint (an inequality such as "
            f"'x >= 0'), got {type(condition).__name__}"
        )
    model = _find_owning_model(condition.body, _wrap(then_value), _wrap(else_value))
    if model is None:
        raise ValueError(
            "if_else() could not determine the owning Model (no variables found "
            "in condition/then/else); call model.if_else(...) directly instead."
        )
    return model.if_else(condition, then_value, else_value, name=name)


def piecewise(
    x: Expression,
    breakpoints,
    values,
    *,
    method: str = "incremental",
    name: Optional[str] = None,
) -> Variable:
    """Declared piecewise-linear function (free-function form of :meth:`Model.piecewise`).

    Discovers the owning :class:`Model` from the variables in *x* and delegates
    to :meth:`Model.piecewise`. See that method for the full contract.

    Examples
    --------
    >>> import discopt.modeling as dm
    >>> cost = dm.piecewise(load, [0, 50, 80, 100], [0, 400, 760, 1100])
    """
    if not isinstance(x, Expression):
        raise TypeError(f"piecewise() input must be a model expression, got {type(x).__name__}.")
    model = _find_owning_model(x)
    if model is None:
        raise ValueError(
            "piecewise() could not determine the owning Model (no variables in the "
            "input); call model.piecewise(...) directly instead."
        )
    return model.piecewise(x, breakpoints, values, method=method, name=name)


def udf(fn: Callable) -> Callable:
    """Compose a Python-callable user-defined function into the expression DAG.

    ``udf`` is a thin pass-through that documents intent: *fn* must build its
    result entirely from ``discopt.modeling`` primitives (``dm.exp``,
    ``dm.maximum``, ``dm.if_else``, arithmetic on variables, ...), so the
    returned expression is a normal DAG node the solver can relax and bound.
    Unlike an opaque numeric callback (e.g. JuMP's ``register``), the body must
    be symbolic — that is what lets discopt build rigorous relaxations.

    Parameters
    ----------
    fn : callable
        A function whose body uses only ``dm.*`` primitives and operator
        overloading on expressions.

    Returns
    -------
    callable
        *fn* unchanged; call it with expression arguments to build the DAG.

    Examples
    --------
    >>> import discopt.modeling as dm
    >>> user_fn = dm.udf(
    ...     lambda x: dm.if_else(x >= 0, dm.maximum(0.25, dm.exp(x) - 1), dm.log(-x + 3))
    ... )
    >>> expr = user_fn(x)   # ordinary discopt expression
    """
    if not callable(fn):
        raise TypeError(f"udf() expects a callable, got {type(fn).__name__}")
    return fn


def custom(fn: Callable, *, name: Optional[str] = None) -> Callable:
    """Wrap an opaque, JAX-traceable callable as an AD-only user function.

    Use this **only** when a function genuinely cannot be expressed with
    ``dm.*`` primitives. If you can write the body symbolically (with
    ``dm.exp``, ``dm.maximum``, ``dm.if_else``, arithmetic on variables, ...),
    use :func:`udf` instead -- that keeps full global-solver support, whereas a
    ``custom`` function is restricted to the local NLP path.

    *fn* must be differentiable by JAX: write it with ``jax.numpy`` operations
    on its array arguments so discopt can autodiff it for gradients/Hessians.
    The returned wrapper builds a :class:`CustomCall` node when called with
    expression arguments::

        import jax.numpy as jnp
        import discopt.modeling as dm

        weird = dm.custom(lambda x: jnp.sum(jnp.sinc(x) ** 2))
        m.minimize(weird(x) + dm.sum(x))

    What you get depends on whether the body traces through the reduced-space
    McCormick type (``MCBox``) -- arithmetic ``+ - * / **`` plus the
    ``discopt._relax.mcbox`` intrinsic namespace:

    - **Traces through MCBox** -> solved **globally with a certificate** by the
      reduced-space engine, branching only on the original degrees of freedom;
      integer/binary variables included (plan P3.1/P3.2, #713).
    - **Does not trace** (a raw ``jnp`` intrinsic applied to an argument, a
      non-affine hidden division, a non-scalar leaf, an unbounded box) -> the
      **local NLP path only**. The result reports ``status="feasible"`` with no
      ``bound``/``gap`` (#998): a single local NLP finds a local optimum, and
      reporting it as a dual bound would be a false certificate. With
      integer/binary variables also present the solver **raises**, since global
      branch-and-bound would have no valid node relaxation (sound-or-refuse).

    For that last case, ``Model.solve(solver="direct")`` runs a derivative-free
    global *search* over the box instead of a single local solve. It still returns
    no certificate, but on a multimodal objective it is a much better answer --
    see :mod:`discopt.solvers.direct` and the ``direct_global`` notebook.

    See :class:`CustomCall`.

    Parameters
    ----------
    fn : callable
        A JAX-traceable function of one or more array arguments returning a
        scalar (objective term) or array (constraint body).
    name : str, optional
        Display name used in reprs and error messages. Defaults to
        ``fn.__name__``.

    Returns
    -------
    callable
        A builder; call it with expression arguments to produce a
        :class:`CustomCall` DAG node.
    """
    if not callable(fn):
        raise TypeError(f"custom() expects a callable, got {type(fn).__name__}")
    from discopt._optional_jax import require_jax

    # #1873: the body is traced and differentiated by JAX on every route (the
    # MCBox engine, the JAX evaluator, DIRECT's local refine), so refuse here, at
    # the call that names the feature, rather than at the first evaluation.
    require_jax("dm.custom (a JAX-traced user function)")

    def _build(*args) -> Expression:
        return CustomCall(fn, *[_wrap(a) for a in args], name=name)

    _build.__name__ = name or str(getattr(fn, "__name__", "custom"))
    return _build


# ─────────────────────────────────────────────────────────────
# Aggregation Functions
# ─────────────────────────────────────────────────────────────


def sum(
    x: Union[Expression, list, Callable],
    *,
    over: Optional[Sequence] = None,
    axis: Optional[int] = None,
) -> Expression:
    """
    Summation over expressions.

    Supports three calling patterns:

    Parameters
    ----------
    x : Expression, list of Expression, or callable
        Expression to sum, list of terms, or a callable ``f(i)`` returning
        an expression for each index ``i`` in *over*.
    over : sequence, optional
        Index set for indexed summation (requires *x* to be callable).
    axis : int, optional
        Axis along which to sum (for array expressions).

    Returns
    -------
    Expression

    Examples
    --------
    >>> dm.sum(x)                                  # sum all elements
    >>> dm.sum(x, axis=0)                          # sum along axis 0
    >>> dm.sum(lambda i: cost[i] * x[i], over=range(n))  # indexed sum
    """
    x = _expand_indexed_container(x)  # dm.sum(indexed_var) -> sum of its elements
    if over is not None and callable(x):
        # Indexed summation: dm.sum(lambda i: expr(i), over=index_set). Tuple
        # members of dimen>1 named sets are unpacked: ``lambda i, j: ...``.
        terms = [_wrap(_call_over(x, i, over)) for i in over]
        return _sum_of_terms(terms)
    if isinstance(x, list) or _is_term_iterable(x):
        # list/tuple/generator of terms: dm.sum(x[i] for i in S)
        terms = [_wrap(t) for t in x]
        return _sum_of_terms(terms)
    return SumExpression(_wrap(x), axis=axis)


#: Below this many terms a per-element sum is left exactly as written: the
#: per-node passes cost microseconds there, and the user's own structure keeps
#: printing, LaTeX and export output unchanged. A cost cutoff, not a tolerance.
_SUM_CANONICAL_MIN_TERMS = 32


def _sum_canonical_enabled() -> bool:
    """``DISCOPT_SUM_CANONICAL`` (default ON, ``=0`` opts out): fold per-element sums.

    #1712. ``dm.sum(c[i] * x[i] for i ...)`` builds one Python node per term, and
    every solver pass that walks the model pays for each one: a 90,000-term
    objective cost seconds per pass where ``dm.sum(c * x)`` costs microseconds.
    :func:`_canonical_affine_sum` rewrites the terms that are exactly a whole
    variable, each entry once, into that vectorized form.

    Graduated 2026-10-17 (``docs/dev/performance-plan.md`` §78). A first
    graduation was reverted because the interval Hessian, the sparse linear
    extractors (the affine-square proof behind POUNCE's QP route) and the
    binary-multilinear expansion refused the folded form (§77.6). They now read
    it through :func:`affine_array_sum`. The full fast suite passed with the flag
    on, and a 26-instance OFF/ON panel, including families that reach those
    passes, was cert-clean. On the issue's model, solve time went from 9.01 s to
    2.72 s. ``=0`` restores the term-by-term sum.
    """
    import os as _os

    return _os.environ.get("DISCOPT_SUM_CANONICAL", "1") != "0"


def _sum_of_terms(terms: list[Expression]) -> Expression:
    if len(terms) >= _SUM_CANONICAL_MIN_TERMS and _sum_canonical_enabled():
        folded = _canonical_affine_sum(terms)
        if folded is not None:
            return folded
    return SumOverExpression(terms)


def _affine_leaf_position(expr: Expression) -> Optional[tuple["Variable", int]]:
    """``(variable, flat C-order position)`` of ``x[i]`` / ``x[i, j]`` on a shaped
    variable, or ``None`` for anything else (a slice, a partial or exotic index)."""
    if not isinstance(expr, IndexExpression):
        return None
    base = expr.base
    if not isinstance(base, Variable):
        return None
    shape = tuple(base.shape or ())
    if not shape:
        return None
    idx = expr.index if isinstance(expr.index, tuple) else (expr.index,)
    if len(idx) != len(shape):
        return None
    flat = 0
    for i, dim in zip(idx, shape):
        if isinstance(i, bool) or not isinstance(i, (int, np.integer)):
            return None
        i = int(i)
        if i < 0:
            i += dim
        if not 0 <= i < dim:
            return None
        flat = flat * dim + i
    return base, flat


def _affine_term_parts(term: Expression) -> Optional[tuple["Variable", int, float]]:
    """``(variable, position, coefficient)`` of ``x[i]``, ``-x[i]``, ``c * x[i]`` or
    ``x[i] * c`` with ``c`` a scalar :class:`Constant`, else ``None``.

    A :class:`Parameter` coefficient is deliberately NOT folded: it can be
    re-valued after the model is built, and copying its value into a constant
    array would freeze it.
    """
    coef = 1.0
    leaf = term
    if isinstance(term, UnaryOp) and term.op == "neg":
        coef, leaf = -1.0, term.operand
    elif isinstance(term, BinaryOp) and term.op == "*":
        for c_node, other in ((term.left, term.right), (term.right, term.left)):
            if type(c_node) is Constant:
                value = np.asarray(c_node.value)
                if value.ndim == 0 and value.dtype.kind in "biuf":
                    coef, leaf = float(value), other
                    break
        else:
            return None
    found = _affine_leaf_position(leaf)
    if found is None:
        return None
    return found[0], found[1], coef


def _canonical_affine_sum(terms: list[Expression]) -> Optional[Expression]:
    """Fold the terms that cover a whole variable into ``dm.sum(C * x)``.

    A variable's terms are folded only when they name every entry of it exactly
    once, so the folded sum holds exactly the products that were written --
    ``C[i] * x[i]`` for each term, no invented zero-coefficient entries, no
    merged duplicates -- just summed in another order. Every other term is kept
    as written, after the folded ones. ``None`` when nothing qualifies.
    """
    groups: dict[int, tuple[Variable, list[tuple[int, float]]]] = {}
    parsed: list[Optional[tuple[Variable, int, float]]] = []
    for t in terms:
        parts = _affine_term_parts(t)
        parsed.append(parts)
        if parts is not None:
            var, pos, coef = parts
            groups.setdefault(id(var), (var, []))[1].append((pos, coef))

    folded: dict[int, Expression] = {}
    for key, (var, entries) in groups.items():
        size = int(var.size)
        if size < 2 or len(entries) != size:
            continue
        seen = np.zeros(size, dtype=bool)
        coefs = np.empty(size, dtype=np.float64)
        for pos, coef in entries:
            if seen[pos]:
                break
            seen[pos] = True
            coefs[pos] = coef
        else:
            # ``len == size`` and no repeat means every entry is covered once.
            C = _wrap(coefs.reshape(var.shape))
            folded[key] = SumExpression(BinaryOp("*", C, var), axis=None)

    if not folded:
        return None
    rest = [t for t, p in zip(terms, parsed) if p is None or id(p[0]) not in folded]
    parts_out = list(folded.values()) + rest
    if len(parts_out) == 1:
        return parts_out[0]
    return SumOverExpression(parts_out)


def affine_array_sum(expr: Expression) -> Optional[tuple["Variable", np.ndarray]]:
    """``(x, C)`` when *expr* is the full reduction ``dm.sum(x)`` or ``dm.sum(C * x)``.

    ``C`` comes back as a flat C-order float array with one coefficient per entry
    of ``x`` (all ones for ``dm.sum(x)``), so ``expr == sum_i C[i] * x.flat[i]``.
    Only an exact shape match qualifies -- no broadcasting -- so each coefficient
    belongs to exactly one entry. This is the form :func:`_canonical_affine_sum`
    emits and the vectorized API writes by hand; scalar-term passes use it to read
    the sum as its coefficients instead of refusing the array :class:`Constant`.
    ``None`` for anything else, including a :class:`Parameter` coefficient.
    """
    if not isinstance(expr, SumExpression) or expr.axis is not None:
        return None
    op = expr.operand
    if isinstance(op, Variable):
        if op.size < 2:
            return None
        return op, np.ones(int(op.size), dtype=np.float64)
    if not (isinstance(op, BinaryOp) and op.op == "*"):
        return None
    if isinstance(op.left, Constant) and isinstance(op.right, Variable):
        const, var = op.left, op.right
    elif isinstance(op.right, Constant) and isinstance(op.left, Variable):
        const, var = op.right, op.left
    else:
        return None
    coefs = np.asarray(const.value, dtype=np.float64)
    if var.size < 2 or coefs.shape != tuple(var.shape):
        return None
    return var, coefs.reshape(-1)


def _gather_flat_index(expr: Expression) -> Optional[tuple["Variable", np.ndarray]]:
    """``(x, flat)`` when *expr* is the gather ``x[np.unravel_index(flat, x.shape)]``.

    An :class:`IndexExpression` on a :class:`Variable` whose index is one 1-D
    integer array per axis (all the same length); ``flat`` is the C-order flat
    position of each gathered entry. ``None`` for anything else.
    """
    if not isinstance(expr, IndexExpression) or not isinstance(expr.base, Variable):
        return None
    var = expr.base
    idx = expr.index if isinstance(expr.index, tuple) else (expr.index,)
    if len(idx) != len(var.shape) or not idx:
        return None
    arrs = []
    for a in idx:
        if not isinstance(a, np.ndarray) or a.ndim != 1 or a.dtype.kind not in "iu":
            return None
        arrs.append(a)
    if len({a.shape for a in arrs}) != 1:
        return None
    try:
        flat = np.ravel_multi_index(tuple(arrs), var.shape)
    except ValueError:  # out of range: not a gather this helper can vouch for
        return None
    return var, np.asarray(flat, dtype=np.int64)


def quadratic_array_sum(
    expr: Expression,
) -> Optional[tuple["Variable", np.ndarray, np.ndarray, np.ndarray]]:
    """``(x, rows, cols, vals)`` when *expr* is ``dm.sum(V * x[R] * x[C])``.

    The full reduction of ``Constant(V) * gather(R) * gather(C)`` over one
    variable, each gather as recognised by :func:`_gather_flat_index`, so
    ``expr == sum_k vals[k] * x.flat[rows[k]] * x.flat[cols[k]]``. This is the
    quadratic part :func:`_builder_objective_expression` emits for an
    ``add_quadratic_objective`` objective; the scalar-term extractors read it as
    its coefficients instead of refusing the array constant (#1802), as they read
    :func:`affine_array_sum`. ``None`` for anything else.
    """
    if not isinstance(expr, SumExpression) or expr.axis is not None:
        return None
    op = expr.operand
    if not (isinstance(op, BinaryOp) and op.op == "*"):
        return None
    left, right = op.left, op.right
    if not (isinstance(left, BinaryOp) and left.op == "*" and isinstance(left.left, Constant)):
        return None
    vals = np.asarray(left.left.value, dtype=np.float64)
    g_r = _gather_flat_index(left.right)
    g_c = _gather_flat_index(right)
    if g_r is None or g_c is None or g_r[0] is not g_c[0]:
        return None
    rows, cols = g_r[1], g_c[1]
    if vals.ndim != 1 or vals.shape != rows.shape or rows.shape != cols.shape:
        return None
    return g_r[0], rows, cols, vals


def prod(x: Union[Expression, list, Callable], *, over: Optional[Sequence] = None) -> Expression:
    """
    Product over expressions, analogous to :func:`sum`.

    Parameters
    ----------
    x : Expression, list of Expression, or callable
        Expression to multiply, list of terms, or a callable ``f(i)``
        returning an expression for each index ``i`` in *over*.
    over : sequence, optional
        Index set for indexed product (requires *x* to be callable).

    Returns
    -------
    Expression
    """
    x = _expand_indexed_container(x)  # dm.prod(indexed_var) -> product of elements
    if over is not None and callable(x):
        terms = [_wrap(_call_over(x, i, over)) for i in over]
        return _multiply_terms(terms)
    if isinstance(x, list) or _is_term_iterable(x):
        terms = [_wrap(t) for t in x]
        return _multiply_terms(terms)
    return FunctionCall("prod", _wrap(x))


def _multiply_terms(terms: list["Expression"]) -> Expression:
    """Fold a list of terms into a product; the empty product is the identity 1."""
    if not terms:
        return Constant(1.0)
    result: Expression = terms[0]
    for t in terms[1:]:
        result = result * t
    return result


def _to_expr_object_array(a) -> np.ndarray:
    """Coerce *a* into a numpy object ndarray of scalar expressions (issue #816).

    Accepts a shaped :class:`Expression` (its scalar elements are pulled out by
    indexing along every axis), an existing ndarray, or a (possibly nested)
    list/tuple of expressions/numbers. Used by :func:`concatenate` / :func:`stack`
    to assemble a vector from pieces without adding a new DAG node type — each
    element remains an ordinary scalar expression the solver already handles.
    """
    if isinstance(a, np.ndarray):
        return a if a.dtype == object else a.astype(object)
    if isinstance(a, Expression):
        s = _known_shape(a)
        if s is None:
            raise TypeError(
                "concatenate()/stack() need expressions with a statically known "
                f"shape; got a {type(a).__name__} whose shape is not known. Index "
                "the pieces explicitly, or assemble the array from scalars."
            )
        out = np.empty(s, dtype=object)
        if s == ():
            out[()] = a
            return out
        for idx in np.ndindex(s):
            out[idx] = a[idx]
        return out
    if isinstance(a, (list, tuple)):
        subs = [_to_expr_object_array(x) for x in a]
        if subs and all(sub.ndim == 0 for sub in subs):
            out = np.empty(len(subs), dtype=object)
            for i, sub in enumerate(subs):
                out[i] = sub[()]
            return out
        return np.stack(subs, axis=0) if subs else np.empty(0, dtype=object)
    # Plain scalar / number.
    out = np.empty((), dtype=object)
    out[()] = a
    return out


def concatenate(arrays: Sequence, axis: int = 0) -> np.ndarray:
    """Join a sequence of array-valued expressions along an existing axis.

    Mirrors :func:`numpy.concatenate`. Each entry of *arrays* may be a shaped
    expression (e.g. ``x[:-1]``), an object ndarray of scalar expressions, or a
    (nested) list/tuple of scalar expressions/numbers. The result is a numpy
    object ndarray whose entries are scalar expressions, so it supports indexing,
    iteration, ``.shape`` and element-wise arithmetic — exactly what the
    method-of-lines "boundary value, interior values, boundary value" assembly
    pattern needs (issue #816).

    Note: to concatenate a scalar boundary value, wrap it in a length-1 sequence
    (``[p_left]``) so it has a leading axis to join along, as numpy requires.
    """
    parts = [_to_expr_object_array(a) for a in arrays]
    return np.concatenate(parts, axis=axis)


def stack(arrays: Sequence, axis: int = 0) -> np.ndarray:
    """Stack a sequence of array-valued expressions along a new axis.

    Mirrors :func:`numpy.stack`; see :func:`concatenate` for the accepted element
    forms and the object-ndarray result contract (issue #816).
    """
    parts = [_to_expr_object_array(a) for a in arrays]
    return np.stack(parts, axis=axis)


def _objective_poles_or_none(model: "Model") -> list:
    """Objective poles for the no-bound diagnostic (#1493); ``[]`` when none.

    Detection only -- see :mod:`discopt._relax.poles`. A failure to analyse is
    reported, not swallowed: it downgrades the diagnostic to the generic one and
    says so, but never breaks a returned solve.
    """
    try:
        from discopt._relax.poles import objective_poles

        return objective_poles(model)
    except Exception as exc:  # noqa: BLE001 - diagnostic only, reported below
        import logging

        logging.getLogger("discopt.solver").warning(
            "objective pole analysis failed (%s: %s); the no-bound diagnostic below "
            "is the generic one",
            type(exc).__name__,
            exc,
        )
        return []


def norm(x: Expression, ord: Union[int, float, str] = 2) -> Expression:
    """
    Vector norm.

    Parameters
    ----------
    x : Expression
        Input vector expression.
    ord : int, float, or str, default 2
        Norm order. ``1`` (L1), ``2`` (L2/Euclidean), and ``inf`` (Chebyshev,
        passed as ``float("inf")`` or ``"inf"``) are supported on the global
        certification path (Rust ``MathFunc``). Other numeric orders ``p >= 1``
        are evaluated and relaxed on the JAX path but are not in the core IR.

        A **non-numeric** order such as ``"fro"`` or ``"nuc"`` is rejected here.
        It used to be accepted silently — ``str(ord)`` made the node
        ``"normfro"`` — and then failed far away in whichever consumer ran
        first, with a message naming a node the caller never wrote:
        ``ValueError: Unsupported norm order: 'normfro'`` from the DAG compiler,
        or a bare ``could not convert string to float: 'fro'`` from the ``.nl``
        exporter. Both are the same defect: this function is the only place that
        knows what the caller actually passed, so it is the only place that can
        say so (CLAUDE.md §3 — refuse loudly rather than fail cheaply later).

    Raises
    ------
    ValueError
        If `ord` is not a supported norm order.

    Notes
    -----
    ``norm`` is a **vector** norm. Given a 2-D argument the evaluators apply
    :func:`numpy.linalg.norm`'s *matrix* semantics — ``ord=2`` is then the
    spectral norm, not ``‖vec(X)‖₂``; ``ord=1``/``inf`` are the largest absolute
    column/row sum. The default (POUNCE tape) evaluator handles the matrix
    1-/inf-norms; the spectral norm needs the JAX evaluator (``discopt[jax]``).
    The relaxation layer spells a 1-D norm out over its elements (``sum|x_i|``,
    ``max|x_i|``, ``sqrt(sum x_i**2)``, ...) exactly as the evaluator computes
    it, so a vector norm relaxes like its hand-written scalar form (#1493). A
    matrix argument
    with ``ord`` 1 or inf is spelled out the same way (max of absolute column /
    row sums) and certifies; the spectral norm (``ord=2``) has no envelope of
    its own: the only claim made about it is ``norm >= 0``, so it cannot
    certify (it gets no useful dual bound rather than a wrong one). Prefer
    building it explicitly from ``dm.sum``/``**`` if you need one on the global
    path.

    Returns
    -------
    Expression
    """
    if ord in (float("inf"), "inf", "Inf"):
        suffix = "inf"
    else:
        try:
            order = float(ord)
        except (TypeError, ValueError):
            raise ValueError(
                f"unsupported norm order {ord!r}: dm.norm is a vector norm and takes "
                '1, 2, float("inf") / "inf", or another numeric p >= 1. Matrix norms '
                '("fro", "nuc") are not supported — build one explicitly, e.g. '
                "dm.sqrt(dm.sum(X * X)) for the Frobenius norm."
            ) from None
        if not order >= 1.0:  # rejects NaN as well as p < 1
            raise ValueError(
                f"unsupported norm order {ord!r}: a p-norm needs p >= 1 (the relaxation "
                "layer's envelope is derived from the norm-equivalence bounds "
                "||x||_inf <= ||x||_p <= ||x||_1, which hold only for p >= 1)"
            )
        suffix = str(ord)
    return FunctionCall(f"norm{suffix}", _wrap(x))


# ─────────────────────────────────────────────────────────────
# Constraints
# ─────────────────────────────────────────────────────────────


class ConstraintSense(Enum):
    """Relational sense of a constraint (``<=``, ``>=``, or ``==``)."""

    LE = "<="
    GE = ">="
    EQ = "=="


@dataclass(eq=False)
class Constraint:
    """
    A single constraint in the model.

    Internally stored in normalized form: ``body sense rhs`` where *body* is
    an :class:`Expression` and *rhs* is ``0.0``.

    Constraints are created via comparison operators on expressions, not
    directly:

    Examples
    --------
    >>> x[0] + x[1] <= 10
    >>> dm.exp(x[2]) == 1.0
    >>> A @ x >= b

    Attributes
    ----------
    body : Expression
        Left-hand side expression (normalized so that rhs == 0).
    sense : str
        One of ``"<="``, ``">="``, ``"=="``.
    rhs : float
        Right-hand side value (always 0.0 in normalized form). This is an
        *enforced* contract, not just a convention: the solve path reads only
        ``body``, so a non-zero ``rhs`` is refused by both ``subject_to`` and
        ``Model.validate`` rather than silently ignored (#909). Build rows with
        the comparison operators, which fold the offset into ``body`` for you.
    name : str or None
        Optional name for debugging and explanation. Read and written as an
        ordinary attribute; a row built by :meth:`Model.constraint` computes it
        lazily on first read (see ``_constraint_name_get``).
    """

    body: Expression
    sense: str
    rhs: float = 0.0
    name: Optional[str] = None

    def __repr__(self):
        return f"{self.body} {self.sense} {self.rhs}"

    def __bool__(self):
        # A Constraint has no boolean value. Because ``Expression.__eq__`` builds
        # a Constraint (the modeling DSL), ``if x == 5:``, ``u in [v]`` (which
        # truth-tests ``u == v``), and ``assert expr == other`` would otherwise
        # silently evaluate this object as truthy — a footgun that masks logic
        # errors (M4). Refuse loudly instead (the cvxpy approach). Use
        # ``m.subject_to(...)`` to add the constraint to the model, or compare the
        # constraint's ``.body``/``.sense``/``.rhs`` fields to test structure.
        raise TypeError(
            "A Constraint has no truth value. '==', '<=', '>=' on modeling "
            "expressions build a Constraint (they do not compare values), so "
            "using one in a boolean context (if/while/assert, 'in', bool()) is "
            "almost always a mistake. Add it with m.subject_to(...); to test an "
            "expression's identity use 'is' or a set/dict keyed by the object."
        )


# ── Constraint.name: materialized on first read (issue #1215, candidate 3) ──
#
# A named indexed family formats one `"family[label]"` string per row at BUILD
# time, for metadata nothing on the solve path reads: the issue measures it at
# 49 B/instance retained (200 000 strings on its headline model) and, timed
# on its own, 0.497 us/instance of the 5.29 us build -- ~9%.
#
# `Model.constraint` therefore records the two *already-live* objects the name
# is made of (the family name string, shared by every row; the member, already
# a key of the family's `members` dict) and lets the getter below do the
# formatting if and when someone asks. Nothing is allocated until then.
#
# The property is installed after the class because a `@dataclass` field and a
# `property` cannot both be spelled in the class body: the generated `__init__`
# captured `name=None` in its own defaults, so replacing the class attribute
# here leaves the signature, `dataclasses.fields()` and `dataclasses.replace()`
# untouched -- `replace()` reads the name back through this getter.
#
# Class-level `None`s keep an unnamed row's instance dict free of all three.
Constraint._name = None
Constraint._name_family = None
Constraint._name_key = None


def _constraint_name_get(self) -> Optional[str]:
    family = self._name_family
    if family is not None:
        from discopt.modeling.indexed import key_label

        key = self._name_key
        label = key_label(key) if type(key) is tuple else str(key)
        self._name = f"{family}[{label}]"
        # Clear the pending marker so the format runs once, not once per read.
        self._name_family = None
    # `_name` is only ever written by this function or `_constraint_name_set`,
    # both of which write `Optional[str]`; the class-level default is `None`.
    # The cast is needed because the three defaults are installed on the class
    # after the `@dataclass` body, so mypy sees them as untyped.
    return cast(Optional[str], self._name)


def _constraint_name_set(self, value: Optional[str]) -> None:
    self._name = value
    # An explicit assignment always wins over a pending family name. Guarded so
    # the common case (nothing pending) adds no instance-dict entry.
    if self._name_family is not None:
        self._name_family = None


Constraint.name = property(_constraint_name_get, _constraint_name_set)  # type: ignore[assignment]


def _builder_row_constraint(row) -> "Constraint":
    """A builder-resident linear row as a :class:`Constraint` (#840).

    The one row->Constraint translation, shared by the eager and the lazy paths
    so the expression a lazy row builds on demand is this one exactly.
    """
    body: Optional[Expression] = None
    for v, local, coeff in row.terms:
        if v.shape == ():
            comp: Expression = v
        elif len(v.shape) <= 1:
            comp = v[local]
        else:
            comp = v[tuple(int(i) for i in np.unravel_index(local, v.shape))]
        term = coeff * comp
        body = term if body is None else body + term
    if body is None:
        body = Constant(np.float64(0.0))
    c: Constraint
    if row.sense == "<=":
        c = body <= row.rhs
    elif row.sense == ">=":
        c = body >= row.rhs
    else:
        c = body == row.rhs
    c.name = row.name
    return c


#: The sense each comparison operator gives a builder row: ``__ge__`` writes
#: ``body >= rhs`` as ``rhs - body <= 0``.
_BUILDER_ROW_SENSE = {"<=": "<=", ">=": "<=", "==": "=="}


def _lazy_builder_row_constraint(row) -> "Constraint":
    """:func:`_builder_row_constraint` with the body deferred to its first read."""
    c = object.__new__(Constraint)
    c.sense = _BUILDER_ROW_SENSE[row.sense]
    c.rhs = 0.0
    c.name = row.name
    c.__dict__["_builder_row"] = row
    return c


def builder_row_of(constraint: "Constraint"):
    """The pending builder row of a lazy constraint whose body is unbuilt, else ``None``."""
    d = constraint.__dict__
    return d.get("_builder_row") if "body" not in d else None


def _constraint_getattr(self, name: str):
    # Only reached when ordinary lookup fails, so a constraint with a body pays
    # nothing. A lazy builder row builds its body once, here, on first read.
    if name == "body":
        row = self.__dict__.get("_builder_row")
        if row is not None:
            body = _builder_row_constraint(row).body
            self.__dict__["body"] = body
            return body
    raise AttributeError(f"{type(self).__name__!r} object has no attribute {name!r}")


Constraint.__getattr__ = _constraint_getattr  # type: ignore[attr-defined]


def _reject_unnormalized_rhs(constraint: "Constraint", *, where: str, index: int = -1) -> None:
    """Refuse a constraint whose ``rhs`` the solve path cannot represent.

    :class:`Constraint` documents ``rhs`` as *always 0.0 in normalized form*, and
    the comparison operators that build every constraint in the supported DSL fold
    the offset into ``body``. Most of the tree honours that invariant by simply not
    looking at ``rhs``: **26 modules read ``Constraint.body`` and never read
    ``.rhs``**, among them the whole relaxation stack (``_relax/dag_compiler``,
    ``milp_relaxation``, ``mccormick_subgradient``,
    ``term_classifier``, ``nonlinear_bound_tightening``, ``dependent_vars``,
    ``implied_integer``, the convexity certificate, ``bilevel/kkt``, Benders, RO).

    A handful of *other* consumers do honour it — ``validation/feasibility``
    (``signed = body - rhs``), the ``.nl`` and GAMS exporters,
    ``problem_classifier``, ``_relax/obbt``, and the Rust ``ConstraintRepr`` (114
    references across the presolve crate). (Issue #909 also listed the LP and MPS
    exporters here; **measured, that is false** — both rebuild the row's
    right-hand side from the *body* alone and silently drop a non-zero ``rhs``, so
    they are corrupters, not honourers, and they keep this refusal. See the
    comments on their ``model.validate()`` calls.) That split is the defect: a row
    carrying a non-zero ``rhs`` is
    *solved* as ``body sense 0`` but *verified* as ``body - rhs sense 0``, so the
    solver returns a point the verifier considers feasible and the user considers
    wrong. Measured on this tree: ``Constraint(w, ">=", 5.0)`` solves to ``w = 0``
    while ``w >= 5.0`` solves to ``w = 5`` — a silent wrong answer, reachable
    through the public API (``Constraint`` is in ``discopt.modeling.__all__``).

    **Why refuse rather than teach the solve path to honour ``rhs``.** Threading it
    through would mean correcting all 26 modules, each of which encodes the ``body
    sense 0`` form structurally rather than arithmetically. A partial job is
    strictly worse than the status quo: today the relaxation stack is uniformly
    rhs-blind, so its McCormick envelope still relaxes the same row the verifier
    checks; half-honoured, the envelope would be built for a *different* row than
    the one being verified — a soundness hazard in place of a wrong-answer hazard.
    Refusing keeps one invariant that all 26 modules already rely on, and it costs
    the caller one obvious rewrite. CLAUDE.md §3: refuse loudly rather than ship a
    silent approximation.

    Raised from both doors — :meth:`Model.subject_to` (so the error lands on the
    offending line) and :meth:`Model.validate` (so a direct
    ``model._constraints.append`` cannot slip past; ``solve`` always validates).
    """
    rhs = getattr(constraint, "rhs", 0.0)
    if rhs is None:
        return
    rhs_arr = np.asarray(rhs, dtype=np.float64)
    if not np.any(rhs_arr != 0.0):
        return
    shown = float(rhs_arr.ravel()[0]) if rhs_arr.size else 0.0
    label = getattr(constraint, "name", None)
    if label is None:
        label = f"_constraints[{index}]" if index >= 0 else "<unnamed>"
    sense = getattr(constraint, "sense", "?")
    raise ValueError(
        f"Constraint '{label}' has a non-zero rhs ({rhs!r}), which the solve path "
        f"cannot represent: Constraint is stored in normalized form 'body {sense} 0' "
        f"and the relaxation/branching stack reads only 'body'. Solving it would "
        f"silently ignore the rhs and return a point the feasibility verifier — "
        f"which does honour rhs — reports as feasible. Build the row with the "
        f"comparison operators, which normalize for you (e.g. 'body {sense} "
        f"{shown!r}'), or subtract the offset yourself: "
        f"Constraint(body - rhs, '{sense}', 0.0). Reached via {where}."
    )


def _csr_with_exact_duplicates(A):
    """``A`` as a float64 CSR matrix whose duplicate entries are summed exactly (#2258).

    Each ``(row, column)`` cell stored more than once becomes one entry holding the
    correctly rounded exact sum of its parts (a ``Fraction`` sum, rounded once;
    integer data is added in Python integers), so every consumer of the builder rows
    reads the same coefficient -- the one ``2**53*x + x - 2**53*x`` gets from the exact like-term
    pass of #2090. A cell whose parts sum to exactly zero keeps a stored zero, as
    ``sum_duplicates`` would. A matrix without duplicates is only converted.
    """
    import math
    from fractions import Fraction

    import scipy.sparse as sp

    if sp.isspmatrix_csr(A) and A.has_canonical_format:
        return A.astype(np.float64)
    coo = A.tocoo()  # keeps duplicates (``tocsr`` from COO would sum them in floats)
    rows = np.asarray(coo.row, dtype=np.int64)
    cols = np.asarray(coo.col, dtype=np.int64)
    data = np.asarray(coo.data)
    order = np.lexsort((cols, rows))
    rows, cols, data = rows[order], cols[order], data[order]
    if len(rows) > 1:
        same = (rows[1:] == rows[:-1]) & (cols[1:] == cols[:-1])
    else:
        same = np.zeros(0, dtype=bool)
    if same.any():
        starts = np.flatnonzero(np.concatenate(([True], ~same)))
        ends = np.append(starts[1:], len(rows))
        integral = np.issubdtype(data.dtype, np.integer) or data.dtype == np.bool_
        out = data[starts].astype(np.float64)
        for k in np.flatnonzero(ends - starts > 1):
            part = data[starts[k] : ends[k]].tolist()
            if integral:
                out[k] = float(builtins_sum(int(v) for v in part))
            elif all(math.isfinite(v) for v in part):
                # Exact rational sum, rounded once (``math.fsum`` raises on an
                # intermediate overflow that the exact sum does not have).
                out[k] = float(builtins_sum((Fraction(v) for v in part), Fraction(0)))
            else:
                out[k] = builtins_sum(part)  # an inf/nan part: no exact sum to keep
        rows, cols, data = rows[starts], cols[starts], out
    else:
        data = data.astype(np.float64)
    indptr = np.zeros(A.shape[0] + 1, dtype=np.int64)
    np.add.at(indptr, rows + 1, 1)
    np.cumsum(indptr, out=indptr)
    out_csr = sp.csr_matrix((data, cols, indptr), shape=A.shape)
    out_csr.has_canonical_format = True
    return out_csr


def _canonicalize_rows_in(item: Any) -> None:
    """Exact like-term collection of every row in ``item`` (#2090).

    See :mod:`discopt.modeling._exact_polynomial`: a row whose like terms would be
    added inexactly in binary64 is replaced, in place, by its exact canonical form;
    every other row is left untouched. The whole model goes through
    :meth:`Model._canonicalize_like_terms` at both solve doors; this per-item form
    is for the few build-time consumers that read a body before then.
    """
    from discopt.modeling._exact_polynomial import canonicalize_rows_in

    canonicalize_rows_in(item)


def _canonicalize_expression(expr: "Expression") -> "Expression":
    """:func:`discopt.modeling._exact_polynomial.canonicalize_expression` (#2090)."""
    from discopt.modeling._exact_polynomial import canonicalize_expression

    return canonicalize_expression(expr)


def _reject_unnormalized_rhs_in(item: Any, *, where: str) -> None:
    """Apply :func:`_reject_unnormalized_rhs` to every row nested in ``item`` (#1858).

    The rows of a disjunct or an indicator constraint are not top-level
    ``Constraint`` entries, so the per-row refusal in ``subject_to`` and
    ``validate`` never saw them -- and the GDP lowerings (big-M, mbigm,
    binary multiplication, the indicator lowering, hull for ``if_then``) read only
    ``body``, so ``Constraint(x, "<=", 2.0)`` in a disjunct was lowered as
    ``x <= 0`` and certified. The rows get the same refusal as a top-level row,
    for the same reason (see :func:`_reject_unnormalized_rhs`), rather than being
    normalized here: a normalized row would be a different object, and disjunct
    rows are keyed by identity (``either_or(big_m={row: M})``, a row shared
    between disjuncts or with the model).

    ``item`` is a ``Constraint``, an ``_IndicatorConstraint``, a
    ``_DisjunctiveConstraint`` (walked through its disjuncts, nested ones
    included), or a list of disjuncts as passed to ``either_or``.
    """
    if isinstance(item, Constraint):
        _reject_unnormalized_rhs(item, where=where)
    elif isinstance(item, _IndicatorConstraint):
        _reject_unnormalized_rhs_in(item.constraint, where=where)
    elif isinstance(item, _DisjunctiveConstraint):
        _reject_unnormalized_rhs_in(item.disjuncts, where=where)
    elif isinstance(item, (list, tuple)):
        for sub in item:
            _reject_unnormalized_rhs_in(sub, where=where)


@dataclass
class ConstraintList:
    """A collection of constraints created from vectorized expressions."""

    constraints: list[Constraint]
    name: Optional[str] = None

    def __len__(self):
        return len(self.constraints)


# ─────────────────────────────────────────────────────────────
# Objective
# ─────────────────────────────────────────────────────────────


class ObjectiveSense(Enum):
    """Optimization direction of the objective (minimize or maximize)."""

    MINIMIZE = "minimize"
    MAXIMIZE = "maximize"


@dataclass
class Objective:
    """Objective function with sense (minimize/maximize)."""

    expression: Expression
    sense: ObjectiveSense


def objective_sense_sign(model: Model) -> float:
    """``-1.0`` if ``model`` maximizes, ``+1.0`` otherwise (or with no objective).

    Every evaluator and kernel in discopt minimizes, so a MAXIMIZE model is handed
    ``-f`` internally and its objective value, multipliers and parameter
    derivatives all come back in that flipped sense.  Anything reporting one of
    those to the user has to undo the flip; #1299 is what happens when each site
    is left to remember on its own (three wrong signs, in two modules).  Multiply
    the internal quantity by this.
    """
    if model._objective is None:
        return 1.0
    return -1.0 if model._objective.sense == ObjectiveSense.MAXIMIZE else 1.0


def repr_space_cutoff(
    repr_: Any,
    internal_cutoff: Optional[float],
    *,
    incumbent_point: Optional[np.ndarray] = None,
    tol: float = 1e-6,
) -> Optional[float]:
    """Internal (minimization-space) cutoff in ``repr_``'s own objective space.

    The B&B tree, the LP relaxation rows and every evaluator carry the objective
    in the internal *minimization* space (``-f`` for a MAXIMIZE model), so
    ``tree.incumbent()[1]`` is ``-f(x_inc)``.  ``repr_`` is a Rust ``ModelRepr``
    handle, and its cutoff-aware kernels (``fbbt_with_cutoff``,
    ``in_tree_presolve``) build the cutoff row against the repr's objective
    *expression* under the repr's declared ``objective_sense``: for a maximize
    they build ``f >= z``, so ``z`` must be ``f(x_inc)``, not ``-f(x_inc)``.
    Handing them the internal value makes the row ``f >= -f(x_inc)``, which on a
    maximize model with a negative optimum is *stricter* than valid and fathoms
    the optimum -- issue #1373, a false ``optimal`` with ``gap_certified=True``.

    The conversion keys off ``repr_.objective_sense`` rather than the Python
    model's because the repr is what the kernel reads (presolve clones the sense
    through, but the kernel's own declaration is the authority).  Use this at
    every such boundary rather than writing the sign by hand; see
    :func:`objective_sense_sign` for why (#1299).

    Returns ``None`` -- meaning *run the reduction without a cutoff* -- whenever
    the two spaces cannot be shown to agree:

    * ``internal_cutoff`` is ``None`` or non-finite;
    * ``repr_.objective_sense`` is missing or unrecognized;
    * ``incumbent_point`` is supplied, is evaluable against the repr, and the
      repr's objective there does **not** match the converted cutoff.

    A skipped cutoff is a looser box, which is sound (CLAUDE.md §3); a cutoff in
    the wrong space is a false certificate.  The verification is what makes this
    an assertion rather than a convention: it also catches a repr whose
    objective has been rescaled or offset away from the tree's value, which no
    amount of sign bookkeeping would.
    """
    if internal_cutoff is None:
        return None
    internal = float(internal_cutoff)
    if not np.isfinite(internal):
        return None

    try:
        sense = str(repr_.objective_sense)
    except Exception:  # pragma: no cover - defensive: older/foreign handle
        return None
    if sense == "minimize":
        cutoff = internal
    elif sense == "maximize":
        cutoff = -internal
    else:  # pragma: no cover - defensive
        return None

    if incumbent_point is not None:
        point = np.asarray(incumbent_point, dtype=np.float64).ravel()
        try:
            n_cols = int(repr_.n_vars)
        except Exception:  # pragma: no cover - defensive
            n_cols = -1
        if point.size == n_cols and np.all(np.isfinite(point)):
            try:
                at_point = float(repr_.evaluate_objective(point))
            except Exception:  # pragma: no cover - defensive
                at_point = float("nan")
            if not np.isfinite(at_point) or abs(at_point - cutoff) > tol * (1.0 + abs(cutoff)):
                # The repr's objective at the incumbent is not the cutoff we
                # derived, so the two spaces are NOT the same space. Refuse.
                return None
    return cutoff


# ─────────────────────────────────────────────────────────────
# Parameter (for parametric optimization / sensitivity)
# ─────────────────────────────────────────────────────────────


class Parameter(Expression):
    """
    A parameter -- a value fixed during a single solve but changeable between solves.

    Unlike constants, parameters are tracked in the expression DAG so that
    JAX can differentiate the optimal objective with respect to them via
    implicit differentiation through KKT conditions.

    Parameters are created through :meth:`Model.parameter`, not directly.

    Attributes
    ----------
    name : str
        Parameter name.
    value : numpy.ndarray
        Current parameter value.
    shape : tuple of int
        Shape of the parameter.

    Examples
    --------
    >>> price = m.parameter("price", value=50.0)
    >>> m.minimize(price * x[0] + cost * x[1])
    >>> result = m.solve()
    """

    # Declared so the ``value`` property's return type is inferable: the getter
    # returns ``self._value`` and the setter assigns to it, which without an
    # annotation is a cycle mypy resolves to "cannot determine type".
    _value: np.ndarray

    def __init__(self, name: str, value: Union[float, np.ndarray], model: "Model"):
        self.name = name
        # Through the setter, so `_shape` is populated by the one path that
        # maintains it (see the setter).
        self.value = np.asarray(value, dtype=np.float64)
        self.model = model

    @property
    def value(self) -> np.ndarray:
        """Current value, always a ``float64`` ndarray (0-d for a scalar)."""
        return self._value

    @value.setter
    def value(self, new_value: Union[float, np.ndarray]) -> None:
        """Re-bind the value, normalising exactly as ``__init__`` does.

        This was a plain attribute, so ``__init__`` established the documented
        "``value`` is an ndarray" invariant and the very next assignment broke it:
        ``p.value = 7.0`` -- the ordinary idiom in a parameter-estimation or
        model-discrimination loop -- left a bare Python float. ``model_to_repr``
        reads the value as an array to build the arena's ``Parameter`` node and
        refused such a model with ``TypeError: 'float' object cannot be converted
        to 'PyArray<T, D>'``, so re-binding a scalar parameter made the model
        un-lowerable while the same value passed to ``m.parameter(...)`` was fine.

        A shape change is refused rather than accommodated: ``shape`` is baked
        into every arena node, tape and relaxation already built from this
        parameter, so silently accepting a new shape would leave those
        inconsistent with the model. Re-declare the parameter instead.
        """
        arr = np.asarray(new_value, dtype=np.float64)
        if hasattr(self, "_value") and arr.shape != self._value.shape:
            raise ValueError(
                f"Parameter {self.name!r} was declared with shape {self._value.shape}; "
                f"re-binding it to shape {arr.shape} would invalidate every arena "
                f"node, tape and relaxation already built from it. Declare a "
                f"separate parameter instead of changing this one's shape."
            )
        self._value = arr
        # `Expression.shape`'s setter is what populates `_shape`, which is the
        # single source of truth `_known_shape` reads. Writing `_value` alone
        # left it unset, so `_known_shape(parameter)` answered "unknown" and the
        # M8 build-time shape check silently stopped firing for every expression
        # containing a parameter -- `q * x` with q of shape (2,) against x of
        # shape (3,) built without complaint. Keep the two in step here.
        self._shape = arr.shape

    # No `shape` property here on purpose. `Expression.shape` is read-write and
    # already answers for a Parameter: the `value` setter writes `_shape`, which
    # is what `_known_shape` -- and so `Expression.shape` -- reads. A read-only
    # override would narrow the base property for no gain.

    def __repr__(self):
        return f"param({self.name})"


# ─────────────────────────────────────────────────────────────
# Solve Result
# ─────────────────────────────────────────────────────────────

#: The one status whose ``gap_certified=True`` certifies something OTHER than an
#: optimality gap — an infeasibility proof legitimately carries neither a dual bound
#: nor an incumbent. Every other status must produce both ends of a gap to claim one;
#: see :meth:`SolveResult.__post_init__`. Deliberately not widened to ``unbounded``:
#: that would *weaken* an existing guard, and an unbounded minimize already carries
#: ``bound=-inf``, so it is decertified by the dual-side check regardless.
_NON_GAP_CERTIFICATE_STATUSES = frozenset({"infeasible"})

#: Where a valid dual bound came from (#1244). A closed vocabulary, checked in
#: ``SolveResult.__post_init__``, so a consumer can branch on provenance without
#: string-matching whatever a producer happened to write.
#:
#: * ``"bnb_tree"`` -- the branch-and-bound frontier minimum, over a tree in
#:   which every node's bound entered with a soundness proof.
#: * ``"convex_proof"`` -- the objective value at a KKT point of a model *proved*
#:   convex. A local minimum of a convex problem is the global minimum, so the
#:   incumbent is simultaneously a valid lower bound.
#: * ``"root_relaxation"`` -- a rigorous bound proved on the root box alone,
#:   used when the tree's own bound had to be discarded as tainted.
#: * ``"lp_dual"`` -- a dual-feasible point of an LP relaxation (weak duality).
#: * ``"external_solver"`` -- a dual bound an external solver reported and discopt
#:   did not prove (``solver="scip"``, #1784). It never accompanies
#:   ``bound_valid=True``: SCIP's presolve was measured certifying a bound past
#:   the true optimum of MINLPLib ``ex1252a`` on a faithfully translated model,
#:   so the number is information, not a certificate.
BOUND_SOURCES = frozenset(
    {"bnb_tree", "convex_proof", "root_relaxation", "lp_dual", "external_solver"}
)

#: Statuses that make no claim about the GLOBAL problem (#1148). Imported from
#: ``discopt.status`` -- a leaf module with no imports of its own -- rather than
#: re-spelled here, so the vocabulary has exactly one definition and the benchmark
#: harness, the solver and this dataclass cannot drift apart on what "local" means.
from discopt.status import is_local_status as _is_local_status  # noqa: E402


def _refuse_retired_variable(var: Any, model: Optional["Model"]) -> None:
    """Refuse a Variable of *model* that is no longer one of its columns.

    ``result.x`` is keyed by name, and a name can outlive its Variable: a pass
    that substitutes a variable out (``AffineDecisionRule.apply`` replaces ``y``
    by its affine policy) drops it from ``model._variables`` and frees the name,
    so a later ``m.continuous("y", ...)`` is legal. A name-only lookup then
    resolved the retired ``y`` to the NEW ``y``'s value without a word. A
    Variable that belongs to the solved model is therefore identified by
    position and identity -- ``model._variables[var._index] is var`` -- before
    its name is consulted. A Variable of a different model (a clone's source,
    a rebuilt model) has no identity in this one and keeps the by-name lookup.

    ``result._model`` is the live model, not a snapshot, so a variable
    substituted out *after* the solve is refused too: loud where the stored
    value may still be right, never silent where it is wrong.
    """
    if model is None or not isinstance(var, Variable) or var.model is not model:
        return
    variables = model._variables
    idx = var._index
    if 0 <= idx < len(variables) and variables[idx] is var:
        return
    raise KeyError(
        f"Variable {var.name!r} is no longer a variable of the solved model "
        "(substituted out by a reformulation such as AffineDecisionRule.apply), so "
        "the solution has no value for it. A variable now carrying the same name, "
        "if any, is a different variable; read the policy or substitution that "
        "replaced it instead."
    )


def _value_not_a_variable_message(node: Any) -> str:
    """Why ``SolveResult.value(node)`` cannot serve a non-``Variable`` argument.

    ``result.x`` is keyed by variable name, so anything that is not a column of
    the solved model has no entry in it. Looking the argument's ``.name`` up
    anyway raised a bare ``KeyError`` on the node's display name (#1218) -- an
    internal error where the honest answer is structural: an expression is
    computed FROM the solution, it is not part of it.
    """
    if isinstance(node, CustomCall):
        return (
            f"value() takes a model Variable; {node.name!r} is an opaque custom "
            "block (a CustomCall). Its body is traced and evaluated inside the "
            "objective/constraints -- it is not a column of the model, so the "
            "solution has no entry for it. If it came from dm.argmin(): the "
            "follower's y* is recovered either by calling the layer at the "
            "solution (phi = dm.argmin_layer(inner, [q]); phi(jnp.array([p*]))), "
            "or by using dm.argmin_kkt(model, inner, ...) instead, which lowers "
            "the follower so its variables ARE model variables and "
            "result.value(v[0]) works."
        )
    if isinstance(node, Expression):
        return (
            f"value() takes a model Variable; got a {type(node).__name__} "
            "expression. Only variables have entries in result.x -- an "
            "expression is computed from them. Read the variables it is built "
            "from (result.value(x)) and combine them, or add the quantity to "
            "the model as a named variable fixed by an equality constraint."
        )
    return (
        f"value() takes a model Variable; got {type(node).__name__}. Pass the "
        "Variable object returned by model.continuous()/integer()/binary(), or "
        "any handle that names one of the solved model's variables."
    )


#: Route stats that mark an incumbent its exit gate refused (#1659, #1561).
_ROUTE_REFUSAL_STATS = ("spatial/exit_gate_refused", "nlpbb/integral_incumbent_unverified")


def _withdraw_refused_incumbent(result, time_limit, max_nodes) -> None:
    """Withdraw an incumbent the route refused and no repair verified (#1775 G6.2).

    Owner decision (2026-10-23): a point the exit gate refuses is never reported.
    The route marks it and still returns it, because ``Model.solve``'s #1537 repair
    (:func:`~discopt.validation.feasibility.repair_point`, adopted only when
    ``verify_point`` accepts the moved point) can still make it a verified
    feasible point -- measured on #1836's robust row: the tree's incumbent is
    5.7e-6 outside ``max(x-0.5, 1.5-x)**2 <= 10``, the exit polish's NLP errors on
    the ``max`` kink, and the repair lands on ``0.5 + sqrt(10)`` exactly. Only a
    point that survives neither is withdrawn: no ``x``, objective or gap, the
    status naming the resource that ran out (``"unknown"`` if none did), and the
    dual bound left standing.
    """
    stats = result.solver_stats or {}
    if result.x is None or not any(stats.get(k) for k in _ROUTE_REFUSAL_STATS):
        return
    if stats.get("certificate/incumbent_repaired"):
        return
    import logging

    from discopt.solver import _status_without_incumbent

    logging.getLogger("discopt.solver").warning(
        "#1775 G6.2: withdrawing an incumbent the exit gate refused and no repair "
        "verified (objective %s); no point is reported.",
        result.objective,
    )
    result.status = _status_without_incumbent(
        result.wall_time, time_limit, result.node_count or 0, max_nodes
    )
    result.x = None
    result.objective = None
    result.gap = None
    result.gap_certified = False
    for _dual in ("constraint_duals", "bound_duals_lower", "bound_duals_upper"):
        if getattr(result, _dual, None) is not None:
            setattr(result, _dual, None)
    result.solver_stats = {**stats, "certificate/incumbent_withdrawn": 1.0}


@dataclass
class SolveResult:
    """
    Result returned by :meth:`Model.solve`.

    Attributes
    ----------
    status : str
        Termination status. The vocabulary is defined in :mod:`discopt.status`:
        ``"optimal"``, ``"feasible"``, ``"infeasible"``, ``"unbounded"``,
        ``"time_limit"``, ``"node_limit"``, ``"iteration_limit"``, ``"error"``,
        and the two **local** statuses added by #1148 —
        ``"local_optimal"`` (a local stationary point, no global claim) and
        ``"local_infeasible"`` (a local solver found no point, which is *not* an
        infeasibility proof; a stalled MPEC continuation lands here), plus
        ``"local_limit"`` (a local search stopped on a limit at a point it did not
        establish as stationary). Two more say the search ended with no incumbent
        and no proof either way (#2053): ``"unknown"`` (feasibility undetermined
        -- e.g. a tree drained without a rigorous fathom, or a decomposition loop
        that found nothing feasible) and ``"no_feasible_point"`` (the
        outer-approximation routes' spelling of the same claim). Neither is an
        infeasibility proof nor an error. ``discopt.status.STATUSES`` is the
        complete set.

        The local statuses are a distinct status rather than a flag beside
        ``"optimal"`` on purpose: a consumer that has never heard of the local
        mode maps an unknown status to "unknown" and skips the row, so it fails
        closed. Reusing ``"optimal"`` would have the benchmark harness score a
        local stationary point as a *proved optimum*. A result carrying a local
        status always has ``gap_certified=False`` and may never carry a
        ``bound``; :meth:`__post_init__` enforces both.
    objective : float or None
        Best objective value found (None if infeasible).
    bound : float or None
        Best dual (lower) bound.
    gap : float or None
        Relative optimality gap
        ``|objective - bound| / max(|objective|, |bound|, 1e-10)``, computed
        from the returned ``(objective, bound)`` pair with the SAME arithmetic
        the convergence test uses, so the two can never disagree (#1386). It
        follows that a solve reporting ``status="optimal"`` always satisfies
        ``gap <= gap_tolerance`` OR ``objective - bound <= abs_gap_tolerance``.

        The denominator is ``max(|objective|, |bound|, 1e-10)``, NOT
        ``|objective|`` as this said before #1386 and NOT the B&B tree's
        internal hybrid gap, whose denominator is floored at 1.0. The routes
        that forwarded the tree's number reported a gap up to 258x away from
        the one their own termination test had just evaluated (measured on the
        six-hump camel at ``gap_tolerance=1.0``: 258.36 reported against 1.0
        tested), and below unit objective scale the disagreement ran the other
        way and understated it.

        **One formula on every exit** (#1585): an optimal exit, a
        ``node_limit``/``time_limit`` stop that kept an incumbent
        (``status="feasible"``), and every post-solve repair all report this
        number, through :func:`discopt.solvers._gap.reported_gap`. Before #1585 a
        limit exit reported ``|objective - bound| / max(1, |objective|)``, so the
        same pair had two gaps depending on why the search stopped.

        The convergence test is a disjunction -- absolute gap
        ``<= abs_gap_tolerance`` (default ``1e-6``) OR relative gap ``<=
        gap_tolerance`` -- and a gap within the absolute tolerance is reported
        as ``0.0``, because the relative number degenerates near a zero optimum.
        So below unit objective scale ``gap == 0.0`` can stand for a relative
        gap far above ``gap_tolerance`` (e.g. ``5.5e-7`` absolute on a ``2e-3``
        objective, #1352). ``solver_stats["gap_criterion"]`` names the arm when
        a criterion was met. ``None`` when there is no incumbent or no finite
        bound, or when a route declined to define a relative gap (AMP at a zero
        incumbent). ``root_gap`` is a separate root statistic with its own
        documented formula.
    x : dict of str to numpy.ndarray, or None
        Variable values keyed by name. None if no feasible solution found.

        Keyed by the columns the SOLVER solved, which on a model that needed a
        solve-time reformulation can be a superset of the variables the caller
        declared: the GDP lowering appends a selector binary per disjunct
        (``_gdp_aux_*``). Those are reported rather than hidden because a
        disjunctive model's selector is the only record of which disjunct the
        solver chose. Use :meth:`declared_x` for the caller's variables alone
        (#1334). The factorable lift's monomial auxiliaries (``_fr_aux_*``) are
        NOT reported (#1727): each is the value of a product of declared
        variables, so it carries nothing the caller cannot compute.
    wall_time : float
        Total wall-clock solve time in seconds.
    node_count : int
        Number of Branch & Bound nodes explored.
    mip_count : int
        Number of MIP/MILP solves performed by the algorithm, when tracked.
    rust_time : float
        Time spent in native Rust — the discopt core (B&B tree, simplex, presolve)
        **and** POUNCE. Together with ``python_time`` this partitions ``wall_time``.
    python_time : float
        Time spent in interpreted Python, including time inside the JAX library.
        Together with ``rust_time`` this partitions ``wall_time``.
    jax_time : float
        Time inside the JAX evaluator. **A SUBSET of** ``python_time``, not a peer
        of it: measured, ~96% of JAX time on the solve path is interpreted-Python
        dispatch/tracing rather than native XLA (heatexch_gen3: 13.34 s Python vs
        0.56 s XLA). Treating this as disjoint from ``python_time`` — as the
        pre-#921 accounting did — makes the split irreconcilable.
    pounce_time : float
        Time inside POUNCE (NLP/LP/QP subsolves). **A SUBSET of** ``rust_time``;
        POUNCE is Rust.
    root_bound : float or None
        Strongest rigorous dual bound proved at the root box, in the reported
        objective sense. None if no root relaxation was built.
    root_gap : float or None
        Relative gap of ``root_bound`` against the final incumbent
        (``|objective - root_bound| / max(1, |objective|)``). None when either
        the root bound or the incumbent is unavailable.
    root_time : float or None
        Wall-clock seconds elapsed when the root node was fathomed/branched.
    solver_stats : dict of str to float or str, or None
        Instrumentation counters, or None. Key families: per-family
        reduction/separation timers (``reduce/<fam>`` / ``separate/<fam>``,
        cumulative seconds), per-source cut counts (``cuts/<source>``, added by
        the P3.1b cut-measurement work and read by the ``p3_1*`` scripts),
        cut-pool gating telemetry (``pool/gate_*``, categorical decision codes),
        and ``"gap_criterion"``. Only the timer families are seconds and bounded
        by ``wall_time``; ``cuts/`` are counts and ``pool/`` are decision codes.

        ``"gap_criterion"`` is the one non-numeric entry: ``"absolute"`` or
        ``"relative"``, naming which arm of the convergence disjunction the
        returned ``(objective, bound)`` pair satisfies (#1243). The key is
        ABSENT when neither does — a solve that stopped on ``time_limit`` /
        ``node_limit`` or on an exhausted tree — so a consumer reading it with
        ``.get()`` gets ``None`` rather than a criterion the solve never met.
    kkt : dict of str to float, or None
        Terminal KKT residuals at the returned point, on the single-NLP routes
        whose backend reports them (#1247); ``None`` elsewhere, including every
        branch-and-bound route — there is no single NLP there whose residuals
        these would be.

        ``primal_infeasibility``, ``dual_infeasibility``, ``complementarity`` and
        ``kkt_error`` are POUNCE's ``final_*``, measured on its internally
        **scaled** problem (what its own convergence test runs on). The same four
        suffixed ``_unscaled`` are the residuals in the model's units — the ones
        a certificate stated in problem units must be built from.
        ``barrier_parameter`` is the terminal interior-point ``mu``, forwarded by
        :meth:`solve`'s ``warm_start`` to seed the next solve.
    constraint_duals : dict of str to numpy.ndarray, or None
        KKT multipliers at the returned point, keyed by ``Constraint.name``
        (one entry per row for a vector body), when the route exposes them.
        Sign convention (#1620), for the objective ``F`` the solver
        *minimized* -- ``F = f`` for MINIMIZE, ``F = -f`` for MAXIMIZE::

            grad F + sum_{<=} mu_i grad(body_i) - sum_{>=} mu_i grad(body_i)
                   + sum_{==} lam_k grad(lhs_k - rhs_k) = 0

        so **both** inequality senses carry ``mu >= 0`` (positive when
        binding), and an equality's ``lam`` is free, signed against
        ``lhs - rhs``. Example: ``min 2a + 3b`` s.t. ``a + b >= 4`` reports
        ``+2`` for that row; ``min x**2 + y**2`` s.t. ``x + y == 5`` reports
        ``-5``. Dict order is **not** declaration order: inequality rows come
        first, then equality rows.
    bound_duals_lower, bound_duals_upper : dict of str to numpy.ndarray, or None
        Multipliers of active variable bounds, keyed by ``Variable.name``,
        ``>= 0`` in the same internal-minimization convention.
    solve_report : dict or None
        POUNCE's structured solve report for the one POUNCE call that produced
        this result -- the ``pounce.solve-report/v1`` document, the same data as
        ``pounce --json-output <file> --json-detail full`` (#1534). Set on the
        routes that make a single POUNCE call: the continuous single-NLP route
        (convex fast path, and the local NLP on a convexity-unknown model), the
        continuous QP route, the LP route when POUNCE answered it, and all three
        arms of ``solver="pounce"`` (``pounce:lp-ipm``, ``pounce:qp-ipm``,
        ``pounce:nlp``), on every status they return. ``None`` elsewhere: every
        branch-and-bound route (no single NLP, as for ``kkt``), an LP answered by
        the simplex or HiGHS, and the cyipopt backend.

        On ``pounce:lp-ipm`` / ``pounce:qp-ipm`` the document is built by discopt
        from POUNCE's ``QpResult`` (its Python convex entry point writes none),
        with the same field mapping POUNCE's CLI uses for that engine
        (:func:`discopt.solvers._pounce_report.convex_report`;
        ``report["fair_metadata"]["generated_by"]`` says so). That engine has no
        line search, regularization or restoration phase, so those columns are
        zero there and its rows match the table printed at ``print_level > 0``
        exactly.

        Keys (the document's own; nothing is renamed):

        * ``report["statistics"]`` -- ``iteration_count``, the ``final_*``
          residuals, evaluation counts, ``total_wallclock_time_secs``, and the
          restoration-phase counts ``restoration_calls``,
          ``restoration_inner_iters``, ``restoration_outer_iters``,
          ``restoration_wall_secs``.
        * ``report["iterations"]`` -- the trajectory, one dict per printed
          iteration row (see below for restoration rows) with ``iter``,
          ``objective``, ``inf_pr``, ``inf_du``, ``mu``,
          ``d_norm``, ``regularization``, ``alpha_dual``, ``alpha_primal``,
          ``alpha_primal_char`` (the line-search flag printed after ``alpha_pr``;
          ``"R"`` marks restoration; see below) and ``ls_trials``. The final
          barrier parameter is ``report["iterations"][-1]["mu"]``. Always
          present: ``[]`` when the solve stopped before its first iteration
          (#1585).
        * ``report["solution"]``, ``report["problem"]``,
          ``report["fair_metadata"]`` (solver version, timestamps).

        With a POUNCE that carries jkitchin/pounce#979 (``main``; not yet in a
        release) the trajectory matches POUNCE's printed iteration table row for
        row on every column: each row has ``phase`` (``"main"`` or
        ``"restoration"``), the inner restoration rows (printed as ``24r``,
        ``25r``, ...) are included in printed order, and the slack-form residual
        is ``inf_pr_internal``. Select ``phase == "main"`` for the outer
        trajectory. As in the printed table, one restoration call puts ``"R"``
        on two rows -- the entry (a ``"restoration"`` row) and the return to the
        main phase -- so count calls with ``statistics["restoration_calls"]`` or
        the ``"main"`` -> ``"restoration"`` transitions, not the ``"R"`` rows.
        On pounce-solver 0.12.0 (below discopt's pin) rows carry no ``phase``, only the
        main-phase rows are present -- restoration shows up as the ``"R"`` row and
        the ``restoration_*`` counts -- and ``inf_pr`` is POUNCE's internal primal
        infeasibility on its slack-reformulated, scaled problem rather than the
        printed column's violation of the original constraints, so the two differ
        wherever a slack sits off its constraint value (typically the first
        iterations).

        Several attempts (#1985). ``report["statistics"]["iteration_count"]`` and
        the trajectory describe one POUNCE attempt, which is not always all the
        work behind the answer:

        * When POUNCE's gh#884 dual-divergence guard re-solved, the counts and
          trajectory are the *retry's*; POUNCE reports nothing of the first
          attempt. ``statistics["counts_attempt"]`` is then ``"retry"``,
          ``statistics["solution_attempt"]`` says which attempt the answer is
          from (``"retry"``, ``"base"`` or ``"undetermined"``, read from whether
          the trajectory ends at the reported final values), and
          ``statistics["total_counts_complete"]`` is ``False``.
        * When ``solver="pounce"`` continued a mid-path solve (#1768), this is the
          report of the call whose answer is published, and
          ``statistics["attempts"]`` lists both calls' counts, with their sum in
          ``statistics["total_iteration_count"]``. Compare formulations by that
          total, not by ``iteration_count``; with ``total_counts_complete`` False
          it is a lower bound.

        It describes the problem POUNCE was handed: for a maximization that is
        the negated objective, and for an LP or QP the matrix form with slacks
        eliminated. Diagnostic only; nothing in the solver reads it back.
    convex_fast_path : bool
        True if the problem was detected as convex and solved with a
        single NLP call (no Branch & Bound), guaranteeing global optimality.
    nlp_bb : bool
        True if the problem was solved using nonlinear Branch & Bound
        (NLP-BB), where continuous NLP subproblems are solved at each
        node with discrete variables fixed via bound tightening.
    gap_certified : bool
        True if the reported optimality gap is mathematically certified.
        False when NLP-BB is used on a nonconvex problem (heuristic mode),
        where the NLP objective is not a valid lower bound.

        On ``status="infeasible"`` there is no gap: ``gap_certified=True``
        there means the *infeasibility* is proved (by presolve, an exhausted
        tree, or an LP/QP Farkas certificate) and is not a heuristic verdict;
        ``objective``, ``bound`` and ``gap`` are ``None``. It is the only status
        allowed to be certified without both ends of a gap (see
        ``_NON_GAP_CERTIFICATE_STATUSES``). ``termination`` and
        ``algorithm_route`` say which machinery produced the proof.
    bound_valid : bool
        True if ``bound`` is a valid global dual bound — a lower bound on the
        global optimum for a MINIMIZE model, an upper bound for a MAXIMIZE one —
        **whatever the termination status** (#1244).

        This is the flag to read before using ``bound`` as a certificate.
        ``gap_certified`` answers a narrower question: whether the *gap closed*.
        A ``time_limit`` or ``node_limit`` exit leaves the gap open, so it is
        never ``gap_certified``, yet its dual bound is usually perfectly valid —
        the frontier minimum over a tree whose every node bound entered with a
        soundness proof. A consumer that reads ``gap_certified`` to decide
        whether ``bound`` can be trusted therefore throws away every valid bound
        from a budgeted run.

        Fails closed: ``False`` means "discopt makes no claim here", not "the
        bound is wrong". It is ``False`` whenever ``bound`` is ``None`` or
        non-finite, on every local status (which may not carry a bound at all),
        and on any producer that has not been taught to assert it.

        Validity by status × route, for the branch-and-bound routes:

        =================  ==================================================
        status             ``bound_valid``
        =================  ==================================================
        ``optimal``        True. The bound is the certificate.
        ``feasible``       True when a bound is reported. The exit did not
                           close the gap, but the retained bound passed the
                           same taint check the certificate does; a tainted one
                           is replaced by an independently proved root bound or
                           dropped to ``None``.
        ``time_limit``     As ``feasible``: True with a bound, and a bound is
        ``node_limit``     reported whenever the search proved one, incumbent
                           or not.
        ``infeasible``     False — ``bound`` is ``None``. The certificate is
                           the infeasibility proof, not a bound.
        ``unbounded``      False.
        local statuses     False — a local solve makes no global claim and may
                           not carry a bound (see ``__post_init__``).
        =================  ==================================================

        The convex fast path (``convex_fast_path=True``) reports
        ``bound = objective`` with ``bound_source="convex_proof"``: valid
        because the convexity proof is rigorous, which is the same premise that
        licenses returning after a single NLP solve.
    bound_source : str or None
        Where a valid bound came from — one of
        :data:`~discopt.modeling.core.BOUND_SOURCES` (``"bnb_tree"``,
        ``"convex_proof"``, ``"root_relaxation"``, ``"lp_dual"``, and
        ``"external_solver"`` for an unproved bound from ``solver="scip"``) — or ``None``
        when there is no bound, or when the producer asserted validity without
        naming a provenance. Diagnostic: ``bound_valid`` is the safety-critical
        flag; this says which machinery earned it.
    algorithm_route : Optional[str]
        Why an algorithm other than the default branch-and-bound ran, when the
        solver chose it automatically (#1059). ``None`` when no automatic
        routing happened -- either the caller named ``solver=`` explicitly, or
        the router declined and the default path ran. When presolve proves the
        model infeasible before any search, it is ``"presolve: infeasibility
        proved by <pass>"`` and ``termination == "presolve"`` (#1618 C-17).
    """

    status: str
    objective: Optional[float] = None
    bound: Optional[float] = None
    gap: Optional[float] = None
    x: Optional[dict[str, np.ndarray]] = None
    wall_time: float = 0.0
    node_count: int = 0
    mip_count: int = 0

    # Layer profiling.
    #
    # ``rust_time`` and ``python_time`` are DISJOINT and partition ``wall_time``:
    # native Rust (discopt core + POUNCE) versus interpreted Python.
    #
    # ``jax_time`` and ``pounce_time`` are diagnostic SUBSETS, not peers:
    #     jax_time    <= python_time     (JAX is ~96% interpreted Python)
    #     pounce_time <= rust_time       (POUNCE is Rust)
    #
    # The old model made ``jax_time`` a peer of ``python_time`` and derived
    # ``python_time = wall - rust - jax``. Because JAX time is overwhelmingly
    # Python time, that double-subtracted and the three fields never reconciled:
    # measured on tspn08, ``jax_time`` read 18.82 s where cProfile found 0.78 s of
    # JAX frames and 11.69 s of POUNCE — a bucket that had no home.
    rust_time: float = 0.0
    python_time: float = 0.0
    jax_time: float = 0.0
    pounce_time: float = 0.0

    # Root-node certification instrumentation (Phase 0 / cert:T0.1). These
    # describe the state of the search at the moment the root node is fathomed
    # or branched — the point that governs whether the solver certifies at the
    # root (like BARON) or opens a tree. ``root_bound`` is the strongest
    # rigorous dual bound proved at the root box, in the *reported* objective
    # sense (already negated for MAXIMIZE, mirroring ``bound``). ``root_gap`` is
    # the relative gap ``|objective - root_bound| / max(1, |objective|)`` of
    # that bound against the final incumbent, using the same floored abs/rel
    # convention as ``gap``. ``root_time`` is the wall-clock seconds elapsed
    # from the whole-solve clock to that moment. All three are ``None`` when
    # the path never builds a root relaxation (e.g. an early infeasibility exit).
    root_bound: Optional[float] = None
    root_gap: Optional[float] = None
    root_time: Optional[float] = None

    # Per-family reduction/separation timers (cert:T0.3). A flat dict of
    # phase-name -> cumulative seconds across the solve, e.g.
    # ``{"reduce/fbbt": .., "reduce/obbt": .., "separate/psd": .., ...}``. Pure
    # instrumentation (never affects solver math); None when nothing was timed.
    # ``float`` for every counter and timer; ``str`` only for the categorical
    # ``"gap_criterion"`` (#1243). ``Any`` rather than ``Union[float, str]``
    # because ``dict`` is INVARIANT in its value type: the ~8 producers across
    # ``solver.py`` build a ``dict[str, float]``, and a ``Union`` value type
    # rejects every one of them at the constructor. The real contract is the
    # docstring above. The criterion is spelled out as a name rather than
    # encoded as a magic number because this dict is read by humans and by the
    # report tooling, and a code would have to be decoded in both.
    solver_stats: Optional[dict[str, Any]] = None

    # KKT duals at the returned point, when the underlying solver exposes them.
    # ``constraint_duals`` is keyed by Constraint.name; entries with a vector
    # body have one multiplier per row. ``bound_duals_lower`` /
    # ``bound_duals_upper`` are keyed by Variable.name. All values are in the
    # internal-minimization sign convention (``>= 0`` at active bounds /
    # binding-from-below inequalities). For maximize problems, the multipliers
    # correspond to the negated objective the solver actually saw.
    constraint_duals: Optional[dict[str, np.ndarray]] = None
    bound_duals_lower: Optional[dict[str, np.ndarray]] = None
    bound_duals_upper: Optional[dict[str, np.ndarray]] = None

    # Terminal KKT residuals at the returned point, on NLP routes whose backend
    # reports them (#1247). ``None`` everywhere else — a branch-and-bound solve
    # has no single NLP whose residuals these would be, and a route that cannot
    # point at a measured residual reports nothing rather than a zero.
    #
    # Keys (see ``solvers.nlp_pounce._kkt_from_info``):
    #   * ``primal_infeasibility`` / ``dual_infeasibility`` / ``complementarity``
    #     / ``kkt_error`` — POUNCE's ``final_*``, measured on the solver's
    #     internally SCALED problem, which is what its own convergence test runs
    #     on;
    #   * the same four suffixed ``_unscaled`` — the residuals in the model's own
    #     units. A certificate stated in problem units (e.g. a CALPHAD
    #     tangent-plane bound) must be built from these, not from the scaled
    #     ones;
    #   * ``barrier_parameter`` — the terminal interior-point ``mu``, forwarded
    #     by ``solve(warm_start=...)`` to seed the next solve's ``mu_init``.
    #
    # Diagnostic, never load-bearing: nothing in the solver reads this field back,
    # so a backend that omits a key cannot change a verdict.
    kkt: Optional[dict[str, float]] = None

    # POUNCE's ``pounce.solve-report/v1`` document for the single POUNCE call that
    # produced this result (#1534): iteration trajectory, restoration statistics,
    # timing. ``None`` on every route without exactly one POUNCE call. When
    # ``solver="pounce"`` continued a mid-path solve (#1768) it is the report of
    # the call whose answer is published, and its ``statistics["attempts"]`` /
    # ``total_iteration_count`` cover both calls (#1985). Diagnostic, never
    # load-bearing, like ``kkt``.
    solve_report: Optional[dict[str, Any]] = None

    # POUNCE qp-ipm's final primal-dual iterate (``x``, ``y``, ``z``, ``z_lb``,
    # ``z_ub`` in the objective units the engine was handed, rows in the order the
    # ``solver="pounce"`` QP route built them) -- set only by that route (#1679).
    # ``solve(warm_start=...)`` forwards it so the next qp-ipm solve starts from the
    # full iterate instead of from ``x`` alone. Seeds an iteration; never changes a
    # verdict.
    pounce_qp_iterate: Optional[dict[str, np.ndarray]] = None

    # Witness for an infeasible result, when the backend computed one. An
    # ``InfeasibilityCertificate`` (per-row minimal constraint violations, in
    # LP-row order) for LPs solved via the POUNCE engine; None otherwise.
    infeasibility_certificate: Optional[object] = None

    # Convex fast path indicator
    convex_fast_path: bool = False

    # NLP-BB indicator and gap certification
    nlp_bb: bool = False
    gap_certified: bool = True

    # #1244: is ``bound`` a valid global dual bound, whatever the status?
    #
    # Defaults to False and is raised only where the solver can point at the
    # proof, so a producer that has not been taught about this field reports "no
    # claim" rather than a claim it never earned. ``__post_init__`` derives it
    # from ``gap_certified`` (a certified gap IS the assertion that the bound is
    # valid) and clears it whenever ``bound`` is absent or non-finite.
    bound_valid: bool = False
    bound_source: Optional[str] = None

    # SubNLP primal-heuristic counters (zero unless the heuristic ran).
    subnlp_calls: int = 0
    subnlp_feasible: int = 0
    subnlp_incumbent_updates: int = 0

    # Structured MIP-NLP decomposition trace. Populated by solver="mip-nlp"
    # paths when iteration/provenance data is available.
    mip_nlp_trace: Optional[dict[str, object]] = None

    # Why this solve failed, when the caller would otherwise be left with a bare
    # ``status="error"`` and no reason (#1246). Set by :func:`discopt.solve_batch`
    # for a model whose solve raised — the batch captures the exception here
    # instead of aborting the remaining models — and ``None`` on every other
    # route, which today reports failures by status alone.
    error: Optional[str] = None

    # Why an algorithm other than the default branch-and-bound ran (#1059).
    # ``None`` means no automatic routing took place — either the caller named a
    # solver explicitly, or the router declined and the default path ran. When
    # populated it is a human-readable reason, e.g.
    # ``"mip-nlp/lp_nlp_bb: minlp certified convex at the root (DISCOPT_CONVEX_MINLP_ROUTE;
    # master=highs)"``.
    algorithm_route: Optional[str] = None

    # Why the search stopped (#1585) -- orthogonal to ``status``, which says what
    # was PROVEN. One of ``discopt.status.TERMINATION_REASONS``:
    #
    # - ``"gap"``: the optimality gap closed within ``gap_tolerance`` /
    #   ``abs_gap_tolerance`` (status usually ``optimal``);
    # - ``"exhausted"``: the tree drained -- every node was pruned or solved
    #   (status usually ``optimal`` with an incumbent, ``infeasible`` without);
    # - ``"unresolved"``: the tree drained but removed a subtree without proof (the
    #   #467 pin or an open #598 floor), so the search is incomplete (#1869);
    # - ``"node_limit"`` / ``"time_limit"`` / ``"iteration_limit"``: a budget ran
    #   out first. Depending on the route the status of such an exit is either the
    #   budget name or ``feasible`` (an incumbent plus a certified bound with an
    #   open gap -- the #933 vocabulary, unchanged), so ``status="feasible"``
    #   alone does not say WHETHER a budget stopped the search, nor which; this
    #   field does, on every branch-and-bound / MILP route;
    # - ``"interrupted"``: a user/debugger stop;
    # - ``"presolve"``: presolve proved ``infeasible`` before any search ran
    #   (``node_count == 0``; ``algorithm_route`` names the pass, #1618 C-17).
    #
    # ``None`` means the route records no reason (a direct NLP/LP solve that is not
    # a search, or a route that has not been taught the field).
    #
    # The field records why the LOOP stopped; ``status`` is decided afterwards and
    # can disagree with the "usually" above (#1590 review N3). Known cases:
    #
    # - a tree that drains at exactly ``max_nodes`` with no incumbent reports
    #   ``status="node_limit"`` (the no-incumbent branch tests the node budget
    #   first) with ``termination="exhausted"``;
    # - a ``"gap"`` exit the solve-level chokepoint later downgrades
    #   (``_refuse_unclosed_published_pair`` / the #1285 polish recheck) reports
    #   ``status="feasible"`` with ``termination="gap"``;
    # - a drained tree whose bound is held below the incumbent by an unresolved
    #   floor reports ``status="feasible"`` with ``termination="unresolved"``
    #   (``"exhausted"`` before #1869).
    #
    # Read ``status`` / ``gap_certified`` for what is proven; never infer a
    # certificate from this field.
    termination: Optional[str] = None

    # Examiner-style validation report (populated if validate=True).
    validation_report: Optional[object] = None

    # Source-level complementarity/MPEC residual report (#1148), populated by
    # ``discopt.mpec.solve_mpec`` on every method. A
    # ``discopt.mpec_report.SourceResidualReport``: residuals computed on the
    # relations' SOURCE operands (which survive every rebuilding pass, #1147),
    # each carrying the definition that produced it, plus the lowered rows'
    # own residual so the two can be compared.
    #
    # ``None`` means NOT MEASURED -- never "measured clean". It arises three ways:
    # the solve produced no incumbent, so there was no point to measure; the
    # residual measurement refused (an operand the interval evaluator cannot walk;
    # ``solve_mpec`` warns and returns the solve result unharmed); or the solve
    # never went through ``solve_mpec`` at all. Use
    # ``discopt.mpec.source_residuals(model, result)`` to measure a result the
    # plain ``Model.solve`` path produced. A model with no complementarity
    # relations reports ``n_scalar_relations=0``, which is a measurement of
    # nothing rather than a clean bill of health -- read that field before the
    # residual values.
    #
    # Typed ``object`` to keep the import lazy -- the report module reaches the
    # interval evaluator, and ``SolveResult`` is constructed on every solve path.
    mpec_report: Optional[object] = None

    # Per-start log of ``discopt.mpec.solve_mpec_multistart`` (#2167): a list of
    # ``discopt.mpec.MultistartRecord``, one per start that ran. ``None`` on every
    # other path.
    multistart: Optional[list] = None

    # Set True when the final incumbent-verification guard (Model.solve, default
    # on) found the returned incumbent INFEASIBLE in the ORIGINAL problem — a
    # false primal, which can only arise from an unsound presolve mutation or a
    # heuristic bug. When True, the incumbent (``x``/``objective``) has been
    # withheld, ``gap_certified`` forced False, and ``status`` set to ``"error"``
    # (a false primal is never reported as a valid, certified, or *optimal*
    # solution -- leaving the status at ``"optimal"`` with no incumbent claims a
    # proven optimum that does not exist). ``bound`` is retained: only the primal
    # was invalidated. This should never be True on
    # correct solver code; it exists so such a bug cannot silently escape as a
    # false result (regression guard for the #770/#772 class).
    incumbent_verification_failed: bool = False

    # #1618 B-18: the local NLP solver's final iterate when it was WITHHELD from
    # ``x`` because it failed the feasibility screen (#815) -- e.g. an
    # ``iteration_limit`` exit of a real-time-iteration / NMPC step. Never an
    # incumbent: ``x``/``objective`` stay ``None``, and nothing (bound, gap,
    # certificate) is derived from it. ``last_iterate_violation`` is its max
    # constraint/bound violation in the declared model. ``None`` when ``x`` was
    # reported, or the route keeps no iterate.
    #
    # #1678 (contract decided): ``x`` is NEVER the withheld iterate. ``x`` is the
    # incumbent -- a point that passed the feasibility screen -- and a caller who
    # reads ``res.x`` after a ``max_iter``/time stop must not be handed an
    # infeasible point as a solution. ``last_iterate`` carries primal values only:
    # no multipliers, slacks or barrier parameter, so ``initial_point=
    # res.last_iterate`` is a cold primal start from an infeasible point and can
    # fail on a hard NLP where a true warm restart (shifted bounds plus
    # multipliers) would not. The solver logs a warning naming this field when it
    # withholds ``x``.
    last_iterate: Optional[dict[str, np.ndarray]] = None
    last_iterate_violation: Optional[float] = None

    # LLM explanation (populated if llm=True)
    _explanation: Optional[str] = None
    _model: Optional["Model"] = None

    # Sensitivity cache (populated lazily by .gradient())
    _sensitivity: Optional[np.ndarray] = None

    # Provenance of the process that SOLVED this result, and the options it
    # solved with (#1266). Set by ``result_io.deserialize_result`` when a result
    # arrives from the solve daemon, so the archived file records the daemon's
    # identity rather than the writing client's. ``None`` on an in-process solve:
    # there the writer IS the solving process and captures its own.
    _provenance: Optional[dict] = None
    _solve_options: Optional[dict] = None

    # The search's uncapped proved dual bound, declared sense, when the route
    # tracks one apart from ``bound`` (NLP-BB under
    # ``DISCOPT_CONVEX_NODE_KEEP_PROVED_BOUND``). ``bound`` is capped at the
    # incumbent's value as the solver computed it; once
    # :meth:`Model._reconcile_objective_with_model` re-values the objective
    # exactly, ``min(this, objective)`` may be published instead. ``None`` elsewhere.
    _proved_bound: Optional[float] = None

    def declared_x(self, model: "Model") -> dict[str, np.ndarray]:
        """``x`` restricted to the variables *model* declares.

        #1334: ``x`` is keyed by the columns the SOLVER solved, and a solve-time
        reformulation can append its own — the GDP lowering adds a selector
        binary per disjunct — so a plain ``print(result.x)`` on a disjunctive
        model shows names like ``_gdp_aux_disj_anon_1_1`` that the caller never
        wrote. This returns just the caller's own. (The factorable lift's
        ``_fr_aux_*`` columns are already left out of ``x``, #1727.)

        The split is taken from *model*'s variable list, not from a name pattern:
        every pass that generates columns would have to be enumerated for a
        prefix rule to be right, and a rule that falls behind a new pass drops a
        real variable from a user's results.

        The generated entries are kept in ``x`` rather than dropped there,
        because for a disjunctive model the selector IS the answer to "which
        disjunct did it pick?" and ``x`` is the only place it is reported.

        Parameters
        ----------
        model : Model
            The model as the caller declared it — the one passed to
            :meth:`Model.solve` / :func:`discopt.solve_model`, not a
            reformulation of it.

        Returns
        -------
        dict of str to numpy.ndarray
            ``{}`` when the solve returned no point. A variable the solve does
            not report is simply absent, so this never raises on a partial
            result.
        """
        if not self.x:
            return {}
        return {v.name: self.x[v.name] for v in model._variables if v.name in self.x}

    def __post_init__(self) -> None:
        # A2 (correctness/API): the failure/no-relaxation sentinel must never
        # escape through the public bound/gap surface. Internally the solver
        # stores ``INFEASIBILITY_SENTINEL`` (``1e30``) as the "lower bound" of a
        # node whose relaxation failed or was declared infeasible, and on the
        # no-relaxation class (a model whose relaxation omits rows, so no dual
        # bound is ever produced) the tree's ``global_lower_bound`` stays at that
        # sentinel. It is *finite* (``np.isfinite(1e30)`` is True), so the
        # existing non-finite guard below does not catch it, and a raw
        # result-assembly path would surface ``bound=1e30`` — and a ``gap``
        # computed from it — as if it were a real dual bound. Map any
        # sentinel-magnitude bound (either sense, so ``-1e30`` from a MAXIMIZE
        # negation too) to ``None`` at this single chokepoint that every
        # ``SolveResult`` construction passes through, so no public consumer
        # (``.bound``/``.gap``, the callback, commentary, the dashboard, the
        # benchmark JSON) ever does arithmetic on it. This is a
        # representation/reporting normalisation only — the internal sentinel is
        # unchanged. ``root_bound``/``root_gap`` get the same treatment.
        if self.bound is not None and abs(self.bound) >= _SENTINEL_THRESHOLD:
            self.bound = None
            self.gap = None
        if self.root_bound is not None and abs(self.root_bound) >= _SENTINEL_THRESHOLD:
            self.root_bound = None
            self.root_gap = None

        # Soundness guard: a *certified* optimality gap requires a finite dual
        # bound. A non-finite bound (``±inf``) or an absent bound (``None``)
        # certifies nothing about optimality — e.g. a ``time_limit`` termination
        # where no node ever produced a finite relaxation bound leaves the
        # global lower bound at ``-inf``. Reporting ``gap_certified=True`` there
        # is a false certification (the benchmark gate would miscount it as a
        # solved/certified instance), so we downgrade it and clear the
        # meaningless bound/gap. Infeasibility certificates are exempt
        # (``_NON_GAP_CERTIFICATE_STATUSES``): ``status="infeasible"`` with
        # ``gap_certified=True`` certifies infeasibility, not a gap, and
        # legitimately carries ``bound=None``.
        if self.gap_certified and self.status not in _NON_GAP_CERTIFICATE_STATUSES:
            if self.bound is None or not np.isfinite(self.bound):
                self.gap_certified = False
                self.bound = None
                self.gap = None

        # Same guard, other end of the gap (#875). A gap has two ends, and the check
        # above only requires the dual one: a ``time_limit`` exit that never found an
        # incumbent came back ``objective=None, gap=None, gap_certified=True``, which
        # claims a certified gap where no gap was ever formed. Harmless where nothing
        # is reported at all, but the flag is exactly what a consumer checks *before*
        # reading the values — the graduation panels count a ``gap_certified=True``
        # instance as certified, and the "no certification regression" rule compares
        # that flag across a flag flip. Reproduced with a 0.5 s budget on a 300-var
        # bilinear model: ``status=time_limit objective=None bound=-7497.0 gap=None
        # gap_certified=True nodes=0``.
        #
        # This only ever downgrades True -> False, so it cannot manufacture a
        # certificate; and it leaves ``bound`` alone, because a dual bound with no
        # incumbent is still a perfectly valid dual bound worth reporting — it is the
        # *gap* claim that was unfounded. Same exemption as above: a status whose
        # certificate is not a gap (``infeasible``) is not asked to produce one.
        if (
            self.gap_certified
            and self.objective is None
            and self.status not in _NON_GAP_CERTIFICATE_STATUSES
        ):
            self.gap_certified = False
            self.gap = None

        # #1148 §C: a LOCAL result may never become a dual bound. A feasible point
        # is a valid upper bound on a minimum, so a local solve may contribute an
        # *incumbent* (after independent feasibility verification -- see
        # ``discopt.mpec_report.accept_local_incumbent``); a dual bound is the
        # certificate, and a local solve proves nothing about it. That asymmetry is
        # what lets a local mode feed the global solver without contaminating it,
        # and it is enforced here rather than left to each producer: every
        # ``SolveResult`` passes through this one chokepoint, so a local status
        # cannot carry a bound by any route. Refusing loudly rather than silently
        # dropping the value: a caller that set one on a local result has a bug in
        # what it believes it proved, and a quiet ``None`` would hide it
        # (CLAUDE.md §3).
        if _is_local_status(self.status):
            if self.bound is not None or self.root_bound is not None:
                raise ValueError(
                    f"SolveResult(status={self.status!r}) carries a dual bound "
                    f"(bound={self.bound!r}, root_bound={self.root_bound!r}). A local "
                    "solve makes no global claim, so it may never contribute a dual "
                    "bound -- only an incumbent, and only after independent "
                    "feasibility verification (#1148 §C)."
                )
            # Certification is a claim about the global problem; a local status
            # makes none. Absent certification is interpreted as NOT certified.
            self.gap_certified = False
            self.gap = None

        # #1856: an infeasibility certificate carries no dual bound. The NLP-BB
        # route returned ``status="infeasible"`` with ``bound=-10.058`` (its last
        # frontier minimum) and, through the derivation below, ``bound_valid=True``
        # -- a finite "valid global dual bound" on a problem with no feasible
        # point, against the documented contract (``bound`` is ``None``). Cleared
        # here, at the chokepoint every construction passes through, rather than
        # route by route; ``bound_valid`` then follows from ``bound is None``.
        if self.status == "infeasible":
            self.bound = None
            self.gap = None

        # #1244: ``bound_valid`` / ``bound_source``, normalized LAST so the
        # derivation below reads the FINAL ``gap_certified``, not the value a
        # producer passed in.
        #
        # The ordering is the whole point. ``gap_certified`` defaults to True,
        # and the guards above revoke it for a missing/non-finite bound, a
        # missing incumbent (#875) and every local status. Deriving validity
        # before those ran would raise the flag off a certificate that is about
        # to be withdrawn -- which is exactly what an early version of this block
        # did on the #654 deadline short-circuit (``objective=None``,
        # ``gap_certified`` still at its default). Right answer, wrong reason,
        # and the wrong reason is what generalizes to a bound that is NOT valid.
        #
        # Three rules:
        #
        # 1. A surviving certified gap IS the assertion that ``bound`` is a valid
        #    global dual bound -- that is what the certificate says, and it is
        #    the flag the phase gates already count ``incorrect_count`` from.
        #    Deriving it here rather than asking ~43 construction sites to repeat
        #    themselves is what stops a new return site from silently reporting
        #    "no claim" on a bound it did certify. It only ever RAISES the flag:
        #    a producer that asserted validity on an uncertified exit (a
        #    ``time_limit`` bound that passed the taint check) keeps it.
        # 2. Validity is a claim ABOUT a number: no number, no claim. This is
        #    also the acceptance criterion -- ``bound_valid`` is False whenever
        #    ``bound`` is None.
        # 3. The provenance vocabulary is closed, and an unknown value raises. A
        #    consumer branching on ``bound_source`` must not have to guess
        #    whether "bnb" meant "bnb_tree"; a typo reading as an unknown source
        #    would silently take the else-branch forever (CLAUDE.md §3).
        if self.gap_certified and self.status not in _NON_GAP_CERTIFICATE_STATUSES:
            self.bound_valid = True
        if self.bound is None or not np.isfinite(self.bound):
            self.bound_valid = False
            self.bound_source = None
        if self.bound_source is not None and self.bound_source not in BOUND_SOURCES:
            raise ValueError(
                f"SolveResult(bound_source={self.bound_source!r}) is not one of "
                f"{sorted(BOUND_SOURCES)}."
            )

    def _set_bound(
        self,
        bound: Optional[float],
        *,
        valid: bool,
        source: Optional[str] = None,
    ) -> None:
        """Set ``bound`` together with its validity claim (#1244).

        ``bound_valid`` / ``bound_source`` are DERIVED in ``__post_init__``, but
        that runs once. Every post-construction mutation of ``bound`` then has to
        maintain the triple by hand, and the audit that added the field found
        FOUR such sites in the tree -- all four the same shape of mistake, none
        of them noticed until searched for:

        * ``Model.solve``'s #844 fallback merge installed the fallback's bound
          beside the primary's stale flag;
        * ``solver._withhold_local_optimality_certificate`` cleared the bound and
          left ``bound_valid=True`` standing;
        * ``solver._merge_route_and_fallback`` installed the loser's bound on the
          winner, leaving provenance naming the winner's machinery for a number
          the other side proved;
        * the same function's #1059 crossing guard cleared a bound it had just
          proved invalid while leaving the claim that it was valid.

        An earlier draft of this docstring said "two sites" -- that was a count of
        the sites the field's own PR happened to touch first, not of the sites
        that exist. The lesson is the opposite of a small number: a field that
        every mutation site must maintain, taught to only some of them, converts
        a latent inconsistency into a shipped one. So the triple moves together
        through here, and a new ``self.bound = ...`` anywhere is a bug.

        The same two normalizations ``__post_init__`` applies are re-applied, so
        a caller cannot install an inconsistent pair: no bound means no claim,
        and the provenance vocabulary is closed.
        """
        if self.status == "infeasible":
            bound = None  # #1856: an infeasibility certificate carries no bound
        self.bound = bound
        if bound is None or not np.isfinite(bound):
            self.bound_valid = False
            self.bound_source = None
            return
        if source is not None and source not in BOUND_SOURCES:
            raise ValueError(f"bound_source={source!r} is not one of {sorted(BOUND_SOURCES)}.")
        self.bound_valid = bool(valid)
        self.bound_source = source if valid else None

    def value(self, var: Variable) -> np.ndarray:
        """
        Get the optimal value of a variable.

        Parameters
        ----------
        var : Variable
            A variable from the solved model (or any handle naming one, such as
            an :class:`~discopt.modeling.indexed.IndexedVar`). Only *variables*
            have entries in the solution: an expression built from them (a sum,
            a product, an opaque :func:`~discopt.modeling.core.custom` /
            :func:`~discopt.modeling.argmin.argmin` node) is not a column of the
            model, and is refused with the reason rather than raising a bare
            ``KeyError`` on its display name (#1218).

        Returns
        -------
        numpy.ndarray
            Optimal value, with the same shape as the variable.

        Raises
        ------
        ValueError
            If no feasible solution is available.
        TypeError
            If *var* is an expression rather than a variable.
        KeyError
            If *var* names no variable of the solved model, or is a Variable of
            the solved model that a reformulation has since substituted out
            (its name may now belong to a different variable).
        """
        if self.x is None:
            raise ValueError("No solution available")
        _refuse_retired_variable(var, self._model)
        # Resolve by name: every handle that names a column of the solved model
        # -- Variable, IndexedVar, anything else carrying its name -- keeps
        # working. A Variable OF the solved model was checked by identity above,
        # so its name can no longer reach a different column (#1799 follow-up).
        # Only a lookup that WOULD have raised reaches the diagnosis below.
        name = getattr(var, "name", None)
        if isinstance(name, str) and name in self.x:
            return self.x[name]
        if not isinstance(var, Variable):
            raise TypeError(_value_not_a_variable_message(var))
        known = ", ".join(sorted(self.x)[:12]) or "(none)"
        raise KeyError(
            f"No variable named {var.name!r} in this solution -- it is not a "
            "variable of the model that was solved (a variable of a different "
            f"Model, or one dropped before the solve). Solution variables: {known}."
        )

    def explain(self, llm: bool = False, model: str | None = None) -> str:
        """Get a human-readable explanation of the solve result.

        Parameters
        ----------
        llm : bool, default False
            Use LLM for a rich, context-aware explanation. Falls back
            to a template string if litellm is unavailable.
        model : str, optional
            LLM model string (e.g. ``"anthropic/claude-sonnet-5"``).
        """
        if llm:
            try:
                return self._explain_with_llm(model)
            except Exception as exc:  # noqa: BLE001 - falls back to the template explanation
                import logging as _logging

                _logging.getLogger("discopt.llm").debug(
                    "LLM explanation unavailable, using the template: %s: %s",
                    type(exc).__name__,
                    exc,
                )
        if self._explanation:
            return self._explanation
        return (
            f"Solved to {self.status} in {self.wall_time:.1f}s. "
            f"Objective: {self.objective}, Gap: {self.gap}, "
            f"Nodes: {self.node_count}"
        )

    def _explain_with_llm(self, llm_model: str | None = None) -> str:
        """Generate LLM-powered explanation (internal)."""
        from discopt.llm.prompts import EXPLAIN_SYSTEM, get_explain_prompt
        from discopt.llm.provider import complete
        from discopt.llm.safety import validate_explanation
        from discopt.llm.serializer import serialize_model, serialize_solve_result

        model_text = ""
        if hasattr(self, "_model") and self._model is not None:
            model_text = serialize_model(self._model) + "\n\n"

        result_text = serialize_solve_result(self, getattr(self, "_model", None))
        status_prompt = get_explain_prompt(self.status)

        text = complete(
            messages=[
                {"role": "system", "content": EXPLAIN_SYSTEM},
                {
                    "role": "user",
                    "content": (f"{model_text}{result_text}\n\n{status_prompt}"),
                },
            ],
            model=llm_model,
            max_tokens=1024,
            timeout=5.0,
        )
        return validate_explanation(text)

    def _ensure_sensitivity(self) -> np.ndarray:
        """Envelope-theorem ``d(obj*)/dp`` for every parameter, computed once.

        The gate-and-compute half of :meth:`gradient`, shared with
        ``Model.solve(sensitivity=True)`` so the eager and lazy paths cannot
        disagree about what is supported or about which point the derivative
        belongs to -- it is always *this* result's ``x``.

        Returns
        -------
        numpy.ndarray
            1-D sensitivities for the model's whole flat parameter vector.
        """
        if self._model is None:
            raise ValueError(
                "No model attached to this SolveResult. "
                "gradient() requires the model reference (set by Model.solve())."
            )
        if not self._model._parameters:
            raise ValueError("Model has no parameters. Nothing to differentiate.")

        # Check all variables are continuous
        for v in self._model._variables:
            if v.var_type != VarType.CONTINUOUS:
                raise ValueError(
                    "gradient() only supports continuous models. "
                    f"Variable '{v.name}' is {v.var_type.value}."
                )
        if not self.x:
            raise ValueError(
                "This result carries no incumbent, so there is no point at which to "
                f"evaluate a sensitivity (status: {self.status!r})."
            )

        # Lazy computation: compute sensitivity from existing solution
        if self._sensitivity is None:
            from discopt._relax.differentiable import _compute_sensitivity_at_solution

            self._sensitivity = _compute_sensitivity_at_solution(self._model, self.x)
        return self._sensitivity

    def gradient(self, param: Parameter) -> Union[float, np.ndarray]:
        """
        Sensitivity of optimal objective w.r.t. a parameter.

        Uses the envelope theorem: for ``min_x f(x; p) s.t. g(x; p) <= 0``,
        the sensitivity is ``d(obj*)/dp = dL/dp |_{x*, λ*}`` where L is the
        Lagrangian and λ* are the optimal dual variables.

        Computed lazily on first call and cached for subsequent calls.

        Parameters
        ----------
        param : Parameter
            A parameter from the solved model.

        Returns
        -------
        float or numpy.ndarray
            Gradient ``d(obj*)/d(param)``, scalar for scalar parameters.

        Raises
        ------
        ValueError
            If the model has integer/binary variables, no model reference
            is attached, no parameters exist, or the result carries no
            incumbent to evaluate the sensitivity at.
        """
        sensitivity = self._ensure_sensitivity()

        # Extract the slice for this parameter
        from discopt._relax.differentiable import _get_param_slice

        start, end = _get_param_slice(param, self._model)
        grad_flat = sensitivity[start:end]
        if param.shape == () or (end - start) == 1:
            return float(grad_flat[0])
        return grad_flat.reshape(param.shape)

    def __repr__(self):
        return (
            f"SolveResult(status={self.status!r}, obj={self.objective}, "
            f"gap={self.gap}, time={self.wall_time:.1f}s, nodes={self.node_count})"
        )


# ─────────────────────────────────────────────────────────────
# Model
# ─────────────────────────────────────────────────────────────


def _require_no_shape(shape, ctor: str) -> None:
    """Reject ``shape=`` when ``over=`` is given (they are mutually exclusive)."""
    if shape not in ((), 0):
        raise ValueError(
            f"{ctor}(): 'over=' (named-set index) and 'shape=' are mutually "
            "exclusive; an indexed variable's size is determined by its set."
        )


# --- Polynomial-degree classifier for the incumbent-verification guard (#772) ---
# Pure-Python and JAX-free: distinguishes the LP/MILP/QP/MIQP "fast family" (linear
# constraints + linear-or-quadratic objective, solved via the JAX-free Rust/POUNCE
# paths) from genuinely nonlinear models. The guard's snapshot builds a JAX evaluator,
# so it must be skipped for the fast family to preserve the JAX-free cold start of
# LP/MILP/QP/MIQP solves (test_lazy_jax_linear_path). Errs toward "nonlinear" on any
# unknown node — the safe direction: the guard runs (extra coverage), never a wrong skip.
_INF_DEGREE = float("inf")


def _degree_child_nodes(e) -> tuple:
    """The sub-expressions whose polynomial degree ``e``'s degree depends on.

    Deliberately narrow: a ``**`` reads its RHS as a *constant exponent* (not a
    degree), and non-``neg`` unary / opaque nodes short-circuit to ``inf`` without
    inspecting children, so those children are not returned.
    """
    if isinstance(e, IndexExpression):
        return (e.base,)
    if isinstance(e, SumExpression):
        return (e.operand,)
    if isinstance(e, SumOverExpression):
        return tuple(e.terms)
    if isinstance(e, UnaryOp):
        return (e.operand,) if e.op == "neg" else ()
    if isinstance(e, MatMulExpression):
        return (e.left, e.right)
    if isinstance(e, BinaryOp):
        return (e.left,) if e.op == "**" else (e.left, e.right)
    return ()  # leaves (int/float/Constant/Variable) and opaque (FunctionCall/...)


def _degree_combine(e, child_degs: list[float]) -> float:
    """Degree of ``e`` from its children's degrees (aligned with
    :func:`_degree_child_nodes`). Mirrors the original per-node rules exactly."""
    if isinstance(e, (int, float, Constant)):
        return 0
    if isinstance(e, Variable):
        return 1
    if isinstance(e, IndexExpression):
        return child_degs[0]
    if isinstance(e, SumExpression):
        return child_degs[0]
    if isinstance(e, SumOverExpression):
        return max(child_degs, default=0)
    if isinstance(e, UnaryOp):
        return child_degs[0] if e.op == "neg" else _INF_DEGREE
    if isinstance(e, (FunctionCall, CustomCall)):
        return _INF_DEGREE
    if isinstance(e, MatMulExpression):
        return child_degs[0] + child_degs[1]
    if isinstance(e, BinaryOp):
        if e.op in ("+", "-"):
            return max(child_degs[0], child_degs[1])
        if e.op == "*":
            return child_degs[0] + child_degs[1]
        if e.op == "/":
            return child_degs[0] if child_degs[1] == 0 else _INF_DEGREE
        if e.op == "**":
            left = child_degs[0]
            k = (
                e.right.value
                if isinstance(e.right, Constant)
                else (e.right if isinstance(e.right, (int, float)) else None)
            )
            try:
                return (
                    left * int(k)
                    if (k is not None and float(k).is_integer() and k >= 0)
                    else _INF_DEGREE
                )
            except (TypeError, ValueError):
                return _INF_DEGREE
        return _INF_DEGREE
    return _INF_DEGREE  # unknown node -> treat as nonlinear (guard runs; safe direction)


def _expression_degree(root) -> float:
    """Polynomial degree of ``root`` in the decision variables; ``inf`` for anything
    that is not a polynomial (transcendental, variable power, variable denominator,
    opaque).

    Iterative post-order over the expression DAG with memoization by node identity,
    so a deeply nested expression (e.g. a long left-associated sum) never overflows
    the Python recursion stack, and shared sub-expressions are walked once (#810).
    """
    memo: dict[int, float] = {}
    stack = [root]
    while stack:
        e = stack[-1]
        if id(e) in memo:
            stack.pop()
            continue
        kids = _degree_child_nodes(e)
        pending = [c for c in kids if id(c) not in memo]
        if pending:
            stack.extend(pending)  # compute children first (no recursion)
            continue
        memo[id(e)] = _degree_combine(e, [memo[id(c)] for c in kids])
        stack.pop()
    return memo[id(root)]


def _is_fast_linear_quadratic_family(model) -> bool:
    """True for LP/MILP/QP/MIQP: linear constraints and a linear-or-quadratic objective
    (the JAX-free solve families). Used to skip the JAX-importing incumbent-verification
    snapshot on those paths so their cold start stays JAX-free."""
    obj = model._objective.expression if model._objective is not None else None
    if obj is not None and _expression_degree(obj) > 2:
        return False
    for c in model._constraints:
        body = getattr(c, "body", None)
        if body is not None and _expression_degree(body) > 1:
            return False
    return True


# Solve caches that ``Model.__init__`` itself declares. ``Model.__deepcopy__`` resets
# these to ``None`` on the copy and omits every other ``*_cache`` attribute (#1479).
_MODEL_INIT_CACHES = frozenset({"_flat_var_offsets_cache"})

#: Solve-time caches whose names do not end in ``_cache``, so the suffix test the
#: copy and pickle paths use would miss them. ``_uniform_relax_analysis`` is the
#: per-model relaxation analysis (``discopt._relax.uniform_relax``): keyed by
#: ``id()`` of the original's DAG nodes, holding locally defined compiled closures
#: that cannot be pickled, and cleared at the start of every solve anyway.
_MODEL_UNNAMED_CACHES = frozenset({"_uniform_relax_analysis"})


class _PreworkClock(_threading.local):
    seconds: float = 0.0


_PREWORK = _PreworkClock()


def last_solve_prework_seconds() -> float:
    """Wall ``Model.solve`` spent on this thread before handing over to
    ``solve_model`` -- the amount deducted from ``time_limit`` (the convex-kernel
    attempt, :func:`discopt.solvers._convex_kernel.last_attempt_seconds`, is part
    of it). Read it after a solve to compute exactly what the default path was
    given; 0.0 on a thread that has not solved."""
    return _PREWORK.seconds


def _is_model_cache(key: str) -> bool:
    return key.endswith("_cache") or key in _MODEL_UNNAMED_CACHES


class _DetachedNlRepr:
    """Stands in for a ``from_nl`` model's ``_nl_repr`` once the model has left the
    process that parsed it -- by ``pickle`` or by a :mod:`discopt.serialize` document.

    The Rust ``PyModelRepr`` cannot be pickled or written, so neither route can
    carry it. Dropping the attribute outright would not be neutral: its *presence*
    is what tells :meth:`Model._referenced_variable_names` to answer "could not
    tell", and a copy that started walking its expressions instead would make that
    guard fire less, not more. This marker keeps the attribute non-``None`` so the
    guard behaves exactly as on the original, and refuses any other use loudly
    rather than handing back something that is not the parse.
    """

    __slots__ = ()

    def __getattr__(self, name: str):
        raise AttributeError(
            f"_nl_repr.{name}: this model was unpickled or loaded from a saved document, "
            "and the parsed .nl representation (a Rust PyModelRepr) does not survive "
            "either. Re-read the source with discopt.from_nl() if the parse itself is "
            "needed."
        )

    def __repr__(self) -> str:
        return "<_nl_repr detached from its .nl parse>"

    def __reduce__(self):
        return (_DetachedNlRepr, ())


#: Model-level *validation guards*: lists of assumptions a construction-time
#: rewrite relied on, re-checked by :meth:`Model.validate` before every solve
#: because variable bounds are mutable afterwards. ``_atan2_preconditions`` holds
#: the sign an ``atan2`` rewrite assumed; ``_piecewise_domains`` the breakpoint
#: span a ``piecewise`` lowering clamps its input to, and the enclosure each
#: ``gdp.partition_disjuncts`` auxiliary was bounded by (#1775 G2.8). Each record references the
#: model's own ``Variable`` objects. A pass that rebuilds a model into a fresh
#: ``Model`` must forward them with :func:`carry_validation_guards` -- the rows the
#: guard protects are forwarded with it, so dropping the guard turns a later bound
#: widening from a refusal into a silent clamp (#1498).
VALIDATION_GUARD_ATTRS: tuple[str, ...] = (
    "_atan2_preconditions",
    "_piecewise_domains",
    # The sign a robust counterpart read a worst-case direction from
    # (``discopt.ro.formulations._common.SIGN_GUARD_ATTR``); set only when present.
    "_ro_sign_preconditions",
)


def carry_validation_guards(src: "Model", dst: "Model") -> None:
    """Forward ``src``'s validation guards onto ``dst``, a model rebuilt from it.

    The same record objects are appended (identity-deduplicated), so carrying
    twice, or through any number of passes, is idempotent and
    :func:`missing_validation_guards` can check by identity.
    """
    for attr in VALIDATION_GUARD_ATTRS:
        records = getattr(src, attr, None) or []
        if not records:
            continue
        held = getattr(dst, attr, None)
        if held is None:
            held = []
            setattr(dst, attr, held)
        seen = {id(r) for r in held}
        for r in records:
            if id(r) not in seen:
                held.append(r)
                seen.add(id(r))


def _builder_objective_expression(c, x: "Variable", constant: float, Q=None) -> "Expression":
    """The expression of a builder objective ``0.5 xᵀSx + cᵀx + constant``.

    The builder's own convention: ``S = triu(Q) + triu(Q, 1)ᵀ`` (only the upper
    triangle of ``Q`` is read), as gathered elementwise products, so the size is
    ``O(nnz)`` and never a chain of scalar terms. ``add_quadratic_objective``
    stores a symmetric ``Q`` (#1818), for which ``S == Q``.

    ``add_linear_objective`` / ``add_quadratic_objective`` store this on
    ``_objective`` with ``_is_placeholder`` set. The flag tells the Rust repr to take
    the builder's own objective (``model_to_repr`` ignores the expression then); the
    expression is for every Python reader. It used to be a zero ``Constant``, and
    each of the 60-odd readers of ``_objective.expression`` -- OA and LOA masters,
    interval bounds, convexity, relaxations -- then saw the objective ``0``: OA
    certified nothing (bound 0) and the simplex GDP lowering lost its certificate
    (#1609, #1798, #1802). Fixing the readers one at a time left the rest wrong.
    """
    # Forms the scalar-term readers already understand: the linear part is
    # ``dm.sum(C * x)`` (:func:`affine_array_sum`), the quadratic part
    # ``dm.sum(V * x[R] * x[C])`` (:func:`quadratic_array_sum`); a scalar ``x`` is
    # written out. Built from the node classes so the shape is exactly that.
    c = np.asarray(c, dtype=np.float64).ravel()
    expr: Expression = Constant(np.float64(constant))
    if np.any(c != 0.0):
        if x.size >= 2:
            expr = expr + SumExpression(BinaryOp("*", _wrap(c.reshape(x.shape)), x), axis=None)
        else:
            expr = expr + float(c[0]) * (x if x.shape == () else x[(0,) * len(x.shape)])
    if Q is not None:
        import scipy.sparse as sp

        S = (sp.triu(Q, 0) + sp.triu(Q, 1).T).tocoo()
        keep = S.data != 0.0
        if np.any(keep):
            rows = S.row[keep].astype(np.int64)
            cols = S.col[keep].astype(np.int64)
            vals = 0.5 * S.data[keep]
            if x.size < 2:
                xs = x if x.shape == () else x[(0,) * len(x.shape)]
                expr = expr + float(vals.sum()) * (xs * xs)
            else:

                def gather(flat_idx: np.ndarray) -> Expression:
                    return IndexExpression(x, np.unravel_index(flat_idx, x.shape))

                term = BinaryOp("*", BinaryOp("*", _wrap(vals), gather(rows)), gather(cols))
                expr = expr + SumExpression(term, axis=None)
    return expr


def carry_builder_objective(src: "Model", dst: "Model") -> None:
    """Re-issue ``src``'s fast-API objective on ``dst``, a model rebuilt from it.

    ``add_linear_objective`` / ``add_quadratic_objective`` keep the real objective in
    ``src``'s Rust builder and flag ``_objective`` as a placeholder; a pass that
    copied ``_objective`` used to carry a zero objective (#1794 B2, #1798), and since
    #1802 it carries the real expression but no builder. This repeats the
    builder call on ``dst`` when ``src``'s objective is that placeholder (an
    ``_objective_expression()`` rebuild is a gathered-index expression the Rust repr
    refuses, which turns FBBT/presolve off). No-op otherwise.

    Call it **after** every variable ``dst`` will hold exists: the call creates
    ``dst``'s builder, which registers the variables present then, and a column
    added later is unknown to it ("Variable not found in model" from the Rust repr).

    The fast-API *rows* are carried separately, as ordinary constraints, with
    ``src._builder_linear_constraints()``.

    Also a no-op when ``dst._objective`` is not ``src``'s placeholder: the pass
    rewrote the objective, and the rewrite (an ordinary :class:`Objective` -- see
    :func:`rewritten_objective`) is what ``dst`` minimizes.
    """
    if src._objective is None or not getattr(src._objective, "_is_placeholder", False):
        return
    if dst._objective is not src._objective:
        return
    lin_blk = src._builder_linear_objective
    quad_blk = src._builder_quadratic_objective
    if lin_blk is not None:
        c, x, constant, sense = lin_blk
        dst.add_linear_objective(c, x, constant=constant, sense=sense)
    elif quad_blk is not None:
        Q, c, x, constant, sense = quad_blk
        dst.add_quadratic_objective(Q, c, x, constant=constant, sense=sense)
    else:
        raise ValueError(
            "objective is a builder placeholder but the model retains no builder "
            "objective block to carry into the rebuilt model"
        )


def rewritten_objective(obj: "Objective", expression: Expression) -> "Objective":
    """A copy of ``obj`` minimizing ``expression``, for a pass that rewrote it.

    The copy is an ordinary objective even when ``obj`` is a fast-API placeholder:
    ``_objective_expression()`` of a placeholder reads the builder block, which
    would discard the rewrite (and a rebuilt model holds no block to read).
    """
    out = _copy.copy(obj)
    out.expression = expression
    out._is_placeholder = False
    return out


def missing_validation_guards(src: "Model", dst: "Model") -> list[str]:
    """``attr: label`` of every guard of ``src`` that ``dst`` does not hold.

    Compared by record identity, which is what :func:`carry_validation_guards`
    preserves (and what a guard's expression -- whose ``==`` builds a constraint
    -- forces).
    """
    missing = []
    for attr in VALIDATION_GUARD_ATTRS:
        held = {id(r) for r in (getattr(dst, attr, None) or [])}
        for r in getattr(src, attr, None) or []:
            if id(r) not in held:
                missing.append(f"{attr}: {r[-1]}")
    return missing


_FALSE_PRIMAL_ERROR = (
    "the incumbent the solver returned is infeasible in the original "
    "model (false-primal guard, #772); it was withheld"
)


def _withhold_false_primal(result: "SolveResult", error: str = _FALSE_PRIMAL_ERROR) -> None:
    """The #772 false-primal response: withhold an incumbent the original model rejects.

    Shared by ``Model.solve``'s final-incumbent guard and the #1537 C recentring
    path, which re-verifies a point mapped back from the recentred model, so the
    two cannot drift.
    """
    result.incumbent_verification_failed = True
    result.gap_certified = False
    result.x = None
    result.objective = None
    result.gap = None
    # The status must stop asserting what the guard just withdrew. Clearing
    # ``x``/``objective`` while leaving ``status="optimal"`` reports a PROVEN
    # OPTIMUM WITH NO SOLUTION -- a caller that keys on the status (every gate and
    # panel in this repo does) reads a certificate that the guard has already
    # refused to stand behind. Observed under
    # ``DISCOPT_PRESOLVE_BOUND_PROPAGATION=1`` on nvs05: ``status='optimal'``,
    # ``objective=None``, 3/3 reps. This is not a limit termination -- an unsound
    # result was detected -- so it reports as an error and refuses loudly
    # (CLAUDE.md §1/§3). ``bound`` is untouched: only the PRIMAL was shown to be
    # invalid, and the dual bound remains rigorous.
    result.status = "error"
    result.error = error


#: How many ``Model.solve`` calls are on the stack (#1537 C). A ContextVar, not a
#: thread-local: ``_run_with_deep_recursion`` runs deep solves on a worker thread
#: inside ``contextvars.copy_context()``, which carries this but not a
#: ``threading.local``, so a sub-solve there still reads as nested.
_SOLVE_DEPTH: _contextvars.ContextVar[int] = _contextvars.ContextVar(
    "discopt_model_solve_depth", default=0
)


def _counts_solve_depth(fn):
    """Track ``Model.solve`` nesting so a pass meant for the caller's own model
    (recentring) can tell the user's top-level call from the solver's sub-solves."""

    @_functools.wraps(fn)
    def wrapper(self, *args, **kwargs):
        token = _SOLVE_DEPTH.set(_SOLVE_DEPTH.get() + 1)
        try:
            return fn(self, *args, **kwargs)
        finally:
            _SOLVE_DEPTH.reset(token)

    return wrapper


#: ``id()`` of every model a solve on the stack has already taken ownership of
#: (#1610). A ContextVar for the same reason as :data:`_SOLVE_DEPTH`.
_SOLVE_OWNED_MODELS: _contextvars.ContextVar[frozenset[int]] = _contextvars.ContextVar(
    "discopt_solve_owned_models", default=frozenset()
)
#: The box each owned model's caller declared, flat ``(lb, ub)``, recorded at the
#: owner's entry (before any solve-time tightening writes the model). Read by
#: :func:`solve_entry_box`.
_SOLVE_ENTRY_BOXES: _contextvars.ContextVar[dict] = _contextvars.ContextVar(
    "discopt_solve_entry_boxes", default={}
)


def solve_entry_box(model: "Model") -> Optional[tuple[np.ndarray, np.ndarray]]:
    """The flat ``(lb, ub)`` box ``model`` carried when the current solve began, or
    ``None`` outside a solve.

    The solve tightens the model's variable bounds in place (FBBT, nonlinear
    tightening, ...) and :func:`_solve_owns_model` restores them on exit, so during
    the solve ``Variable.lb``/``ub`` are the WORKING box. Anything that must speak
    about the model the user declared -- the duals it reports, judged against the
    declared bounds by the examiner -- reads this instead.
    """
    return _SOLVE_ENTRY_BOXES.get().get(id(model))


@_contextlib.contextmanager
def _solve_owns_model(model: "Model") -> "Iterator[bool]":
    """Lend ``model`` to the solver for one solve; hand it back unchanged (#1610).

    The solve path uses the caller's ``Model`` as its working copy. Root FBBT
    writes the box it tightened into ``v.lb``/``v.ub``
    (``_apply_flat_bounds_to_model`` before the factorable lift, the node and
    root reduction passes, ...), ``DISCOPT_COEF_TIGHTEN`` replaces big-M rows in
    ``model._constraints``, and the structure-cut presolve appends auxiliary
    columns and rows. Each write is valid *for that solve* and wrong after it: a
    tightening derived from ``x <= p`` at ``p = 8`` survived as a declared
    ``x.ub == 8``, so the re-solve at ``p = 10`` returned ``x = 8`` labelled
    ``optimal``.

    Fixing the write sites one at a time would not fix the class -- there are
    dozens, and the next pass to write the model would bring the defect back.
    This is the one boundary every solve crosses. On entry it records the
    caller's variables and their boxes (fix stack included, via
    :meth:`Model.saved_bounds`), the constraint list, the objective, the name set
    and the builder-resident rows; on exit -- exceptions included -- it puts
    every one of them back. Inside, the solve uses the model exactly as before,
    so the solve itself is bound-neutral by construction.

    Re-entrant per model: a nested ``Model.solve``/``solve_model`` on a model an
    outer solve already holds is part of that solve and must keep seeing its
    working state, so only the outermost entry snapshots and restores. Yields
    whether this entry is the owner.
    """
    owned = _SOLVE_OWNED_MODELS.get()
    if id(model) in owned:
        yield False
        return
    token = _SOLVE_OWNED_MODELS.set(owned | {id(model)})
    vars_entry = list(model._variables)
    _lbs = [np.asarray(v.lb, dtype=np.float64).ravel() for v in vars_entry]
    _ubs = [np.asarray(v.ub, dtype=np.float64).ravel() for v in vars_entry]
    box_token = _SOLVE_ENTRY_BOXES.set(
        {
            **_SOLVE_ENTRY_BOXES.get(),
            id(model): (
                np.concatenate(_lbs) if _lbs else np.zeros(0),
                np.concatenate(_ubs) if _ubs else np.zeros(0),
            ),
        }
    )
    cons_entry = list(model._constraints)
    objective_entry = model._objective
    names_entry = set(model._names)
    blocks_entry = list(model._builder_linear_blocks)
    try:
        with model.saved_bounds(vars_entry):
            yield True
    finally:
        try:
            grew = len(model._variables) != len(vars_entry) or any(
                a is not b for a, b in zip(model._variables, vars_entry)
            )
            # In place, not rebound: a caller may hold the list object itself.
            model._variables[:] = vars_entry
            model._constraints[:] = cons_entry
            model._objective = objective_entry
            model._names.clear()
            model._names.update(names_entry)
            blocks_changed = len(model._builder_linear_blocks) != len(blocks_entry) or any(
                a is not b for a, b in zip(model._builder_linear_blocks, blocks_entry)
            )
            if blocks_changed:
                model._builder_linear_blocks[:] = blocks_entry
            if model._builder is not None and (grew or blocks_changed):
                # The Rust builder cannot drop a column or a row; rebuild it from
                # the restored Python-side records (the path ``clone`` uses).
                model._replay_builder()
        finally:
            _SOLVE_ENTRY_BOXES.reset(box_token)
            _SOLVE_OWNED_MODELS.reset(token)


def _solve_leaves_model_unchanged(fn):
    """Run ``fn(model, ...)`` under :func:`_solve_owns_model` (#1610).

    The result's ``_problem_fingerprint`` -- what ``Model.sensitivity()`` checks
    a stored solution against -- is stamped inside the solve, on the working
    state. Once the caller's model is restored the result is about *that*
    problem, so the owner re-stamps it there.
    """

    @_functools.wraps(fn)
    def wrapper(model, *args, **kwargs):
        with _solve_owns_model(model) as owner:
            result = fn(model, *args, **kwargs)
        if owner and getattr(result, "_problem_fingerprint", None) is not None:
            from discopt._evaluator_cache import solution_state_fingerprint

            setattr(result, "_problem_fingerprint", solution_state_fingerprint(model))
        if owner:
            _attach_block_duals(model, result)
        return result

    return wrapper


def _attach_block_duals(model: "Model", result: "SolveResult") -> None:
    """Key the duals of each named ``add_linear_constraints`` block by its name (#1680).

    The routes name a builder row ``f"{name}_{r}"`` (the row names every exporter
    and the evaluator share), so a block's duals came back as ``demand_0``,
    ``demand_1``, ... and a caller had to reassemble them positionally. This adds
    ``constraint_duals[name]`` -- shape ``(m,)``, row ``r`` of the block's ``A``
    at position ``r`` -- alongside the per-row keys, which stay for backward
    compatibility.

    Fail-closed, like the per-row matcher it reads from: a block gets the entry
    only when EVERY one of its rows has a dual, its name is used by no other
    block, and the name is not already a key (a Python constraint of the same
    name keeps its own dual). Values are copied, never recomputed.
    """
    cd = getattr(result, "constraint_duals", None)
    blocks = getattr(model, "_builder_linear_blocks", None)
    if not cd or not blocks:
        return
    counts: dict[str, int] = {}
    for blk in blocks:
        if blk[4]:
            counts[blk[4]] = counts.get(blk[4], 0) + 1
    for A, _x, _sense, _b, name in blocks:
        if not name or counts[name] != 1 or name in cd:
            continue
        keys = [f"{name}_{r}" for r in range(int(A.shape[0]))]
        if not keys or any(k not in cd or np.size(cd[k]) != 1 for k in keys):
            continue
        cd[name] = np.array([float(np.asarray(cd[k]).reshape(())) for k in keys], dtype=float)


def _post_solve_abs_gap_tol(result: "SolveResult", abs_gap_tolerance: Optional[float]) -> float:
    """The absolute gap tolerance a post-solve gap recomputation reports at (#1585).

    The one the certificate was judged at when the solver wrapper recorded it
    (``SolveResult._judged_gap_tolerances``), else the caller's.
    """
    judged = getattr(result, "_judged_gap_tolerances", None)
    if judged is not None:
        return float(judged[1])
    from discopt.solver import _resolve_abs_gap_tolerance

    return float(_resolve_abs_gap_tolerance(abs_gap_tolerance))


def _affine_scalar_terms(expr) -> Optional[tuple[dict, float]]:
    """``({Variable: coef}, const)`` for an affine expression over SCALAR variables,
    else ``None``. Used only to restrict an ``if_else`` branch's enclosure box."""
    if isinstance(expr, Constant):
        v = np.asarray(expr.value)
        return ({}, float(v.reshape(()))) if v.size == 1 else None
    if isinstance(expr, Variable):
        return ({expr: 1.0}, 0.0) if expr.size == 1 and expr.shape in ((), (1,)) else None
    if isinstance(expr, UnaryOp) and expr.op == "neg":
        r = _affine_scalar_terms(expr.operand)
        return None if r is None else ({k: -a for k, a in r[0].items()}, -r[1])
    if isinstance(expr, BinaryOp):
        if expr.op in ("+", "-"):
            left, right = _affine_scalar_terms(expr.left), _affine_scalar_terms(expr.right)
            if left is None or right is None:
                return None
            sgn = 1.0 if expr.op == "+" else -1.0
            coef = dict(left[0])
            for k, a in right[0].items():
                coef[k] = coef.get(k, 0.0) + sgn * a
            return coef, left[1] + sgn * right[1]
        if expr.op in ("*", "/"):
            left, right = _affine_scalar_terms(expr.left), _affine_scalar_terms(expr.right)
            if left is None or right is None:
                return None
            if expr.op == "/":
                if right[0] or right[1] == 0.0:
                    return None
                return {k: a / right[1] for k, a in left[0].items()}, left[1] / right[1]
            if not left[0]:
                return {k: left[1] * a for k, a in right[0].items()}, left[1] * right[1]
            if not right[0]:
                return {k: right[1] * a for k, a in left[0].items()}, right[1] * left[1]
    return None


def _scalar_binary_leaf_key(expr) -> Optional[tuple[int, int]]:
    """``(id(variable), flat_column)`` when ``expr`` is ONE binary column -- a scalar
    binary :class:`Variable` or a scalar-valued index into one -- else ``None``."""
    if isinstance(expr, Variable):
        if expr.var_type is VarType.BINARY and int(expr.size) == 1:
            return (id(expr), 0)
        return None
    if isinstance(expr, IndexExpression) and isinstance(expr.base, Variable):
        base = expr.base
        if base.var_type is not VarType.BINARY:
            return None
        try:
            cols = np.arange(int(base.size)).reshape(tuple(base.shape) or ())[expr.index]
        except (IndexError, TypeError, ValueError):
            return None
        cols = np.asarray(cols)
        return (id(base), int(cols.reshape(()))) if cols.size == 1 else None
    return None


def _affine_binary_terms(expr) -> Optional[tuple[dict, float]]:
    """``({key: (leaf, coef)}, const)`` for an expression affine in single binary
    columns (see :func:`_scalar_binary_leaf_key`), else ``None``."""
    if isinstance(expr, Constant):
        v = np.asarray(expr.value)
        return ({}, float(v.reshape(()))) if v.size == 1 else None
    key = _scalar_binary_leaf_key(expr)
    if key is not None:
        return ({key: (expr, 1.0)}, 0.0)
    if isinstance(expr, UnaryOp) and expr.op == "neg":
        r = _affine_binary_terms(expr.operand)
        return None if r is None else ({k: (e, -a) for k, (e, a) in r[0].items()}, -r[1])
    if isinstance(expr, BinaryOp) and expr.op in ("+", "-", "*", "/"):
        left, right = _affine_binary_terms(expr.left), _affine_binary_terms(expr.right)
        if left is None or right is None:
            return None
        if expr.op in ("+", "-"):
            sgn = 1.0 if expr.op == "+" else -1.0
            terms = dict(left[0])
            for k, (e, a) in right[0].items():
                e0, a0 = terms.get(k, (e, 0.0))
                terms[k] = (e0, a0 + sgn * a)
            return terms, left[1] + sgn * right[1]
        if expr.op == "/":
            if right[0] or right[1] == 0.0:
                return None
            return {k: (e, a / right[1]) for k, (e, a) in left[0].items()}, left[1] / right[1]
        if not left[0]:
            return {k: (e, left[1] * a) for k, (e, a) in right[0].items()}, left[1] * right[1]
        if not right[0]:
            return {k: (e, right[1] * a) for k, (e, a) in left[0].items()}, right[1] * left[1]
    return None


def _require_binary_indicator(indicator, where: str) -> None:
    """Refuse an indicator column that is not one binary column (#1844).

    An integer ``z in [0, 3]`` or a continuous ``z in [0, 1]`` has no single
    meaning as "the rows hold when z == 1": the big-M lowering scales the slack by
    ``1 - z`` (over-enforcing the rows for ``z >= 2``) while binary multiplication
    multiplies the body by ``z`` (active for any ``z > 0``), so the optimum
    depended on ``gdp_method``. Checked at ``if_then`` and again by
    ``Model.validate`` (a variable's type can change after the call, and a
    deserialized model never passes through ``if_then``).
    """
    if _scalar_binary_leaf_key(indicator) is not None:
        return
    base = indicator.base if isinstance(indicator, IndexExpression) else indicator
    vtype = getattr(base, "var_type", None)
    what = (
        "a binary variable but not a single column"
        if vtype is VarType.BINARY
        else f"{vtype.name.lower() if vtype is not None else type(base).__name__}"
    )
    raise TypeError(
        f"{where}: the indicator {indicator!r} must be a single binary variable "
        f"(or a BooleanVar), but it is {what}. A non-binary selector has no single "
        "'active' value: the big-M and binary-multiplication lowerings would give "
        "different optima (#1844). Use a binary variable (m.binary(...)) and, if "
        "needed, link it to the integer one."
    )


def _normalize_indicator(indicator, where: str):
    """``(column, active_value)`` for an ``if_then`` indicator (#1677).

    A plain variable / indexed variable passes through with ``active_value=1``
    when it is ONE binary column; an integer or continuous selector, or a vector
    of columns, is refused here (#1844: nothing downstream refused it, and the
    lowerings then disagreed -- big-M over-enforced the rows for ``z >= 2``,
    binary multiplication treated every ``z > 0`` as active). A ``BooleanVar``
    is its backing binary; ``~b`` is that binary with ``active_value=0``. A
    compound expression is accepted only when it is an affine function of ONE
    binary column taking exactly the values {0, 1}: ``z`` itself
    (``active_value=1``) or its complement ``1 - z`` (``active_value=0``).
    Normalising here means every consumer -- the big-M / hull GDP lowering, the
    certificate verifier, serialization, the MPEC residuals -- sees a single 0/1
    column plus the value that activates the rows, which they all already handle.
    Anything else has no 0/1 column to act as the indicator and is refused now
    rather than with a ``TypeError`` deep inside ``solve()``.
    """
    if isinstance(indicator, BooleanVar):
        return indicator.variable, 1
    if isinstance(indicator, LogicalNot) and isinstance(indicator.operand, BooleanVar):
        return indicator.operand.variable, 0
    if isinstance(indicator, LogicalExpression):
        raise TypeError(
            f"{where}: the indicator must be a binary variable or a BooleanVar, not "
            f"the logical expression {indicator!r}; state it with "
            "m.logical(expr.implies(...)) or introduce a BooleanVar for it."
        )
    if not isinstance(indicator, Expression):
        raise TypeError(
            f"{where}: the indicator must be a binary variable or a BooleanVar, got "
            f"{type(indicator).__name__}."
        )
    if isinstance(indicator, (Variable, IndexExpression)):
        _require_binary_indicator(indicator, where)
        return indicator, 1
    aff = _affine_binary_terms(indicator)
    if aff is not None:
        terms = {k: ea for k, ea in aff[0].items() if ea[1] != 0.0}
        if len(terms) == 1:
            ((leaf, coef),) = terms.values()
            const = aff[1]
            if const == 0.0 and coef == 1.0:
                return leaf, 1
            if const == 1.0 and coef == -1.0:
                return leaf, 0
    raise TypeError(
        f"{where}: the indicator expression {indicator!r} is not a 0/1 indicator. "
        "Use a binary variable z (active when z == 1) or its complement 1 - z "
        "(active when z == 0); any other expression has no single binary column "
        "taking exactly the values {0, 1}."
    )


def _condition_box(cond) -> Optional[dict]:
    """The declared box of the variables in ``cond`` (``body <= 0``) tightened by one
    bound-propagation step on that row, as ``{Variable: Interval}``; ``None`` when the
    condition is absent, not affine over scalar variables, or tightens nothing.

    Sound: every point of the declared box satisfying ``cond`` lies in the returned
    box. An empty result (the condition cannot hold) is also ``None``.
    """
    if cond is None or getattr(cond, "sense", None) != "<=":
        return None
    aff = _affine_scalar_terms(cond.body - cond.rhs if cond.rhs else cond.body)
    if aff is None or not aff[0]:
        return None
    from discopt._relax.convexity.interval import Interval

    coef, const = aff
    lo = {v: float(np.asarray(v.lb).reshape(())) for v in coef}
    hi = {v: float(np.asarray(v.ub).reshape(())) for v in coef}
    mins = {v: min(a * lo[v], a * hi[v]) for v, a in coef.items()}
    if not all(np.isfinite(m_) for m_ in mins.values()):
        return None
    # ``np.sum``, not ``sum``: this module's ``sum`` is the modeling ``dm.sum``.
    total_min = const + float(np.sum(list(mins.values())))
    box: dict = {}
    for v, a in coef.items():
        if a == 0.0:
            continue
        # a*v <= -(const + sum_{j != v} min(a_j v_j))
        rest = total_min - mins[v]
        lim = -rest / a
        nlo, nhi = lo[v], hi[v]
        if a > 0.0:
            nhi = min(nhi, lim)
        else:
            nlo = max(nlo, lim)
        if nlo > nhi:
            return None
        if (nlo, nhi) != (lo[v], hi[v]):
            box[v] = Interval(nlo, nhi)
    return box or None


class _IfElseAux:
    """The derivation of one :meth:`Model.if_else` auxiliary's box.

    ``last`` is the box last derived (``None`` for one recovered from a file,
    whose derivation is unknown). Plain attributes so ``copy.deepcopy`` and
    ``pickle`` carry it with the model's own memo.
    """

    __slots__ = ("w", "then_expr", "else_expr", "cond", "complement", "last")

    def __init__(self, w, then_expr, else_expr, cond, complement, last):
        self.w = w
        self.then_expr = then_expr
        self.else_expr = else_expr
        self.cond = cond
        self.complement = complement
        self.last = last

    def __getstate__(self):
        return {k: getattr(self, k) for k in self.__slots__}

    def __setstate__(self, state):
        for k, v in state.items():
            setattr(self, k, v)


_IF_ELSE_DISJ_NAME = re.compile(r"^_(.+)_(\d+)_disj$")


def _recover_if_else_auxes(model: "Model") -> int:
    """Re-register the :meth:`Model.if_else` disjunctions of a model read from a file.

    The document stores the hull disjunction ``[cond, w == a] v [-cond, w == b]``
    and ``w``'s bounds, not that ``w``'s bounds were derived from ``a`` and ``b``.
    The disjunction is recognised by exactly the shape and names ``if_else``
    emits; each match is registered with ``last=None``, so
    :meth:`Model._refresh_if_else_bounds` refuses a box widened after loading
    rather than solving on bounds that no longer enclose the branches.
    """
    found = 0
    for c in model._constraints:
        if not isinstance(c, _DisjunctiveConstraint) or c.method != "hull":
            continue
        mt = _IF_ELSE_DISJ_NAME.match(c.name or "")
        if mt is None or len(c.disjuncts) != 2 or any(len(d) != 2 for d in c.disjuncts):
            continue
        ws, exprs = [], []
        for d in c.disjuncts:
            eq = d[1]
            body = eq.body
            if not (
                isinstance(eq, Constraint)
                and eq.sense == "=="
                and isinstance(body, BinaryOp)
                and body.op == "-"
                and isinstance(body.left, Variable)
            ):
                break
            ws.append(body.left)
            exprs.append(body.right)
        else:
            w = ws[0]
            if ws[1] is w and w.size == 1 and w.name == f"_{mt.group(1)}_{mt.group(2)}":
                model._if_else_auxes.append(
                    _IfElseAux(w, exprs[0], exprs[1], c.disjuncts[0][0], c.disjuncts[1][0], None)
                )
                found += 1
    return found


class Model:
    """
    A Mixed-Integer Nonlinear Program.

    The central object for formulating and solving optimization problems.
    Build a model by declaring variables, setting an objective, adding
    constraints, and calling :meth:`solve`.

    Parameters
    ----------
    name : str, default "model"
        Descriptive name for the model.

    Examples
    --------
    >>> import discopt.modeling as dm
    >>> m = dm.Model("my_problem")
    >>> x = m.continuous("x", shape=(3,), lb=0, ub=10)
    >>> y = m.binary("y", shape=(2,))
    >>> m.minimize(cost @ x + fixed_cost @ y)
    >>> m.subject_to(A @ x <= b, name="capacity")
    >>> result = m.solve()
    >>> result.value(x)
    """

    def __init__(self, name: str = "model"):
        self.name = name
        self._variables: list[Variable] = []
        # Cached exclusive prefix-sum of variable sizes (flat start offsets); see
        # ``_flat_var_offset``. ``None`` until first requested / after growth.
        self._flat_var_offsets_cache: Optional[list[int]] = None
        self._parameters: list[Parameter] = []
        # Sign assumptions the `atan2` rewrites in this model were built on, as
        # ``(denominator_expr, "positive"|"negative", label)``. `dm.atan2` reads
        # bounds at construction, but bounds are mutable afterwards, so
        # `validate()` re-checks these before every solve -- see
        # `discopt.modeling._atan2.check_preconditions` for the measured failure
        # this prevents. Empty for the overwhelming majority of models, and the
        # check costs one interval walk per entry, not a walk of the model.
        self._atan2_preconditions: list[tuple[Expression, str, str]] = []
        # The input domain every `piecewise` call relied on, as
        # ``(input_expr, span_lo, span_hi, label)``. The lowered rows force the
        # input into the breakpoint span, so a bound widened past it after
        # declaration would silently clamp the model; `validate()` re-checks
        # (see `discopt.modeling._piecewise.check_domains`, issue #1482).
        self._piecewise_domains: list[tuple[Expression, float, float, str]] = []
        # Persistent set of declared variable/parameter names for O(1)
        # uniqueness checks (M7). Rebuilding ``{v.name ...} | {p.name ...}`` on
        # every declaration made model construction O(n²); this set is updated
        # incrementally at each registration site instead. Must stay in sync
        # with ``_variables``/``_parameters`` — every append to those lists that
        # introduces a name also adds it here.
        self._names: set[str] = set()
        self._constraints: list[Constraint] = []
        # #840: linear families emitted through the fast paths — ``constraint(fast=True)``
        # (via ``_try_fast_linear_family``) and the direct ``add_linear_constraints``
        # matrix API — are NOT appended to ``_constraints``: they are emitted as sparse
        # rows into the Rust builder and recorded on ``_builder_linear_blocks`` (adding
        # them to ``_constraints`` too would double-count them in the native solve). The
        # NLPEvaluator, ``_check_constraint_feasibility``, and the #772 incumbent guard
        # build their view of the model from Constraint objects, so they would be BLIND
        # to these rows (evaluate_constraints -> [], the guard accepts any point — the
        # #840 false-primal hole). To close that hole for BOTH fast paths with a single
        # source of truth, those consumers materialize the builder rows on demand via
        # ``_builder_linear_constraints()``; the builder blocks stay the sole store, so
        # there is no separate mirror to fall out of sync or double-count.
        self._objective: Optional[Objective] = None
        # R4: names of lifted product-factor auxes whose interval spans 0, set by
        # the factorable reform under ``DISCOPT_LIFT_ZERO_SPANNING_FACTORS`` so the
        # solver keeps them as spatial-branching candidates (see
        # ``factorable_reform._lift_zero_spanning_factors_enabled``). Empty by
        # default, so it never changes behaviour with the flag off.
        self._zero_spanning_factor_auxes: set[str] = set()
        # Names of lifted auxes typed INTEGER only because their defining equality
        # ``w == a*x + b`` (integral a, b over integer x) makes them integral: their
        # value is implied by other integer columns, so a primal heuristic must not
        # round, fix or move them independently (#1588 review, nvs22). Set by the
        # factorable reform; empty by default.
        self._implied_integer_auxes: set[str] = set()
        self._builder = None  # Optional PyModelBuilder, lazy-initialized
        # Starting point for the model's variables, keyed ``(var name, element)``
        # -> value (#1225). A *partial* map: only elements someone actually gave
        # a value for appear, so an absent key means "no guess" rather than
        # "guess 0.0". Populated by ``from_nl`` from a ``.nl`` file's ``x``
        # segment and by ``set_initial_point``; read back by ``to_nl`` when no
        # explicit ``initial_point=`` is passed. It is a hint for an exporter,
        # not solver input — nothing on the solve path reads it.
        self._initial_point: dict[tuple[str, int], float] = {}
        self._aux_counter = 0  # monotonic suffix for if_else auxiliary names
        # How each if_else auxiliary's box was derived (#2061 review).
        self._if_else_auxes: list[_IfElseAux] = []
        # Complementarity conditions added via ``complementarity()``/``mcp()``;
        # recorded for introspection and bound tightening (see ``discopt.mpec``),
        # and forwarded by every model-rebuilding pass (#1147).
        self._complementarities: list = []
        # The subset of those whose generated rows THIS model already carries,
        # mapped to the method that lowered them — an identity map
        # (``Complementarity`` is identity-hashed). Model-owned so it deep-copies
        # and pickles with the model, and so that one relation lowered by
        # different methods into different models keeps a truthful record for
        # each; the mark lived on the relation as weakrefs first and the method
        # as a plain field, and both were wrong for the same reason.
        self._lowered_complementarities: dict = {}
        # Size accounting for the #1182 exact continuous (simplex/CNF) lowering,
        # one ``SimplexLoweringRecord`` per disjunction that pass handled. Empty
        # on every other GDP method and on any model that was never lowered, so
        # a reader never has to ask whether the attribute exists. Declared here
        # rather than attached by the pass so the four size quantities of #1182
        # requirement 4 survive pickling and copying with the model.
        self._simplex_lowerings: list = []
        # GDP building blocks constructed on this model that have not been
        # attached to it (#1430). ``Model.disjunction()`` and
        # ``Model.make_disjunct()`` are FACTORIES: alone among the disjunctive
        # helpers on ``Model`` (``either_or``, ``if_else``, ``if_then``,
        # ``implies``, ``add_disjunction``) they build an object and append
        # nothing to ``_constraints``. A caller who forgets the attaching call
        # gets a model whose disjunctive structure is simply ABSENT, and the
        # solver then certifies ``status="optimal"`` for the relaxed problem:
        # measured, ``m.disjunction([[x >= 4, y >= 1], [y >= 6, x >= 1]])`` on
        # ``min x + y`` over ``[0, 10]^2`` returns ``0.0`` with ``bound=-1e-12``
        # where the correct optimum is ``5.0``, and the ``make_disjunct`` form
        # returns ``0.0/0.0``. These two lists are what lets ``validate`` refuse
        # that loudly instead of shipping a false certificate (CLAUDE.md §1/§3).
        # Build-time bookkeeping only: nothing on the solve path reads them, and
        # they are not serialized — a document records the attached model.
        self._gdp_factory_disjunctions: list = []
        self._gdp_factory_disjuncts: list = []
        # Decomposition annotations (Benders / Lagrangian). Populated by
        # ``set_stage``/``first_stage``/``second_stage``/``set_block``/
        # ``mark_coupling``; consumed by ``discopt.decomposition``. Empty by
        # default, in which case structure is auto-detected.
        self._decomp_stages: dict[str, int] = {}
        self._decomp_blocks: dict[str, int] = {}
        self._coupling_keys: set = set()
        # Element-wise block labels for the structure-aware KKT path (#1370).
        # ``_block_labels_var`` maps a variable NAME to one block id per element
        # (flat, C order); ``_block_labels_con`` maps a constraint name AND/OR
        # ``id(constraint)`` to one id per row. Negative = shared / linking.
        # Written by ``set_block``/``set_constraint_block``, resolved into NLP
        # index space by ``discopt.block_structure``. Separate from
        # ``_decomp_blocks`` on purpose: that one is whole-variable and feeds
        # ``discopt.decomposition``, which cannot represent a variable whose
        # elements span blocks.
        self._block_labels_var: dict[str, np.ndarray] = {}
        self._block_labels_con: dict = {}
        # Named index sets registered via ``set()`` (see ``discopt.modeling.sets``).
        self._sets: list = []
        # Names of variables discopt itself created as mathematically free
        # (e.g. the CVaR value-at-risk ``eta``). The user never declared them, so
        # the "very large or infinite declared bounds" warning -- whose remedy is
        # "declare tighter bounds" -- does not name them (#1618 X-29b).
        self._free_by_construction: set = set()
        # Linear constraint blocks emitted directly into the Rust builder
        # (fast-API ``add_linear_constraints`` and the indexed fast path). Each
        # entry is ``(A_csr, x, sense, b, name)``. Kept so .nl export and
        # introspection can recover constraints that bypass ``_constraints``.
        self._builder_linear_blocks: list = []
        # Set by ``from_mps`` / ``from_lp``: the file's column names in file order
        # and where each column lives in the model's variables
        # (``discopt.modeling._linear_files.FileColumns``). ``None`` otherwise.
        self.file_columns: Optional[Any] = None
        # Linear objective emitted directly into the Rust builder via
        # ``add_linear_objective``: ``(c, x, constant, sense)`` or ``None``. Kept
        # so .nl export can recover an objective that bypasses ``_objective``
        # (which only holds a zero placeholder in that case). Linear is
        # ``(c, x, constant, sense)``; quadratic is ``(Q_csr, c, x, constant,
        # sense)`` for ``0.5 x'Qx + c'x + constant``. At most one is set.
        self._builder_linear_objective: Optional[tuple] = None
        self._builder_quadratic_objective: Optional[tuple] = None
        # A solve result loaded alongside this model by ``discopt.load`` (the
        # fitted state saved with ``Model.save(..., result=...)``). ``None`` on a
        # freshly built model and on one saved without a result. Nothing on the
        # solve path reads it; it is there so a model and the fit it belongs to
        # travel together instead of desynchronising across two files.
        self.saved_result: Optional["SolveResult"] = None
        # The most recent successful :meth:`solve` result, recorded so
        # :meth:`sensitivity` can start its local NLP from the point this model
        # was actually solved to and cross-check against it (#1313). ``None``
        # until a solve returns a solution vector; nothing on the solve path
        # reads it.
        self._last_solve_result: Optional["SolveResult"] = None
        #: Provenance of a model read back by :func:`discopt.load` -- what wrote
        #: the document and when (see :mod:`discopt.provenance`). ``None`` on a
        #: model built in memory: nothing has been written yet, so there is no
        #: record to carry, and inventing one at construction would date the model
        #: to when it was *built* rather than when it was saved.
        self.provenance: Optional[dict] = None

    # ── Copying (#1479) ──────────────────────────────────────────────
    #
    # The default ``copy.deepcopy`` works on a freshly built model but failed in
    # two states every real model reaches: a model read by ``from_nl`` (the Rust
    # ``PyModelRepr`` in ``_nl_repr``: "cannot pickle 'builtins.PyModelRepr'")
    # and a model that has been *solved* (the evaluator caches hold the POUNCE
    # module: "cannot pickle 'module' object"). A model built with the fast
    # linear API failed a third way, on the Rust ``PyModelBuilder`` that is the
    # sole store of its rows. ``__deepcopy__`` handles exactly those three
    # things and deep-copies everything else as the default would, so a fresh
    # model copies byte-for-byte as before (asserted in ``test_transformations``).

    def __deepcopy__(self, memo: dict) -> "Model":
        cls = type(self)
        new = cls.__new__(cls)
        memo[id(self)] = new
        # Copy every expression node children-first into the shared memo, so the
        # attribute loop below meets each one as a memo hit (see
        # ``_expressions_children_first``).
        # ``_copy_node_into_memo`` rather than ``copy.deepcopy``: each node's
        # children are already copied, so ``Expression.__deepcopy__``'s own walk
        # would only re-find memo hits -- once per node, which cost 26-44 % of a
        # model copy (#1822).
        nodes = self._expressions_children_first()
        # #1854: copy every model that owns a shared leaf to completion first (see
        # ``_foreign_owner_models``), so those leaves are memo hits below.
        for owner in self._foreign_owner_models(nodes):
            if id(owner) not in memo:
                _copy.deepcopy(owner, memo)
        for node in nodes:
            if id(node) not in memo:
                _copy_node_into_memo(node, memo)
        for key, value in self.__dict__.items():
            if _is_model_cache(key):
                # Solve-time memoisation (evaluators, convexity, FBBT structure,
                # the native NLP base, flat offsets). Keyed by object identity
                # and rebuilt on demand, so a copy starts cold rather than
                # inheriting entries that describe the original's objects. A
                # cache ``__init__`` declares is reset to its declared ``None``;
                # a lazily attached one is left absent, as on a fresh model
                # (every reader goes through ``getattr(model, name, None)``).
                if key in _MODEL_INIT_CACHES:
                    new.__dict__[key] = None
                continue
            if key == "_builder":
                new.__dict__[key] = None  # rebuilt below from the Python-side record
                continue
            if key == "_nl_repr":
                # The parsed ``.nl`` source: read-only after ``from_nl`` and read
                # by nothing on the solve path. A copy shares it rather than
                # dropping it, which keeps the copy's attribute set faithful.
                new.__dict__[key] = value
                continue
            try:
                new.__dict__[key] = _copy.deepcopy(value, memo)
            except TypeError as exc:
                raise TypeError(
                    f"Model {self.name!r}: attribute {key!r} ({type(value).__name__}) "
                    f"cannot be deep-copied: {exc}. Model.__deepcopy__ knows how to "
                    "handle solve caches (*_cache), the Rust builder and _nl_repr; "
                    "a new uncopyable attribute must be taught to it here rather "
                    "than silently dropped."
                ) from exc
        new._restore_row_marks(self._row_marks_by_position())
        if self._builder is not None:
            new._replay_builder()
        return new

    # ``copy.deepcopy`` and ``pickle`` both walk an object graph recursively, a few
    # interpreter frames per level, so an expression built by a loop
    # (``e = e + x[i]``) is a chain as deep as the loop is long: ``clone()``
    # raised ``RecursionError`` on a 500-term sum, pickle on a few thousand. Both
    # memoise, so visiting the nodes children-first first means every later visit
    # of a child is a memo hit and the nesting never exceeds one level -- the
    # object graph produced is the same, only the order it is built in changes.
    # A root this walk does not know is merely copied the old, recursive way.
    def _expression_roots(self) -> list:
        roots: list = []
        if self._objective is not None:
            roots.append(self._objective.expression)
        for c in self._constraints:
            if isinstance(c, Constraint):
                roots.append(c.body)
            elif isinstance(c, _IndicatorConstraint):
                roots += [c.indicator, c.constraint.body]
            elif isinstance(c, _DisjunctiveConstraint):
                # A disjunct may hold a whole disjunction (``Model.disjunction()``
                # nested inside ``either_or``), not only rows: walk into it rather
                # than reading a ``.body`` it does not have (WP-6 sweep).
                stack = [c]
                while stack:
                    for r in (r for dd in stack.pop().disjuncts for r in dd):
                        if isinstance(r, _DisjunctiveConstraint):
                            stack.append(r)
                        elif isinstance(r, Constraint):
                            roots.append(r.body)
            elif isinstance(c, _SOSConstraint):
                roots += list(c.variables)
            elif isinstance(c, _LogicalConstraint):
                roots += _logical_leaves(c.expression)
        for rel in self._complementarities:
            roots += [getattr(rel, "f", None), getattr(rel, "g", None)]
        return roots

    def _foreign_owner_models(self, nodes: list) -> list:
        """Models other than this one that own a leaf this model reaches (#1854).

        A GDP / transformation result shares the source model's ``Variable``
        objects, whose ``model`` is the source, so copying (or pickling) the
        result reaches the source through a shared leaf's state. Reached from
        inside the leaf, the source was rebuilt -- and its Rust builder replayed
        -- while that leaf was still empty (``'Variable' object has no attribute
        'name'``). ``__deepcopy__`` copies these models first and ``__getstate__``
        writes them first, so each is complete before anything that needs it.
        """
        owners: list = []
        seen: set[int] = {id(self)}
        for leaf in [*nodes, *self._variables, *self._parameters]:
            if not isinstance(leaf, (Variable, Parameter)):
                continue
            owner = getattr(leaf, "model", None)
            if isinstance(owner, Model) and id(owner) not in seen:
                seen.add(id(owner))
                owners.append(owner)
        return owners

    def _expressions_children_first(self) -> list:
        from discopt.serialize import _children

        order: list = []
        seen: set[int] = set()
        stack: list = [(r, False) for r in reversed(self._expression_roots())]
        while stack:
            node, expanded = stack.pop()
            if expanded:
                order.append(node)
                continue
            if not isinstance(node, Expression) or id(node) in seen:
                continue
            seen.add(id(node))
            stack.append((node, True))
            stack.extend((ch, False) for ch in reversed(_children(node)))
        return order

    # ``mark_coupling`` and ``set_constraint_block`` key an unnamed row by
    # ``id(constraint)``. A copy owns new constraint objects, so carrying those
    # integers over verbatim left every such mark pointing at the ORIGINAL's rows:
    # on the copy the coupling set and block labels silently came back empty, and
    # ``discopt.serialize`` then refused to save it. The marks are moved by row
    # position instead -- the one thing original and copy agree on. A key naming
    # no current row (the row was removed) is dropped: it marks nothing here, and
    # an integer outliving its object can only ever alias an unrelated one.
    def _row_marks_by_position(self) -> tuple[list[int], list[tuple[int, Any]]]:
        pos = {id(c): i for i, c in enumerate(self._constraints)}
        coupling = sorted(pos[k] for k in self._coupling_keys if isinstance(k, int) and k in pos)
        labels = [
            (pos[k], v)
            for k, v in self._block_labels_con.items()
            if isinstance(k, int) and k in pos
        ]
        return coupling, labels

    def _restore_row_marks(self, marks: tuple[list[int], list[tuple[int, Any]]]) -> None:
        coupling, labels = marks
        rows = self._constraints
        self._coupling_keys = {k for k in self._coupling_keys if not isinstance(k, int)}
        self._coupling_keys.update(id(rows[i]) for i in coupling)
        self._block_labels_con = {
            k: v for k, v in self._block_labels_con.items() if not isinstance(k, int)
        }
        for i, v in labels:
            self._block_labels_con[id(rows[i])] = v

    def _replay_builder(self) -> None:
        """Rebuild the Rust builder of a copy from its retained Python-side blocks.

        Every builder-resident row enters through :meth:`add_linear_constraints`
        (the ``Model.constraint`` fast path included) and every builder-resident
        objective through :meth:`add_linear_objective` /
        :meth:`add_quadratic_objective`, each of which records its inputs on the
        model. Replaying those records through the same entry points gives the
        copy a builder with the same rows, in the same order.
        """
        blocks = list(self._builder_linear_blocks)
        lin_obj = self._builder_linear_objective
        quad_obj = self._builder_quadratic_objective
        objective = self._objective
        self._builder = None
        self._builder_linear_blocks = []
        self._get_builder()
        for A, x, sense, b, name in blocks:
            self.add_linear_constraints(A, x, sense, b, name=name)
        if lin_obj is not None:
            c_vec, x, constant, sense = lin_obj
            self.add_linear_objective(c_vec, x, constant=constant, sense=sense)
        elif quad_obj is not None:
            Q, c_vec, x, constant, sense = quad_obj
            self.add_quadratic_objective(Q, c_vec, x, constant=constant, sense=sense)
        # The objective entry points install a fresh placeholder; keep the
        # copied one so the copy's objective object graph matches the original's.
        self._objective = objective

    # ── Pickling ─────────────────────────────────────────────────────
    #
    # The same three obstacles ``__deepcopy__`` handles, and the same treatment:
    # solve caches are dropped (an unpickled model starts cold), the Rust builder
    # is replayed from its Python-side record, and everything else -- including
    # ``_last_solve_result`` and ``_source_nl_path`` -- travels as the default
    # pickle would carry it. Two things differ, both because a pickle leaves the
    # process: ``_nl_repr`` becomes a ``_DetachedNlRepr`` marker (see that class for
    # why it is not just dropped), and ``_solve_deadline`` is dropped -- it is an
    # absolute ``time.perf_counter()`` reading, and that clock's origin is
    # per-process, so the number means nothing in the process that unpickles it.
    #
    # ``pickle`` is for moving a model between processes running the same
    # discopt. It carries a stamp, ``(_MODEL_PICKLE_FORMAT, discopt.__version__,
    # SCHEMA)``: a pickle of another layout -- or of none, from before the stamp --
    # is refused, since ``__dict__.update`` would install attributes this code does
    # not expect, or leave out ones it does; the same layout from another discopt
    # version loads with a ``ProvenanceSkewWarning``. Nodes are not stamped (a
    # per-node stamp is a per-node cost): a lone ``Expression`` pickle carries its
    # model through its variables, and with it that model's one stamp. To keep a
    # model on disk, use ``Model.save`` /
    # ``discopt.modeling.dumps`` (``discopt.serialize``), whose compatibility rules
    # are in ``docs/dev/serialization-format.md``.

    def __getstate__(self) -> tuple:
        import discopt
        from discopt.serialize import SCHEMA

        # First in the dict, so the pickler writes the nodes children-first before
        # anything that refers to them (see ``_expressions_children_first``).
        nodes = self._expressions_children_first()
        state: dict = {
            # #1854: first of all, so each is unpickled whole before the nodes.
            "_pickle_foreign_models": self._foreign_owner_models(nodes),
            "_pickle_expressions": [*nodes, _open_children_first_scope()],
            "_pickle_format": (_MODEL_PICKLE_FORMAT, discopt.__version__, SCHEMA),
        }
        for key, value in self.__dict__.items():
            if _is_model_cache(key):
                if key in _MODEL_INIT_CACHES:
                    state[key] = None
                continue
            if key == "_builder":
                state[key] = None
                continue
            if key == "_nl_repr" and value is not None:
                state[key] = _DetachedNlRepr()
                continue
            if key == "_solve_deadline":
                continue
            state[key] = value
        # The id-keyed row marks travel by position (see ``_row_marks_by_position``).
        return state, self._builder is not None, self._row_marks_by_position()

    def __setstate__(self, state: tuple) -> None:
        stamp = None
        if isinstance(state, tuple) and len(state) == 3 and isinstance(state[0], dict):
            stamp = state[0].pop("_pickle_format", None)
        if not (isinstance(stamp, tuple) and len(stamp) == 3) or stamp[0] != _MODEL_PICKLE_FORMAT:
            if stamp is None:
                found = "no format stamp"
            else:
                found = f"format {stamp[0] if isinstance(stamp, tuple) and stamp else stamp!r}"
            raise TypeError(
                f"this Model was pickled by a different discopt pickle layout ({found}; "
                f"this discopt reads format {_MODEL_PICKLE_FORMAT}). pickle is for "
                "same-version transport -- use Model.save()/discopt.modeling.load() to "
                "keep a model, or re-pickle it with the discopt that wrote it."
            )
        import discopt

        if stamp[1] != discopt.__version__:
            from discopt.serialize import ProvenanceSkewWarning

            warnings.warn(
                f"this Model was pickled by discopt {stamp[1]} and is being unpickled "
                f"by discopt {discopt.__version__}; the pickle layout matches, but a "
                "model's meaning can still differ between versions.",
                ProvenanceSkewWarning,
                stacklevel=2,
            )
        attrs, had_builder, row_marks = state
        attrs.pop("_pickle_expressions", None)
        attrs.pop("_pickle_foreign_models", None)
        self.__dict__.update(attrs)
        self._restore_row_marks(row_marks)
        if had_builder:
            self._replay_builder()

    # ``copy.copy`` also goes through ``__getstate__``/``__setstate__`` once they
    # exist. Keep it what it was before they did -- a plain shallow copy sharing
    # every attribute -- since callers (``relax_objective_defining_equality``)
    # rely on it being cheap and on it changing nothing but what they reassign.
    def __copy__(self) -> "Model":
        cls = type(self)
        new = cls.__new__(cls)
        new.__dict__.update(self.__dict__)
        return new

    def clone(self) -> "Model":
        """Return an independent deep copy of this model.

        The copy owns new :class:`Variable`, :class:`Constraint` and
        :class:`Parameter` objects (a variable of the copy is *not* a variable of
        the original, and fixing one leaves the other alone). Solve caches are
        not carried -- the copy starts cold -- but the last solve result and the
        ``.nl`` source path are, since the copy is still the same model. Works on
        fresh, solved, ``from_nl`` and fast-API-built models.

        This is the copy :func:`discopt.transformations.create_using` runs a
        transformation on.
        """
        return _copy.deepcopy(self)

    # ── Rich representation (LaTeX / HTML in standard PSE form) ──

    def to_latex(
        self,
        max_rows: Optional[int] = None,
        standalone: bool = False,
        precision: Optional[int] = None,
    ) -> str:
        """Render the model as a LaTeX ``aligned`` block in standard problem form
        (``minimize f(x)`` / ``subject to g(x) <= 0`` / variable domains).

        The output follows publication conventions (implicit products, folded
        signs, standard operator names, recovered ``\\sum_{i=lo}^{hi}`` indexed
        sums, ``x \\in [0, 10]^{3}`` vector domains) and compiles under pdflatex
        with ``amsmath``/``amssymb`` as well as typesetting under MathJax.

        Parameters
        ----------
        max_rows : int, optional
            Cap on the number of constraint/variable rows shown; excess is
            summarised with a ``\\vdots`` row. ``None`` (default) renders everything.
        standalone : bool, optional
            Wrap the block in a minimal compilable ``article`` document.
        precision : int, optional
            Round printed decimals to this many significant figures. The default
            ``None`` prints every coefficient exactly (shortest round-trip form),
            so the display states the model's constraints, not rounded ones.
        """
        from discopt.modeling import latex

        return latex.model_to_latex(
            self, max_rows=max_rows, standalone=standalone, precision=precision
        )

    def to_html(self, max_rows: Optional[int] = None, precision: Optional[int] = None) -> str:
        """Render the model as standalone HTML (the PSE LaTeX typeset via MathJax,
        with a header naming the model and its size). See :meth:`to_latex`."""
        from discopt.modeling import latex

        return latex.model_to_html(self, max_rows=max_rows, precision=precision)

    def _repr_latex_(self) -> str:
        from discopt.modeling import latex

        return f"$$\n{latex.model_to_latex(self, max_rows=latex._DEFAULT_MAX_ROWS)}\n$$"

    def _repr_markdown_(self) -> str:
        # VS Code's notebook renderer typesets ``text/markdown`` outputs with
        # KaTeX but does not reliably render ``text/latex`` outputs; emit the
        # same PSE block as fenced display math so it renders there too.
        # Jupyter/MathJax frontends prefer ``_repr_latex_``/``_repr_html_``.
        from discopt.modeling import latex

        return f"$$\n{latex.model_to_latex(self, max_rows=latex._DEFAULT_MAX_ROWS)}\n$$"

    def _repr_html_(self) -> str:
        from discopt.modeling import latex

        return latex.model_to_html(self, max_rows=latex._DEFAULT_MAX_ROWS)

    # ── Index sets ──

    def set(self, name: str, members, dimen: Optional[int] = None):
        """Declare a named index set.

        A :class:`~discopt.modeling.sets.Set` is the authoritative index for
        indexed variables, parameters, and constraints. Members may be scalars
        (``dimen == 1``) or fixed-arity tuples; duplicates are removed and
        first-occurrence order is preserved.

        Parameters
        ----------
        name : str
            Identifier for the set, unique among the model's sets.
        members : iterable
            The set members.
        dimen : int, optional
            Declared dimensionality; inferred from *members* when omitted.

        Returns
        -------
        Set
            The registered set, supporting algebra (``|``, ``&``, ``-``, ``*``)
            and filtering (``where``).

        Examples
        --------
        >>> m = Model()
        >>> plants = m.set("plants", ["pitt", "sf", "nyc"])
        >>> markets = m.set("markets", ["a", "b"])
        >>> len(plants * markets)
        6
        """
        from discopt.modeling.sets import Set

        if any(s.name == name for s in self._sets):
            raise ValueError(f"Set name '{name}' already used in model")
        s = Set(name, members, dimen=dimen)
        self._sets.append(s)
        return s

    # ── Variable constructors ──

    def _rebuild_name_index(self) -> None:
        """Recompute the persistent ``_names`` cache from the current lists (M7).

        Call after any bulk reassignment of ``_variables``/``_parameters`` that
        bypasses the registration sites (e.g. the reformulation passes that build
        a new ``Model`` with ``new_model._variables = list(model._variables)``),
        so a later ``_check_name`` on that model stays correct.
        """
        self._names = {v.name for v in self._variables} | {p.name for p in self._parameters}

    def _flat_var_offset(self, var: "Variable") -> int:
        """Return the flat start index of ``var`` in the stacked x vector.

        The offset is the sum of the sizes of every variable preceding ``var``
        in ``self._variables``. Summing that slice from scratch is O(n) per call,
        and the relaxation / AD / term-classifier builds resolve a flat index
        once per variable leaf per term — O(n·terms) overall. That quadratic was
        the dominant *uninterruptible* pre-B&B root-setup cost that made
        ``solve(time_limit=T)`` overrun its budget on large factorable models
        (issue #654; sub-sites #507 term-classifier build, #187 DAG compile).

        An exclusive prefix-sum table is memoized and rebuilt only when the
        (append-only) variable list grows, so each lookup is O(1). This is a pure
        speedup: ``_variables`` only ever grows and a Variable's ``_index`` /
        ``size`` are immutable after construction, so a cached offset can never
        go stale without the length changing. Indices at/past the end collapse to
        the full total, exactly as the ``[: var._index]`` slice did.
        """
        n = len(self._variables)
        # ``getattr`` fallback guards the rare path that builds a Model without
        # ``__init__`` (e.g. a shallow ``copy.copy`` of a pre-attribute object).
        offsets: Optional[list[int]] = getattr(self, "_flat_var_offsets_cache", None)
        if offsets is None or len(offsets) != n + 1:
            offsets = [0] * (n + 1)
            acc = 0
            for k, v in enumerate(self._variables):
                acc += v.size
                offsets[k + 1] = acc
            self._flat_var_offsets_cache = offsets
        idx = var._index
        return offsets[idx] if idx < n else offsets[n]

    def _fresh_name(self, base: str) -> str:
        """``base``, or ``base_2``, ``base_3``, ... -- the first not yet in ``_names``.

        For names a reformulation pass generates (#1799). A pass builds its names
        from a prefix and a counter or the source's names, and two applications --
        two unnamed disjunctions under hull, say -- can produce the same one. Two
        variables sharing a name make name-keyed output ambiguous and the
        serialized document unloadable, so the second gets a suffix instead.
        """
        if base not in self._names:
            return base
        k = 2
        while f"{base}_{k}" in self._names:
            k += 1
        return f"{base}_{k}"

    def _register_generated_variable(self, var: "Variable") -> "Variable":
        """Append a variable a reformulation pass created, registering its name (#1799).

        The passes append to ``_variables`` directly -- they do not register with
        the Rust builder, whose columns a lowering re-issues once all of them exist
        (#1798) -- and so used to skip ``_names`` too. The transformed model then
        accepted a second variable with an auxiliary's name, which
        ``serialize.dumps`` wrote and ``loads`` refused. Registering here makes
        :meth:`_check_name` refuse that declaration where it is made. Choose the
        name with :meth:`_fresh_name`; a clash here is a bug in the pass.
        """
        if var.name in self._names:
            raise ValueError(
                f"reformulation generated the variable name {var.name!r}, which the "
                "model already uses (pick it with Model._fresh_name)"
            )
        if var._index != len(self._variables):
            # ``Variable.__init__`` takes its column from ``len(_variables)`` at
            # construction, so a pass that constructs two variables before
            # registering either gives both the same column, and every expression
            # over the second one reads the first one's value and box. Measured
            # (#1917): the origin-free hull row on GDPlib ``hda`` built ``v - y*t``
            # against another ``t``'s box, and the root LP certified a feasible
            # model ``infeasible``. Refuse instead of renumbering: the pass may
            # already have handed the stale column to something else.
            raise ValueError(
                f"reformulation generated the variable {var.name!r} with column "
                f"{var._index}, but it is being registered at column "
                f"{len(self._variables)} (construct each generated variable right "
                "before registering it, or set its _index when registering)"
            )
        self._variables.append(var)
        self._names.add(var.name)
        return var

    def _register_variable(self, var: "Variable") -> "Variable":
        """Append a variable and register it with the Rust builder if active."""
        self._variables.append(var)
        self._names.add(var.name)  # keep the O(1) name set in sync (M7)
        if self._builder is not None:
            var._builder_idx = self._builder.add_variable(
                var.name,
                var.var_type.value,
                list(var.shape),
                var.lb.flatten().astype(np.float64),
                var.ub.flatten().astype(np.float64),
            )
        return var

    def _make_indexed_var(
        self, name, var_type, index_set, lb, ub, default_lb, default_ub
    ) -> "IndexedVar":
        """Build an :class:`IndexedVar` backed by one flat variable over *index_set*."""
        from discopt.modeling.indexed import IndexedVar, resolve_indexed_values

        lb_arr = resolve_indexed_values(index_set, lb, default_lb, np.float64)
        ub_arr = resolve_indexed_values(index_set, ub, default_ub, np.float64)
        self._check_name(name)
        flat = Variable(name, var_type, (len(index_set),), lb_arr, ub_arr, self)
        self._register_variable(flat)
        return IndexedVar(flat, index_set)

    @overload
    def continuous(
        self,
        name: str,
        shape: Union[int, tuple[int, ...]] = ...,
        lb: Optional[Union[float, np.ndarray]] = ...,
        ub: Optional[Union[float, np.ndarray]] = ...,
        over: None = ...,
    ) -> Variable: ...

    @overload
    def continuous(
        self,
        name: str,
        shape: Union[int, tuple[int, ...]] = ...,
        lb: Optional[Union[float, np.ndarray]] = ...,
        ub: Optional[Union[float, np.ndarray]] = ...,
        *,
        over: "_SetBase",
    ) -> "IndexedVar": ...

    def continuous(
        self,
        name: str,
        shape: Union[int, tuple[int, ...]] = (),
        lb: Optional[Union[float, np.ndarray]] = -9.999e19,
        ub: Optional[Union[float, np.ndarray]] = 9.999e19,
        over=None,
    ) -> Union[Variable, "IndexedVar"]:
        """
        Create continuous decision variable(s).

        Parameters
        ----------
        name : str
            Variable name (must be unique in the model).
        shape : int or tuple of int, default ()
            Scalar ``()`` or tuple for array variables.
        lb : float or numpy.ndarray, default -9.999e19
            Lower bound (scalar broadcast to *shape*, or array matching *shape*).
            ``None`` means the default. A NaN entry raises ``ValueError``.
        ub : float or numpy.ndarray, default 9.999e19
            Upper bound (scalar broadcast to *shape*, or array matching *shape*).
            ``None`` means the default. A NaN entry raises ``ValueError``.

            The default ``±9.999e19`` means *no bound* (#1678): an LP/MILP that
            runs off along it is reported ``unbounded``, and any other result
            whose point sits on it is ``feasible`` with no dual bound, never a
            certified ``optimal`` at that corner. An explicit bound below it,
            however large, is honoured as declared.

        Returns
        -------
        Variable
            Expression that can be used in objectives and constraints.

        .. warning::

            NLP solvers (ipm, ipopt, pounce) use interior-point barrier methods
            that require finite, reasonably-sized bounds.  The defaults
            (±9.999×10¹⁹) exceed the safe threshold (~10¹⁵) and will cause
            NaN objectives or ``iteration_limit`` status.  Always supply
            explicit ``lb``/``ub`` when the problem has a known feasible range::

                x = m.continuous("x", lb=-100, ub=100)   # good
                x = m.continuous("x")                     # risky for NLP solvers

            A ``UserWarning`` is raised at solve time when bounds exceed 10¹⁵.

        Examples
        --------
        >>> x = m.continuous("x")                           # scalar, unbounded
        >>> flow = m.continuous("flow", shape=(5,), lb=0)   # 5-vector, non-negative
        >>> X = m.continuous("X", shape=(3, 4), lb=0, ub=1) # 3x4 matrix
        >>> ship = m.continuous("ship", over=links, lb=0)   # indexed over a named set

        When *over* is given (a :class:`~discopt.modeling.sets.Set`), an
        :class:`~discopt.modeling.indexed.IndexedVar` is returned: ``ship[key]``
        indexes by set member, and ``lb``/``ub`` may be a scalar, a ``dict``
        keyed by member, or a callable ``fn(member)``.
        """
        # None is the natural spelling of "no bound" (#1294), as in `integer`.
        if lb is None:
            lb = -9.999e19
        if ub is None:
            ub = 9.999e19
        if over is not None:
            _require_no_shape(shape, "continuous")
            return self._make_indexed_var(
                name, VarType.CONTINUOUS, over, lb, ub, -9.999e19, 9.999e19
            )
        if isinstance(shape, int):
            shape = (shape,)
        self._check_name(name)
        var = Variable(name, VarType.CONTINUOUS, shape, lb, ub, self)
        return self._register_variable(var)

    @overload
    def binary(
        self, name: str, shape: Union[int, tuple[int, ...]] = ..., over: None = ...
    ) -> Variable: ...

    @overload
    def binary(
        self, name: str, shape: Union[int, tuple[int, ...]] = ..., *, over: "_SetBase"
    ) -> "IndexedVar": ...

    def binary(
        self,
        name: str,
        shape: Union[int, tuple[int, ...]] = (),
        over=None,
    ) -> Union[Variable, "IndexedVar"]:
        """
        Create binary (0/1) decision variable(s).

        Parameters
        ----------
        name : str
            Variable name (must be unique in the model).
        shape : int or tuple of int, default ()
            Scalar ``()`` or tuple for array variables.

        Returns
        -------
        Variable
            Binary variable with bounds ``[0, 1]``.

        Examples
        --------
        >>> use = m.binary("use")                    # single binary
        >>> active = m.binary("active", shape=(5,))  # 5 binary indicators
        >>> assign = m.binary("assign", over=workers * tasks)  # indexed binary
        """
        if over is not None:
            _require_no_shape(shape, "binary")
            return self._make_indexed_var(name, VarType.BINARY, over, 0.0, 1.0, 0.0, 1.0)
        if isinstance(shape, int):
            shape = (shape,)
        self._check_name(name)
        var = Variable(name, VarType.BINARY, shape, 0.0, 1.0, self)
        return self._register_variable(var)

    @overload
    def integer(
        self,
        name: str,
        shape: Union[int, tuple[int, ...]] = ...,
        lb: Optional[Union[float, np.ndarray]] = ...,
        ub: Optional[Union[float, np.ndarray]] = ...,
        over: None = ...,
    ) -> Variable: ...

    @overload
    def integer(
        self,
        name: str,
        shape: Union[int, tuple[int, ...]] = ...,
        lb: Optional[Union[float, np.ndarray]] = ...,
        ub: Optional[Union[float, np.ndarray]] = ...,
        *,
        over: "_SetBase",
    ) -> "IndexedVar": ...

    def integer(
        self,
        name: str,
        shape: Union[int, tuple[int, ...]] = (),
        lb: Optional[Union[float, np.ndarray]] = None,
        ub: Optional[Union[float, np.ndarray]] = None,
        over=None,
    ) -> Union[Variable, "IndexedVar"]:
        """
        Create general integer decision variable(s).

        Parameters
        ----------
        name : str
            Variable name (must be unique in the model).
        shape : int or tuple of int, default ()
            Scalar ``()`` or tuple for array variables.
        lb : float or numpy.ndarray, optional
            Lower bound. Honored when supplied (never replaced by the
            fallback). When omitted, the finite fallback ``0`` is used and a
            ``UserWarning`` is emitted (see below).
        ub : float or numpy.ndarray, optional
            Upper bound. Honored when supplied. When omitted, the finite
            fallback ``1e6`` is used and a ``UserWarning`` is emitted.

            A fractional bound is stored as the integer range it admits
            (#2252): a bound within ``1e-6`` of an integer *is* that integer
            (``lb=1.000001`` stores ``1``), otherwise ``lb`` rounds up and
            ``ub`` rounds down (``lb=1.5`` stores ``2``). The same rule applies
            to every later ``x.lb = ...``/``x.ub = ...``, so every solve route
            and :func:`~discopt.validation.feasibility.verify_point` see one
            integral box.

        Returns
        -------
        Variable
            Integer-valued variable.

        Notes
        -----
        Branch-and-bound needs a bounded integer domain, so an *unspecified*
        ``lb``/``ub`` falls back to ``[0, 1e6]``. Previously this substitution
        was silent, so a model whose true optimum needed a negative integer or
        one above ``1e6`` was quietly truncated and the wrong optimum reported
        as certified (correctness issue C-6). The fallback is now applied
        **loudly** — a ``UserWarning`` names the variable and the imposed
        range — and it **never** overrides a bound you provide. Pass explicit
        ``lb``/``ub`` (e.g. ``lb=-5, ub=10``) to silence the warning and to
        solve the problem you actually mean. A result whose point sits on a
        defaulted side carries no certificate: it is reported ``feasible`` with
        no dual bound, since the problem as posed may be unbounded (#2281).

        Examples
        --------
        >>> n = m.integer("n_units", lb=0, ub=10)
        >>> batch = m.integer("batch", shape=(3,), lb=1, ub=100)
        >>> n = m.integer("n", over=plants, lb=0, ub=10)  # indexed integer
        """
        # #2281: which sides discopt invents, so a certificate resting on one is
        # withheld (``_withhold_default_box_certificate``).
        defaulted = frozenset(side for side, val in (("lb", lb), ("ub", ub)) if val is None)
        lb, ub = self._resolve_integer_defaults(name, lb, ub)
        if over is not None:
            _require_no_shape(shape, "integer")
            ivar = self._make_indexed_var(
                name, VarType.INTEGER, over, lb, ub, _INTEGER_DEFAULT_LB, _INTEGER_DEFAULT_UB
            )
            ivar.flat._int_default_sides = defaulted
            return ivar
        if isinstance(shape, int):
            shape = (shape,)
        self._check_name(name)
        var = Variable(name, VarType.INTEGER, shape, lb, ub, self)
        var._int_default_sides = defaulted
        return self._register_variable(var)

    @staticmethod
    def _resolve_integer_defaults(name, lb, ub):
        """Substitute finite fallback integer bounds for unspecified sides, loudly.

        Returns the (possibly-substituted) ``(lb, ub)``. A ``None`` side is
        replaced with the finite fallback (``0`` / ``1e6``) and recorded so a
        single ``UserWarning`` can name exactly which side(s) discopt had to
        default. A user-provided bound is passed through unchanged and never
        warns (correctness issue C-6).
        """
        defaulted: list[str] = []
        if lb is None:
            lb = _INTEGER_DEFAULT_LB
            defaulted.append(f"lb={_INTEGER_DEFAULT_LB:g}")
        if ub is None:
            ub = _INTEGER_DEFAULT_UB
            defaulted.append(f"ub={_INTEGER_DEFAULT_UB:g}")
        if defaulted:
            warnings.warn(
                f"integer variable '{name}': no explicit "
                f"{' and '.join(defaulted)} supplied; discopt is imposing the "
                f"finite default integer bound(s) so branch-and-bound has a "
                f"bounded domain. This default box silently cuts any optimum "
                f"below {_INTEGER_DEFAULT_LB:g} or above {_INTEGER_DEFAULT_UB:g}. "
                f"Pass explicit lb/ub to solve the intended problem and silence "
                f"this warning.",
                UserWarning,
                stacklevel=3,
            )
        return lb, ub

    def _make_indexed_param(self, name, index_set, value) -> "IndexedParam":
        """Build an :class:`IndexedParam` backed by one flat parameter over *index_set*."""
        from discopt.modeling.indexed import IndexedParam, resolve_indexed_values

        arr = resolve_indexed_values(index_set, value, 0.0, np.float64)
        self._check_name(name)
        flat = Parameter(name, arr, self)
        self._parameters.append(flat)
        self._names.add(name)  # keep the O(1) name set in sync (M7)
        return IndexedParam(flat, index_set)

    @overload
    def parameter(
        self, name: str, value: Union[float, np.ndarray], over: None = ...
    ) -> Parameter: ...

    @overload
    def parameter(self, name: str, value, *, over: "_SetBase") -> "IndexedParam": ...

    def parameter(
        self,
        name: str,
        value: Union[float, np.ndarray],
        over=None,
    ) -> Union[Parameter, "IndexedParam"]:
        """
        Create a parameter for parametric optimization / sensitivity.

        Parameters are fixed during a solve but tracked in the expression
        DAG for differentiation via implicit diff through KKT conditions.

        Parameters
        ----------
        name : str
            Parameter name (must be unique in the model).
        value : float or numpy.ndarray
            Current parameter value.

        Returns
        -------
        Parameter
            Parameter expression usable in objectives and constraints.

        Examples
        --------
        >>> price = m.parameter("price", value=50.0)
        >>> demand = m.parameter("demand", value=np.array([100, 200, 150]))
        >>> cap = m.parameter("cap", over=plants, value={"pitt": 10, "sf": 20})

        When *over* is given (a :class:`~discopt.modeling.sets.Set`), an
        :class:`~discopt.modeling.indexed.IndexedParam` is returned and *value*
        may be a scalar, a ``dict`` keyed by member, or a callable ``fn(member)``.
        """
        if over is not None:
            return self._make_indexed_param(name, over, value)
        self._check_name(name)
        param = Parameter(name, value, self)
        self._parameters.append(param)
        self._names.add(name)  # keep the O(1) name set in sync (M7)
        return param

    # ── Objective ──

    @staticmethod
    def _scalar_objective(expr: Expression, sense: str) -> Expression:
        """Refuse a non-scalar objective here, where the user's line is (#1445).

        A shape-``(k,)`` objective used to be accepted silently and surfaced only
        at solve time as ``jax.grad``'s "Gradient only defined for scalar-output
        functions", or as a wall of ``pounce::py ERROR`` lines -- six frames below
        anything the caller wrote, naming a library they never imported. Every
        route failed loudly (no false bound was ever produced), but none of them
        said what was wrong with the model.

        Anything of ``size == 1`` is scalar for this purpose -- shape ``()``,
        ``(1,)`` and ``(1, 1)`` all denote a single number and all already
        worked, so they stay accepted. Only a genuinely multi-element objective
        is refused.
        """
        shape = getattr(expr, "shape", None)
        if shape is None or int(np.prod(shape)) == 1:
            return expr
        raise ValueError(
            f"{sense}() needs a scalar objective, got shape {tuple(shape)}. "
            f"Reduce it first -- dm.sum(expr) for a total, expr[i] for one "
            f"component, or w @ expr for a weighted combination. To "
            f"optimize several objectives at once, see discopt.mo "
            f"(weighted_sum / epsilon_constraint), which returns a Pareto front "
            f"rather than a single point."
        )

    @classmethod
    def _checked_objective(cls, expr, sense: str) -> Expression:
        """Validate and wrap a ``minimize``/``maximize`` argument (#1628, #1445).

        ``None`` is refused rather than read as "no objective": discopt's
        feasibility spelling is ``minimize(0)`` (what the GAMS reader emits for
        an objectiveless CNS solve), and a model with no objective at all is
        refused by :meth:`validate`. Accepting ``None`` used to wrap it as a NaN
        constant, and the solve reported ``status="feasible"`` with
        ``objective=nan`` -- the usual cause being a builder helper that forgot
        its ``return``. A non-finite *constant* objective is refused for the same
        reason: it can only produce a NaN/inf objective, never an optimum.
        """
        if expr is None:
            raise TypeError(
                f"{sense}() got None, not an expression. A helper that builds the "
                f"objective most likely forgot its `return`. For a pure "
                f"feasibility problem, use m.minimize(0)."
            )
        if isinstance(expr, (str, bytes)):
            raise TypeError(
                f"{sense}() needs a numeric expression, got {type(expr).__name__} {expr!r}."
            )
        if isinstance(expr, (list, tuple)) and any(isinstance(e, Expression) for e in expr):
            # numpy's own message here is "setting an array element with a
            # sequence", which names neither the objective nor the fix.
            raise TypeError(
                f"{sense}() got a {type(expr).__name__} of expressions, not one "
                f"scalar expression. Combine them first, e.g. dm.sum(...) for a "
                f"total; for several objectives at once see discopt.mo."
            )
        wrapped = cls._scalar_objective(_wrap(expr), sense)
        if isinstance(wrapped, Constant) and not np.all(np.isfinite(wrapped.value)):
            raise ValueError(
                f"{sense}() got a non-finite constant objective "
                f"({wrapped.value.tolist()!r}); an objective must be finite. For a "
                f"pure feasibility problem, use m.minimize(0)."
            )
        return wrapped

    def minimize(self, expr: Expression):
        """
        Set the objective to minimize.

        Parameters
        ----------
        expr : Expression
            Expression to minimize. Must be scalar (any shape whose total size
            is 1); a multi-element expression is refused (#1445) -- reduce it,
            or use :mod:`discopt.mo` for several objectives.

        Raises
        ------
        TypeError
            If ``expr`` is ``None``, a string, or a list of expressions (#1628).
            For a pure feasibility problem, use ``minimize(0)``.
        ValueError
            If ``expr`` has more than one element, or is a non-finite constant.

        Examples
        --------
        >>> m.minimize(cost @ x)
        >>> m.minimize(dm.sum(lambda i: c[i] * x[i], over=range(n)))
        """
        self._objective = Objective(
            self._checked_objective(expr, "minimize"), ObjectiveSense.MINIMIZE
        )

    def maximize(self, expr: Expression):
        """
        Set the objective to maximize.

        Parameters
        ----------
        expr : Expression
            Expression to maximize. Must be scalar (any shape whose total size
            is 1); a multi-element expression is refused (#1445) -- reduce it,
            or use :mod:`discopt.mo` for several objectives.

        Raises
        ------
        TypeError
            If ``expr`` is ``None``, a string, or a list of expressions (#1628).
            For a pure feasibility problem, use ``minimize(0)``.
        ValueError
            If ``expr`` has more than one element, or is a non-finite constant.

        Examples
        --------
        >>> m.maximize(profit @ x - dm.sum(penalty * y))
        """
        self._objective = Objective(
            self._checked_objective(expr, "maximize"), ObjectiveSense.MAXIMIZE
        )

    # ── Bound scoping: the shared primitive behind every fix ──────────

    def _resolve_variable(self, key) -> "Variable":
        """``key`` as a Variable of *this* model, or a loud refusal."""
        if isinstance(key, Variable):
            if key.model is not self:
                raise ValueError(
                    f"Variable {key.name!r} belongs to model {key.model.name!r}, not "
                    f"{self.name!r}. Fixing it would have no effect on this model's "
                    "solve, and nothing downstream would report the mismatch."
                )
            return key
        if isinstance(key, str):
            for v in self._variables:
                if v.name == key:
                    return v
            raise KeyError(
                f"No variable named {key!r} in model {self.name!r} "
                f"(have: {[v.name for v in self._variables][:10]})"
            )
        raise TypeError(f"Expected a Variable or a variable name, got {type(key).__name__}.")

    @_contextlib.contextmanager
    def saved_bounds(self, variables=None, *, copy: bool = False) -> "Iterator[Model]":
        """Snapshot variable boxes on entry; restore them on exit, exceptions included.

        The low-level primitive: it saves and restores *boxes*, so it covers the
        bound-override passes (whose ``lb`` and ``ub`` differ) as well as fixing
        (where they coincide). :meth:`fixed` is the fixing-shaped sugar over it.

        Three call sites in ``_relax/`` hand-rolled this exact
        ``saved = [...]`` / ``try`` / ``finally: restore`` block before it
        existed (node_reduce, root_reduce, primal_heuristics); they now share
        this one so their restore semantics cannot drift apart.

        Parameters
        ----------
        variables : iterable of Variable, optional
            Restrict the snapshot to these. Defaults to every variable.
        copy : bool, default False
            Snapshot bound *arrays* by reference (the default) or by value.
            By-reference is sound because of an invariant that holds across
            the tree: a writer either **rebinds** ``v.lb`` outright, or rebinds
            it to a fresh writable copy *before* mutating (``gams_parser`` does
            the latter) — so a snapshot taken earlier still refers to the array
            it saved. Declared bounds are a read-only ``broadcast_to`` view, so
            a naive in-place write raises rather than silently corrupting the
            snapshot. The default matters: this runs once per branch-and-bound
            node, where copying every box would add allocation to the hot loop
            for no correctness gain. Pass ``copy=True`` if the body hands the
            arrays to something that may mutate them in place.

        Notes
        -----
        The fix stack is restored too, so a :meth:`Variable.fix` leaked inside
        the scope is unwound with everything else. A body that *over*-unfixes
        cannot have those frames restored (their boxes are gone); the box
        itself is still restored, which is what the solve reads.
        """
        vars_ = list(self._variables) if variables is None else list(variables)
        if copy:
            saved = [
                (
                    np.array(v.lb, dtype=np.float64, copy=True),
                    np.array(v.ub, dtype=np.float64, copy=True),
                    len(v._bound_stack),
                )
                for v in vars_
            ]
        else:
            saved = [(v.lb, v.ub, len(v._bound_stack)) for v in vars_]
        # #2281: the record of defaulted integer sides is part of the box state a
        # caller's write inside the block can change; the restore puts it back.
        records = [v._int_default_sides for v in vars_]
        completed = False
        try:
            yield self
            completed = True
        finally:
            # A `fixed()` scope entered INSIDE this one and still open when it
            # exits is the mirror image of the #1311 hazard: truncating the fix
            # stack here would pop that scope's frame, leaving a context manager
            # whose `__exit__` has nothing left to restore and no error until it
            # runs -- if it ever does. Detected before unwinding, reported after
            # the boxes are back (the restore is this scope's contract, and a
            # half-restored model is worse than a loud one) (#1321).
            orphaned: list[str] = []
            for v, (lb, ub, depth), record in zip(vars_, saved, records):
                v.lb = lb
                v.ub = ub
                del v._bound_stack[depth:]
                if record or v._int_default_sides:
                    v._int_default_sides = record
                    at = v.__dict__.get("_int_default_record_at")
                    if at:
                        for d in [d for d in at if d >= depth]:
                            del at[d]
                # Cheap in the node loop, where no variable carries a scope
                # token at all: the scan only runs for variables that do.
                toks = v._fix_scope_tokens
                if toks and any(d >= depth for _tok, d in toks):
                    orphaned.append(v.name)
                    v._fix_scope_tokens = [t for t in toks if t[1] < depth]
            if completed and orphaned:
                raise RuntimeError(
                    f"Model.saved_bounds(): a fixed() scope opened inside this "
                    f"block is still open on {orphaned}; restoring the saved "
                    "boxes would discard the fix frames it is holding. Close "
                    "every fixed() scope before the saved_bounds() block it was "
                    "opened in exits."
                )

    @_contextlib.contextmanager
    def fixed(self, *mappings, **by_name) -> "Iterator[Model]":
        """Fix several variables for the duration of a block, then restore them.

        The scoped counterpart of :meth:`Variable.fix`, and the recommended way
        to run one task on a model built for another: a regression and a design
        problem differ only in their objective and in which columns are free, so
        the model is written once and each task states what it holds fixed.

        Variables may be named by keyword, or given as a mapping keyed by
        ``Variable`` or by name — the mapping form is what indexed variables
        need, since their names are not Python identifiers.

        >>> m.minimize(sse)
        >>> with m.fixed(F=F_data):                 # regression: k, n free
        ...     fit = m.solve()
        >>> m.maximize(profit)
        >>> with m.fixed({k: fit.value(k), n: fit.value(n)}):   # design: F free
        ...     design = m.solve()

        For a *partial* fix — some elements of one variable pinned, others free
        — use :meth:`Variable.fixed` with ``where``, composing several with
        :class:`contextlib.ExitStack` when there is more than one.

        Raises
        ------
        ValueError
            If no variables were given, or one belongs to another model.
        """
        targets: list[tuple[Variable, Any]] = []
        for mapping in mappings:
            if not isinstance(mapping, dict):
                raise TypeError(
                    "Model.fixed() takes mappings of variable -> value and/or "
                    f"name=value keywords, got a positional {type(mapping).__name__}."
                )
            targets.extend((self._resolve_variable(k), v) for k, v in mapping.items())
        targets.extend((self._resolve_variable(k), v) for k, v in by_name.items())
        if not targets:
            raise ValueError(
                "Model.fixed() needs at least one variable to fix; an empty scope "
                "would silently do nothing while reading as if it fixed something."
            )
        # #1332 item 6: `m.fixed({x: 1.0}, x=2.0)` named `x` twice and the last
        # value silently won, leaving fix_depth 2 for one variable -- two frames
        # of the same scope, with one of the two values the caller asked for
        # simply discarded. Nothing about the call says which. Refuse it: the
        # caller either meant one of the two, or meant two different variables.
        _seen: dict[int, Variable] = {}
        _repeated = []
        for var, _value in targets:
            if id(var) in _seen:
                _repeated.append(var.name)
            _seen[id(var)] = var
        if _repeated:
            raise ValueError(
                f"Model.fixed() names {sorted(set(_repeated))} more than once. "
                "Only one value would take effect and the others would be "
                "discarded silently; pass each variable once."
            )

        depths = [(var, len(var._bound_stack)) for var, _ in targets]
        token = object()
        # Only variables whose fix() succeeded carry this scope's token: if a later
        # fix() raises, the ones before it must still unwind cleanly below, and the
        # original error must surface rather than a spurious out-of-order one.
        tokened: list[Variable] = []
        completed = False
        try:
            for var, value in targets:
                depth_at_entry = len(var._bound_stack)
                var.fix(value)
                var._fix_scope_tokens.append((token, depth_at_entry))
                tokened.append(var)
            yield self
            completed = True
        finally:
            # #1311: same out-of-order hazard as ``Variable.fixed()``, checked
            # per variable before any unwinding -- an overlapping (not
            # properly nested) scope on ANY one of this scope's variables must
            # not be silently popped past.
            out_of_order = [
                var.name
                for var in tokened
                if not var._fix_scope_tokens or var._fix_scope_tokens[-1][0] is not token
            ]
            if out_of_order:
                raise RuntimeError(
                    f"Model.fixed(): scopes were closed out of order on "
                    f"{out_of_order}; another fixed() scope on at least one of "
                    "these variables is still open. Close nested scopes in the "
                    "reverse order they were entered."
                )
            for var in tokened:
                var._fix_scope_tokens.pop()
            unbalanced = []
            for var, depth_before in reversed(depths):
                while len(var._bound_stack) > depth_before:
                    var.unfix()
                if len(var._bound_stack) != depth_before:
                    unbalanced.append(var.name)
            if completed and unbalanced:
                raise RuntimeError(
                    f"The body of Model.fixed() called unfix() more often than fix() "
                    f"on {unbalanced}; the boxes restored on exit are not the ones "
                    "this scope saved."
                )

    def implicit(
        self,
        residual: Callable,
        u_inputs: Sequence,
        n_unknowns: int,
        x0=None,
        *,
        tol: float = 1e-10,
        max_iter: int = 50,
        name: str = "implicit",
        formulation: str = "custom_root",
        bounds=None,
    ) -> Expression:
        """Define a vector ``v`` implicitly by ``residual(u, v) = 0`` (issue #379).

        ``v`` (length ``n_unknowns``) is compiled to a differentiable JAX inner
        solve (Newton forward, implicit-function-theorem derivatives), returned
        as an expression node you index (``v[i]``) and use like any other. It
        rides on :func:`custom`, so a model containing it is solved on the
        **local NLP path only** (no global certificate) and integers are
        rejected. ``u_inputs`` are the model expressions the block depends on
        (the DAG edges into the solve); they are required, not inferred.

        ``formulation="full_space"`` is the alternative lowering: ``v`` becomes a
        real vector variable and the residuals become real ``== 0`` constraints,
        so the block is ordinary algebra. That keeps JAX off the solve path (the
        tape refuses a ``CustomCall``) and keeps a global certificate reachable
        (a relaxation needs the equations), at the cost of the reduced-space size
        win. In that mode ``residual`` receives **discopt expressions** and must
        be written in discopt operators rather than ``jnp.*``. There is no inner
        Newton solve, so ``x0`` / ``tol`` / ``max_iter`` are *refused* rather
        than silently dropped -- select a root with ``bounds`` and warm-start
        through ``solve(initial_solution=...)``.
        See :func:`discopt.modeling.implicit_full_space`.

        See :func:`discopt.modeling.implicit` for parameter details.

        Examples
        --------
        >>> u = m.continuous("u", lb=0.1, ub=100.0)
        >>> v = m.implicit(lambda U, V: [V[0] ** 2 - U[0]], [u], n_unknowns=1)
        >>> m.minimize((v[0] - 3.0) ** 2)   # v = sqrt(u); optimum at u = 9
        """
        if formulation == "full_space":
            from discopt.modeling.implicit import implicit_full_space as _full

            # There is no inner Newton solve in this arm, so these two control
            # nothing.  Accepting them silently would let a caller tune a knob
            # that is not connected to anything (CLAUDE.md §3: no dead flags).
            for _k, _v, _default in (("tol", tol, 1e-10), ("max_iter", max_iter, 50)):
                if _v != _default:
                    raise ValueError(
                        f"{_k}= does not apply with formulation='full_space': the "
                        "residuals become ordinary equality constraints and are "
                        "solved by the outer solver, not by an inner Newton "
                        "iteration. Use solve() tolerances instead."
                    )
            return _full(self, residual, u_inputs, n_unknowns, x0, bounds=bounds, name=name)
        if formulation != "custom_root":
            raise ValueError(
                f"formulation must be 'custom_root' or 'full_space', got {formulation!r}"
            )
        if bounds is not None:
            # Not a silent no-op: the opaque node has no column to put a box on,
            # so honouring `bounds` here would mean emitting inequality
            # constraints on the node output -- a different model than the caller
            # asked for.  Refuse rather than guess (CLAUDE.md §3).
            raise ValueError(
                "bounds= is only supported with formulation='full_space'; the "
                "custom_root node has no variable to bound. Add explicit "
                "constraints on the returned node if you need them."
            )
        from discopt.modeling.implicit import implicit as _implicit

        return _implicit(residual, u_inputs, n_unknowns, x0, tol=tol, max_iter=max_iter, name=name)

    # ── Constraints ──

    def subject_to(
        self,
        constraint: Union[Constraint, list[Constraint], bool],
        name: Optional[str] = None,
    ):
        """
        Add constraint(s) to the model.

        Parameters
        ----------
        constraint : Constraint or list of Constraint
            Constraint(s) created by comparison operators (``<=``, ``>=``,
            ``==``) on expressions.
        name : str, optional
            Name for the constraint(s). Named constraints enable better
            debugging and LLM-generated explanations.

        Examples
        --------
        >>> m.subject_to(x[0] + x[1] <= 10)
        >>> m.subject_to(dm.exp(x[0]) == 1.0)
        >>> m.subject_to(A @ x <= b, name="capacity")
        >>> m.subject_to([x[i] + x[i+1] <= limits[i] for i in range(n-1)],
        ...              name="adjacent_limits")
        """
        if isinstance(constraint, Constraint):
            _reject_unnormalized_rhs(constraint, where="subject_to")
            # M5: never let ``subject_to`` corrupt an earlier row or clobber a
            # name the caller set. The corruption case is *re-adding the same
            # object* (or one already carrying a different name): stamping
            # ``constraint.name`` in place would rename the earlier model row and
            # overwrite the caller's own name. In those cases store an
            # independent copy so each row is self-contained. For the common case
            # — a fresh, unnamed constraint added once — stamp the name in place
            # so the object the caller holds *is* the object in the model
            # (identity that ``mark_coupling`` and other object-keyed APIs rely
            # on). ``_dc_replace`` is only paid when it is actually needed.
            already_added = getattr(constraint, "_added_to", None) is not None
            has_own_name = constraint.name is not None and constraint.name != name
            if already_added or has_own_name:
                # Re-add of an already-placed object, or one the caller already
                # named: copy so we never rename the earlier row nor clobber the
                # caller's name. O(1) — no scan of ``_constraints``.
                self._constraints.append(_dc_replace(constraint, name=name))
            else:
                # First placement of a fresh, unnamed constraint: stamp in place
                # (preserving object identity for object-keyed APIs) and record
                # that it now belongs to a model so a later re-add copies instead.
                constraint.name = name
                constraint._added_to = id(self)
                self._constraints.append(constraint)
            return
        if isinstance(constraint, bool):
            raise TypeError(
                f"Expected Constraint (from <=, >=, == on expressions), "
                f"got {type(constraint)}. Did you mean to compare expressions?"
            )
        # list / tuple / generator / any iterable of constraints (named
        # by ordinal: ``name_0``, ``name_1``, ...).
        try:
            items = list(constraint)
        except TypeError:
            raise TypeError(
                f"Expected Constraint or an iterable of Constraints, got {type(constraint)}."
            ) from None
        for k, c in enumerate(items):
            if not isinstance(c, Constraint):
                raise TypeError(
                    f"Expected Constraint (from <=, >=, == on expressions), "
                    f"got {type(c)} at position {k}."
                )
            _reject_unnormalized_rhs(c, where="subject_to", index=k)
            # Copy-on-name here too (M5): never mutate the caller's list elements.
            self._constraints.append(_dc_replace(c, name=f"{name}_{k}" if name else None))

    def constraint(self, index_set, rule, name: Optional[str] = None, fast: bool = True):
        """Add a family of constraints indexed by a named set.

        For each member of *index_set* the *rule* is evaluated to produce a
        constraint; tuple members are unpacked into positional arguments
        (``rule(i, j)`` for a ``dimen == 2`` set, ``rule(i)`` otherwise). A rule
        may return :data:`~discopt.modeling.indexed.Skip` to omit that member.
        Generated constraints are named ``name[key]`` (e.g. ``capacity[pitt]``).

        When ``fast`` is ``True`` (default) and every generated constraint is
        affine in a single backing variable with a uniform sense, the whole
        family is emitted as one sparse-matrix call into the Rust builder instead
        of thousands of Python expression objects. This is purely a performance
        path: the resulting model is identical, and any family that is not
        single-variable-affine transparently falls back to the general path.
        Pass ``fast=False`` to force the general path (e.g. for debugging).

        Parameters
        ----------
        index_set : Set
            The set to iterate.
        rule : callable
            ``rule(member)`` -> Constraint (or ``Skip``).
        name : str, optional
            Prefix for the per-key constraint names.
        fast : bool, default True
            Allow linear fast-path emission into the Rust builder.

        Returns
        -------
        IndexedConstraint
            A keyed view of the generated constraints.

        Examples
        --------
        >>> m.constraint(plants, lambda p: ship_out(p) <= cap[p], name="capacity")
        """
        from discopt.modeling.indexed import IndexedConstraint, Skip
        from discopt.modeling.sets import call_member

        # A family is the bulk path: every row it builds is reachable, so each
        # collection triggered while building it traverses the whole model and
        # frees nothing. Measured at ~40% of a 200 000-row build's wall
        # (see :func:`bulk_construction_gc`).
        #
        # ``members`` and ``rows`` are filled in ONE pass. This used to build a
        # list of ``(member, constraint)`` tuples and then walk it three more
        # times -- a dict comprehension, a list comprehension for the fast-linear
        # probe, and the append loop -- which on a 5 000-member family is 15 000
        # extra iterations and 5 000 throwaway tuples per family.
        members: dict = {}
        rows: list = []
        with bulk_construction_gc():
            for member in index_set:
                c = call_member(rule, member, index_set.dimen)
                if c is Skip:
                    continue
                if not isinstance(c, Constraint):
                    raise TypeError(
                        f"constraint rule for key {member!r} returned {type(c)}, "
                        "expected a Constraint (from <=, >=, == on expressions) or Skip."
                    )
                # The name is recorded, not formatted: both objects are already
                # alive (``name`` is one string shared by the whole family,
                # ``member`` is about to become a key of ``members``), so this
                # costs two stores and no allocation. ``Constraint.name``
                # formats on first read -- see ``_constraint_name_get``.
                if name:
                    c._name_family = name
                    c._name_key = member
                else:
                    c.name = None
                members[member] = c
                rows.append(c)

        if fast and self._try_fast_linear_family(rows, name):
            # Rows were emitted into the Rust builder (recorded on
            # ``_builder_linear_blocks``), NOT appended to ``_constraints`` — that would
            # double-count them in the native solve. The NLPEvaluator / feasibility check
            # / #772 guard recover them from the builder blocks via
            # ``_builder_linear_constraints()`` (#840), so their view stays complete
            # without a separate mirror. Introspection view still returned.
            return IndexedConstraint(name, index_set, members, fast=True)
        self._constraints.extend(rows)
        return IndexedConstraint(name, index_set, members, fast=False)

    def _try_fast_linear_family(self, constraints: list, name: Optional[str]) -> bool:
        """Emit a single-variable-affine, uniform-sense family into the builder.

        Returns ``True`` if the whole family was emitted as one
        ``add_linear_constraints`` call, ``False`` if it is ineligible (caller
        then uses the general expression path).
        """
        from discopt.modeling.indexed import affine_form

        if not constraints:
            return False
        sense = constraints[0].sense
        if any(c.sense != sense for c in constraints):
            return False

        rows = []
        var = None
        for c in constraints:
            aff = affine_form(c.body)
            if aff is not None and aff.merged:
                # #2090: these coefficients go into the Rust builder now, so a row
                # whose like terms were added in floating point is collected
                # exactly here (validate is too late for it) and re-read.
                _canonicalize_rows_in(c)
                aff = affine_form(c.body)
            if aff is None or aff.var is None:
                return False
            if var is None:
                var = aff.var
            elif aff.var is not var:
                return False
            rows.append(aff)

        import scipy.sparse as sp

        m_rows = len(rows)
        n_cols = var.size
        data: list[float] = []
        indices: list[int] = []
        indptr = [0]
        b = np.empty(m_rows, dtype=np.float64)
        for r, aff in enumerate(rows):
            for pos in sorted(aff.coeffs):
                coeff = aff.coeffs[pos]
                if coeff != 0.0:
                    data.append(coeff)
                    indices.append(pos)
            indptr.append(len(data))
            # body sense 0  ==>  A x sense (-const)
            b[r] = -aff.const
        A = sp.csr_matrix(
            (
                np.asarray(data, dtype=np.float64),
                np.asarray(indices, dtype=np.int64),
                np.asarray(indptr, dtype=np.int64),
            ),
            shape=(m_rows, n_cols),
        )
        self.add_linear_constraints(A, var, sense, b, name)
        return True

    # ── Decomposition annotations (Benders / Lagrangian) ──

    def _decomp_var_name(self, var) -> str:
        """Resolve a decomposition annotation target to a variable name.

        Accepts a :class:`Variable`, a name string, or an indexed reference
        (``y[i]``) / single-variable expression — resolving the latter to its
        *base variable name*, since decomposition staging is whole-variable.
        Resolving ``y[i]`` to ``"y"`` (rather than the stray ``str(y[i])``, e.g.
        ``"y[3][0]"``, which silently never matches) prevents an annotated
        variable from being misclassified into the recourse subproblem.
        """
        if isinstance(var, Variable):
            return var.name
        if isinstance(var, str):
            return var
        base = getattr(var, "base", None)
        if isinstance(base, Variable):
            return base.name
        try:
            from discopt._relax.gdp_reformulate import _collect_variables

            names = list(_collect_variables(var).keys())
        except Exception:
            names = []
        if len(names) == 1:
            return names[0]
        raise TypeError(
            f"Cannot resolve a decomposition variable from {var!r}; pass a Variable "
            "(e.g. model.first_stage(y)). Staging is per whole variable, so an "
            "expression spanning zero or multiple variables is ambiguous."
        )

    def set_stage(self, var: "Variable", stage: int) -> "Model":
        """Tag a variable with a decomposition stage.

        Stage ``1`` denotes a *complicating* / first-stage variable (held in
        the Benders master); higher stages denote recourse/subproblem
        variables. Consumed by :func:`discopt.decomposition.detect_decomposition`.
        Accepts a :class:`Variable`, a name string, or an indexed reference
        (``y[i]``, resolved to the whole variable). Returns ``self`` for chaining.
        """
        self._decomp_stages[self._decomp_var_name(var)] = int(stage)
        return self

    def first_stage(self, *vars: "Variable") -> "Model":
        """Mark variables as first-stage (complicating) for Benders."""
        for v in vars:
            self.set_stage(v, 1)
        return self

    def second_stage(self, *vars: "Variable") -> "Model":
        """Mark variables as second-stage (recourse/subproblem) for Benders."""
        for v in vars:
            self.set_stage(v, 2)
        return self

    def set_block(self, var: "Variable", block_id) -> "Model":
        """Assign a variable — or each of its elements — to a block.

        Two granularities, one vocabulary (#1370):

        * ``set_block(y, 3)`` assigns the WHOLE variable to block 3. This is the
          decomposition annotation :func:`discopt.decomposition.detect_decomposition`
          has always consumed, and it is stored exactly where it always was.
        * ``set_block(V, ids)`` with an array-like ``ids`` broadcastable to
          ``V.shape`` assigns block membership **per element**. A model that
          stores K replicas in one array variable — K contingency cases, K
          scenarios, K trajectories — cannot say what it means at whole-variable
          granularity, and that is the case the structure-aware KKT path exists
          for.

        A **negative** id means *shared* (the arrowhead border):
        ``model.set_block(p_base, -1)``.

        Element labels are consumed by
        :mod:`discopt.block_structure`, which resolves them into the emitted
        NLP's index space and hands them to POUNCE. They are deliberately NOT
        written into ``_decomp_blocks``: a variable whose elements span several
        blocks has no single decomposition block, and inventing one would feed
        ``discopt.decomposition`` a partition the model never declared.

        Accepts a :class:`Variable`, a name string, or an indexed reference
        (``y[i]``, resolved to the whole variable).
        """
        name = self._decomp_var_name(var)
        if isinstance(block_id, (int, np.integer)) and not isinstance(block_id, bool):
            self._decomp_blocks[name] = int(block_id)
            self._block_labels_var.pop(name, None)
            return self

        target = None
        for v in self._variables:
            if v.name == name:
                target = v
                break
        if target is None:
            raise ValueError(
                f"set_block: no variable named {name!r} on this model, so an "
                "element-wise block declaration cannot be shape-checked. Add the "
                "variable first, or pass the Variable object."
            )
        ids = np.asarray(block_id)
        if ids.dtype == bool or not np.issubdtype(ids.dtype, np.integer):
            raise TypeError(
                f"set_block: block ids for {name!r} must be integers (negative = shared); "
                f"got dtype {ids.dtype}."
            )
        shape = target.shape if target.shape != () else (1,)
        try:
            ids = np.broadcast_to(ids, shape)
        except ValueError as exc:
            raise ValueError(
                f"set_block: block ids of shape {ids.shape} are not broadcastable to "
                f"variable {name!r} of shape {target.shape}."
            ) from exc
        self._block_labels_var[name] = np.ascontiguousarray(ids, dtype=np.int64).reshape(-1)
        self._decomp_blocks.pop(name, None)
        return self

    def set_constraint_block(self, constraint: Union[Constraint, str], block_id) -> "Model":
        """Assign a constraint — or each of its rows — to a block (#1370).

        ``block_id`` is an int, or an array-like of one id per row for an
        array-valued body (one :class:`Constraint`, many rows). Negative means
        *linking*: the row's dual is placed with the shared border.

        Declaring constraints is **optional**. Left undeclared, a row's block is
        derived from the columns it actually touches in the emitted NLP's
        Jacobian — a row over block ``b``'s columns (plus shared ones) is block
        ``b``'s, a row spanning two blocks is linking. That derivation is
        mechanical, not a heuristic: it reads the declared variable partition and
        the row's own sparsity, and it is checked either way. Declare a row
        explicitly to override it — most usefully to push a row that touches only
        shared columns onto the border deliberately.

        Accepts the :class:`Constraint` object returned by :meth:`subject_to`, or
        its name. Rows added through the fast builder path
        (:meth:`add_linear_constraints`) are materialized fresh on every read, so
        their object identity does not survive; declare those **by name**.
        """
        ids = np.asarray(block_id)
        if ids.dtype == bool or not np.issubdtype(ids.dtype, np.integer):
            raise TypeError(
                "set_constraint_block: block ids must be integers (negative = linking); "
                f"got dtype {ids.dtype}."
            )
        labels = np.ascontiguousarray(ids, dtype=np.int64).reshape(-1)
        if isinstance(constraint, str):
            self._block_labels_con[constraint] = labels
            return self
        cname = getattr(constraint, "name", None)
        self._block_labels_con[id(constraint)] = labels
        if cname:
            self._block_labels_con[cname] = labels
        return self

    def mark_coupling(self, constraint: Union[Constraint, str]) -> "Model":
        """Mark a constraint as *coupling* (to dualize in Lagrangian relaxation).

        Accepts the :class:`Constraint` object added via :meth:`subject_to`, or
        its name string. Coupling constraints are the linking rows whose removal
        separates the model into independent blocks.
        """
        if isinstance(constraint, str):
            self._coupling_keys.add(constraint)
        else:
            self._coupling_keys.add(id(constraint))
            cname = getattr(constraint, "name", None)
            if cname:
                self._coupling_keys.add(cname)
        return self

    def analyze_decomposition(self):
        """Analyze this model's decomposition structure (does not solve it).

        Returns a
        :class:`~discopt.decomposition.advisor.DecompositionAdvisor` exposing the
        structure report, discovered decomposition candidates, block partition,
        and graph views/exports. See ``docs/design/decomposition-advisor.md``.
        Runs :meth:`validate` first, the canonicalization every ``solve`` applies.
        """
        from discopt.decomposition import analyze_decomposition

        return analyze_decomposition(self)

    # ── Fast construction API (direct arena building) ──

    def _get_builder(self):
        """Lazily initialize the Rust model builder, registering all existing variables."""
        if self._builder is None:
            from discopt._rust import PyModelBuilder

            self._builder = PyModelBuilder()
            for var in self._variables:
                var._builder_idx = self._builder.add_variable(
                    var.name,
                    var.var_type.value,
                    list(var.shape),
                    var.lb.flatten().astype(np.float64),
                    var.ub.flatten().astype(np.float64),
                )
        return self._builder

    def add_linear_constraints(
        self,
        A,
        x: "Variable | VarBlock | list[Variable] | tuple[Variable, ...]",
        sense: str,
        b,
        name: Optional[str] = None,
    ):
        """
        Add linear constraints in bulk: each row of A defines one constraint.

        Bypasses Python expression objects — builds directly into the Rust
        expression arena via a single PyO3 call. For large models (1000+
        constraints), this is orders of magnitude faster than operator
        overloading.

        Parameters
        ----------
        A : scipy.sparse matrix or numpy.ndarray
            Constraint coefficient matrix, shape ``(m, n)`` where
            ``n == x.size``. Any scipy sparse format (CSR, CSC, COO) or
            dense array. Automatically converted to CSR internally.
        x : Variable, VarBlock, or list/tuple of Variable
            Array variable whose size matches ``A.shape[1]``, or several variables
            whose flattened entries, in order, are the columns of ``A``.
        sense : str
            ``"<="``, ``"=="``, or ``">="``. Applied to all rows.
        b : numpy.ndarray or float
            Right-hand side, shape ``(m,)`` or scalar (broadcast).
        name : str, optional
            Prefix for constraint names (``"{name}_0"``, ``"{name}_1"``, ...).
            After a solve, ``result.constraint_duals[name]`` holds the block's
            duals as one ``(m,)`` array in row order, alongside the per-row
            ``"{name}_{r}"`` keys (#1680).

        Raises
        ------
        ValueError
            If dimensions don't match or sense is invalid.
        """
        import scipy.sparse as sp

        if sense not in ("<=", "==", ">="):
            raise ValueError(f"Invalid sense '{sense}'. Expected '<=', '==', or '>='.")

        # Convert to CSR. A sparse input may store several entries for one row and
        # column; they are summed *exactly* here (#2258), before any path reads the
        # matrix. ``tocsr``/``sum_duplicates`` add them in binary64, and the LP
        # reader, the affine evaluator and ``verify_point`` each did it in their own
        # order: ``2**53, 1, -2**53`` in one cell read as 0 on one path and as 1, 2 or
        # 0 on others, so a solve certified x = 10 for the row ``x <= 1``.
        if not sp.issparse(A):
            A = sp.csr_matrix(np.asarray(A, dtype=np.float64))
        else:
            A = _csr_with_exact_duplicates(A)

        if isinstance(x, (list, tuple)):
            x = x[0] if len(x) == 1 else VarBlock(x)
        m_rows, n_cols = A.shape
        if n_cols != x.size:
            raise ValueError(f"A has {n_cols} columns but variable '{x.name}' has size {x.size}.")

        b = np.broadcast_to(np.asarray(b, dtype=np.float64), (m_rows,)).copy()
        # A scalar variable goes through the column-map path, which references it by
        # its variable node. The single-variable builder call emits ``x[0]`` (an Index
        # node), which on a scalar variable lost the row: a one-variable model read
        # from a file solved to 0 instead of 1 (caught by the #1561 verification).
        record = x
        if not isinstance(x, VarBlock) and getattr(x, "shape", None) == ():
            x = VarBlock([x])
        if isinstance(x, VarBlock):
            builder = self._get_builder()
            chk = x._checked
            if chk is not None and chk[0] == id(self) and chk[1] == len(self._variables):
                block_idx = chk[2]
            else:
                missing = [v.name for v in x.vars if not hasattr(v, "_builder_idx")]
                if missing:
                    raise ValueError(
                        f"Variables {missing} are not registered in the builder. Ensure "
                        "they were created via m.continuous/binary/integer."
                    )
                owned = {id(v) for v in self._variables}
                foreign = [v.name for v in x.vars if id(v) not in owned]
                if foreign:
                    raise ValueError(f"Variables {foreign} do not belong to this model.")
                block_idx = np.array([v._builder_idx for v in x.vars], dtype=np.int64)
                # Same model, same variables (append-only list): the checks hold. A
                # builder reset re-registers variables with the same indices.
                x._checked = (id(self), len(self._variables), block_idx)
            pos, local = x.columns()
            builder.add_linear_constraints_cols(
                A.indptr.astype(np.int64),
                A.indices.astype(np.int64),
                A.data,
                block_idx[pos],
                local.astype(np.int64),
                sense,
                b,
                name,
            )
            self._builder_linear_blocks.append((A, record, sense, b, name))
            return

        builder = self._get_builder()
        if not hasattr(x, "_builder_idx"):
            raise ValueError(
                f"Variable '{x.name}' is not registered in the builder. "
                "Ensure the variable was created via m.continuous/binary/integer."
            )

        builder.add_linear_constraints(
            A.indptr.astype(np.int64),
            A.indices.astype(np.int64),
            A.data,
            x._builder_idx,
            sense,
            b,
            name,
        )
        # Record the block so exporters (.nl) and introspection can recover the
        # constraints that live only in the Rust builder. CSR ``A`` and ``b`` are
        # already in their final float form here.
        self._builder_linear_blocks.append((A, x, sense, b, name))

    def add_linear_objective(
        self,
        c,
        x: Variable,
        constant: float = 0.0,
        sense: str = "minimize",
    ):
        """
        Set a linear objective: ``c'x + constant``.

        Parameters
        ----------
        c : numpy.ndarray
            Cost vector, shape ``(n,)`` matching ``x.size``.
        x : Variable
            Variable reference.
        constant : float, default 0.0
            Scalar offset.
        sense : str, default "minimize"
            ``"minimize"`` or ``"maximize"``.
        """
        c = np.asarray(c, dtype=np.float64).flatten()
        if c.shape[0] != x.size:
            raise ValueError(
                f"c has {c.shape[0]} elements but variable '{x.name}' has size {x.size}."
            )
        builder = self._get_builder()
        if not hasattr(x, "_builder_idx"):
            raise ValueError(f"Variable '{x.name}' is not registered in the builder.")
        builder.set_linear_objective(c, x._builder_idx, constant, sense)
        self._objective = Objective(
            _builder_objective_expression(c, x, constant),
            ObjectiveSense.MINIMIZE if sense == "minimize" else ObjectiveSense.MAXIMIZE,
        )
        # See ``_builder_objective_expression``: the Rust repr takes the builder's
        # own objective when this flag is set; every Python reader gets the expression.
        self._objective._is_placeholder = True
        # Record the block so .nl export can recover the objective that lives
        # only in the Rust builder (``_objective`` holds a zero placeholder).
        self._builder_linear_objective = (c, x, float(constant), sense)
        self._builder_quadratic_objective = None

    def add_quadratic_objective(
        self,
        Q,
        c,
        x: Variable,
        constant: float = 0.0,
        sense: str = "minimize",
    ):
        """
        Set a quadratic objective: ``0.5 x'Qx + c'x + constant``.

        Parameters
        ----------
        Q : scipy.sparse matrix or numpy.ndarray
            Quadratic coefficient matrix, shape ``(n, n)``. A non-symmetric ``Q``
            is replaced by its symmetric part ``(Q + Q')/2``, which has the same
            ``x'Qx``; a symmetric ``Q`` is stored as given.
        c : numpy.ndarray
            Linear coefficient vector, shape ``(n,)``.
        x : Variable
            Variable reference.
        constant : float, default 0.0
            Scalar offset.
        sense : str, default "minimize"
            ``"minimize"`` or ``"maximize"``.
        """
        import scipy.sparse as sp

        n = x.size
        c = np.asarray(c, dtype=np.float64).flatten()
        if c.shape[0] != n:
            raise ValueError(f"c has {c.shape[0]} elements but variable '{x.name}' has size {n}.")

        if not sp.issparse(Q):
            Q = sp.csr_matrix(np.asarray(Q, dtype=np.float64))
        elif not sp.isspmatrix_csr(Q):
            Q = Q.tocsr()
        Q = Q.astype(np.float64)

        if Q.shape != (n, n):
            raise ValueError(f"Q has shape {Q.shape} but expected ({n}, {n}).")
        # #1818: the builder reads only the upper triangle, so a non-symmetric Q
        # built a different objective than ``0.5 x'Qx`` -- an upper-only Q doubled
        # its cross terms and a lower-only Q lost them. Store the symmetric part,
        # which has the same ``x'Qx``; every reader (the Rust builder, the Python
        # objective expression, the retained block, the convexity certificate)
        # then sees that one matrix. ``0.5*Q + 0.5*Q'`` rather than ``(Q + Q')/2``
        # so a huge entry cannot overflow; a symmetric Q is left untouched.
        if (Q != Q.T).nnz:
            Q = (0.5 * Q + 0.5 * Q.T).tocsr()
        Q.sum_duplicates()
        Q.sort_indices()

        builder = self._get_builder()
        if not hasattr(x, "_builder_idx"):
            raise ValueError(f"Variable '{x.name}' is not registered in the builder.")
        builder.set_quadratic_objective(
            Q.indptr.astype(np.int64),
            Q.indices.astype(np.int64),
            Q.data,
            c,
            x._builder_idx,
            constant,
            sense,
        )
        self._objective = Objective(
            _builder_objective_expression(c, x, constant, Q),
            ObjectiveSense.MINIMIZE if sense == "minimize" else ObjectiveSense.MAXIMIZE,
        )
        # See ``_builder_objective_expression``.
        self._objective._is_placeholder = True
        # Record the block so .nl export can recover the quadratic objective
        # that lives only in the Rust builder.
        self._builder_quadratic_objective = (Q, c, x, float(constant), sense)
        self._builder_linear_objective = None

    # ── Logical constraints (GDP) ──

    def if_then(
        self,
        indicator: "Expression | BooleanVar | LogicalNot",
        then_constraints: list[Constraint],
        name: Optional[str] = None,
    ):
        """
        Add indicator (if-then) constraint.

        If ``indicator == 1``, all *then_constraints* must hold.
        If ``indicator == 0``, the constraints are relaxed.
        Avoids manual big-M formulation.

        Parameters
        ----------
        indicator : Variable, BooleanVar or expression
            A binary variable (or ``BooleanVar``). The complement ``1 - z`` of a
            binary ``z`` (or ``~b`` of a ``BooleanVar``) is also accepted and means
            "if ``z == 0``"; it is stored as ``z`` with active value 0 (#1677). Any
            other expression is refused with a ``TypeError``.
        then_constraints : list of Constraint
            Constraints that must hold when the indicator is active.
        name : str, optional
            Base name for the constraint group.

        Notes
        -----
        How the indicator is lowered depends on ``gdp_method``. Under
        ``"binary_multiplication"`` (#1775 G2.5) each row ``body (sense) 0``
        becomes the exact ``body * z (sense) 0`` (``body * (1 - z)`` for an
        indicator active at 0), with no big-M. Under every other method it is
        lowered to a big-M row. ``M`` is the tightest valid
        value discopt can derive for the body over the variable box (an LP bound
        for a linear body, interval arithmetic otherwise) **times a 1.01 safety
        factor** (``_relax/gdp_reformulate.py``); a body with no finite bound is
        refused. So ``m.if_then(z, [x >= 500])`` with ``x`` in ``[0, 1000]``
        becomes ``x - 500 >= -505 (1 - z)``, i.e. ``505 z - x <= 5``, not the
        exact ``x >= 500 z``. Both are valid and agree at integral ``z``; the
        1% margin only loosens the LP relaxation (here ``z <= 5/505`` rather
        than ``z = 0`` at ``x = 0``), which can cost root bound and nodes on
        models dominated by such rows. When that matters, write the exact
        big-M row by hand (#1620).

        Examples
        --------
        >>> m.if_then(y[0], [x[0] >= 10, x[1] <= 50], name="unit0_active")
        """
        # #1617: a ``BooleanVar`` (from :meth:`boolean`) is backed by a binary
        # Variable; use it. Any other logical expression has no single 0/1 column to
        # act as the indicator -- refuse here, at the call, rather than with a
        # ``float()`` TypeError deep inside ``solve()``. #1677: a complemented
        # binary ``1 - z`` (or ``~b``) is the same column with ``active_value=0``.
        indicator, active_value = _normalize_indicator(indicator, "if_then")
        # Only a row can be an indicator constraint. A disjunction (or any other
        # container) passed here was stored as the row and then crashed every walk
        # that reads ``.constraint.body`` -- pickle, deepcopy, clone -- while solve
        # reported it as never added (#1797 review S1). Refuse it here, before
        # anything is recorded.
        for k, c in enumerate(then_constraints):
            if not isinstance(c, Constraint):
                raise TypeError(
                    f"if_then: then_constraints[{k}] is a {type(c).__name__}, not a "
                    "Constraint. if_then accepts only rows; to make a disjunction "
                    "conditional on a selector, nest it in a block: "
                    "d = m.make_disjunct(name); d.add_disjunction(...), then add d with "
                    "m.add_disjunction([d, ...])"
                )
        # #1858: refuse a raw non-zero rhs before anything is recorded.
        _reject_unnormalized_rhs_in(list(then_constraints), where=f"if_then {name or '<anon>'!r}")
        for k, c in enumerate(then_constraints):
            c.name = f"{name}_then_{k}" if name else None
            # Store as indicator constraint; Rust presolve will handle
            # reformulation to big-M or GDP branching
            self._constraints.append(
                _IndicatorConstraint(
                    indicator=indicator,
                    constraint=c,
                    active_value=active_value,
                )
            )

    def either_or(
        self,
        disjuncts: list[list[Constraint]],
        name: Optional[str] = None,
        *,
        semantics: Union[DisjunctionSemantics, str] = DisjunctionSemantics.SELECT_ONE,
        big_m: Union[float, dict, None] = None,
    ) -> "_DisjunctiveConstraint":
        """
        Add disjunctive constraint (Generalized Disjunctive Programming).

        Exactly one disjunct is **selected**, and the selected disjunct's
        constraints are enforced
        (:attr:`DisjunctionSemantics.SELECT_ONE`). An *unselected* disjunct's
        constraints are not enforced, but they may still happen to hold: the
        projection of the feasible set onto the model variables is the
        **union** of the disjuncts, so a point lying in the overlap of two
        disjuncts stays feasible and is assigned to one selected mode.

        This is *not* "exactly one group of constraints holds". That stronger
        reading is :attr:`DisjunctionSemantics.EXACTLY_ONE_TRUE`, which
        requires reifying every selector, and which no lowering implements yet
        (issue #1124) — passing it raises rather than silently reusing one-way
        activation.

        Parameters
        ----------
        disjuncts : list of list of Constraint
            Each inner list is a disjunct -- a group of constraints that
            must all hold together.
        name : str, optional
            Name for the disjunction.
        semantics : DisjunctionSemantics or str, default ``SELECT_ONE``
            The declared meaning of the disjunction. Recorded on the model.
            ``OR`` (at least one selected) is lowered by big-M (#1775 G1.4); a
            lowering that does not encode the declared value refuses it rather
            than approximating it.
        big_m : float or dict, optional
            User big-M values for ``gdp_method="big-m"`` (#1775 G2.6; Pyomo's
            ``bigM``). A number applies to every row; a dict maps a row
            (the ``Constraint`` object passed in ``disjuncts``) to its M, with
            the key ``None`` as the default for the others. Rows without a value
            get the computed M as before. Each value is a magnitude and must be
            finite and ``>= 0``. Each one is checked when the model is lowered:
            it is certified when it is at least the interval bound of the row's
            body, or at least a rigorous LP bound over the model's linear rows and
            the linear rows of each region where the row is relaxed (each other
            disjunct, and for a nested disjunction each region where an enclosing
            disjunct is off); it is **refused** when the LP finds a point
            feasible for the whole model that the value would cut; and otherwise
            it is used but not certified, in which case ``solve`` withholds the
            certificate (``optimal`` becomes ``feasible``, ``infeasible`` becomes
            ``unknown``, and the bound is dropped), so a user M can never produce
            a false certificate. The withhold applies only when this solve's
            lowering actually read the value; a hull solve does not. Other
            methods ignore it, with a warning.

        Examples
        --------
        >>> m.either_or([
        ...     [x[0] <= 5, x[1] >= 10],   # mode A
        ...     [x[0] >= 15, x[1] <= 3],   # mode B
        ... ], name="operating_mode")

        The returned disjunction's :attr:`~_DisjunctiveConstraint.indicators` are
        its per-disjunct selection booleans, usable in :meth:`logical`:

        >>> d = m.either_or([[x[0] <= 5], [x[0] >= 15]], name="mode")
        >>> m.logical(d.indicators[0].implies(other_disjunct_indicator))
        """
        _refuse_empty_disjunction(disjuncts, "either_or", name)
        _reject_unnormalized_rhs_in(disjuncts, where=f"either_or {name or '<anon>'!r}")  # #1858
        dc = _DisjunctiveConstraint(
            disjuncts=disjuncts,
            name=name,
            semantics=_coerce_disjunction_semantics(semantics),
            _model=self,
            big_m=_normalize_big_m(big_m, disjuncts, name),
        )
        _key_big_m(dc)
        self._constraints.append(dc)
        return dc

    def complementarity(
        self,
        x: "Expression",
        y: "Expression",
        *,
        method: str = "gdp",
        name: Optional[str] = None,
        scale: Optional[float] = None,
    ):
        r"""Add a complementarity constraint :math:`0 \le x \perp y \ge 0`.

        Enforces ``x >= 0``, ``y >= 0`` and ``x * y == 0`` — at least one of
        ``x``, ``y`` is zero. This is the defining structure of MPCCs/MPECs,
        KKT-reformulated bilevel programs, and equilibrium models. The smooth
        bilinear equality ``x * y == 0`` is avoided: its relaxation cannot
        capture the either/or structure and it is degenerate at the solution
        (standard constraint qualifications fail).

        This is the fluent front-end for the reformulations in
        :mod:`discopt.mpec`; the condition is recorded on the model (see
        ``Model._complementarities``) and immediately reformulated into ordinary
        constraints solved by :meth:`solve`.

        Vector/array operands are complementarity **elementwise**: for every
        index ``i`` independently, ``x_i · y_i == 0`` with ``x_i, y_i >= 0`` (a
        separate disjunction per index — *not* a single "all ``x`` zero or all
        ``y`` zero" choice). A scalar side broadcasts against a vector side;
        incompatible shapes are rejected.

        Parameters
        ----------
        x, y : Expression
            The complementary pair. Both are constrained non-negative. May be
            scalars or equally-shaped (or scalar-broadcastable) arrays.
        method : {"gdp", "sos1"}, default "gdp"
            Reformulation. ``"gdp"`` lowers to the exact disjunction
            ``(x == 0) ∨ (y == 0)`` (big-M with a selector binary), so
            branch-and-bound branches on the finite either/or choice and the
            integrality-aware FBBT infers the partner is zero when one side is
            bounded away from zero — markedly fewer nodes than the bilinear
            encoding. ``"sos1"`` encodes the pair as a Special Ordered Set of
            type 1. For the Scholtes regularization homotopy (a *solve-time*
            algorithm, not a static reformulation), use
            :func:`discopt.mpec.solve_mpec` with ``method="scholtes"``.
        name : str, optional
            Base name for the generated constraints.
        scale : float, optional
            Characteristic magnitude of the relation's residual, recorded as
            provenance for a meaningful residual tolerance when the two
            operands carry unrelated physical magnitudes (#1147). It changes
            no lowering and no solver behaviour.

        Returns
        -------
        discopt.mpec.Complementarity
            The recorded relation. It keeps the *source* operands and survives
            every model-rebuilding pass, so a residual computed from it is a
            residual of the declared condition rather than of the lowered rows.

        Examples
        --------
        >>> # min (x-1)^2 + (y-1)^2  s.t.  0 <= x ⊥ y >= 0
        >>> m.complementarity(x, y)
        """
        from discopt import mpec
        from discopt.transformations import get as _get_transformation

        if method in ("gdp", "sos1"):
            lower = _get_transformation(f"mpec.{method}")
        elif method == "scholtes":
            raise ValueError(
                "method='scholtes' is a solve-time regularization homotopy, not "
                "a static reformulation. Build the pair with "
                "discopt.mpec.complementarity(...) and call "
                "discopt.mpec.solve_mpec(model, pairs, method='scholtes')."
            )
        else:
            raise ValueError(
                f"unknown complementarity method {method!r}; use 'gdp' or 'sos1' "
                "(or discopt.mpec.solve_mpec for 'scholtes')."
            )

        # The relation is the durable record (#1147): it keeps the SOURCE
        # operands, the bounds the relation declares on them, its role and its
        # scale, and every rebuilding pass forwards it. The rows emitted below
        # are the lowering; they are not recoverable back into a source residual.
        pair = mpec.Complementarity(
            _wrap(x),
            _wrap(y),
            name,
            role=mpec.ComplementarityRole.NCP_PAIR,
            scale=scale,
        )
        lower.apply(self, pairs=[pair])
        self._complementarities.append(pair)
        return pair

    def mcp(
        self,
        residual: "Expression",
        variable: "Expression",
        *,
        lb: Optional[float] = None,
        ub: Optional[float] = None,
        method: str = "gdp",
        name: Optional[str] = None,
        scale: Optional[float] = None,
    ):
        r"""Declare the box-bounded mixed-complementarity relation
        :math:`F(z) \perp z \in [l, u]`.

        The MCP form pairs a *residual* with a **bounded** variable rather than
        with a second nonnegative expression:

        * :math:`z = l`       ⇒ :math:`F(z) \ge 0`
        * :math:`l < z < u`   ⇒ :math:`F(z) = 0`
        * :math:`z = u`       ⇒ :math:`F(z) \le 0`

        :math:`l = 0, u = +\infty` is exactly :meth:`complementarity`, and is
        recorded as such so the two forms never diverge on the case they share.

        The relation is lowered on declaration, exactly, by splitting it into at
        most two symmetric NCP pairs on shifted slacks (#2058):

        * both bounds finite, ``l < u``: ``F = w⁺ − w⁻`` with
          ``0 <= w⁺ ⊥ z − l >= 0`` and ``0 <= w⁻ ⊥ u − z >= 0``. ``w±`` are
          bounded by the interval enclosure of ``F``; if that enclosure is not
          finite the declaration is refused (declare finite bounds on the
          variables ``F`` reads);
        * ``u = +inf``: ``0 <= F ⊥ z − l >= 0``; ``l = -inf``:
          ``0 <= −F ⊥ u − z >= 0``;
        * both infinite: ``F == 0``; ``l == u``: ``z`` is pinned and ``F`` free.

        Each pair goes to the same lowering :meth:`complementarity` uses, and
        the rows ``z >= l`` / ``z <= u`` are emitted as constraints (the box may
        be narrower than ``z``'s declared bounds). The relation keeps its source
        operands and round-trips through every rebuilding pass, so the residual
        report measures the box condition itself (the natural map
        ``|z − mid(l, u, z − F)|``), not the rows.

        A vector relation uses the same scalar box for every element; declare
        per-element relations for per-element boxes.

        Parameters
        ----------
        residual : Expression
            The residual :math:`F(z)`.
        variable : Expression
            The complementary variable :math:`z`.
        lb, ub : float, optional
            The box. Default to ``variable``'s declared bounds when it is a
            plain scalar :class:`Variable`; required otherwise, since the
            relation's semantics *are* those bounds.
        method : {"gdp", "sos1"}, default "gdp"
            The exact lowering each NCP half goes to, as in
            :meth:`complementarity`. For the Scholtes homotopy build the relation
            with :func:`discopt.mpec.box_mcp` and call
            :func:`discopt.mpec.solve_mpec` with ``method="scholtes"``.
        name : str, optional
            Name of the relation.
        scale : float, optional
            Characteristic residual magnitude, for a meaningful tolerance when
            the residual and the variable carry unrelated physical magnitudes.

        Returns
        -------
        discopt.mpec.Complementarity
            The recorded relation.

        Raises
        ------
        ValueError
            For an empty box, array ``lb``/``ub``, an unknown method, or a
            two-sided box whose residual has no finite interval enclosure. A
            refused declaration leaves the model unchanged.

        Examples
        --------
        >>> # Excess supply F(p) = (2p - 2) - (10 - p) = 3p - 12 on p in [0, 3].
        >>> # Uncapped, the market clears at p = 4; with the cap p_max = 3 it
        >>> # clears at the cap with excess demand, F(3) = -3 <= 0.
        >>> m = dm.Model("price_cap")
        >>> p = m.continuous("p", lb=0, ub=3)
        >>> m.minimize((p - 10) ** 2)
        >>> rel = m.mcp(3 * p - 12, p)  # the box defaults to p's bounds [0, 3]
        >>> round(m.solve().objective, 6)
        49.0
        """
        from discopt import mpec
        from discopt.transformations import get as _get_transformation

        if method == "scholtes":
            raise ValueError(
                "method='scholtes' is a solve-time regularization homotopy, not "
                "a static reformulation. Build the relation with "
                "discopt.mpec.box_mcp(...) and call "
                "discopt.mpec.solve_mpec(model, [relation], method='scholtes')."
            )
        if method not in ("gdp", "sos1"):
            raise ValueError(
                f"unknown complementarity method {method!r}; use 'gdp' or 'sos1' "
                "(or discopt.mpec.solve_mpec for 'scholtes')."
            )
        pair = mpec.box_mcp(_wrap(residual), _wrap(variable), lb=lb, ub=ub, name=name, scale=scale)
        _get_transformation(f"mpec.{method}").apply(self, pairs=[pair])
        self._complementarities.append(pair)
        return pair

    def _branch_bounds(
        self,
        then_expr: "Expression",
        else_expr: "Expression",
        then_cond: Optional["Constraint"] = None,
        else_cond: Optional["Constraint"] = None,
    ) -> tuple[float, float]:
        """Sound bounds for an if_else auxiliary variable.

        The auxiliary ``w`` must enclose the image of *both* branches, since
        either may be selected. Returns ``(min lo, max hi)`` over the static
        interval enclosures of the two branch expressions. Falls back to the
        default (huge) bounds when either enclosure is non-finite or cannot be
        computed; presolve/FBBT tighten from there. Always sound.

        Each branch is enclosed over the box restricted by the condition under
        which it is SELECTED (``then_cond`` / ``else_cond``), not the whole box:
        a branch is never evaluated outside its own region, and on
        ``if_else(x >= 0, exp(x) - 1, log(-x + 3))`` over ``x in [-10, 10]`` the
        whole-box enclosure of ``log(-x + 3)`` is undefined, which left ``w`` on
        the default +/-9.999e19 box -- a bound the hull reformulation rightly
        refuses, so the solve raised (#1043's own repro). The restriction is one
        bound-propagation step on a linear condition over scalar variables;
        anything else keeps the declared box, which is always sound.
        """
        from discopt._relax.convexity.interval_eval import evaluate_interval

        los: list[float] = []
        his: list[float] = []
        for e, cond in ((then_expr, then_cond), (else_expr, else_cond)):
            box = _condition_box(cond)
            try:
                iv = evaluate_interval(e, self, box)
                lo = float(np.asarray(iv.lo).reshape(()))
                hi = float(np.asarray(iv.hi).reshape(()))
            except Exception:
                return -9.999e19, 9.999e19
            if not (np.isfinite(lo) and np.isfinite(hi)):
                return -9.999e19, 9.999e19
            los.append(lo)
            his.append(hi)
        return min(los), max(his)

    def _refresh_if_else_bounds(self, *, context: str) -> int:
        """Re-derive every :meth:`if_else` auxiliary's box; return how many changed.

        ``w``'s bounds are :meth:`_branch_bounds` of the two branches over the box
        *at declaration*. Widening a variable a branch reads afterwards left them in
        place: ``w = if_else(x >= 0.5, x, 2 * x)`` on ``x in [0, 1]``, then
        ``x.ub = 10``, ``maximize(w)`` was certified ``optimal`` at 1, against a true
        10 (#2061 review; the same stale-derived-bound defect as the complementarity
        lowerings). Every solve boundary and ``save`` call this first.

        Bounds the user set on ``w`` themselves are model constraints, not
        derivations: when ``w``'s box differs from the one last derived, the new
        derivation is intersected with it rather than replacing it. An auxiliary
        read from a file (``last is None``, :func:`_recover_if_else_auxes`) has no
        record of which bounds were derived, so its box is kept, and a box that no
        longer encloses the branches is refused instead of solved on.
        """
        # Inside a solve the boundary restores every box on exit
        # (:func:`_solve_owns_model`), so a write there is temporary and must
        # not move ``last`` -- else the restored box would read as a user edit.
        persistent = id(self) not in _SOLVE_OWNED_MODELS.get()
        changed = 0
        for a in getattr(self, "_if_else_auxes", ()):
            lo, hi = self._branch_bounds(a.then_expr, a.else_expr, a.cond, a.complement)
            cur = (float(np.asarray(a.w.lb)), float(np.asarray(a.w.ub)))
            if a.last is None:
                if lo < cur[0] or hi > cur[1]:
                    raise ValueError(
                        f"{context}: the if_else auxiliary {a.w.name!r} was read from a "
                        f"file with bounds [{cur[0]:g}, {cur[1]:g}], but its branches now "
                        f"range over [{lo:g}, {hi:g}]: a variable they read was widened "
                        "after loading. The file records the bounds if_else derived at "
                        "save time, not how they were derived, so they could cut the "
                        "optimum. Re-declare the if_else on a model built in this session "
                        "(or narrow the bound back) before solving or saving."
                    )
                continue
            if cur != a.last:
                # The user re-bounded w: keep that constraint, tighten within it.
                ilo, ihi = max(lo, cur[0]), min(hi, cur[1])
                lo, hi = (ilo, ihi) if ilo <= ihi else cur
            if (lo, hi) != cur:
                a.w.lb = lo
                a.w.ub = hi
                changed += 1
            if persistent:
                a.last = (lo, hi)
        return changed

    def if_else(
        self,
        condition: "Constraint",
        then_value: Union["Expression", float],
        else_value: Union["Expression", float],
        *,
        name: Optional[str] = None,
    ) -> Variable:
        """Piecewise conditional expression ``then if condition else otherwise``.

        Introduces an auxiliary continuous variable ``w`` and a two-way
        disjunction so that, when *condition* holds, ``w == then_value``, and
        when it fails, ``w == else_value``. The disjunction is lowered to a
        big-M / hull reformulation by the GDP pass at solve time, so ``w`` may
        be used anywhere a continuous expression is allowed (objective or
        constraint bodies), composes with the relaxation pipeline, and keeps a
        valid global lower bound under branch-and-bound.

        Parameters
        ----------
        condition : Constraint
            An *inequality* constraint (e.g. ``x >= 0``). Equality conditions
            are rejected: a zero-measure condition is not a meaningful split.
        then_value : Expression or float
            Value of the result when *condition* holds.
        else_value : Expression or float
            Value of the result when *condition* fails.
        name : str, optional
            Base name for the auxiliary variable and disjunction.

        Returns
        -------
        Variable
            The auxiliary variable ``w`` standing for the conditional value.

        Notes
        -----
        On the boundary where the condition holds with equality, *both*
        disjuncts are feasible, so the relaxed graph includes both branch
        values at that single point. This is a sound over-approximation for a
        global solver — it never excludes a true optimum.

        Examples
        --------
        >>> # user_function_1d(x) = (x >= 0) ? max(0.25, exp(x) - 1) : log(-x + 3)
        >>> w = m.if_else(x >= 0, maximum(0.25, exp(x) - 1), log(-x + 3))
        >>> m.subject_to(y >= w)
        """
        if not isinstance(condition, Constraint):
            raise TypeError(
                f"if_else() condition must be a Constraint (an inequality such "
                f"as 'x >= 0'), got {type(condition).__name__}"
            )
        if condition.sense == "==":
            raise ValueError(
                "if_else() condition must be an inequality, not an equality; "
                "an equality condition holds on a zero-measure set."
            )
        # #1858: the complement below is built from ``body`` alone.
        _reject_unnormalized_rhs(condition, where="if_else condition")
        # #2090: the branch values feed ``_branch_bounds`` (w's box) right here, at
        # build time, so they are collected exactly now rather than at validate.
        _canonicalize_rows_in(condition)
        then_expr = _canonicalize_expression(_wrap(then_value))
        else_expr = _canonicalize_expression(_wrap(else_value))
        # The comparison operators normalize the condition to ``body <= 0``, whose
        # complement is ``-body <= 0``. A raw ``Constraint(body, ">=", 0.0)`` keeps
        # its sense, and its complement is ``-body >= 0``: negating the body under
        # the *same* sense covers both (#1858; a hardcoded ``"<="`` made the
        # complement of a raw ``>=`` row identical to the row itself).
        complement = Constraint(-condition.body, sense=condition.sense, rhs=0.0)
        lb, ub = self._branch_bounds(then_expr, else_expr, condition, complement)
        self._aux_counter += 1
        base = name or "ifelse"
        w = self.continuous(f"_{base}_{self._aux_counter}", lb=lb, ub=ub)
        # w's box is derived from the branches' box; it is re-derived at every
        # solve and save (:meth:`_refresh_if_else_bounds`, #2061 review).
        self._if_else_auxes.append(
            _IfElseAux(w, then_expr, else_expr, condition, complement, (lb, ub))
        )
        # Force the hull (perspective) reformulation: it disaggregates the
        # disjunct variables, so each branch's nonlinear body is relaxed only
        # over its own active region. Big-M keeps every branch's equation in
        # the global model and yields an unreliable relaxation bound for
        # nonlinear equality disjuncts (it can cut off the true optimum).
        # SELECT_ONE, like every other disjunction here. The two branches are
        # complementary by construction (``body <= 0`` and ``-body <= 0``), so
        # they overlap only on the boundary ``body == 0`` where both hold —
        # exactly the sound over-approximation described above.
        self._constraints.append(
            _DisjunctiveConstraint(
                disjuncts=[
                    [condition, w == then_expr],
                    [complement, w == else_expr],
                ],
                name=f"_{base}_{self._aux_counter}_disj",
                method="hull",
                semantics=DisjunctionSemantics.SELECT_ONE,
            )
        )
        return w

    # ── Special ordered sets ──

    def sos1(self, variables: list[Variable], name: Optional[str] = None):
        """
        Add SOS Type 1 constraint: at most one variable can be nonzero.

        Parameters
        ----------
        variables : list of Variable
            Variables in the special ordered set.
        name : str, optional
            Constraint name.
        """
        self._constraints.append(_SOSConstraint(1, variables, name))

    def sos2(self, variables: list[Variable], name: Optional[str] = None):
        """
        Add SOS Type 2 constraint: at most two adjacent variables can be nonzero.

        Parameters
        ----------
        variables : list of Variable
            Variables in the special ordered set (order matters).
        name : str, optional
            Constraint name.
        """
        self._constraints.append(_SOSConstraint(2, variables, name))

    # ── Piecewise-linear functions ──

    def piecewise(
        self,
        x: "Expression",
        breakpoints,
        values,
        *,
        method: str = "incremental",
        name: Optional[str] = None,
    ) -> Variable:
        """Declare ``y = f(x)`` for a tabulated piecewise-linear function ``f``.

        ``f`` is the continuous piecewise-linear interpolant of the table
        ``(breakpoints[i], values[i])`` on ``[breakpoints[0], breakpoints[-1]]``.
        The call returns a new continuous variable ``y`` and adds the mixed-integer
        linear rows that tie it to ``f(x)``; ``y`` can then be used anywhere an
        expression can (objective, constraints, other nonlinear terms).

        The rows are an **exact** representation of the graph of ``f``, not an
        approximation of it: at every feasible point ``y == f(x)``, at the
        breakpoints and between them. A solve of a model using ``y`` is therefore
        a solve of the declared model, and its certificate (``gap_certified``)
        means what it always means. If the table was sampled from some nonlinear
        function, the model solved is the one with the *interpolant*; the table is
        the declaration.

        Parameters
        ----------
        x : Expression
            The input: a scalar variable, an element ``v[i]``, an array variable
            (the same function is applied elementwise and ``y`` has ``x``'s shape),
            or a scalar expression over variables.
        breakpoints : array_like
            Strictly increasing, finite, at least two entries. Repeated
            breakpoints (jumps) are refused; model a discontinuous function with
            :meth:`either_or`.
        values : array_like or callable
            ``f`` at each breakpoint, finite; or a callable ``g(float) -> float``
            sampled at the breakpoints (``f`` is then the interpolant of those
            samples).
        method : str, default ``"incremental"``
            The MILP encoding. All are exact; they differ in size and LP strength.

            * ``"incremental"`` (``"inc"``, ``"delta"``) -- ``n - 2`` ordering
              binaries, locally ideal. Default: lowest shifted-geometric-mean
              wall time on two interleaved panels of seeded random tables
              (``discopt_benchmarks/scripts/piecewise_method_panel.py``; numbers
              in ``docs/notebooks/piecewise_linear.ipynb``).
            * ``"log"`` (``"logarithmic"``, ``"ebd"``) -- ``ceil(log2(n - 1))``
              binaries via the Gray-code SOS2 embedding
              (:mod:`discopt._relax.embedding`), locally ideal. Fewest binaries;
              a close second on the panels.
            * ``"disaggregated"`` (alias ``"dcc"``) -- one binary per segment,
              locally ideal.
            * ``"sos2"`` (``"lambda"``) -- convex-combination weights under a
              declared :meth:`sos2` set, lowered at solve time by the generic SOS2
              reformulation (one binary per breakpoint, O(n^2) exclusion rows).
              Slowest on the panels. The model writers refuse SOS relations, so
              use another method for a model you intend to export.
        name : str, optional
            Name of the output variable ``y``. Auxiliary variables and rows get a
            ``_pwl<k>_<name>`` prefix.

        Returns
        -------
        Variable
            The output ``y``, with bounds ``[min(values), max(values)]``.

        Raises
        ------
        PiecewiseDomainError
            (a ``ValueError``) if the domain of ``x`` is not contained in
            ``[breakpoints[0], breakpoints[-1]]`` -- an infinite bound included.
            The rows would otherwise restrict ``x`` to the span, silently
            clamping the model. The declared bounds of a variable are compared
            exactly; a composite expression is judged by its interval enclosure.
            Because bounds are mutable, :meth:`validate` repeats the check before
            every solve.
        ValueError
            For a malformed table or an unknown *method*.

        Notes
        -----
        Univariate only. The encodings follow :cite:t:`Vielma2010`; the
        logarithmic one is :cite:t:`Vielma2011`. To replace terms that are
        *nonlinear functions* (``exp(x)``, ``x**3``) by piecewise-linear
        constructs, use :func:`nonlinear_to_pwl`, which keeps the certificate
        question explicit (a rigorous outer approximation, or an uncertified
        approximation).

        Examples
        --------
        >>> q = m.continuous("q", lb=0, ub=40)            # flow, m3/h
        >>> head = m.piecewise(q, [0, 10, 20, 30, 40],
        ...                    [52, 50, 45, 36, 22], name="head")
        >>> m.subject_to(head >= 30)
        """
        from discopt.modeling._piecewise import (
            PiecewiseLinear,
            build_piecewise,
            normalize_piecewise_method,
        )

        canonical = normalize_piecewise_method(method)
        table = PiecewiseLinear.from_table(breakpoints, values)
        return build_piecewise(self, x, table, canonical, name)

    # ── Logical propositions ──

    @staticmethod
    def _validate_binaries(variables, method_name: str):
        """Check that all entries are binary variables (Variable or IndexExpression)."""
        for v in variables:
            if isinstance(v, IndexExpression):
                base = v.base
                if not isinstance(base, Variable):
                    raise TypeError(
                        f"{method_name}() requires binary variables, "
                        f"got IndexExpression with non-Variable base"
                    )
                if base.var_type != VarType.BINARY:
                    raise ValueError(
                        f"{method_name}() requires binary variables, "
                        f"but '{base.name}' has type {base.var_type.name}"
                    )
            elif isinstance(v, Variable):
                if v.var_type != VarType.BINARY:
                    raise ValueError(
                        f"{method_name}() requires binary variables, "
                        f"but '{v.name}' has type {v.var_type.name}"
                    )
            else:
                raise TypeError(
                    f"{method_name}() requires Variable or IndexExpression, got {type(v).__name__}"
                )

    def at_least(self, k: int, binaries: list, name: Optional[str] = None):
        """Add constraint: at least *k* of the binary variables must be 1."""
        self._validate_binaries(binaries, "at_least")
        self.subject_to(sum(binaries) >= k, name=name)

    def at_most(self, k: int, binaries: list, name: Optional[str] = None):
        """Add constraint: at most *k* of the binary variables can be 1."""
        self._validate_binaries(binaries, "at_most")
        self.subject_to(sum(binaries) <= k, name=name)

    def exactly(self, k: int, binaries: list, name: Optional[str] = None):
        """Add constraint: exactly *k* of the binary variables must be 1."""
        self._validate_binaries(binaries, "exactly")
        self.subject_to(sum(binaries) == k, name=name)

    def implies(self, y1, y2, name: Optional[str] = None):
        """Add implication constraint: y1 = 1 implies y2 = 1."""
        self._validate_binaries([y1, y2], "implies")
        self.subject_to(y1 <= y2, name=name)

    def iff(self, y1, y2, name: Optional[str] = None):
        """Add equivalence constraint: y1 = 1 if and only if y2 = 1."""
        self._validate_binaries([y1, y2], "iff")
        self.subject_to(y1 == y2, name=name)

    def disjunction(
        self,
        disjuncts: list[list],
        name: Optional[str] = None,
        *,
        semantics: Union[DisjunctionSemantics, str] = DisjunctionSemantics.SELECT_ONE,
        big_m: Union[float, dict, None] = None,
    ) -> "_DisjunctiveConstraint":
        """Create a disjunction object for nesting inside either_or().

        Unlike :meth:`either_or`, this does **not** add the disjunction to
        the model. Use it to build nested disjunctions. Carries the same
        select-one semantics as :meth:`either_or`.

        Parameters
        ----------
        disjuncts : list of list
            Each inner list is a group of constraints (a disjunct).
        name : str, optional
            Name for the disjunction.
        semantics : DisjunctionSemantics or str, default ``SELECT_ONE``
            The declared meaning of the disjunction; see :meth:`either_or`.
        big_m : float or dict, optional
            User big-M values, as in :meth:`either_or` (#1775 G2.6).

        Returns
        -------
        _DisjunctiveConstraint

        Raises
        ------
        ValueError
            Not here — but :meth:`validate` (and therefore :meth:`solve`) refuses
            a model still holding a disjunction this factory built that was never
            nested into an attached one (#1430). Dropping it silently would have
            the solver certify an optimum for the *relaxed* problem.
        """
        _refuse_empty_disjunction(disjuncts, "disjunction", name)
        _reject_unnormalized_rhs_in(disjuncts, where=f"disjunction {name or '<anon>'!r}")  # #1858
        dc = _DisjunctiveConstraint(
            disjuncts=disjuncts,
            name=name,
            semantics=_coerce_disjunction_semantics(semantics),
            big_m=_normalize_big_m(big_m, disjuncts, name),
        )
        _key_big_m(dc)
        # #1430: remember what this factory handed out, so ``validate`` can tell a
        # disjunction that was nested into the model from one that was forgotten.
        # Tracked by identity at the *construction* site rather than reconstructed
        # later from the constraint list: an unattached object leaves no trace in
        # the model at all, so there is nothing to find after the fact.
        self._gdp_factory_disjunctions.append(dc)
        return dc

    def make_disjunct(self, name: str) -> "Disjunct":
        """Create a named disjunct block with an auto-generated indicator.

        Parameters
        ----------
        name : str
            Block name. A boolean indicator ``{name}_active`` is created.

        Returns
        -------
        Disjunct

        Example
        -------
        >>> d1 = m.make_disjunct("mode_a")
        >>> d1.subject_to(x <= 3)

        Raises
        ------
        ValueError
            Not here — but :meth:`validate` (and therefore :meth:`solve`) refuses a
            model holding a non-empty disjunct that was never passed to
            :meth:`add_disjunction` (#1430). Its indicator binary IS registered on
            the model while its constraints are not, so the silent outcome is a
            certified optimum for a model missing every row the block carried.
        """
        d = Disjunct(name, self)
        self._gdp_factory_disjuncts.append(d)  # #1430; see ``_unattached_gdp_blocks``
        return d

    def add_disjunction(
        self,
        disjuncts: list["Disjunct"],
        name: Optional[str] = None,
        *,
        semantics: Union[DisjunctionSemantics, str] = DisjunctionSemantics.SELECT_ONE,
    ) -> None:
        """Add a disjunction over Disjunct blocks.

        Exactly one disjunct is **selected**: this maps to indicator
        constraints (``if_then``) and an ``exactly(1, ...)`` selector, i.e.
        :attr:`DisjunctionSemantics.SELECT_ONE`. The rows are tagged with their
        disjunction, so ``solve(gdp_method="hull")`` lowers the block by the
        convex hull with the Disjunct indicators as its selectors (the same
        relaxation ``either_or`` gets); other methods use big-M. A block with an
        empty disjunct has no row carrying that indicator and stays on big-M. A
        block nested in a Disjunct (:meth:`Disjunct.add_disjunction`) is hulled
        inside its enclosing block's hull (#1775 G2.1).

        Because each block owns a *named* indicator, the select-one reading is
        directly observable here, and it is the one users most often misread:
        constraining an indicator to 0 means "this mode is not **selected**",
        **not** "this disjunct's predicate is false". With overlapping
        disjuncts a deselected block's constraints may still hold at the
        optimum. Forcing a predicate false is
        :attr:`DisjunctionSemantics.EXACTLY_ONE_TRUE`, which is not
        implemented (issue #1124).

        Parameters
        ----------
        disjuncts : list of Disjunct
            The disjunct blocks to form the disjunction.
        name : str, optional
            Name for the disjunction.
        semantics : DisjunctionSemantics or str, default ``SELECT_ONE``
            The declared meaning of the disjunction: ``SELECT_ONE`` (an
            ``exactly(1)`` row) or ``OR`` (``at_least(1)``, #1775 G1.4). Anything
            else raises: this path lowers to indicator constraints immediately,
            so there is no later pass that could honor it.

        Example
        -------
        >>> d1 = m.make_disjunct("mode_a")
        >>> d1.subject_to(x <= 3)
        >>> d2 = m.make_disjunct("mode_b")
        >>> d2.subject_to(x >= 7)
        >>> m.add_disjunction([d1, d2], name="mode_select")
        """
        # This path lowers immediately (``if_then`` + ``exactly(1)``), so it gates
        # here rather than in the GDP pass — but on the pair it emits, via the
        # same predicate that pass uses, not on which member it was handed.
        resolved = _coerce_disjunction_semantics(semantics)
        _require_semantics_supported(resolved, _BLOCK_ROWS, "add_disjunction()")
        blocks = list(disjuncts)
        _claim_blocks(blocks, "the model", name)
        self._emit_block_disjunction(blocks, name, parent=None, semantics=resolved)

    def _emit_block_disjunction(
        self,
        disjuncts: list["Disjunct"],
        name: Optional[str],
        parent: Optional[Variable],
        semantics: DisjunctionSemantics = DisjunctionSemantics.SELECT_ONE,
    ) -> None:
        """Lower one block disjunction, then the disjunctions nested in its blocks.

        ``parent`` (#1775 G1.2) is the indicator column of the Disjunct this block
        disjunction is nested in, or ``None`` at top level. A nested block's
        indicators sum to ``parent`` instead of 1 -- all 0 when the enclosing
        disjunct is not selected -- and its rows carry ``parent`` so the GDP pass
        and the GDP tree can find the nesting. A top-level call emits exactly the
        rows it emitted before nesting existed.
        """
        # #1615 C-10a: a per-call key tags each emitted indicator row with its
        # disjunction and disjunct index, so ``gdp_method="hull"`` can find the
        # block again. Counted over keys already present so a cloned or
        # deserialized model cannot collide.
        taken = {
            c.disjunction[0]
            for c in self._constraints
            if isinstance(c, _IndicatorConstraint) and c.disjunction is not None
        }
        # A block disjunction with no row of its own tags nothing, so its key is
        # known only from the nesting record (#1790); without this a disjunction
        # nested in it, or the next one added, would reuse it.
        taken.update(getattr(self, "_gdp_block_members", {}))
        n_keys = len(taken)
        key = f"add_disjunction:{name or ''}:{n_keys}"
        while key in taken:
            n_keys += 1
            key = f"add_disjunction:{name or ''}:{n_keys}"
        n_start = len(self._constraints)
        for k, d in enumerate(disjuncts):
            n_before = len(self._constraints)
            self.if_then(d.indicator.variable, d._constraints, name=d.name)
            for row in self._constraints[n_before:]:
                row.disjunction = (key, k, len(disjuncts))
                row.parent = parent
                row.semantics = semantics
            # #1430: the block's rows are now in ``_constraints``; record that so
            # ``validate`` does not report it as forgotten. Set per disjunct rather
            # than for the call, so a list that raises part-way through leaves an
            # honest record of which blocks actually made it in.
            d._attached = True
        if parent is not None or any(d._nested for d in disjuncts):
            # A block whose only content is a nested disjunction emits no row, so
            # nothing tags its indicator; the GDP tree needs it to attach the child.
            # If no disjunct emits a row, nothing records the disjunction at all
            # (#1790), so its parent and its place in ``_constraints`` are kept too.
            # Recorded only when nesting is involved: a model without nesting gains
            # no state. Read with ``getattr(model, "_gdp_block_members", {})``.
            members = self.__dict__.setdefault("_gdp_block_members", {})
            members[key] = _BlockMembers(
                [d.indicator.variable for d in disjuncts], parent, n_start, name, semantics
            )
        for d in disjuncts:
            for kind, item, inner_name, inner_semantics in d._nested:
                if kind == "block":
                    self._emit_block_disjunction(
                        item, inner_name, parent=d.indicator.variable, semantics=inner_semantics
                    )
                else:
                    if item._model is not None or item.parent_indicator is not None:
                        # #1790: the same object nested in two blocks would be one
                        # row list under two parents; the second would overwrite the
                        # first's link and the first block would lose its nesting.
                        raise ValueError(
                            f"disjunction {item.name or '<anon>'!r} is nested in more than "
                            "one Disjunct block (or is already on the model); a "
                            "disjunction belongs to exactly one place -- build one per "
                            "block with Model.disjunction"
                        )
                    item.parent_indicator = d.indicator.variable
                    item._model = self
                    self._constraints.append(item)
        indicators = [d.indicator.variable for d in disjuncts]
        # Named ``_select``, not ``_xor``: this row is the select-one selector
        # cardinality (exactly one indicator active), not a truth-XOR over the
        # disjunct predicates.
        row_name = f"_disj_{name}_select" if name else None
        at_least = semantics.cardinality is SelectorCardinality.AT_LEAST_ONE
        if parent is None:
            if at_least:
                self.at_least(1, indicators, name=row_name)
            else:
                self.exactly(1, indicators, name=row_name)
        else:
            self._validate_binaries(indicators, "add_disjunction")
            if at_least:
                # At least one when the parent is selected, none when it is not.
                self.subject_to(sum(indicators) >= parent, name=row_name)
                for ind in indicators:
                    self.subject_to(ind <= parent)
            else:
                self.subject_to(sum(indicators) == parent, name=row_name)

    # ── Boolean logic (GDP) ──

    def boolean(
        self,
        name: str,
        shape: Union[tuple, int] = (),
    ) -> Union["BooleanVar", "BooleanVarArray"]:
        """Create boolean decision variable(s) backed by binary variables.

        Parameters
        ----------
        name : str
            Variable name.
        shape : tuple or int
            Shape of the boolean variable array. Scalar by default.

        Returns
        -------
        BooleanVar or BooleanVarArray
        """
        if isinstance(shape, int):
            shape = (shape,)
        var = self.binary(name, shape=shape)
        if shape == () or shape == (1,):
            return BooleanVar(var)
        return BooleanVarArray(var)

    def logical(
        self,
        expr: "LogicalExpression",
        name: Optional[str] = None,
    ) -> None:
        """Add a propositional logic constraint.

        Parameters
        ----------
        expr : LogicalExpression
            A boolean expression built from BooleanVars using ``&``, ``|``,
            ``~``, ``.implies()``, ``.equivalent_to()``.
        name : str, optional
            Constraint name.

        Examples
        --------
        >>> Y = m.boolean("choice", shape=(3,))
        >>> m.logical(Y[0].implies(Y[1] & ~Y[2]))
        """
        if not isinstance(expr, LogicalExpression):
            raise TypeError(f"Expected LogicalExpression, got {type(expr).__name__}")
        self._constraints.append(_LogicalConstraint(expr, name))

    # ── Solve ──

    @_counts_solve_depth
    @_solve_leaves_model_unchanged
    def solve(
        self,
        time_limit: float = 3600,
        gap_tolerance: float = 1e-4,
        abs_gap_tolerance: Optional[float] = None,
        threads: int = 1,
        llm: bool = False,
        sensitivity: bool = False,
        stream: bool = False,
        deterministic: bool = False,
        partitions: int = 0,
        initial_solution: Optional[dict] = None,
        warm_start: Optional["SolveResult"] = None,
        skip_convex_check: bool = False,
        nlp_bb: Optional[bool] = None,
        lazy_constraints: Optional[Callable] = None,
        incumbent_callback: Optional[Callable] = None,
        node_callback: Optional[Callable] = None,
        cut_callback: Optional[Callable] = None,
        solver: Optional[str] = None,
        validate: bool = False,
        verify_incumbent: bool = True,
        gauss_newton: bool = False,
        tuning: Optional["SolverTuning"] = None,
        debug: Any = None,
        **kwargs,
    ) -> Union[SolveResult, Iterator["SolveUpdate"]]:
        r"""
        Solve the model.

        For convex pure-continuous models, solves the NLP directly. For
        nonconvex continuous models and models with integer/binary variables,
        uses spatial Branch & Bound unless another solver backend is selected.

        Parameters
        ----------
        time_limit : float, default 3600
            Wall-clock time limit in seconds.
        gap_tolerance : float, default 1e-4
            Relative optimality gap tolerance for termination.
        abs_gap_tolerance : float, optional
            Absolute optimality gap tolerance ``|objective - bound|`` for
            termination. The search stops when EITHER the relative or the
            absolute criterion holds -- as it always has; this exposes the
            absolute half, which used to be a module constant (1e-6) with no
            caller control (#1243). ``None`` (the default) keeps each route's
            established default, so omitting it changes nothing.

            Use it when the optimum sits near zero, where a relative tolerance
            carries no information: a phase-stability certificate is the
            absolute test ``bound >= -eps`` on a quantity that is approximately
            0 at the answer. Must be finite and strictly positive.

            :attr:`SolveResult.solver_stats` then carries ``"gap_criterion"``,
            ``"absolute"`` or ``"relative"``, naming which arm stopped the
            search; the key is absent when neither did (a ``time_limit`` /
            ``node_limit`` stop, or an exhausted tree).
        threads : int, default 1
            Number of CPU threads for Rust components.
        llm : bool, default False
            Enable LLM explanation of results.
        sensitivity : bool, default False
            Eagerly compute ``d(obj*)/dp`` w.r.t. every Parameter, so
            :meth:`SolveResult.gradient` answers without further work and an
            unsupported model is refused here. This is the *objective*
            sensitivity (envelope theorem) only; for ``dx*/dp``, ``dλ*/dp``,
            second derivatives, or the total derivative of an arbitrary
            expression, use :meth:`Model.sensitivity`.
        stream : bool, default False
            If True, return an iterator of :class:`SolveUpdate` instead of
            the final result. **Not implemented** — no backend produces the update
            feed, so this currently raises ``NotImplementedError``. It is not a
            "print the solver log" switch: for that, attach a handler to the
            ``discopt`` logger at INFO (what the Pyomo plugin's ``tee=True`` does).
        deterministic : bool, default False
            Make the search a function of the model rather than of machine speed,
            by rendering every **role-2** wall budget inert — the sub-budgets that
            decide *how much work* a stage does, as opposed to the role-1
            ``time_limit`` that decides *when to stop*. A solve then reproduces
            when the role-1 budget never binds — it terminates on work
            (``max_nodes``, the gap) with real slack against ``time_limit``. Expect
            a longer run: nothing truncates a stage early any more.

            **``time_limit`` still binds** (#1371). "Expect a longer run" means up
            to the wall, not past it: a stage that would have been cut short by its
            role-2 share now runs until the *solve* deadline instead, and no
            further. Until #1371 the two were removed together — the role-2 helpers
            answered "no clock at all" — and this mode was silently exempt from
            #1152's "hard wall with an anytime bound". Measured then:
            ``casctanks`` took 600.04 s against ``time_limit=60`` (10.0x) and
            ``bchoco08`` 376.28 s against 30 s (12.5x), where the same solves with
            ``deterministic=False`` returned in 60.23 s and 30.11 s.

            The consequence for reproducibility is unchanged and is the sentence
            above: give the solve a budget generous enough that role-1 never binds.
            If it does bind, you get a truncated — and therefore machine-speed
            dependent — answer, which is the trade this mode exists to let you
            avoid, not an overrun.

            Until #1116 this defaulted to ``True`` and was read nowhere. See
            :meth:`discopt.solver.solve_model`.
        partitions : int, default 0
            Retired (#1873). Piecewise McCormick partitions configured the
            McCormick-"nlp" relaxation route, which has been removed; any nonzero
            value raises ``ValueError``. See
            ``docs/dev/nlp-mccormick-route-retirement.md``.
        rlt : bool or str, default "auto"
            Reformulation-Linearization Technique control for the McCormick LP
            relaxation. ``"auto"`` defers per-node RLT cuts to the structure-gated
            cut policy; ``True`` engages RLT in full (build-time level-1 root-bound
            tightening plus per-node cuts); ``False`` forces it off. Replaces the
            legacy ``DISCOPT_RLT=1`` environment variable. Sound regardless of
            setting (a constraint×bound product never removes a feasible point).
            Passed through to :func:`discopt.solver.solve_model`.
        milp_backend : {"highs", "native"}, optional
            Engine for a pure LP or MILP model. The default ``None`` defers to
            the environment: a MILP to ``DISCOPT_LP_MILP_BACKEND`` (default: the
            in-house Rust MILP engine, whether or not ``highspy`` is installed),
            an LP to ``DISCOPT_LP_BACKEND`` (default: the in-house Rust simplex;
            an explicitly set ``DISCOPT_LP_MILP_BACKEND`` still decides an LP
            when it is unset). ``"highs"`` is the opt-in HiGHS route with
            discopt-verified certificates (needs the ``discopt[highs]`` extra);
            its ``node_count`` is HiGHS's own ``mip_node_count``, which counts
            the root: ``0`` when HiGHS presolve settles the model, ``1`` when the
            root node closes it, more once HiGHS branches. ``"native"`` names
            discopt's own engines explicitly, with a route label saying so: the
            in-house LP solve (Rust simplex, POUNCE if it declines) for an LP,
            the Rust MILP engine for a MILP. On the MILP engine ``node_count`` is
            the engine's, ``strategy`` selects the next node (``"best_first"``,
            ``"depth_first"``, ``"best_estimate"``), ``branching_rule`` picks the
            variable to branch on, ``node_callback`` fires at the engine's node
            checkpoints, ``max_nodes`` caps the tree and ``milp_cuts`` switches
            the root cut loop. ``batch_size`` has no effect there (it sized the
            retired Python MILP tree's batches).
            ``algorithm_route`` names the engine that ran. Refused for a model
            that is not an LP or MILP and with ``nlp_bb=True``; ``"highs"`` is
            refused with any callback, since HiGHS runs none. ``lazy_constraints``,
            ``incumbent_callback`` and ``cut_callback`` route a MILP to spatial
            branch and bound, the engine that screens them. If presolve fixes
            every integer the model is solved as an LP and ``branching_rule`` /
            ``milp_cuts`` are unused (a warning says so). Overrides the
            ``DISCOPT_LP_MILP_BACKEND`` environment variable. Passed through to
            :func:`discopt.solver.solve_model`::

                r = m.solve(milp_backend="native", strategy="depth_first",
                            branching_rule="strong", batch_size=1, milp_cuts=False)
                r.node_count, r.algorithm_route

        milp_cuts : bool, optional
            Only with ``milp_backend="native"`` on a MILP. ``False`` skips the
            root cut loop (cover, clique and Gomory cuts), so the tree branches
            on the plain LP relaxation; the default keeps it.
        branching_rule : str, optional
            Only with ``milp_backend="native"`` on a MILP: which fractional
            integer variable a node branches on. ``"pseudocost"`` (default:
            reliability pseudocosts, most-fractional until a variable has
            observations), ``"most_fractional"``, ``"least_fractional"`` or
            ``"strong"`` (solves both child LPs of every candidate; those probe
            LPs are reported in ``solver_stats["branching/strong_probe_lps"]``,
            not in ``node_count``). Changes the search order, never a bound.
        initial_solution : dict, optional
            Initial feasible solution mapping Variable objects to values
            (scalars, lists, or numpy arrays).  Used as a warm-start point
            for NLP solves, AMP local incumbent improvement, and as the initial
            incumbent in Branch & Bound.
            Values are validated against variable bounds and integrality
            requirements; violations produce warnings and are corrected
            automatically (clamped / rounded).
        warm_start : SolveResult, optional
            A previous :class:`SolveResult` for this model, used as a PRIMAL-DUAL
            start (#1247). On the single-NLP routes it forwards the point, the
            constraint multipliers, the variable-bound multipliers and the
            terminal barrier parameter to POUNCE, which derives its warm-start
            options from them; successive solves that differ only slightly — a
            phase-diagram trace stepping ``T``, a fitting loop nudging a
            ``Parameter`` — then start from the previous solution's dual
            information instead of from a cold central point.

            On every other route only the primal point is usable, and it is used:
            it becomes the initial point, exactly as ``initial_solution`` would.

            Convergence-affecting only. Where a solve starts cannot change what it
            certifies at termination; on a nonconvex NLP it can change *which*
            local stationary point is reached, and on a global route it only seeds
            the incumbent search. Passing both ``warm_start`` and
            ``initial_solution`` raises — two different starting points, silently
            resolved, is the kind of thing that makes a warm start look broken.

            The result must come from a model with the same variables and
            constraints; a mismatch raises ``ValueError`` rather than starting
            from a partially filled point.
        skip_convex_check : bool, default False
            If True, skip automatic convexity detection **and the global
            search** for a purely continuous model: it is solved with a single
            *local* NLP call, with no spatial branch-and-bound. The result is
            therefore uncertified -- ``status="feasible"`` (never
            ``"optimal"``), ``bound=None``, ``node_count=0`` -- and on a
            nonconvex model it can be a local, non-global optimum (#1615
            B-02a). Leave it False (default) for a global solve: a model proved
            convex is then solved with a single certified NLP call, and any
            other model gets spatial branch-and-bound. On a model with integer
            variables the solve is still branch-and-bound; the flag disables the
            convexity-gated routes (the convex MINLP and GP auto-routes) and the
            "nonconvex model under NLP-BB" warning.
        nlp_bb : bool or None, default None
            Nonlinear Branch & Bound mode. When ``None`` (default), a MINLP
            certified convex at the root is auto-routed to LP/NLP branch and
            bound (``solver="mip-nlp"``, ``mip_nlp_method="lp_nlp_bb"`` on the
            HiGHS master since #1658; ``DISCOPT_CONVEX_ROUTE_METHOD=oa`` selects
            outer approximation, ``DISCOPT_CONVEX_MINLP_ROUTE=0`` opts out); a
            convex MINLP the route refuses (e.g. the caller set an option the
            MIP-NLP family ignores) falls back to NLP-BB, and
            everything else runs spatial B&B. When ``True``, forces NLP-BB
            (heuristic mode if nonconvex) and suppresses the OA auto-route.
            When ``False``, forces spatial B&B.
        lazy_constraints : callable, optional
            Lazy constraint callback. Called at integer-feasible nodes.
            Should accept ``(ctx, model)`` and return a list of
            :class:`~discopt.callbacks.CutResult`. If cuts are returned,
            the solution is not accepted as incumbent until it satisfies
            all lazy constraints.
        incumbent_callback : callable, optional
            Incumbent callback. Called when a new incumbent is about to
            be accepted. Should accept ``(ctx, model, solution)`` and
            return ``True`` to accept or ``False`` to reject. A rejection
            prunes the node that produced the point without proving the rest
            of its box holds no acceptable point, so the solve is certified
            ``optimal`` only if the accepted incumbent is within tolerance of
            that node's bound; otherwise it reports ``feasible`` with the
            node's bound kept in ``bound`` (#1964).
        node_callback : callable, optional
            Node callback. Called after each batch of nodes is processed.
            Should accept ``(ctx, model)`` and return ``None``. A MILP with a
            node callback is solved by discopt's MILP tree rather than HiGHS
            (which exposes no nodes), so the callback sees real nodes. An LP has
            no tree; the callback is not called and a warning says so.
        cut_callback : callable, optional
            Cut callback, invoked at **every** node — spatial ones included,
            unlike ``lazy_constraints``, which fires only at integer-feasible
            nodes. Accepts ``(ctx, model)`` where ``ctx`` is a
            :class:`~discopt.callbacks.NodeCutContext` carrying the node's BOX,
            its relaxation solution and the incumbent, and returns a list of
            :class:`~discopt.callbacks.CutResult` (possibly empty).
            Runs on discopt's spatial branch and bound: a MILP with a cut
            callback leaves the HiGHS and MILP-tree routes, which have no cut
            hook, and ``nlp_bb=True`` with a cut callback is refused.

            **Every returned cut is validated before it is accepted.** A cut the
            solver derives is a theorem; one you hand it is an assertion, and
            discopt applies its cut pool at every node — so an invalid cut
            removes the optimum from the whole tree and the solve can report a
            false ``optimal``. Each cut is therefore checked against the points
            this solve has already verified feasible, and a violator raises
            :class:`~discopt.callbacks.CutValidationError` rather than being
            quietly dropped. ``CutResult(scope="local")`` is refused outright:
            there is no subtree-scoped pool to hold such a cut. The gate is a
            filter, not a proof — ``SolveResult.solver_stats["cut_validation/*"]``
            reports how many points it actually tested.
        solver : str, optional
            Optional backend selector.

            Use ``solver="direct"`` for **derivative-free global search** over the
            variable box (DIRECT). Intended for a model whose objective or
            constraints contain an opaque ``dm.custom`` body that cannot be
            relaxed — that model otherwise degrades to a single local NLP, or
            raises when integer variables are also present. It requires a finite
            box and **returns no certificate**: ``bound`` and ``gap`` are ``None``,
            ``gap_certified`` is ``False``, and the status is never ``"optimal"``.
            Prefer the default solver whenever the model can be written
            algebraically. Options: ``max_evals`` (the cost control),
            ``epsilon``, ``direct_variant`` (``"classic"``/``"gl"``), ``divide``,
            ``break_ties``, ``local_refine``, ``local_refine_after``,
            ``local_refine_method`` (``"auto"``/``"nlp"``/``"derivative-free"``),
            ``local_refine_time_limit``, ``feasibility_tolerance``::

                import jax.numpy as jnp
                import discopt.modeling as dm

                m = dm.Model("rastrigin")
                x = m.continuous("x", shape=2, lb=-4.12, ub=6.12)
                f = dm.custom(lambda v: 20 + jnp.sum(v**2 - 10 * jnp.cos(2 * jnp.pi * v)))
                m.minimize(f(x))

                r = m.solve(solver="direct", max_evals=2000)
                r.objective       # ~0.0 at the origin
                r.bound           # None -- no dual information
                r.gap_certified   # False -- by design

            Use ``solver="pounce"`` for exactly one POUNCE interior-point solve of
            the model as written, with no convexity classification, presolve,
            spatial branch-and-bound or HiGHS fallback (#1533). An LP goes to
            POUNCE's convex LP IPM (``lp-ipm``) and a QP whose Hessian discopt
            proves positive semidefinite (an exact rational test) to its
            ``qp-ipm``; both are convex, so they report ``"optimal"``. Every other
            continuous model -- a QP not so proved, a QCQP, an NLP -- goes to the
            filter line-search NLP IPM once and reports ``"local_optimal"`` with
            no bound and ``gap_certified=False``, since nothing global was
            proved. (A solve POUNCE ends one barrier update early is continued
            once from its own point, and is ``"local_limit"`` if that does not
            finish it, #1768. So a *feasible* point can come back
            ``"local_limit"``: measured on pooling NLPs whose POUNCE
            ``Solve_Succeeded`` point had barrier parameter ~1.8e-6 and a ~1.6e9
            multiplier on a degenerate row. A caller that wants any feasible
            local point, e.g. as an upper bound, should accept
            ``"local_limit"`` with ``result.x`` and check its feasibility. The
            continuation rescales the rows at that point, so a caller-fixed
            ``nlp_scaling_method`` turns it off: such a mid-path
            ``Solve_Succeeded`` is reported ``"local_limit"`` without being
            continued.) ``result.algorithm_route`` names the arm
            (``"pounce:lp-ipm"``, ``"pounce:qp-ipm"``, ``"pounce:nlp"``) and
            ``result.solver_stats["pounce/iterations"]`` the convex engine's
            iteration count. A local infeasibility is ``"local_infeasible"``.
            Integer/binary variables, and an ``nlp_solver`` other than
            ``"pounce"``, raise ``ValueError``; any other option left at a
            non-default value is ignored with a warning naming it.
            Options go in ``pounce_options`` (an alias of ``ipopt_options``)::

                r = m.solve(solver="pounce",
                            pounce_options={"print_level": 5, "tol": 1e-9})

            The convex LP/QP engine accepts ``tol``, ``max_iter``,
            ``max_wall_time``, ``print_level`` (any positive value prints its
            iteration trace), ``tau`` and ``tau_max``, and with pounce-solver
            >= 0.13 its own ``qp_presolve``, ``qp_reg``, ``qp_hsde``,
            ``qp_equilibrate`` and ``qp_crossover`` (``qp_crossover=True`` on an
            LP returns a vertex; ``qp_presolve``/``qp_crossover`` cannot be
            combined with a warm start), #1985; an NLP-engine option such
            as ``mu_strategy`` on an LP raises rather than being ignored.
            ``result.solve_report`` describes the POUNCE work behind the answer;
            compare formulations by its ``statistics["total_iteration_count"]``
            where present, not ``iteration_count`` (see ``SolveResult``).
            The NLP engine does **not** run at Ipopt's defaults: discopt seeds
            ``constr_viol_tol=1e-8`` and ``bound_relax_factor=0`` (iterates
            and the returned point stay inside the declared box;
            ``pounce_option_defaults`` / ``pounce_incumbent_options`` in
            ``discopt.solvers``), and a ``pounce_options`` entry overrides
            either (#1620). The same baseline applies wherever discopt returns
            a POUNCE point as the solution.

            Use ``solver="amp"`` to select
            Adaptive Multivariate Partitioning. AMP-specific keyword
            arguments include ``rel_gap``, ``abs_tol``, ``max_iter``,
            ``n_init_partitions``, ``partition_method``, ``milp_time_limit``,
            ``milp_gap_tolerance``, ``presolve_bt``, ``presolve_bt_algo``,
            ``presolve_bt_time_limit``, ``presolve_bt_mip_time_limit``,
            ``apply_partitioning``, ``disc_var_pick``,
            ``partition_scaling_factor``, ``partition_scaling_factor_update``,
            ``disc_add_partition_method``, ``disc_abs_width_tol``,
            ``convhull_formulation``, ``convhull_ebd``,
            ``convhull_ebd_encoding``, ``use_start_as_incumbent``,
            ``obbt_at_root``, ``obbt_with_cutoff``, ``alphabb_cutoff_obbt``,
            and ``obbt_time_limit``.
            Use ``solver="gurobi"`` to select the optional Gurobi backend for
            LP, MILP, QP, MIQP, QCP, and MIQCP models. Quadratic objectives
            and quadratic constraints use the ``0.5 * x.T @ Q @ x + c.T @ x``
            convention; nonconvex quadratic objectives or constraints require
            opting into Gurobi's nonconvex mode explicitly,
            for example ``gurobi_options={"NonConvex": 2}``. Unsupported model
            classes raise ``NotImplementedError`` instead of silently falling
            back to another backend. Pass Gurobi parameters through
            ``gurobi_options={...}``.
            Use ``solver="scip"`` (``pip install discopt[scip]``) to hand the
            whole model to SCIP through PySCIPOpt, bypassing discopt's own
            solvers. Unlike ``"gurobi"`` it accepts general nonlinear models:
            the expression DAG is translated in memory into SCIP expressions,
            and anything without an exact SCIP spelling (``atan``, ``erf``,
            ``min``/``max``, ``dm.custom``, a variable exponent whose base is
            not provably positive) raises ``ScipUnsupportedError`` instead of
            being approximated. Pass SCIP parameters through
            ``scip_options={...}``, e.g. ``{"limits/nodes": 1000}``.
            SCIP's claims are reported but **never certified**: an optimum is
            ``status="feasible"`` and an infeasibility or unboundedness claim
            is ``status="unknown"``, both with ``gap_certified=False``, with
            SCIP's dual bound kept as information
            (``bound_source="external_solver"``) and SCIP's own status in
            ``termination``.
            Use ``solver="mip-nlp"`` to select the MIP-NLP decomposition
            family. Current implemented ``mip_nlp_method`` values are ``"oa"``,
            ``"ecp"``, ``"fp"``, ``"goa"``, and ``"lp_nlp_bb"``; ``"roa"``
            is reserved until its dedicated implementation lands. The
            LP/NLP-BB method uses single-tree lazy OA cuts and runs on
            ``milp_solver="simplex"`` (the default via ``"auto"``) or
            ``"gurobi"``. Top-level OA/ECP options such
            as ``equality_relaxation``,
            ``ecp_mode``, ``feasibility_cuts``, ``heuristic_nonconvex``,
            ``add_slack``, ``max_slack``, ``oa_penalty_factor``,
            ``add_no_good_cuts``, ``integer_to_binary``, ``feasibility_norm``,
            ``add_regularization``, ``level_coef``, ``stalling_limit``,
            ``cycling_check``, ``solution_pool``, ``num_solution_iteration``,
            and ``init_strategy``
            take precedence over duplicate keys in ``mip_nlp_options``.
            ``solution_pool`` currently requires ``milp_solver="gurobi"``.
            Experimental SHOT-parity controls are accepted only with
            ``mip_nlp_profile="shot"`` and include ``tree_strategy``,
            ``cut_strategy``, ``objective_epigraph``, ``anti_epigraph``,
            ``nonlinear_partitioning``, ``quadratic_partitioning``,
            ``absolute_value_auxiliaries``, ``monomial_extraction``,
            ``signomial_extraction``, ``integer_bilinear_strategy``,
            ``integer_bilinear_max_bits``, ``quadratic_extraction``,
            ``direct_quadratic_routing``, ``rootsearch_strategy``,
            ``fixed_nlp_strategy``, ``solution_pool_capacity``,
            ``hyperplane_max_per_iter``, ``hyperplane_selection_factor``,
            ``relaxation_phase``, ``mip_solution_limit_strategy``,
            ``convex_bounding``, ``master_repair``, and ``reduction_cuts``.
            MIP-NLP runs attach a structured ``result.mip_nlp_trace`` payload.
            For ``mip_nlp_method="goa"``,
            convexity-certified MINLPs use OA's valid master bounds and other
            models use AMP/global relaxations. AMP options such as ``rel_gap``,
            ``abs_tol``, ``max_iter``, ``n_init_partitions``,
            ``partition_method``, ``milp_time_limit``, ``milp_gap_tolerance``,
            ``presolve_bt``, and ``convhull_formulation`` may also be passed as
            top-level aliases. AMP-only options apply only on the nonconvex AMP
            path and are ignored with a warning when GOA automatically hands a
            convexity-certified model to OA.
            Supported ``add_regularization`` values are
            ``"level_L1"``, ``"level_L2"``, ``"level_L_infinity"``,
            ``"grad_lag"``, ``"hess_lag"``, ``"hess_only_lag"``, and
            ``"sqp_lag"``. Supported initialization strategies are ``"rNLP"``,
            ``"initial_binary"``, ``"max_binary"``, and ``"fp"``.
            The ``mip_nlp_method`` selector determines the
            effective ``ecp_mode`` and cannot be overridden by
            ``mip_nlp_options``.
        validate : bool, default False
            If True, run Examiner-style KKT validation on the returned
            point and attach the :class:`~discopt.validation.ExaminerReport`
            to ``result.validation_report``. Errors during validation are
            swallowed and leave ``validation_report`` as ``None``.
        tuning : SolverTuning, optional
            Advanced relaxation / branch-and-bound tuning (RLT families, McCormick
            separation toggles, node-bound mode, …) as a single typed, validated,
            per-call object — the supported replacement for the legacy
            ``DISCOPT_*`` environment variables (which remain as deprecated
            defaults). ``None`` resolves each field from its env default, exactly
            reproducing the prior behavior. Example:
            ``model.solve(tuning=SolverTuning(rlt_quad=False, node_bound_mode="milp"))``.
        gauss_newton : bool, default False
            If True and the objective is a non-negative-weighted sum of squares
            (e.g. ``dm.sum((C @ S - D) ** 2)`` or an explicit
            ``Σ (resid_i) ** 2``), use the Gauss-Newton objective Hessian
            ``2 Jᵀ J`` of the residuals instead of the exact second derivative.
            This sidesteps the super-linear second-derivative compile that can
            dominate least-squares solves (issue #98). Supported on both NLP
            evaluator backends: the JAX arm differentiates a residual function,
            the default tape arm reads ``∂r/∂x`` from an auxiliary POUNCE tape
            whose constraint rows are the residuals. The Gauss-Newton
            Hessian is always PSD and exact at a zero-residual solution, but
            drops the ``Σ rᵢ ∇²rᵢ`` curvature term, so it changes the Newton
            step (iteration path) without changing the KKT point converged to.
            Silently falls back to the exact dense Hessian when the objective
            is not a recognized sum of squares (or the model maximizes).
        debug : bool, str, or DebugSession, optional
            Attach the interactive branch-and-bound debugger (a "pdb for B&B").
            ``True`` / ``"repl"`` drops into a human REPL at the first
            checkpoint; ``"on-error"`` enters only at termination when the
            outcome is not a certified optimum (limit hit, interrupted,
            "unknown", or certified infeasible) — not supported on the
            pure-Rust MILP fast-path, whose hook carries no final status; a
            ready-made :class:`discopt.debug.DebugSession` uses a custom
            frontend. ``None`` (default) leaves the solve untouched —
            fire-sites short-circuit on a module-global check, so a detached
            solve is bound-neutral. Currently instruments the spatial-McCormick
            B&B path (nonconvex MINLP / continuous). See :mod:`discopt.debug`.
        \*\*kwargs
            Additional keyword arguments passed to the solver backend.

        Returns
        -------
        SolveResult or Iterator[SolveUpdate]
            Solve result, or a streaming iterator if ``stream=True``.

        Raises
        ------
        ValueError
            If the model fails validation (no objective, duplicate names, etc.).
        TypeError
            If *initial_solution* contains non-Variable keys.
        """
        # Entry clock: the #844 fallback below caps its budget at what is left of
        # ``time_limit`` measured from HERE, not from the primary's start.
        _t_solve0 = _time.perf_counter()
        # #1873: refuse the retired McCormick-"nlp" route's options before any
        # route (native kernel, convex kernel, HiGHS, ...) can take the model and
        # silently ignore them.
        from discopt.solver import _refuse_retired_relaxation_options

        _refuse_retired_relaxation_options(
            kwargs.get("mccormick_bounds", "auto"),
            partitions,
            kwargs.get("relaxation_arithmetic", "mccormick"),
            kwargs.get("use_learned_relaxations", False),
        )
        self.validate()
        # #1775 G2.6: which user big-M disjunctions this solve's lowerings read.
        from discopt.gdp.user_big_m import use_counts as _ubm_use_counts

        _ubm_snapshot = _ubm_use_counts(self)

        # --- #1537 C: exact recentring of large-offset variables (default ON; =0 opts out) ---
        # A box far from the origin is the same model in coordinates ``x = z + c``
        # but not the same numerics (23/69 certificates lost and 4 false ones under
        # a 1e6 shift, measured by the invariance harness). The recentred twin is
        # solved through this same method -- every route, the convex kernel
        # included -- and the result is mapped back and re-verified against THIS
        # model. Callbacks see solver coordinates, so a solve with any callback, or
        # a streaming one, is left unrecentred.
        from discopt.modeling import _recentre

        if (
            _recentre.recentre_enabled()
            # Only the caller's own top-level solve. A sub-solve the solver runs on
            # a tightened model of its own (RENS, a relaxation probe...) is a nested
            # ``Model.solve``; recentring those broke bound neutrality on unshifted
            # models (graduation panel: 4stufen, hda, heatexch_gen* reported moved
            # variables although the user's model has nothing to move).
            and _SOLVE_DEPTH.get() == 1
            and not getattr(self, "_recentre_inner", False)
            and not stream
            and lazy_constraints is None
            and incumbent_callback is None
            and node_callback is None
            and cut_callback is None
        ):
            _solve_args = dict(
                time_limit=time_limit,
                gap_tolerance=gap_tolerance,
                abs_gap_tolerance=abs_gap_tolerance,
                threads=threads,
                llm=llm,
                sensitivity=sensitivity,
                deterministic=deterministic,
                partitions=partitions,
                initial_solution=initial_solution,
                warm_start=warm_start,
                skip_convex_check=skip_convex_check,
                nlp_bb=nlp_bb,
                solver=solver,
                validate=validate,
                verify_incumbent=verify_incumbent,
                gauss_newton=gauss_newton,
                tuning=tuning,
                debug=debug,
                **kwargs,
            )
            # #1929 follow-up: the nested solve below gets what is LEFT of
            # ``time_limit``, not all of it again -- building the recentred twin is
            # part of this solve (it took 48.7 s of a 60 s limit on gams04 before
            # its rewrite was made linear, and is charged either way). Validated
            # first: ``max(0.0, nan - spent)`` would quietly turn a NaN limit into
            # an already-spent one.
            from discopt.solver import _validate_solve_budgets

            _validate_solve_budgets(gap_tolerance, time_limit)

            def _left_of_limit() -> float:
                return max(0.0, float(time_limit) - (_time.perf_counter() - _t_solve0))

            try:
                _rc = _recentre.recentre(self)
            except _recentre.RecentreUnsupported as exc:
                import logging as _logging

                # WARNING, not INFO: the user set the flag and it did nothing. The
                # model is solved unrecentred -- as a nested solve, so the pass
                # does not retry -- and the reason is stamped on the result.
                _logging.getLogger(__name__).warning(
                    "%s is set but recentring was skipped (%s); solving %r unrecentred",
                    _recentre.FLAG,
                    exc,
                    self.name,
                )
                _solve_args["time_limit"] = _left_of_limit()
                _unrecentred = cast(
                    Union[SolveResult, Iterator[SolveUpdate]], self.solve(**_solve_args)
                )
                if isinstance(_unrecentred, SolveResult):
                    if _unrecentred.solver_stats is None:
                        _unrecentred.solver_stats = {}
                    _unrecentred.solver_stats["recentre/skipped"] = str(exc)
                return _unrecentred
            if _rc is not None:
                _solve_args["time_limit"] = _left_of_limit()
                result = _recentre.solve_recentred(self, _rc, _solve_args)
                # The same tail the unrecentred path runs, on THIS model: the
                # objective recomputed from the mapped point in the original
                # coordinates, the #1313/#1322 solved-point stamp, and the derived
                # reports (switched off for the inner solve, so none of them can
                # describe the recentred model).
                if result.objective is not None and result.x is not None:
                    self._reconcile_objective_with_model(result)
                # #1551 on THIS model too. The inner solve judged the recentred
                # objective, which the solve door's exact pass (#2090/#2097) collects
                # into exactly rounded coefficients -- resolvable to the ulp -- while
                # the objective reported here is THIS model's, evaluated as written.
                # Measured on #1551's ``6y^2 + By + C``: the inner guard saw no error
                # and a certificate finer than the 0.039-wide enclosure of the
                # user's objective passed. Downgrade-only, like every call of it.
                from discopt.solver import (
                    _resolve_abs_gap_tolerance,
                    _withhold_unresolved_objective_certificate,
                )

                _withhold_unresolved_objective_certificate(
                    result,
                    self,
                    float(gap_tolerance),
                    _resolve_abs_gap_tolerance(abs_gap_tolerance),
                )
                if result.x is not None:
                    from discopt._evaluator_cache import solution_state_fingerprint

                    setattr(result, "_problem_fingerprint", solution_state_fingerprint(self))
                    self._last_solve_result = result
                if llm:
                    try:
                        result._explanation = result._explain_with_llm()
                    except Exception as _exp_exc:  # noqa: BLE001 - advisory, as below
                        import logging as _logging

                        _logging.getLogger("discopt.llm").debug(
                            "post-solve LLM explanation skipped: %s: %s",
                            type(_exp_exc).__name__,
                            _exp_exc,
                        )
                if sensitivity:
                    result._ensure_sensitivity()
                if validate and result.x:
                    from discopt.validation.examiner import examine

                    try:
                        result.validation_report = examine(result, self)
                    except Exception as _val_exc:
                        # Same outcome as the unrecentred path (report None), but
                        # said out loud rather than silently.
                        import logging as _logging

                        _logging.getLogger(__name__).warning(
                            "validation report not produced: %s: %s",
                            type(_val_exc).__name__,
                            _val_exc,
                        )
                        result.validation_report = None
                return result

        # Reject misspelled / unknown solve() keyword arguments loudly (M6).
        # ``**kwargs`` is forwarded verbatim to ``solve_model`` and its backends,
        # which historically only *warned* (or silently swallowed) unknown keys —
        # so ``m.solve(gap_tolerence=1e-3)`` ran at the DEFAULT gap while the user
        # believed they had tightened it (a results-integrity hazard). Validate
        # against the union of solve_model's parameters and the curated
        # backend-passthrough set; an unknown key raises TypeError with a
        # near-match suggestion (CLAUDE.md §3: loud refusal over silent swallow).
        if kwargs:
            from discopt.solver import selector_for_kwarg, solve_model_accepted_kwargs

            # Selector-aware: an option that only exists for solver="direct" or
            # solver="surrogate" is NOT accepted on a default solve. A flat
            # allowlist would accept m.solve(n_jobs=8) on a branch-and-bound run,
            # ignore it, and run serially — the M6 hazard this guard exists to
            # stop, on a parameter users already confuse with `threads`.
            allowed = solve_model_accepted_kwargs(solver)
            unknown = [k for k in kwargs if k not in allowed]
            if unknown:
                import difflib

                bad = unknown[0]
                owner = selector_for_kwarg(bad)
                if owner is not None:
                    raise TypeError(
                        f"solve() got '{bad}', which is an option of "
                        f"solver={owner!r} and has no effect on this solve. "
                        f"Pass solver={owner!r} to use it. Backend options are "
                        f"rejected rather than silently ignored (a swallowed "
                        f"option would leave the solver at its default while you "
                        f"believe it was set)."
                    )
                close = difflib.get_close_matches(bad, sorted(allowed), n=1, cutoff=0.6)
                hint = f" Did you mean '{close[0]}'?" if close else ""
                raise TypeError(
                    f"solve() got an unexpected keyword argument '{bad}'.{hint} "
                    f"Unknown solver options are rejected rather than silently "
                    f"ignored (a swallowed option would leave the solver at its "
                    f"default while you believe it was set)."
                )

        # #1386: the sibling of the rejection above, one level down. An unknown
        # option NAME is refused because "a swallowed option would leave the
        # solver at its default while you believe it was set" — and the same
        # failure was reachable through a KNOWN name carrying a value that
        # cannot be satisfied. ``gap_tolerance=nan`` makes every
        # ``rel_gap <= tol`` comparison False, silently switching off the
        # relative arm of the convergence test. Checked here, before this method
        # derives the budgets it forwards (``max(0.0, time_limit - spent)``
        # quietly turns a NaN limit into 0.0), and again in ``solve_model`` for
        # callers that reach the solver without going through this method.
        from discopt.solver import _validate_solve_budgets

        _validate_solve_budgets(gap_tolerance, time_limit)

        # A declared complementarity relation that no lowering emitted rows for
        # would be solved as if the condition were absent — and certified
        # optimal against a feasible set the model does not describe. Refuse
        # loudly instead (#1147). Checked here so an alternate backend selected
        # below (direct / amp / gurobi / mip-nlp) is refused too, and again in
        # ``solve_model`` for the callers that reach the solver without going
        # through this method.
        if self._complementarities:
            from discopt.mpec import require_all_relations_lowered

            require_all_relations_lowered(self, context="Model.solve")
        # if_else auxiliaries first: a lowering's enclosure may read one.
        self._refresh_if_else_bounds(context="Model.solve")
        if getattr(self, "_lowered_complementarities", None):
            # A lowering's auxiliary bounds were derived from the box at lowering
            # time; re-derive them for the box being solved (#2061 review).
            from discopt.mpec import refresh_lowering_bounds

            refresh_lowering_bounds(self, context="Model.solve")

        # Opt-in Gauss-Newton objective Hessian (issue #98). Read by
        # ``solver._make_evaluator`` when (re)building the NLPEvaluator; toggling
        # it participates in the evaluator-cache fingerprint.
        self._gauss_newton_hessian = bool(gauss_newton)

        # Validate initial solution if provided
        _x0_flat = None
        if initial_solution is not None:
            from discopt.warm_start import validate_initial_solution

            _x0_flat = validate_initial_solution(self, initial_solution)

        # Primal-dual warm start (#1247). The primal half is turned into the
        # ordinary initial point here, so every route benefits from it; the dual
        # half rides along to the single-NLP routes on ``_warm_start_state``.
        _warm_start_state = None
        if warm_start is not None:
            if initial_solution is not None:
                raise ValueError(
                    "solve() got both initial_solution and warm_start, which name two "
                    "different starting points. Pass one: warm_start carries the previous "
                    "solve's point AND its duals; initial_solution carries a point only."
                )
            if not isinstance(warm_start, SolveResult):
                raise TypeError(
                    "warm_start must be a SolveResult from a previous solve of this model, "
                    f"got {type(warm_start).__name__}"
                )
            from discopt.warm_start import (
                bound_duals_from_result,
                primal_point_from_result,
            )

            _x0_flat = primal_point_from_result(self, warm_start)
            _warm_start_state = {
                "x": _x0_flat,
                "constraint_duals": warm_start.constraint_duals,
                "bound_duals_lower": bound_duals_from_result(self, warm_start.bound_duals_lower),
                "bound_duals_upper": bound_duals_from_result(self, warm_start.bound_duals_upper),
                "barrier_parameter": (warm_start.kkt or {}).get("barrier_parameter"),
                # #1679: the qp-ipm arm of solver="pounce" seeds from the engine's
                # own iterate; the named duals above are in a different row order.
                "pounce_qp_iterate": warm_start.pounce_qp_iterate,
            }

        # Pre-solve LLM analysis (advisory only, never blocks solving)
        if llm:
            try:
                from discopt.llm.advisor import presolve_analysis

                warnings = presolve_analysis(self)
                for w in warnings:
                    import logging

                    logging.getLogger("discopt.llm").info("Pre-solve: %s", w)
            except Exception as exc:  # noqa: BLE001 - advisory only, never blocks solving
                import logging as _logging

                _logging.getLogger("discopt.llm").debug(
                    "pre-solve LLM analysis skipped: %s: %s", type(exc).__name__, exc
                )

        if stream:
            if warm_start is not None:
                # The streaming driver takes neither a start point nor duals, so a
                # warm start handed to it would be silently inert — the exact
                # failure #1247 exists to remove. (``initial_solution`` has the
                # same limitation on this path; it predates this guard.)
                raise ValueError(
                    "solve(stream=True) cannot take a warm_start: the streaming driver has no "
                    "seam for a starting point or its duals. Solve without stream=True to use it."
                )
            return self._solve_streaming(
                time_limit=time_limit,
                gap_tolerance=gap_tolerance,
                abs_gap_tolerance=abs_gap_tolerance,
                **kwargs,
            )

        # Convex LP-OA branch-and-cut kernel fast path (#798, gated by
        # DISCOPT_CONVEX_KERNEL, default-OFF). ``try_convex_solve`` routes ONLY
        # provably-convex composite-of-affine MINLPs and returns a fully-certified
        # SolveResult whose incumbent is verified feasible against this pristine
        # model (#779); it returns None — falling through to the default path
        # below, untouched — for the flag-off case, any non-convex model, or an
        # unverifiable incumbent. Wrapped so a kernel error can never break solve.
        #
        # #911: a DECLINED attempt is no longer free. ``_ck_elapsed`` is the wall the
        # attempt actually spent (spec build and the #779 feasibility verification
        # included) and it is deducted from the budget handed to the default path
        # below, so ``solve(time_limit=T)`` can no longer run for ~2T because a
        # convex-eligible model failed to certify. Measured before the fix (medians,
        # interleaved arms, 2 replicates): ``clay0304hfsg`` at a 10 s budget ran
        # 22.01 s against an OFF arm of 10.55 s, and at a 30 s budget 269.17 s
        # against 31.13 s. After: 12.94 s and 37.06 s.
        #
        # ``last_attempt_seconds()`` is EXACTLY 0.0 whenever DISCOPT_CONVEX_KERNEL is
        # off (it is reset on entry and the clock starts after the flag check), so the
        # default path subtracts a literal zero and every deadline below is unchanged.
        def _guard_unresolved_objective(res: "SolveResult") -> None:
            """#1551 guard at this method's tolerances (see ``solver``)."""
            from discopt.solver import (
                _resolve_abs_gap_tolerance,
                _withhold_unresolved_objective_certificate,
            )

            _withhold_unresolved_objective_certificate(
                res, self, float(gap_tolerance), _resolve_abs_gap_tolerance(abs_gap_tolerance)
            )

        # #1561: the declared model, captured before any route can extend it.
        # Structure cuts (``cut_recognizer``) append auxiliary columns and rows to
        # ``self._variables``/``self._constraints`` during the solve, and presolve
        # may tighten bounds in place; the backstop below judges the point the
        # caller asked about, on the variables and bounds the caller declared.
        from discopt.validation.feasibility import declared_variables as _declared_variables

        _declared_vars_entry = _declared_variables(self)
        _declared_cons_entry = list(self._constraints)
        _declared_builder_rows_entry = self._num_builder_constraint_rows()

        def _model_unchanged_since_entry() -> bool:
            if len(self._variables) != len(_declared_vars_entry) or any(
                v.name != d.name or int(getattr(v, "size", 1)) != d.size
                for v, d in zip(self._variables, _declared_vars_entry)
            ):
                return False
            if self._num_builder_constraint_rows() != _declared_builder_rows_entry:
                return False
            return len(self._constraints) == len(_declared_cons_entry) and all(
                a is b for a, b in zip(self._constraints, _declared_cons_entry)
            )

        def _declared_logic_now():
            """#1659: the declared disjunctive/indicator/SOS/logical rows, or None."""
            from discopt.validation.feasibility import DeclaredLogic, has_declared_logic

            return DeclaredLogic(self) if has_declared_logic(self) else None

        def _withhold_unverified_certificate(
            res: "SolveResult", evaluator=None, declared=None, logic=None
        ) -> None:
            """#1561 certified-incumbent backstop: no certificate on a point
            ``verify_point`` rejects.

            Every route has its own exit gate, and they do not agree with
            :func:`~discopt.validation.feasibility.verify_point`, the repo's single
            definition of a feasible incumbent: NLP-BB's gate judged the point as
            computed, with integer columns up to 1e-5 off, while ``verify_point``
            judges its integral realisation (#1380). On tls2 with every row scaled
            by 1e6 that disagreement published ``optimal``/``gap_certified=True``
            on a point whose snapped row 18 is violated by 6.67 where 1.0 is
            allowed. The route-level gate is fixed too; this is the class-level
            check at the one place every route's result passes, so a gate that
            drifts again cannot certify what ``verify_point`` refuses.

            The point is judged on the DECLARED model: ``evaluator`` and
            ``declared`` (a ``declared_variables`` snapshot) are the pre-solve rows
            and columns, and ``x`` is laid out over the declared names only.
            Without a pre-solve evaluator the rows are compiled now, which is the
            declared model only if the solve left ``_variables``/``_constraints``
            untouched; when it did not, there is no declared evaluator to judge
            against, and the post-solve model (declared rows plus the solver's
            own additions, columns included) is judged instead -- stricter, never
            looser.

            Only a CERTIFIED result is judged, and the point is not withheld: the
            loose #772 screen above decides that. A rejected point is reported
            ``feasible``, uncertified, with ``solver_stats
            ["certificate/incumbent_unverified"]`` set. ``bound`` is untouched; it
            is a dual bound and does not depend on the incumbent.
            """
            if not res.x or not (res.status == "optimal" or res.gap_certified):
                return
            import logging as _vlogging

            import numpy as _np

            from discopt.validation.feasibility import verify_point

            try:
                if evaluator is None and _model_unchanged_since_entry():
                    # #1743: an all-affine model's rows are read off the affine
                    # walk, not a tape/JAX evaluator built after the solve.
                    from discopt._affine_evaluator import post_solve_evaluator

                    evaluator = post_solve_evaluator(self)
                    declared = _declared_vars_entry
                    logic = _declared_logic_now()
                if evaluator is not None:
                    if declared is None:
                        raise ValueError("a pre-solve evaluator needs its declared variables")
                    _cols = [d.name for d in declared]
                else:
                    _cols = [v.name for v in self._variables]
                _flat = _np.concatenate(
                    [
                        _np.atleast_1d(_np.asarray(res.x[_n], dtype=_np.float64)).ravel()
                        for _n in _cols
                    ]
                )
                if evaluator is not None:
                    _verdict = verify_point(
                        self, _flat, evaluator=evaluator, variables=declared, logic=logic
                    )
                else:
                    _verdict = verify_point(self, _flat)
                _ok, _reason = bool(_verdict.ok), _verdict.reason
            except Exception as _vexc:
                # A check that cannot run cannot vouch for a certificate (§7):
                # decertify rather than publish an unchecked one.
                _ok, _reason = False, f"verification raised {type(_vexc).__name__}: {_vexc}"
            if _ok:
                return
            _vlogging.getLogger("discopt.solver").error(
                "UNVERIFIED CERTIFICATE (#1561): the incumbent reported as %s "
                "(objective=%s) fails verify_point on the declared model (%s). "
                "Reporting it as 'feasible', uncertified.",
                res.status,
                res.objective,
                _reason,
            )
            if res.status == "optimal":
                res.status = "feasible"
            res.gap_certified = False
            res.solver_stats = dict(res.solver_stats or {})
            res.solver_stats["certificate/incumbent_unverified"] = 1.0

        def _repair_published_incumbent(
            res: "SolveResult", evaluator=None, declared=None, logic=None
        ) -> None:
            """#1537 E: publish the incumbent repaired to float noise, and re-judge
            the certificate on the repaired objective.

            :func:`~discopt.validation.feasibility.repair_point` has the measurement.
            In short: ``verify_point``'s row allowance depends on the units a row is
            written in, so a solver's working-accuracy residual (1e-9..7e-6 on the
            three corpus cells) passes it in one set of coordinates and fails it in an
            identical model in another, and the objective the solver reports is bought
            with that residual -- ``ex14_1_9`` with rows x1e-3 certified ``-9.98e-6``
            against a true minimum of ~0. Repairing the point removes the dependence
            on the units: the result is feasible to float noise in every coordinate
            system, and its objective is the honest one.

            The repaired point is adopted only if ``verify_point`` accepts it on the
            declared model. If its objective then crosses the published bound, the
            bound is refuted (a verified point past it): the certificate is withdrawn
            and the bound cleared with its validity flag (#1244's rule), loudly.
            Otherwise the bound is never touched. The certificate is re-asked
            of the new ``(objective, bound)`` pair by the same arbiter that grants it
            (``_withhold_stale_certificate``): downgrade-only, so a solve whose
            certified objective was bought with a residual loses the certificate,
            and a solve whose was not keeps it.

            Nested internal solves (the root-relaxation fallback in ``solver.py``,
            ``solve_mpec``, ``estimate``, ``infeasibility``) run this too, by design
            and harmlessly: those callers read ``x``/``objective``, or ``bound``
            only behind ``status == "optimal"``. The repair is downgrade-only on
            status/certificate and clears a bound only when a verified point refutes
            it, so a nested caller can lose a bound that was invalid, never gain one.

            Known staleness (diagnostic only, never a certificate input):
            ``gap_criterion``, ``kkt`` and the duals still describe the solver's
            pre-repair point; the repaired point is within the solver's own
            feasibility tolerance of it.
            """
            from discopt.validation.feasibility import incumbent_repair_enabled

            if not incumbent_repair_enabled() or not res.x or res.objective is None:
                return
            import logging as _rlogging

            import numpy as _np

            from discopt.validation.feasibility import repair_point, verify_point

            _log = _rlogging.getLogger("discopt.solver")
            stats = res.solver_stats = dict(res.solver_stats or {})
            if evaluator is None:
                if not _model_unchanged_since_entry():
                    stats["certificate/repair_skipped"] = "model changed during the solve"
                    return
                from discopt._affine_evaluator import post_solve_evaluator

                evaluator = post_solve_evaluator(self)  # #1743
                declared = _declared_vars_entry
                logic = _declared_logic_now()
            if declared is None:
                raise ValueError("a pre-solve evaluator needs its declared variables")
            _names = [d.name for d in declared]
            if not set(_names) <= set(res.x):
                stats["certificate/repair_skipped"] = "result lacks a declared column"
                return
            if logic is None and any(type(c) is not Constraint for c in _declared_cons_entry):
                # A disjunction / indicator / SOS / logical row is not in the declared
                # evaluator's rows, and none were frozen with it, so a move judged on
                # those rows alone could break one.
                stats["certificate/repair_skipped"] = "non-algebraic rows"
                return
            # Any EXTRA column in ``res.x`` (a factorable-lift ``_fr_aux_*``, a
            # structure-cut aux) is the solver's internal column, not part of the
            # declared model; it is reported as the solver left it (see
            # ``SolveResult.declared_x``). Only declared columns are the claim.
            _shapes = [_np.shape(res.x[n]) for n in _names]
            _flat = _np.concatenate(
                [_np.atleast_1d(_np.asarray(res.x[n], dtype=_np.float64)).ravel() for n in _names]
            )
            _rows_ev = evaluator
            if logic:
                # #1659: repair against the declared rows plus the logic rows the
                # point must meet -- its closest disjunct, its active indicators.
                # The moved point is then re-judged on the whole logic below.
                from discopt.validation.feasibility import _DeclaredModelView, snap_integers

                _view = _DeclaredModelView(self, declared)
                _rows_ev = logic.realised_evaluator(_view, snap_integers(_view, _flat), evaluator)
            rep = repair_point(self, _flat, evaluator=_rows_ev, variables=declared)
            if rep.x is None:
                if rep.excess_before > 0.0:
                    stats["certificate/repair_declined"] = rep.reason
                return
            verdict = verify_point(
                self,
                rep.x,
                with_objective=True,
                evaluator=evaluator,
                variables=declared,
                logic=logic,
            )
            if not verdict.ok or verdict.objective is None:
                stats["certificate/repair_declined"] = f"repaired point: {verdict.reason}"
                return
            from discopt.solver import (
                _bound_crosses_objective,
                _recertify_gap_closed,
                _resolve_abs_gap_tolerance,
                _withhold_stale_certificate,
            )

            is_max = self._objective is not None and (
                self._objective.sense == ObjectiveSense.MAXIMIZE
            )
            old_obj, new_obj = float(res.objective), float(verdict.objective)
            bnd = res.bound
            has_bound = bnd is not None and _np.isfinite(float(bnd))
            # A verified point past the published bound refutes the bound (CLAUDE.md
            # §1): ``bound <= incumbent`` (min) is the certificate invariant. Decided
            # here, before anything is written, and acted on after the write-back.
            bound_refuted = has_bound and _bound_crosses_objective(float(bnd), new_obj, is_max)
            off = 0
            for n, shp in zip(_names, _shapes):
                size = int(_np.prod(shp)) if shp else 1
                vals = rep.x[off : off + size]
                res.x[n] = vals.reshape(shp) if shp else _np.asarray(vals[0])
                off += size
            res.objective = new_obj
            stats["certificate/incumbent_repaired"] = 1.0
            stats["certificate/repair_excess_before"] = float(rep.excess_before)
            # Magnitude only: the ``certificate/`` family is non-negative floats.
            stats["certificate/repair_objective_shift"] = float(abs(new_obj - old_obj))
            if bound_refuted:
                # #1244's rule, as in ``_withhold_stale_certificate``'s crossing arm:
                # the incumbent is verified and the bound is not, so the bound is the
                # weaker claim -- clear it with its validity flag and its gap, and
                # withdraw the certificate it supported. Never publish either.
                _log.error(
                    "incumbent repair (#1537 E): the repaired, verified point has objective "
                    "%.12g beyond the published bound %.12g (%s sense) -- the bound is "
                    "invalid. Withdrawing the certificate and the bound.",
                    new_obj,
                    float(bnd),
                    "max" if is_max else "min",
                )
                if res.gap_certified:
                    stats["certificate/repair_decertified"] = 1.0
                res.gap_certified = False
                if res.status == "optimal":
                    res.status = "feasible"
                res._set_bound(None, valid=False)
                res.gap = None
                stats["certificate/repair_bound_refuted"] = 1.0
                return
            if not has_bound:
                return
            from discopt.solvers._gap import reported_gap as _reported_gap

            # Re-judge at the tolerances the certificate was granted at: the solver
            # wrapper records them (AMP meets ``rel_gap``, not ``gap_tolerance``).
            _judged = getattr(res, "_judged_gap_tolerances", None)
            if _judged is not None:
                gtol, atol = float(_judged[0]), float(_judged[1])
            else:
                gtol = float(gap_tolerance)
                atol = _resolve_abs_gap_tolerance(abs_gap_tolerance)
            was_certified = bool(res.gap_certified)
            # #1585: the one SolveResult.gap formula, at the judged abs tolerance.
            res.gap = _reported_gap(new_obj, float(bnd), abs_tol=atol)
            if not was_certified:
                return
            if _recertify_gap_closed(old_obj, float(bnd), is_max, gtol, atol):
                res.status, res.gap, res.gap_certified, _ = _withhold_stale_certificate(
                    res.status,
                    new_obj,
                    float(bnd),
                    res.gap,
                    True,
                    is_max,
                    gtol,
                    atol,
                    "incumbent repair (#1537 E)",
                )
            elif abs(new_obj - float(bnd)) > abs(old_obj - float(bnd)):
                # A certificate whose pair did not close even at the tolerances it
                # was judged at (no recorded tolerances, or a pairless proof): only
                # the repair's MARGINAL effect is judged -- a pair the repair moved
                # further apart no longer supports the certificate.
                _log.warning(
                    "incumbent repair (#1537 E): the repaired objective %.12g is further "
                    "from the bound %.12g than the certified %.12g; withdrawing the "
                    "certificate.",
                    new_obj,
                    float(bnd),
                    old_obj,
                )
                res.gap_certified = False
                if res.status == "optimal":
                    res.status = "feasible"
            if was_certified and not res.gap_certified:
                stats["certificate/repair_decertified"] = 1.0

        _ck_elapsed = 0.0
        # #1422: the native-tree share of ``_ck_elapsed``, so the attempt can be
        # billed to ``wall_time`` without breaking its rust/python partition.
        _ck_rust_elapsed = 0.0
        # #1422: the rigorous dual bound a DECLINED attempt proved and used to throw
        # away, adopted below only if it beats what the default path manages. None
        # whenever the flag is off, the attempt certified, or no tree ran.
        _ck_declined_bound: Optional[float] = None
        _ck_declined_incumbent: Optional[tuple] = None
        # #1346: an EXPLICIT ``solver=`` is a decision, not a hint. Consulting the
        # convex kernel for a route the caller has already ruled out costs them a
        # convexity classification they can never benefit from -- and #911 charges
        # that wall to their budget, so ``solve(solver="gurobi", time_limit=12)``
        # handed Gurobi 11.99996 s instead of 12. Harmless while the kernel was
        # opt-in; visible the moment it became the default, as 7 CI failures across
        # the Gurobi dispatch tests and the two "the caller chose the algorithm"
        # route tests.
        #
        # The classification is only worth paying for when the router is actually
        # free to choose. It is NOT free here, so it does not run -- which is also
        # why ``test_explicit_mip_nlp_keeps_the_whole_limit`` means what its name says
        # again.
        # #1500: the kernel neither receives nor consults ``lazy_constraints`` /
        # ``incumbent_callback``, and it runs OUTSIDE ``solve_model``, so neither the
        # dispatch refusal nor the unscreened-point backstop there could see a
        # certified result it returned. Leave callback solves to the default path.
        # #1615 C-10b: the kernel lowers every disjunction by big-M
        # (``_convex_kernel._build``), so a caller who asked for another GDP
        # reformulation would get big-M with the option silently ignored. Leave
        # such solves to the default path, which honours ``gdp_method``.
        # #1775 G3.1: likewise any ``gdp_options``: ``solve_model`` validates them
        # (unknown or unread keys raise) and the kernel would drop them unread.
        if (
            not skip_convex_check
            and solver is None
            and lazy_constraints is None
            and incumbent_callback is None
            and kwargs.get("gdp_method", "big-m") == "big-m"
            and kwargs.get("gdp_options") is None
        ):
            _ck_res = None

            # #1624: a model the convex-MINLP router would divert goes to the
            # route, not to the kernel. The kernel's attempt takes the whole of any
            # ``time_limit <= 120``, so when it cannot certify, ``solve_model`` gets
            # ~0 s, the router's convexity proof hits the expired deadline, and the
            # route never fires: on MINLPLib ``syn``/``rsyn`` 30 of 51 instances
            # returned no incumbent, against 51/51 with the kernel off. The option
            # snapshot mirrors what ``solve_model`` consults before routing, so the
            # kernel defers exactly when the route would be taken.
            def _route_preempts_convex_kernel(model: "Model") -> Optional[str]:
                from discopt.solver import _convex_route_preempts_kernel

                return _convex_route_preempts_kernel(
                    model,
                    {
                        **kwargs,
                        "threads": threads,
                        "deterministic": deterministic,
                        "partitions": partitions,
                        "skip_convex_check": skip_convex_check,
                        "nlp_bb": nlp_bb,
                        "lazy_constraints": lazy_constraints,
                        "incumbent_callback": incumbent_callback,
                        "node_callback": node_callback,
                        "abs_gap_tolerance": abs_gap_tolerance,
                    },
                    time_limit=time_limit,
                )

            try:
                from discopt.solvers._convex_kernel import (
                    convex_kernel_reserve_seconds,
                    keep_declined_bound_enabled,
                    keep_declined_incumbent_enabled,
                    last_attempt_rust_seconds,
                    last_attempt_seconds,
                    last_declined_bound,
                    last_declined_incumbent,
                    try_convex_solve,
                )

                try:
                    # #1440: withhold a bounded slice so a DECLINED attempt cannot
                    # leave the default path with ~0 s. Default 0.0 -- the attempt
                    # is byte-identical until the knob is set, because a reserve is
                    # the fractional cap under another name and #1422 measured a
                    # 50 % cutoff destroying 3 of 16 certifications at a 4 s budget.
                    # See ``convex_kernel_reserve_seconds`` for the measured closure
                    # of every other candidate (predictor, free seed, pump seed, and
                    # the ORACLE-seed ceiling that kills the #764 port outright).
                    _ck_reserve = convex_kernel_reserve_seconds(float(time_limit))
                    _ck_res = try_convex_solve(
                        self,
                        time_limit=max(0.0, float(time_limit) - _ck_reserve),
                        gap_tolerance=gap_tolerance,
                        defer_to=_route_preempts_convex_kernel,
                    )
                finally:
                    # In the ``finally`` so an attempt that raised part-way through
                    # still has its consumed wall deducted -- the caller paid for it
                    # either way.
                    _ck_elapsed = last_attempt_seconds()
                    _ck_rust_elapsed = min(_ck_elapsed, last_attempt_rust_seconds())
                    if keep_declined_bound_enabled():
                        _ck_declined_bound = last_declined_bound()
                    if keep_declined_incumbent_enabled():
                        _ck_declined_incumbent = last_declined_incumbent()
            except Exception:
                _ck_res = None
            if _ck_res is not None:
                # #1551: this return skips ``solve_model`` and everything below,
                # so the evaluation-error guard has to run here too.
                # #1561 judges the route's own point; the #1537 E repair then
                # improves what is published (downgrade-only), and #1551 judges that.
                _withhold_unverified_certificate(_ck_res)
                _repair_published_incumbent(_ck_res)
                _guard_unresolved_objective(_ck_res)
                self._withhold_default_box_certificate(_ck_res)
                self._withhold_user_big_m_certificate(_ck_res, _ubm_snapshot)
                self._withhold_conservative_ro_certificate(_ck_res)
                return _ck_res

        from discopt._relax.deadline import deadline_scope
        from discopt.solver import solve_model

        # Attach the interactive B&B debugger if requested. The fire-sites in
        # the solve loop short-circuit on a module-global ``None`` check, so a
        # detached solve (``debug=None``) is unaffected. ``debug`` may be True,
        # "repl", "on-error", or a ready-made ``DebugSession``.
        _debug_guard = None
        if debug is not None and debug is not False:
            from discopt import debug as _dbg

            _debug_guard = _dbg.attach(_dbg.make_session(debug))

        # --- Final-incumbent verification snapshot (#772 guard, default on) ---
        # ``solve_model``'s presolve mutates this model's constraint DAG IN PLACE,
        # so any feasibility check taken AFTER the solve reflects the (possibly
        # unsoundly) mutated model — it cannot catch a false primal produced by an
        # unsound presolve (the #770 class, where the incumbent is feasible in the
        # mutated model but not the original). Capture a COMPILED feasibility
        # evaluator of the ORIGINAL model here, before any mutation: a compiled JAX
        # evaluator has its structure baked in, so it remains a faithful, immutable
        # representation of the original problem across the solve (verified: it
        # agrees with a freshly parsed model after a real presolve run). Built once
        # and cache-warm for the solve itself; fully wrapped so it can never break a
        # solve.
        import logging as _logging

        # Skip the (JAX-importing) snapshot for the LP/MILP/QP/MIQP fast family: those
        # paths are JAX-free by design and do not run the nonlinear presolve mutation
        # this guard defends against, so building a JAX evaluator there would regress
        # their JAX-free cold start (``_is_fast_linear_quadratic_family`` is pure-Python).
        #
        # #822: the snapshot is NOT gated on ``verify_incumbent``. Returning an
        # incumbent that is infeasible in the original model is the cardinal error
        # (CLAUDE.md §1); a user flag must not be able to disable that soundness
        # withhold. On a nonlinear solve the evaluator is already built during the
        # solve, so ``cached_evaluator(self)`` here is a cache hit (~0 ms) — the
        # verification is effectively free and now always runs. ``verify_incumbent``
        # is retained for API compatibility but no longer suppresses the withhold.
        _verify_snap = None
        _verify_snap_vars = None
        _verify_snap_logic = None
        if self._constraints and not _is_fast_linear_quadratic_family(self):
            # #840: this model is genuinely nonlinear (an expression constraint plus a
            # nonlinear objective or constraint), so it routes to spatial B&B, which
            # materializes any builder-resident linear rows (``add_linear_constraints`` /
            # the ``constraint(fast=True)`` fast path) into ``_constraints`` at solve time
            # regardless. Materializing them HERE first — before the verification snapshot
            # — means the snapshot and the solve build their evaluator on the identical
            # ``_constraints`` (same objects, empty builder → identical fingerprint), so
            # they share ONE compiled evaluator instead of each compiling the linear rows
            # separately. Model-preserving (relocates rows, does not alter the feasible
            # set); the solve-time materialization becomes a no-op.
            if self._num_builder_constraint_rows() > 0:
                self._materialize_builder_linear_rows()
            try:
                # Routed through the backend dispatcher, not straight to
                # ``cached_evaluator``: that import pulls jax at module scope, so
                # calling it here imported JAX on every nonlinear solve even when
                # the tape backend was selected (#75). The jax import stays inside
                # the fallback so it happens only when the tape is not used.
                from discopt._tape_nlp_evaluator import build_evaluator, jax_fallback_evaluator

                _verify_snap = (
                    build_evaluator(self, lambda: jax_fallback_evaluator(self)),
                    [v.name for v in self._variables],
                )
                # #1561: the same columns, frozen, for the certificate backstop.
                _verify_snap_vars = (
                    _declared_vars_entry
                    if _model_unchanged_since_entry()
                    else _declared_variables(self)
                )
                # #1659: and the rows inside disjunctions / indicators, which the
                # evaluator above does not compile, frozen at the same moment.
                _verify_snap_logic = _declared_logic_now()
            except Exception as _snap_exc:
                # Same §7 point as the verification handler below: without the
                # snapshot the false-primal guard cannot run at all, so this is a
                # disabled soundness check, not a skipped nicety. Non-fatal, but
                # never silent.
                _logging.getLogger("discopt.solver").error(
                    "INCUMBENT-VERIFICATION SNAPSHOT FAILED: %s: %s. The false-primal "
                    "guard cannot run on this solve.",
                    type(_snap_exc).__name__,
                    _snap_exc,
                )
                _warnings.warn(
                    f"incumbent-verification snapshot failed "
                    f"({type(_snap_exc).__name__}: {_snap_exc}); the false-primal "
                    f"guard is disabled for this solve",
                    RuntimeWarning,
                    stacklevel=2,
                )

        # Install a process-global wall-clock deadline that JAX-compiled
        # while_loops (LP/QP/NLP IPM) can poll via host callback so they
        # self-terminate within ``time_limit + ε`` instead of running to
        # XLA convergence after Python's budget is gone (issue #80).
        # #844: reserve a slice of the budget for the LP-per-node fallback below, but
        # ONLY for models that engine can serve (pure-integer, minimize; plus mixed /
        # maximize when the #860 flag is on). Safe because
        # the instances at risk certify almost instantly -- nvs04 in 0.2 s, nvs06 in
        # 0.3 s of a 40 s budget -- so they finish long before the reduced primary
        # budget binds, while the instances this targets (tln4/tln5) burn 100% of the
        # budget and still return nothing. Out-of-scope models keep the full budget.
        #
        # #911: everything from here on splits what is LEFT of the caller's budget,
        # not the budget as stated. The reserve is a fraction of the remainder for the
        # same reason the primary is: 35% of a budget that has already been spent is
        # not available to reserve. ``_remaining_tl`` is ``time_limit`` less
        # ``_prework_s`` -- never ``time_limit`` itself, even with the convex kernel
        # off -- and ``last_solve_prework_seconds()`` reports the deduction exactly.
        #
        # What is left is measured from this method's entry clock, not as
        # ``time_limit - _ck_elapsed``: the convex-kernel attempt is not the only
        # work above. The evaluator build and the incumbent-verification snapshot
        # run here too, and on a large model they are seconds each --
        # ``parabol5_2_4`` spent ~20 s of a 60 s limit above this line, none of it
        # charged, so ``solve_model`` started with a full minute. The kernel's wall
        # is inside the same elapsed time, so it is still deducted exactly once.
        #
        # ``solve_model``'s recursion gate sizes every body before it starts its
        # own clock (``telecomsp_nor_sun``: ~9 s). The count is memoised by body
        # identity, so sizing ``self`` HERE charges that walk to this budget and
        # leaves the gate a cache hit.
        from discopt._relax.factorable_reform import _max_expr_node_count

        _max_expr_node_count(self)
        _prework_s = _time.perf_counter() - _t_solve0
        _PREWORK.seconds = _prework_s
        _remaining_tl = max(0.0, time_limit - _prework_s)
        _fb_reserve = 0.0
        if (
            _lp_spatial_fallback_enabled()
            and not kwargs.get("lp_spatial", False)
            # An explicitly chosen backend keeps the caller's FULL budget. Reserving
            # from ``solve(solver="gurobi", time_limit=8)`` forwarded only 5.2 s,
            # silently shrinking a limit the user stated outright — and an external
            # MILP/QP backend has no use for this fallback anyway.
            and solver is None
            # #1611 D-25: an explicitly requested decomposition (Lagrangian, Benders,
            # ...) is the caller's chosen algorithm. When it returned no incumbent the
            # fallback used to re-solve with the LP-per-node B&B and report THAT as
            # ``optimal`` -- ignoring ``max_nodes`` and hiding that the requested
            # method never produced the answer. The decomposition's own result stands.
            and not kwargs.get("decomposition")
            # The engine branches on integer PRODUCTS in constraint rows; a box-only
            # model gives it nothing to work with, and the primary solves such a
            # model directly.
            and self._constraints
        ):
            try:
                from discopt._relax.lp_spatial_bb import _is_in_scope

                # #860 widened the engine to mixed-integer and MAXIMIZE models behind
                # ``DISCOPT_LP_SPATIAL_MIXED``; #1357 RETIRED that flag under CLAUDE.md
                # §5's retirement rule after its panel failed bar (2) — the reserve was
                # where the loss came from. Two of the four decisive instances lost
                # their incumbent entirely (``tls2``, ``st_e31``): the reserve handed
                # 35% of the budget to a fallback that then DECLINED the model anyway
                # (``require_incremental=True`` + an infinite root box), so the primary
                # ran out of time at 65% and returned nothing. Budget taken from a path
                # that was going to succeed, given to one that never ran.
                #
                # The default path therefore uses the pre-#860 gate. The widening is
                # still callable explicitly via ``_is_in_scope(..., mixed=True)``.
                from discopt._relax.problem_classifier import ProblemClass, classify_problem

                # A LINEAR integer model is not this fallback's class: the engine
                # branches on integer PRODUCTS, and with none it is a plain LP-per-node
                # integer B&B, weaker than the MILP engine the primary already is. On
                # the 2026-11-13 MIPLIB population (`docs/dev/highs-mip-replacement-
                # plan.md` §8.3) 22 linear in-scope solves ended with no incumbent: the
                # fallback supplied none of them (on reblock420 it raised RecursionError
                # on the model's 420-term rows) and its reserve cut the engine to 65 % of
                # the budget -- solves stopping at 8.6-17.7 s of a 20 s limit.
                if _is_in_scope(self) and classify_problem(self) != ProblemClass.MILP:
                    _fb_reserve = 0.35 * _remaining_tl
                    # NOTE: scope is checked here, but whether the engine can actually
                    # build its incremental structure is only known once it runs (see
                    # ``require_incremental`` below). A model that is in scope yet
                    # unbuildable therefore hands back its reserve unused — the primary
                    # keeps 65% of the budget and the fallback returns immediately.
                    # Probing buildability here instead would mean building the
                    # structure twice, and that build is itself the #654 overrun on
                    # large factorable models, so the cheaper mistake is this one.
            except Exception:
                _fb_reserve = 0.0
        # ``max(0.0, ...)``: an attempt that consumed the whole budget leaves nothing,
        # and ``solve_model`` handles a spent budget through its existing deadline
        # short-circuit (a rigorous root-relaxation bound, never a certified claim)
        # rather than by running an unbounded search.
        _primary_tl = max(0.0, _remaining_tl - _fb_reserve)

        # #917: the reserve above is deducted from every in-scope solve and spent by
        # only the no-incumbent minority, so a primary that finds an incumbent and
        # then hits its reduced deadline forfeits 35% of the caller's budget — nobody
        # spends it. Hand that slice to the primary as an *extension it may take only
        # while holding an incumbent*: the fallback serves exclusively the
        # no-incumbent case, so the state that triggers the extension is precisely the
        # state in which the fallback has nothing to contribute, and the #844 path is
        # preserved unchanged (same 65% primary budget, same 35% fallback budget, same
        # order). See ``_lp_spatial_reserve_extension_enabled`` for the measurement.
        _fb_extension = (
            _fb_reserve if (_fb_reserve > 0.0 and _lp_spatial_reserve_extension_enabled()) else 0.0
        )

        from discopt._relax.factorable_reform import collect_lift_aux_names
        from discopt._relax.soc_rewrite import collect_squared_soc_rows

        _lift_aux_names: set[str] = set()
        _soc_rows_by_model: dict = {}
        _t_primary0 = _time.perf_counter()
        try:
            with (
                deadline_scope(_primary_tl),
                collect_lift_aux_names() as _lift_aux_names,
                collect_squared_soc_rows() as _soc_rows_by_model,
            ):
                result = solve_model(
                    self,
                    time_limit=_primary_tl,
                    incumbent_time_extension=_fb_extension,
                    gap_tolerance=gap_tolerance,
                    abs_gap_tolerance=abs_gap_tolerance,
                    threads=threads,
                    deterministic=deterministic,
                    partitions=partitions,
                    initial_point=_x0_flat,
                    warm_start=_warm_start_state,
                    skip_convex_check=skip_convex_check,
                    nlp_bb=nlp_bb,
                    lazy_constraints=lazy_constraints,
                    incumbent_callback=incumbent_callback,
                    node_callback=node_callback,
                    cut_callback=cut_callback,
                    solver=solver,
                    tuning=tuning,
                    **kwargs,
                )
        finally:
            if _debug_guard is not None:
                _debug_guard.__exit__(None, None, None)
            # Drop the wall-clock deadline ``solve_model`` stashes on the model
            # (#654). It is written in four places there and cleared in none, so
            # once the solve returns the stash holds a timestamp already in the
            # PAST — and any later consumer reading it sees a permanently expired
            # budget.
            #
            # Not hypothetical: it silently switched off ``IncrementalMcCormickLP``'s
            # structure build for anything running after a solve (the #844
            # no-incumbent fallback, which by construction runs once the primary has
            # spent its budget). The engine degraded to its slow cold path and the
            # symptom read as a *measurement* rather than as a capability turning
            # itself off.
            #
            # Cleared here, in the ``finally`` that already runs the moment
            # ``solve_model`` returns, so every later step in this method sees a
            # clean model. Note this covers the ``Model.solve`` path; a direct
            # ``solve_model(...)`` call still leaves its stash behind, and consumers
            # that may run after one should pass an explicit deadline rather than
            # read the ambient stash.
            try:
                del self._solve_deadline
            except AttributeError:
                pass

        # --- #1933: duals for the squared cone rows the caller wrote ---------- #
        # ``solve_model`` solved those rows in their norm form; its multipliers are
        # for that function, so rescale them to the caller's row (or withhold them).
        _soc_rows = _soc_rows_by_model.get(id(self))
        if _soc_rows and isinstance(result, SolveResult):
            from discopt._relax.soc_rewrite import convert_squared_soc_duals

            convert_squared_soc_duals(result, self, _soc_rows)

        # --- Bill the convex-kernel attempt to the reported wall (#1422) ------ #
        # #911 made the DECLINED attempt's wall count against the budget handed to
        # ``solve_model``; it never made it count in what the solve REPORTS. The two
        # halves have to move together, because subtracting the attempt from the
        # budget is precisely what makes ``solve_model``'s own clock start after the
        # attempt is over: on an eligible-but-uncertifiable model the attempt takes
        # ``min(time_limit, DISCOPT_CONVEX_KERNEL_BUDGET)`` -- the whole budget for
        # any ``time_limit <= 120`` -- so ``solve_model`` gets ~0 s, takes its #654
        # deadline short-circuit, and reports a wall measured from an anchor set
        # after the budget was already gone.
        #
        # Measured on ``clay0303hfsg`` (in-repo corpus) at ``time_limit=8``:
        #
        #     status=time_limit  nodes=0  reported_wall=0.061 s  TRUE wall=8.528 s
        #     convex-kernel attempt=8.051 s   unaccounted=8.466 s
        #
        # i.e. an 8.5-second solve reported as 61 milliseconds, a 140x under-report.
        # That is the defect behind #1422, whose ``ball_mk2_30`` reading
        # (``status='time_limit' nodes=0 t=0.010s`` against an 8 s budget) is the same
        # signature: the status was honest -- the budget really was spent -- and the
        # WALL was the lie. Every consumer that buckets by time reads this field;
        # this repo's own benchmark runner reports median time over solved instances
        # and total wall over all of them from it.
        #
        # Charged the same way the #844 fallback below charges its own wall, and split
        # so the documented ``rust_time + python_time == wall_time`` partition
        # survives: the native tree is Rust, the spec build / convexity classification
        # and the #779 incumbent verification are Python.
        if _ck_elapsed > 0.0:
            result.wall_time += _ck_elapsed
            result.rust_time += _ck_rust_elapsed
            result.python_time += _ck_elapsed - _ck_rust_elapsed

        # --- No-incumbent fallback to the LP-per-node spatial engine (#844) ---
        # A class of pure-integer MINLPs (tln4/tln5/tln6, ball_mk2_30) returns NO
        # incumbent from the default NLP-per-node path while this engine finds one:
        # it solves a McCormick LP per node with LP-based dive/pump primals, where the
        # NLP-based heuristics cannot round the loose bilinear envelope into
        # feasibility (#826 falsified those; the LP variants were never tried because
        # they sat behind an opt-in flag).
        #
        # It is a FALLBACK, not a route, and that ordering is what makes it safe --
        # measured, not assumed. Routing in-scope models *instead of* the default path
        # was built and panelled first (72 instances) and FAILED: 3 gains but 4
        # certification regressions (nvs04 0.72 -> 6.3e8, nvs06, nvs09, nvs15). The
        # panel split exactly along one line: every gain was an instance the default
        # path leaves with no incumbent, every regression one it already certifies. As
        # a fallback the gains are kept and the regressions cannot occur -- those four
        # never reach this branch.
        #
        # Soundness: only ever fills in a MISSING incumbent, and the engine verifies
        # every point it accepts against a ground-truth evaluator, so it cannot weaken
        # or replace an existing certificate.
        #
        # #917 leaves this branch's budget at the full reserve rather than clamping it
        # to the time actually left. The extension can only fire while the primary
        # holds an incumbent, so a solve that took it never reaches here — the clamp
        # would guard nothing, and it measurably HARMED the default path: sizing the
        # fallback from elapsed wall makes it depend on the primary's run-to-run
        # overshoot, and on nvs13 at a 6 s budget that flipped the reserve across the
        # 1.0 s floor between two runs of the same configuration (incumbent -580.4 in
        # one, none in the other). The #844 fallback keeps the budget it was
        # panelled at.
        # A certified infeasible and an unbounded result also carry no objective, but
        # they are answers, not missing incumbents: the fallback filling one in
        # overwrote a proved ``infeasible`` with ``optimal`` (integer column boxed in
        # [-1.6, -1.07], found by adversarial testing of #1229).
        _primary_decided = result.status == "unbounded" or (
            result.status == "infeasible" and bool(result.gap_certified)
        )
        if _fb_reserve > 1.0 and result.objective is None and not _primary_decided:
            # The reserve is a floor, not a cap. A primary that gave up early (NLP-BB
            # returned on nvs17 in 0.3 s of a 20 s budget) leaves more than the
            # reserve unspent, and holding the fallback to 35% then surfaced ITS
            # limit as the solve's ``time_limit`` at 7.4 s. A primary that spent its
            # budget leaves at most the reserve, so the #917 sizing above is
            # unchanged for it, and the ``> 1.0`` floor still reads the reserve.
            #
            # And the caller's remaining time is the CAP: the reserve used to be a
            # floor here too (``max(reserve, remaining)``), which differs from the
            # remaining time only when the primary overran its own share -- and then
            # it granted the fallback a full reserve past the caller's ``time_limit``
            # (QPLIB_3361/3709: primary out at T+44 of 60 s, fallback deadline T+64).
            # Measured from solve entry, not ``_t_primary0``: the setup before the
            # primary (1.6 s on QPLIB_3709 at load ~40, more under contention) is
            # spent too. A shorter fallback can only weaken its bound, never falsify one.
            _fb_budget = max(0.0, time_limit - (_time.perf_counter() - _t_solve0))
            _t_fb0 = _time.perf_counter()
            try:
                from discopt._relax.lp_spatial_bb import solve_lp_spatial_bb

                # Fresh process-global deadline: the primary's scope has expired, and
                # the JAX-compiled LP loops poll it.
                with deadline_scope(_fb_budget):
                    # use_obbt=False: the root OBBT pass is the dominant source of
                    # wall-clock overshoot here (measured on tln6: 77.4 s with it
                    # versus 17.4 s without, against the same budget), and this pass
                    # exists to find a PRIMAL quickly, not to tighten the root box —
                    # the dual bound is the primary path's job. Dropping it keeps the
                    # fallback inside its reserve.
                    #
                    # require_incremental=True: without the incremental McCormick
                    # structure the engine has no cuts, no feasibility pump, and
                    # rebuilds the relaxation per node. Measured on ball_mk2_30 while
                    # its monomial still declined, that cold path spent 61 s on the
                    # ROOT LP alone against a 21 s reserve: 0 nodes, no incumbent,
                    # 2.91x over budget. It cannot produce a primal inside a
                    # fallback-sized budget, so declining costs no gain and removes
                    # the overrun. ball_mk2_30 itself now MAPS (#861 narrowed the
                    # monomial gate to odd powers on a straddling root) and so takes
                    # the incremental path here — but measured, it still returns no
                    # incumbent, just a sound bound, having spent the reserve.
                    #
                    # The guard is deliberately NOT tightened to re-exclude it. Its
                    # premise ("the structure builds" ⇒ "this path can find a primal")
                    # is a proxy, and #861 widened the gap between the two — but no
                    # predicate can decide in advance whether a primal is coming, and
                    # a "give up if no incumbent by X% of the reserve" rule would
                    # forfeit precisely the late incumbents this fallback exists to
                    # catch (tln4/tln5 are found deep in the reserve, not early).
                    # Tuning such a rule until ball_mk2_30 exits early would be a
                    # single-instance fix, which this repo rejects. Instead the
                    # reserve's OUTPUT is no longer discarded: the bound merge below
                    # runs whether or not a primal was found, so a spent reserve now
                    # buys a tighter dual bound rather than nothing. Closing the primal
                    # half remains #844 work.
                    _fb = solve_lp_spatial_bb(
                        self,
                        time_limit=_fb_budget,
                        gap_tolerance=gap_tolerance,
                        use_obbt=False,
                        require_incremental=True,
                    )
                if _fb is not None:
                    # Keep the TIGHTER of the two dual bounds, and do it whether or not
                    # the fallback found a primal.
                    #
                    # Which one is tighter depends on the SENSE: for a minimize the dual
                    # bound is a LOWER bound (larger is tighter); for a maximize it is an
                    # UPPER bound (smaller is tighter). ``_is_in_scope`` used to admit
                    # minimize only, so an unconditional ``max`` was correct; #860 widens
                    # the engine to maximize models, where ``max`` would still be SOUND
                    # (both are valid upper bounds) but would keep the LOOSER one.
                    # Merge conflict note: main moved this merge out of the
                    # ``_fb.objective is not None`` block (#861 review, below) while #860
                    # made it sense-aware; both are needed and they compose — placement
                    # from main, sense from #860.
                    #
                    # Why it moved (#861 review): once a model is admitted but hard, the
                    # fallback spends its whole reserve, computes a sound bound, finds no
                    # primal, and everything was thrown away — the reserve produced
                    # nothing *even though it produced something valid*. Measured on
                    # ball_mk2_30 at a 30 s budget: the fallback returned bound -27.88
                    # (<= the 0.0 oracle) and the solve reported ``bound=None``. That is
                    # the real cost the review flagged as "spends the budget for
                    # nothing", and it is a reporting gap, not a reason to re-tighten
                    # ``require_incremental``: no predicate can decide in advance whether
                    # a primal is coming, and a budget-fraction early exit would forfeit
                    # exactly the late incumbents this fallback exists to catch.
                    if _fb.bound is not None:
                        # #1244: this merge MUTATES an already-constructed
                        # result, so it runs after ``__post_init__`` and must
                        # maintain the (bound, bound_valid, bound_source) triple
                        # itself -- a bound installed here with a stale
                        # ``bound_valid=False`` beside it would be discarded by
                        # every consumer that checks the flag, which is the whole
                        # point of the fallback's work.
                        _maximize = (
                            self._objective is not None
                            and self._objective.sense == ObjectiveSense.MAXIMIZE
                        )
                        if result.bound is None:
                            _fb_wins, _merged_bound = True, _fb.bound
                        elif _maximize:
                            _fb_wins = _fb.bound < result.bound
                            _merged_bound = min(result.bound, _fb.bound)
                        else:
                            _fb_wins = _fb.bound > result.bound
                            _merged_bound = max(result.bound, _fb.bound)
                        if _fb_wins:
                            # #1244. ``_fb`` is an ``LpSpatialResult`` -- a
                            # 6-field NamedTuple with NO ``bound_valid`` /
                            # ``bound_source``, so reading them off it raised
                            # ``AttributeError``, which the ``except`` below
                            # turned into a warning after ``result.bound`` had
                            # already been mutated. The claim is derived here
                            # instead, from what that engine documents: it is a
                            # spatial branch-and-bound whose module invariant is
                            # "every LP bound is a valid LOWER bound on sgn*f",
                            # gated on ``_objective_bound_valid`` -- the same
                            # frontier-bound standard the other B&B routes
                            # report, hence ``bnb_tree``.
                            result._set_bound(_merged_bound, valid=True, source="bnb_tree")
                        else:
                            # The primary's bound survives; its existing claim
                            # still describes it, so re-assert it unchanged
                            # rather than leaving the triple to drift.
                            result._set_bound(
                                _merged_bound,
                                valid=result.bound_valid,
                                source=result.bound_source,
                            )
                    result.node_count = (result.node_count or 0) + _fb.node_count
                # #1038: ``solve_lp_spatial_bb`` neither receives nor consults
                # ``lazy_constraints``/``incumbent_callback``, so its primal is
                # unscreened by the user's gate. "Only ever fills in a MISSING
                # incumbent" is exactly the hole when a callback is in play: the
                # incumbent may be missing *because the user vetoed every point
                # the primary found*, and this branch then reinstated the vetoed
                # point as ``optimal`` — the #748 defect, one layer above the
                # tree (measured on the #748 reproduction: the primary correctly
                # returned ``unknown``/no incumbent and this branch overwrote it
                # with the rejected x=1). Take the fallback's BOUND (merged
                # above — a dual bound over the un-cut relaxation is still valid
                # for the more constrained problem) but never its primal.
                if (
                    _fb is not None
                    and _fb.objective is not None
                    and (lazy_constraints is not None or incumbent_callback is not None)
                ):
                    import logging as _logging

                    _logging.getLogger(__name__).info(
                        "#844 LP-spatial fallback found a primal, but a "
                        "lazy_constraints/incumbent_callback is active and that engine "
                        "cannot consult it — discarding the unscreened primal (#1038); "
                        "its dual bound is kept."
                    )
                elif _fb is not None and _fb.objective is not None:
                    from discopt.solver import _unpack_solution

                    result.status = _fb.status
                    result.objective = _fb.objective
                    result.x = _unpack_solution(self, np.asarray(_fb.x))
                    result.gap = _fb.gap
                    # Never claim a certificate the fallback did not actually prove.
                    result.gap_certified = _fb.status == "optimal"
                    # Say which engine answered. The route used to keep naming the
                    # primary alone, so a result the LP-per-node engine proved read
                    # as the primary's (measured: nvs15 under ``nlp_bb=True,
                    # deterministic=True`` -- NLP-BB returned ``time_limit`` with one
                    # node, this branch certified in 38, and the route said
                    # ``nlp-bb``).
                    # ``_fb`` is an ``LpSpatialResult`` (status, objective, bound,
                    # gap, x, node_count) with no route of its own, so the engine is
                    # named here; reading ``_fb.algorithm_route`` raised and the
                    # ``except`` below reported a "failed" fallback after the primal
                    # had already been adopted.
                    result.algorithm_route = (
                        f"{result.algorithm_route or 'unknown'} [#844 no-incumbent "
                        "fallback: lp-spatial-bb]"
                    )
                    result.solver_stats = {
                        **(result.solver_stats or {}),
                        "fallback/lp_spatial_primal": 1.0,
                    }
            except Exception as _fb_exc:
                # Never break a solve -- but never swallow silently either. A bare
                # ``except`` here previously turned a hard TypeError into an invisible
                # no-op and cost several wrong conclusions.
                _warnings.warn(
                    f"#844 LP-spatial fallback failed, keeping the default-path "
                    f"result: {type(_fb_exc).__name__}: {_fb_exc}",
                    RuntimeWarning,
                    stacklevel=2,
                )
            finally:
                # The fallback's time is part of this solve. ``wall_time`` was the
                # primary's alone, so a solve that ran 7.4 s reported 0.3 s.
                # Python-driven engine, so its time goes to ``python_time`` and the
                # rust/python partition of ``wall_time`` still holds.
                _fb_elapsed = _time.perf_counter() - _t_fb0
                result.wall_time += _fb_elapsed
                result.python_time += _fb_elapsed

        # --- Adopt a DECLINED convex-kernel attempt's INCUMBENT (#1440) ------- #
        # Same waste, the other half of it. #1422 bought back the dual bound a
        # declined attempt proved and dropped; a declined attempt also discards any
        # FEASIBLE POINT it found. Both come out of the budget the attempt already
        # spent, so neither changes the allocation #1440 is about -- and the
        # allocation is not fixable directly: the two obvious repairs (a fractional
        # cap, abandon-on-no-incumbent) were built and falsified under #911 and
        # #1422 respectively. Recovering what the spend already produced is what is
        # left, and it is free.
        #
        # Measured on ``clay0303hfsg`` (kernel-eligible, declines at any budget below
        # ~16 s): at a 12 s limit the attempt holds a point with objective 47287.5613
        # against a reference optimum of 26669.10957 -- valid, not a false primal
        # -- while proving a bound of 23239.60-25496.44. Today that solve returns an
        # incumbent of NONE with the kernel on; with the kernel off it returns an
        # incumbent but a bound of -0.0, a 100% gap. Adopting both halves reports a
        # ~50% gap where neither configuration reported anything usable.
        #
        # Soundness -- this is a STRONGER argument than the bound's, not a weaker
        # one. A dual bound can only be inferred; an incumbent is CHECKABLE, and this
        # one is checked twice against the PRISTINE model before it can be reported:
        # once by #779's ``_incumbent_is_feasible`` (the full row-map verifier) at the
        # publication site in ``_convex_kernel``, and again by the #772 false-primal
        # screen below, which runs on whatever ``result.x`` holds by then and so
        # covers the adopted point with no change of its own. A point is never a
        # certificate either way: ``gap_certified`` is never set here, and the status
        # is never upgraded -- a recovered incumbent turns "time limit, nothing found"
        # into "time limit, here is a feasible point", which is exactly what it is.
        if _ck_declined_incumbent is not None:
            from discopt.solvers._gap import (
                bound_inversion_tolerance as _ci_inv_tol_fn,
            )
            from discopt.solvers._gap import reported_gap as _ci_gap_fn

            _ci_obj, _ci_x = _ck_declined_incumbent
            # Minimization space for either sense, as in the bound merge below:
            # ``objective_sense_sign`` is -1.0 for MAXIMIZE, so ``_s * value`` is
            # always "smaller is better" and one set of comparisons covers both.
            _s = objective_sense_sign(self)
            _ci_cand = _s * float(_ci_obj)
            _ci_cur = None if result.objective is None else _s * float(result.objective)
            _ci_log = _logging.getLogger("discopt.solver")
            if _ci_cur is not None and _ci_cand >= _ci_cur:
                # Nothing to buy: the default path already found this point or better.
                # (Not an error, and by far the common case -- the kernel declines
                # most often on models the default path then solves outright.)
                pass
            elif result.status == "infeasible":
                # The default path PROVED no feasible point exists and the kernel
                # holds one that the row-map verifier accepted. One of the two is
                # unsound and nothing here can tell which, so report neither and say
                # so loudly rather than overwrite a proof with a point (§3).
                _ci_log.error(
                    "convex kernel: DISCARDING the declined attempt's verified incumbent "
                    "%.12g — this solve returned status='infeasible', so one of the two is "
                    "unsound. Keeping the default path's result unchanged. Please report "
                    "this against #1440 with the model.",
                    float(_ci_obj),
                )
            elif result.gap_certified:
                # A certified result asserts its incumbent IS the optimum; a verified
                # feasible point strictly better than it contradicts the certificate.
                # Same refusal as above -- never silently break a certificate, never
                # silently keep one the evidence disputes.
                _ci_log.error(
                    "convex kernel: DISCARDING the declined attempt's verified incumbent "
                    "%.12g — it improves on the CERTIFIED optimum %.12g this solve "
                    "reported, so one of the two is unsound. Keeping the default path's "
                    "result unchanged. Please report this against #1440 with the model.",
                    float(_ci_obj),
                    float(result.objective) if result.objective is not None else float("nan"),
                )
            elif (
                result.bound is not None
                and result.bound_valid
                and _s * float(result.bound) - _ci_cand
                > _ci_inv_tol_fn(_s * float(result.bound), _ci_cand)
            ):
                # The point sits BELOW a dual bound this solve proved valid. Same
                # refusal: a rigorous bound and a verified point cannot both be right.
                _ci_log.error(
                    "convex kernel: DISCARDING the declined attempt's verified incumbent "
                    "%.12g — it crosses the dual bound %.12g this solve proved, so one of "
                    "the two is unsound. Keeping the default path's result unchanged. "
                    "Please report this against #1440 with the model.",
                    float(_ci_obj),
                    float(result.bound),
                )
            else:
                result.objective = float(_ci_obj)
                result.x = dict(_ci_x)
                # ``gap`` has to move with the pair it is computed from (#1386): a
                # gap left over from the default path's (bound, objective) describes
                # numbers that are no longer both there. Recompute it when a valid
                # bound exists and drop it otherwise, rather than leave a stale one.
                if result.bound is not None and result.bound_valid:
                    result.gap = _ci_gap_fn(
                        float(_ci_obj),
                        float(result.bound),
                        abs_tol=_post_solve_abs_gap_tol(result, abs_gap_tolerance),
                    )
                else:
                    result.gap = None
                _ci_log.debug(
                    "convex kernel: adopted the declined attempt's verified incumbent "
                    "%.12g (previous: %s)",
                    float(_ci_obj),
                    "none" if _ci_cur is None else f"{_s * _ci_cur:.12g}",
                )

        # --- Adopt a DECLINED convex-kernel attempt's dual bound (#1422) ------ #
        # The attempt above took ``min(time_limit, DISCOPT_CONVEX_KERNEL_BUDGET)`` --
        # the caller's WHOLE budget for any ``time_limit <= 120`` -- so on a model it
        # declines, everything below it ran with ~0 s left and typically reports no
        # bound at all. The kernel had nonetheless PROVED one and dropped it on the
        # floor: on ``ball_mk2_30`` (this issue's instance) its tree proves -28.8789
        # while the solve returns ``bound=None``. Measured over the 39 kernel-eligible
        # instances of the MINLPLib snapshot at an 8 s budget, 82% of all kernel wall
        # (152.0 s of 185.4 s) goes to models it declines, and 15 of those 20 carry a
        # finite discarded bound.
        #
        # This buys the bound back at zero cost to the attempt, which is why it is
        # viable where the two ALLOCATION fixes are not: a fractional cap was built
        # and rejected under #911, and abandon-on-no-incumbent was falsified for this
        # issue -- the kernel finds its first incumbent essentially AT convergence
        # (16 of 19 certifiers past 50% of their own wall, 10 past 97%), so
        # "no incumbent yet" predicts nothing and cutting on it costs certifications
        # at exactly the tight budgets where the waste hurts. This does not fix the
        # allocation; it stops the allocation being paid for nothing.
        #
        # Runs after the #844 merge so the two bound merges compose -- whichever of
        # the three routes proved the tightest bound is the one reported.
        #
        # Soundness: a declined attempt has no verified incumbent, so #779's
        # cross-check is unavailable here. The evidence that stands in for it is in
        # ``keep_declined_bound_enabled`` (12 oracle-backed comparisons against
        # ``minlplib.solu``, 0 bounds above their reference optimum), and only the two
        # outcomes whose ``bound`` is a genuine minimum over OPEN nodes are published
        # at all. Two guards ship regardless. Above all, this bound is NEVER used to
        # prune: it lands on an already-finished result, so even if it were wrong it
        # could not cut an optimum out of any search.
        if _ck_declined_bound is not None:
            # ``_s * bound`` is a LOWER bound in minimization space for either sense,
            # so one comparison covers both (``objective_sense_sign`` is -1.0 for a
            # MAXIMIZE model, whose ``bound`` is an upper bound). This is the #860
            # lesson from the merge above: an unconditional ``max`` stays SOUND on a
            # maximize model but keeps the LOOSER of the two bounds.
            from discopt.solvers._gap import (
                bound_inversion_tolerance as _bound_inversion_tolerance,
            )
            from discopt.solvers._gap import reported_gap as _reported_gap

            _s = objective_sense_sign(self)
            _cand = _s * float(_ck_declined_bound)
            _obj = result.objective
            _cur = result.bound
            _inv_tol = _bound_inversion_tolerance(
                _cand, _s * float(_obj) if _obj is not None else _cand
            )
            if _obj is not None and _cand - _s * float(_obj) > _inv_tol:
                # Guard 1 -- the bound crosses an incumbent this solve actually
                # found. One of the two is unsound and nothing here can tell which,
                # so report neither: leave the default path's result untouched and
                # say so loudly rather than ship a broken certificate (§3).
                _logging.getLogger("discopt.solver").error(
                    "convex kernel: DISCARDING the declined attempt's dual bound %.12g — it "
                    "crosses the incumbent %.12g this solve found, so one of the two is "
                    "unsound. Keeping the default path's result unchanged. Please report "
                    "this against #1422 with the model.",
                    float(_ck_declined_bound),
                    float(_obj),
                )
            elif _cur is None or _cand > _s * float(_cur):
                # Guard 2 -- adopt only when it is strictly TIGHTER than whatever the
                # routes above proved (and whenever they proved nothing).
                #
                # ``_set_bound``, not ``result.bound = ...``: the (bound, bound_valid,
                # bound_source) triple moves together (#1244), and a bound installed
                # beside a stale ``bound_valid=False`` is discarded by every consumer
                # that checks the flag -- i.e. silently buys back nothing.
                # ``bnb_tree``: the convex kernel is a native branch-and-bound tree
                # and this is its frontier bound, the same standard the other B&B
                # routes report under that provenance.
                result._set_bound(float(_ck_declined_bound), valid=True, source="bnb_tree")
                if _obj is not None:
                    # #1585: the one SolveResult.gap formula (symmetric in the
                    # pair, so the reported-sense values go in directly).
                    result.gap = _reported_gap(
                        float(_obj),
                        float(_ck_declined_bound),
                        abs_tol=_post_solve_abs_gap_tol(result, abs_gap_tolerance),
                    )

        # Attach model reference and auto-generate LLM explanation
        result._model = self

        # --- Verify the final incumbent against the ORIGINAL problem (#772) ---
        # A reported incumbent that is INFEASIBLE in the original model is a false
        # primal — the worst error class (CLAUDE.md §1). It cannot happen on correct
        # solver code, but if an unsound presolve mutation or a heuristic bug ever
        # produces one, this guard refuses to return it: withhold the incumbent and
        # decertify, loudly. The check is deliberately LOOSE so it can never flag an
        # incumbent that is feasible within the solver's own tolerance — only a gross
        # violation (the #770 violations were 0.4–17.6) trips it. That looseness lives
        # in ``passes_false_primal_screen``, shared with the single-NLP source screen
        # in ``solver.py`` so the two cannot drift; spelling it inline as ``tol=1e-3``
        # loosened only the absolute leg and made the screen scale-blind on
        # large-magnitude rows (#1061).
        # ``result.x`` is truth-tested, not ``is not None``-tested: a solver that
        # reports "no incumbent" as an EMPTY DICT rather than ``None`` (every
        # no-incumbent exit of the MIP-NLP/OA route did, #1105) sails past an
        # ``is not None`` check and reaches the ``result.x[_n]`` lookup below,
        # which raises ``KeyError: 'x0'``. That lands in the ``except`` arm, so
        # the user is told the incumbent is "UNSCREENED" for a solve that has no
        # incumbent at all -- a soundness warning fired on a result where there
        # was nothing to screen. Screening runs only when an incumbent exists.
        if _verify_snap is not None and result.x:
            try:
                import numpy as _np

                from discopt._relax.primal_heuristics import passes_false_primal_screen

                _snap_ev, _snap_names = _verify_snap
                _flat = _np.concatenate(
                    [
                        _np.atleast_1d(_np.asarray(result.x[_n], dtype=_np.float64)).ravel()
                        for _n in _snap_names
                    ]
                )
                if not passes_false_primal_screen(_snap_ev, _flat):
                    _logging.getLogger("discopt.solver").error(
                        "FALSE PRIMAL DETECTED: the reported incumbent (objective=%s) is "
                        "INFEASIBLE in the original problem. This indicates an unsound presolve "
                        "mutation or a heuristic bug. Withholding the incumbent and decertifying "
                        "— the result is NOT a valid solution.",
                        result.objective,
                    )
                    _withhold_false_primal(result)
            except Exception as _ver_exc:
                # A swallowed exception here does not "skip verification" -- it
                # DELETES the soundness guard while leaving every caller believing
                # it ran, which is exactly the failure CLAUDE.md §7 is written from.
                # The solve is still returned (a broken checker must not break a
                # correct solve), but silently is not an option.
                _logging.getLogger("discopt.solver").error(
                    "INCUMBENT VERIFICATION DID NOT RUN: %s: %s. The false-primal "
                    "guard was skipped, so this incumbent is UNSCREENED.",
                    type(_ver_exc).__name__,
                    _ver_exc,
                )
                _warnings.warn(
                    f"incumbent verification did not run "
                    f"({type(_ver_exc).__name__}: {_ver_exc}); the returned incumbent "
                    f"is unscreened by the false-primal guard",
                    RuntimeWarning,
                    stacklevel=2,
                )

        # --- #1551: a certificate finer than the objective's float resolution ---
        # ``solve_model``'s wrapper runs the same check on every result it returns;
        # repeated here for what this method does after that call (the #844
        # fallback merge), and BEFORE the derived reports below so ``sensitivity``,
        # ``validation_report`` and the no-bound diagnostic describe the result the
        # caller is handed, not the pre-withdrawal one. Idempotent: a withdrawn
        # certificate is not re-tested. The convex-kernel fast path returns early
        # and calls the same guard at its own return.
        if isinstance(result, SolveResult):
            # #1561: after the #772 screen (which may already have withheld the
            # point) and on the same pre-solve snapshot of the declared rows. It
            # judges the point the ROUTE certified: a route whose gate accepted a
            # point verify_point rejects loses its certificate whatever the repair
            # below makes of the point.
            if _verify_snap is not None and _verify_snap_vars is not None:
                _withhold_unverified_certificate(
                    result, _verify_snap[0], _verify_snap_vars, _verify_snap_logic
                )
            else:
                _withhold_unverified_certificate(result)
            # #1537 E: publish the incumbent repaired to float noise and re-judge its
            # certificate on the repaired objective (downgrade-only; bound untouched).
            if _verify_snap is not None and _verify_snap_vars is not None:
                _repair_published_incumbent(
                    result, _verify_snap[0], _verify_snap_vars, _verify_snap_logic
                )
            else:
                _repair_published_incumbent(result)
            _guard_unresolved_objective(result)
            # #1678 (b): after every other guard, so nothing re-grants it.
            self._withhold_default_box_certificate(result)
            # #1775 G2.6: a user big-M that could not be certified.
            self._withhold_user_big_m_certificate(result, _ubm_snapshot)
            # #1848: a box robust counterpart that is only a conservative restriction.
            self._withhold_conservative_ro_certificate(result)
            # #1775 G6.2: a point the route's exit gate refused, that the #1537 repair
            # above did not turn into one ``verify_point`` accepts, is not reported.
            _withdraw_refused_incumbent(result, time_limit, kwargs.get("max_nodes"))
            # #1727: drop the factorable lift's auxiliary columns from ``x``. After
            # the guards above, which judge the point as the route left it. Only
            # names the lift recorded AND the caller did not declare.
            if _lift_aux_names and result.x:
                _declared_names = {v.name for v in self._variables}
                for _aux_name in _lift_aux_names - _declared_names:
                    result.x.pop(_aux_name, None)

        if llm:
            try:
                result._explanation = result._explain_with_llm()
            except Exception as _exp_exc:  # noqa: BLE001 - advisory only, never blocks solving
                _logging.getLogger("discopt.llm").debug(
                    "post-solve LLM explanation skipped: %s: %s",
                    type(_exp_exc).__name__,
                    _exp_exc,
                )

        if sensitivity:
            # Until this branch existed the flag was DEAD: `sensitivity` appeared in
            # the signature and the docstring and was read nowhere, so
            # `solve(sensitivity=True)` was byte-for-byte `solve()` while promising
            # derivatives (CLAUDE.md §3 -- no dead flags). It now eagerly computes
            # what `result.gradient()` would otherwise compute on first call, at THIS
            # result's own x, so the two paths cannot disagree and an unsupported
            # model (integers, no parameters, no incumbent) is refused here rather
            # than at some later `.gradient()` call.
            #
            # Deliberately NOT wrapped in try/except: the caller asked for
            # derivatives, so failing to produce them is a failure, not an advisory
            # (contrast the `llm` block above, which is decoration).
            #
            # This is d(obj*)/dp only -- the envelope theorem needs nothing but the
            # duals already in hand. dx*/dp is a different object requiring its own
            # KKT solve, and lives in `Model.sensitivity()`.
            result._ensure_sensitivity()

        if validate and result.x:  # same no-incumbent guard as above (#1105)
            try:
                from discopt.validation.examiner import examine

                result.validation_report = examine(result, self)
            except Exception:
                result.validation_report = None

        # --- #1493: an ``error`` status always says what failed ---------------- #
        # ``error`` is documented as "why this solve failed", yet only
        # ``solve_batch`` ever set it, so every in-process ``status="error"``
        # arrived with ``error=None`` and the caller could not tell a backend
        # failure from a withheld incumbent from a crashed relaxation. Routes that
        # know their cause now record it at the source (the single-NLP route, the
        # false-primal guard above); this is the backstop for every other route, so
        # the invariant holds for all of them rather than for the ones audited.
        if isinstance(result, SolveResult) and result.status == "error" and not result.error:
            result.error = (
                "the solve route ended with status='error' without recording a cause; "
                "the discopt.solver log for this solve has the details"
            )

        # --- No dual bound at all: say so (#1256) ---------------------------- #
        # A solve that produces no valid relaxation bound returns ``bound=None``
        # and, absent this, says nothing else: the only trace was a
        # ``logger.debug`` inside whichever relaxation declined, so a user reading
        # ``status="feasible", bound=None`` had no way to tell "the gap is open"
        # from "nothing ever bounded this model". The reproducer was
        # ``log10(sum(10**y))``, whose ``10**y`` canonicalized to an opaque node
        # with no envelope; every node inherited no bound and the search ran to the
        # limit silently. WARNING (not ``warnings.warn``) so it reaches a user who
        # has configured no logging at all, without turning into a test-visible
        # Python warning on a result that is otherwise correct.
        # #1533: solver="pounce" never builds a relaxation, so "the relaxation layer
        # could not bound this objective" would misdescribe it; its missing bound is
        # the route's contract. Scoped to that route only: every other route keeps
        # both diagnostics below exactly as before.
        # #1551: a bound withdrawn because the objective is unresolvable at the
        # incumbent was produced and then refused, with its own WARNING; "could not
        # bound this objective" would misdescribe that too.
        # #1753: a deliberate local solve (skip_convex_check=True) builds no
        # relaxation either; the abstained-classifier local route gets its own
        # warning below instead of the envelope advice.
        _local_nlp_route = isinstance(result, SolveResult) and (
            result.algorithm_route or ""
        ).startswith("local-nlp:")
        _no_bound_by_design = isinstance(result, SolveResult) and (
            (result.algorithm_route or "").startswith("pounce:")
            or (_local_nlp_route and "skip_convex_check=True" in (result.algorithm_route or ""))
            or bool((result.solver_stats or {}).get("certificate/objective_unresolved"))
            # #1678 (b): withdrawn because it rested on the default box, with its
            # own warning naming the variables.
            or bool((result.solver_stats or {}).get("certificate/default_box_withheld"))
        )
        if isinstance(result, SolveResult) and result.bound is None and result.status == "error":
            # #1507: the envelope/epigraph advice below describes a relaxation that
            # could not bound the objective. On a failed solve that diagnosis is a
            # guess, and it was wrong on the linear-objective convex QCP #1507
            # reported; say what is actually known instead.
            _logging.getLogger("discopt.solver").warning(
                "No valid dual bound was produced for model %r: the solve failed "
                "(status=error: %s). The result cannot be certified globally optimal.",
                self.name,
                result.error,
            )
        elif (
            isinstance(result, SolveResult)
            and result.bound is None
            and result.status not in ("infeasible", "unbounded")
            and not _no_bound_by_design
            and (_poles := _objective_poles_or_none(self))
        ):
            # #1493: a POLE, not a missing envelope. ``min 1/x`` on ``[-5, 5]``
            # has no dual bound on any box holding ``x = 0`` -- the objective is
            # unbounded there -- and the epigraph advice below cannot change that.
            # The status stays what the solve proved (a feasible point, no bound):
            # ``unbounded`` means CERTIFIED unboundedness (``discopt.status``),
            # which no relaxation proves at a pole, and the constraints may
            # exclude the pole anyway (``x**2 >= 1``).
            from discopt._relax.poles import describe_poles

            if all(p.excluded_by_constraints for p in _poles):
                # #1616 A-04: the box allows the denominator to vanish but the
                # linear rows do not, so "a pole inside the box" mis-states the
                # cause. The relaxation bounds each term over the variable box and
                # never sees the implied range; a variable carrying that range does.
                _logging.getLogger("discopt.solver").warning(
                    "No valid dual bound was produced for model %r (status=%s): its "
                    "objective divides by an expression that the variable bounds "
                    "allow to reach 0, although the linear constraints keep it away "
                    "from 0 -- %s. The relaxation bounds each term over the variable "
                    "box, where the quotient is unbounded, so it does not use that "
                    "implied range. To give it the range, introduce a variable for the "
                    "denominator with the implied bound, e.g. "
                    "`d = m.continuous('d', lb=<implied lower bound>)` with "
                    "`m.subject_to(d == <denominator>)`, and divide by `d`.",
                    self.name,
                    result.status,
                    describe_poles(_poles),
                )
            else:
                _logging.getLogger("discopt.solver").warning(
                    "No valid dual bound was produced for model %r (status=%s): its "
                    "objective has a pole inside the variable box -- %s. The objective "
                    "diverges near the pole, so no relaxation can bound it on a box "
                    "that contains the pole and the result carries no optimality claim "
                    "(the problem itself is unbounded if it diverges in the optimizing "
                    "direction at feasible points near the pole). If the pole is not "
                    "meant to be reachable, bound the denominator away from zero (e.g. "
                    "a strictly positive lower bound) or split the model by its sign.",
                    self.name,
                    result.status,
                    describe_poles(_poles),
                )
        elif (
            isinstance(result, SolveResult)
            and result.bound is None
            and result.status not in ("infeasible", "unbounded")
            and not _no_bound_by_design
            and _local_nlp_route
        ):
            # #1753: the convexity classifier abstained, so the solve ran one local
            # NLP and built no relaxation; the envelope advice would misdescribe it.
            _logging.getLogger("discopt.solver").warning(
                "No valid dual bound was produced for model %r (status=%s): "
                "convexity could not be established, so the model was solved by a "
                "single local NLP and no relaxation was built. The result is a "
                "feasible point with no global optimality claim.",
                self.name,
                result.status,
            )
        elif (
            isinstance(result, SolveResult)
            and result.bound is None
            and result.status not in ("infeasible", "unbounded")
            and not _no_bound_by_design
        ):
            _logging.getLogger("discopt.solver").warning(
                "No valid dual bound was produced for model %r: the relaxation "
                "layer could not bound this objective (status=%s). The result "
                "cannot be certified globally optimal. A nonlinear term with no "
                "envelope is the usual cause; an epigraph reformulation "
                "(minimize z subject to f(x) <= z) often gives the relaxation "
                "something to bound.",
                self.name,
                result.status,
            )
        elif (
            isinstance(result, SolveResult)
            and result.bound is not None
            and result.status in ("feasible", "time_limit", "node_limit", "iteration_limit")
            and not result.gap_certified
            and not _no_bound_by_design
            and (_poles := _objective_poles_or_none(self))
            and not all(p.excluded_by_constraints for p in _poles)
        ):
            # #1680: the pole case of the #1493 diagnostic when a bound DID come
            # back. A least-squares fit of ``k1/(k2-k1) * (...)`` is bounded below by
            # 0 (every term is squared), so the tree is not fathomed at the root the
            # way ``min 1/x`` is: it branches until the time limit, because every
            # node box that still meets the pole set (here the whole diagonal
            # ``k1 == k2``) keeps the trivial bound and cannot be pruned. Measured on
            # the A->B->C reproducer: ``time_limit=30`` returned at 30.2 s with
            # ``bound=0.0`` and the right incumbent and said nothing about why the
            # gap stayed open. Only on an uncertified result, so it never adds noise
            # to a certified one; detection only, like the branch above.
            from discopt._relax.poles import describe_poles

            _logging.getLogger("discopt.solver").warning(
                "The gap did not close for model %r (status=%s, bound=%.6g): its "
                "objective has a pole inside the variable box -- %s. Every branch-and-"
                "bound node whose box meets the pole keeps a weak bound and cannot be "
                "pruned, so the search runs to its limit without certifying. If "
                "the singularity is removable (a 0/0 such as k1/(k2-k1)*(exp(-k1*t)-"
                "exp(-k2*t)) at k1 == k2), rewrite the expression without the division; "
                "otherwise bound the denominator away from zero or split the model by "
                "its sign.",
                self.name,
                result.status,
                float(result.bound),
                describe_poles(_poles),
            )

        # --- The objective must be THIS model's objective at the returned point -
        #
        # A solve may run on a REFORMULATED model -- `factorable_reformulate`
        # lifts subexpressions into `_fr_aux_*` columns, `reformulate_integer_*`
        # binary-expands integer factors into `_ipx_*` columns -- and the value it
        # reports is that lifted model's objective at the lifted point. The lift is
        # exact in exact arithmetic, but its big-M rows carry the binary-expansion
        # weights, so a row violation INSIDE the absolute feasibility tolerance
        # buys objective in proportion to those weights.
        #
        # Measured on `nvs07` via the NLP-BB route (minlplib optimum 4.0). The
        # lifted model is `factorable -> integer-bilinear`, 84 columns, 261 rows:
        #
        #   reported objective   3.9992714241881955   gap_certified=True
        #   lifted objective at the reported point    3.9992714241881955  (agrees)
        #   worst lifted row violation                9.82e-09  (gate is 1e-06)
        #   THIS model's objective at that same point 4.000005454149035
        #
        # 64 lifted rows sit violated by ~1e-9..1e-8, each a big-M row whose
        # objective sensitivity reaches 3.3e+04; the objective slack they can buy
        # totals 7.345e-04 against an observed super-optimality of 7.286e-04. So
        # the solve certified a value 7.3e-04 BELOW an attainable optimum -- a
        # false optimal, CLAUDE.md #1's worst class -- while every check it ran
        # agreed with it, because they all ran in the lifted space.
        #
        # The user's model is the arbiter of what its objective is. `self` is
        # pristine here: the reformulations rebind `solve_model`'s local, never
        # this object (root cuts may APPEND rows, which cannot change the
        # objective). Downgrade-only: this replaces a number, and then the shared
        # certificate guard re-tests the pair, so a gap that existed only in
        # lifted space is withdrawn rather than republished.
        #
        # This makes the REPORT honest; it does not make the lift exact. The gate
        # still measures an absolute row violation against rows whose objective
        # sensitivity the lift itself introduced, so the search still explores a
        # space that is not equivalent to this model at solver tolerance. That is
        # tracked in #1414 (with #1380's unfiled follow-up folded into it); this
        # reconciliation is the CLAUDE.md #3 workaround that ships alongside it.
        if (
            isinstance(result, SolveResult)
            and result.objective is not None
            and result.x is not None
        ):
            self._reconcile_objective_with_model(result)

        # --- #1313: remember the point this model was solved to ---------------- #
        # ``Model.sensitivity()`` runs its own local NLP, whose starting point
        # decides which local solution the derivatives describe on a nonconvex
        # model. Without this the two calls answered about different basins and
        # both said ``status="optimal"``. Kept as the last *successful* solve only
        # (a failed/infeasible solve carries no point to start from) and read
        # nowhere on the solve path itself.
        if isinstance(result, SolveResult) and result.x is not None:
            # --- #1322: stamp WHICH problem this point solves ----------------
            # Nothing invalidated the recorded result when the model changed,
            # and the cross-check compared objective VALUES only, so a
            # parameter change that moved the global optimum to another basin
            # left `sensitivity()` warm-starting into the old well and
            # reporting `matches_reference=True` -- the #1313 failure again,
            # now with a stamp saying it had been checked. The fingerprint is
            # process-local (it holds object identities) and is attached to the
            # result rather than declared on it, so it cannot ride along into a
            # serialized document; `result_io` writes an explicit field list.
            # Deliberately not guarded: `solution_state_fingerprint` is a total
            # function over model state that has already been validated and
            # solved, so a raise here is a real defect, and a swallowed one
            # would put the reference back to being unverifiable while still
            # reporting `matches_reference=True` -- the exact failure being
            # fixed.
            from discopt._evaluator_cache import solution_state_fingerprint

            setattr(result, "_problem_fingerprint", solution_state_fingerprint(self))
            self._last_solve_result = result

        # #2042: an attached debugger must never be bypassed in silence. Routes with
        # a search tree fire checkpoints (the native kernel and HiGHS defer to ones
        # that do); a route with no tree to step through -- an LP, a convex QP/NLP,
        # the convex-MINLP decomposition -- fires none, so say so.
        if _debug_guard is not None and _debug_guard.session.checkpoints_seen == 0:
            _route = getattr(result, "algorithm_route", None) or "unknown"
            _warnings.warn(
                f"debug: this solve fired no debugger checkpoints (route {_route!r} "
                "has no branch-and-bound tree the debugger can step through), so "
                "nothing was recorded.",
                UserWarning,
                stacklevel=2,
            )

        return result

    def _withhold_user_big_m_certificate(
        self, result: "SolveResult", snapshot: Optional[dict[int, int]] = None
    ) -> None:
        """#1775 G2.6: no certificate that rests on an unverified user big-M.

        A user M (``either_or(..., big_m=...)``) that is too small cuts feasible
        points of an unselected disjunct, so neither an optimum, nor a dual bound,
        nor an infeasibility proved over the lowered model is a proof for the
        model as declared. :func:`discopt.gdp.user_big_m.uncertified_user_big_ms`
        names every user M it could not certify (one proven too small has already
        been refused by the lowering). When it names any: ``optimal`` becomes
        ``feasible``, ``infeasible`` becomes ``unknown``, ``gap_certified`` is set
        ``False`` and the bound and gap are cleared. The incumbent is kept: it was
        verified against the declared model by the guards before this one.

        Only the disjunctions whose user Ms a lowering of this solve read are
        judged (``snapshot``, from :func:`discopt.gdp.user_big_m.use_counts` at
        the start of the solve): ``hull``, ``mbigm`` and the other methods ignore
        a user M (with a warning), so it cannot weaken their result -- and its
        validation may not even apply there (a row ``hull`` lowers but big-M
        cannot, #1851 review). A disjunction with a user M and no tracking key is
        always judged. Without a snapshot every one is judged. Only ever
        downgrades.
        """
        from discopt.gdp.user_big_m import (
            model_has_user_big_m,
            uncertified_user_big_ms,
            used_since,
        )

        if not model_has_user_big_m(self):
            return
        if not (
            result.status in ("optimal", "infeasible")
            or bool(result.gap_certified)
            or result.bound is not None
        ):
            return
        reasons = uncertified_user_big_ms(
            self, used=None if snapshot is None else used_since(snapshot)
        )
        if not reasons:
            return
        import logging as _ulogging
        import warnings as _uwarnings

        msg = (
            f"{self.name}: {len(reasons)} user big_m value(s) could not be certified, so "
            f"this result carries no certificate and no dual bound (#1775 G2.6). First: "
            f"{reasons[0]}. Raise big_m above the reported bound, or leave it unset."
        )
        _ulogging.getLogger("discopt.solver").warning(msg)
        _uwarnings.warn(msg, UserWarning, stacklevel=3)
        if result.status == "optimal":
            result.status = "feasible"
        elif result.status == "infeasible":
            result.status = "unknown"
        result.gap_certified = False
        result._set_bound(None, valid=False)
        result.gap = None
        result.solver_stats = dict(result.solver_stats or {})
        result.solver_stats["certificate/user_big_m_uncertified"] = float(len(reasons))

    def _withhold_conservative_ro_certificate(self, result: "SolveResult") -> None:
        """#1848: no certificate from a robust counterpart that is not exact.

        The box counterpart worst-cases each occurrence of an uncertain parameter
        on its own. Where a component still occurs more than once in a non-affine
        row (after like terms cancel), the occurrences may take different bounds,
        so the counterpart is a conservative *restriction* of the robust problem:
        a point it accepts is robust, but its ``infeasible`` does not prove the
        robust problem infeasible and its optimum is not the robust optimum. The
        rows are recorded by ``discopt.ro`` (``CONSERVATIVE_ATTR``); a result on
        such a model keeps its point and loses its certificate. Only downgrades.
        """
        from discopt.ro.formulations._common import CONSERVATIVE_ATTR

        rows = getattr(self, CONSERVATIVE_ATTR, None)
        if not rows:
            return
        if not (
            result.status in ("optimal", "infeasible")
            or bool(result.gap_certified)
            or result.bound is not None
        ):
            return
        import logging as _rlogging
        import warnings as _rwarnings

        msg = (
            f"{self.name}: the box robust counterpart of {rows} is conservative (an "
            "uncertain parameter occurs more than once in a nonlinear term, and each "
            "occurrence was worst-cased separately), so this result is robust but "
            "carries no certificate and no dual bound (#1848)."
        )
        _rlogging.getLogger("discopt.solver").warning(msg)
        _rwarnings.warn(msg, UserWarning, stacklevel=3)
        if result.status == "optimal":
            result.status = "feasible"
        elif result.status == "infeasible":
            result.status = "unknown"
        result.gap_certified = False
        result._set_bound(None, valid=False)
        result.gap = None
        result.solver_stats = dict(result.solver_stats or {})
        result.solver_stats["certificate/ro_conservative_rows"] = float(len(rows))

    def _withhold_default_box_certificate(self, result: "SolveResult") -> None:
        """#1678 (b): no certificate that rests on the default ``±9.999e19`` box.

        A variable declared without a bound gets ``DEFAULT_VARIABLE_BOUND`` on
        that side. That number is a stand-in for "no bound" -- the user never
        wrote it -- so a result whose point sits on it describes the box discopt
        invented, not the problem the user posed. ``min x - z**2`` with
        ``z*x <= 3``, ``x`` free and ``z in [-2, 2]`` is unbounded (``z = 0``,
        ``x -> -inf``), yet the spatial tree published ``optimal`` with
        objective = bound = ``-9.999e19`` and ``gap_certified=True``. That is a
        false certificate.

        A side counts as defaulted when its magnitude is at least
        ``DEFAULT_VARIABLE_BOUND``. The value is indistinguishable from an
        explicitly written ``9.999e19``, and both mean "unbounded" (the AMPL and
        NL convention reads ``>= 1e20`` the same way). An explicit finite bound
        below it, even a huge one such as ``1e18``, is honoured as posed (#850).

        A point "sits on" a defaulted side when its coordinate is past
        ``EFFECTIVE_INF`` (``1e19``), the threshold at which POUNCE and Ipopt
        themselves read a value as infinite. Incumbents only approach the corner (``-9.9984e19`` was
        measured), so an equality test would miss them. When a coordinate does,
        the result loses its certificate and its dual bound: ``optimal`` becomes
        ``feasible``, ``gap_certified`` is set ``False``, and ``bound``/``gap``
        are cleared. A bound proved over the invented box says nothing about the
        unbounded problem. ``unbounded`` and ``infeasible`` are left alone. The
        LP/MILP route proves ``unbounded`` directly (``_highs_std_form`` hands
        the default sides to HiGHS as infinite). This guard is the class-level
        backstop for every other route. It only ever downgrades.

        The same holds for a dual bound with no point behind it. A finite
        ``bound`` of magnitude past ``EFFECTIVE_INF`` on a model with a defaulted
        side is a relaxation of the invented box (an unbounded convex MIQP
        measured ``unknown`` with ``bound = -1.9998e20``, twice the default box,
        #1699). It is cleared the same way.

        #2281: the integer fallback box is the same kind of invention. A side
        ``Model.integer`` filled because the caller wrote none (recorded in
        ``Variable._int_default_sides``; a later caller write such as ``x.lb = 0``
        takes it out, discopt's own writes never do) and that still holds its
        default value (``0`` / ``1e6``) counts as defaulted. An entry with
        ``lb == ub`` (a ``fix()`` pin, or a written side equal to the default) is
        held by a written bound and does not count. Integer points reach a
        defaulted side exactly, so a coordinate within half a unit of it is "on"
        it, and the result is
        downgraded as above (``min -x - y`` s.t. ``x - 2y >= -3``, ``x >= 0``
        integer, was certified ``optimal`` at ``x = 1e6`` by the HiGHS MILP route
        and the native spatial kernel; it is unbounded). An explicitly written
        ``ub=1e6`` is not a default and is honoured. The bound-only test above
        does not apply: a dual bound near ``-1e6`` is not recognisable as the
        box's. The ``.nl`` path defaults integers to ``+/-inf`` and never sets the
        record.
        """
        import logging as _dlogging
        import warnings as _warnings

        import numpy as _np

        from discopt._relax._numeric import EFFECTIVE_INF
        from discopt.constants import DEFAULT_VARIABLE_BOUND

        _sentinel = DEFAULT_VARIABLE_BOUND * (1.0 - 1e-12)
        _on_side = EFFECTIVE_INF
        hits: list[str] = []
        int_hit = False
        # A variable the model never references (GAMS ``obj =e= f(x)`` folded into
        # the objective leaves ``obj`` behind) is free in every sense: its value
        # is arbitrary, often the box side, and it cannot make the problem
        # unbounded. ``None`` means "could not tell", and then every variable counts.
        used = self._referenced_variable_names()
        by_name = {v.name: v for v in self._variables if used is None or v.name in used}
        for name, val in (result.x or {}).items():
            v = by_name.get(name)
            if v is None:
                continue
            xv = _np.atleast_1d(_np.asarray(val, dtype=_np.float64)).ravel()
            lb = _np.broadcast_to(_np.asarray(v.lb, dtype=_np.float64), v.shape).ravel()
            ub = _np.broadcast_to(_np.asarray(v.ub, dtype=_np.float64), v.shape).ravel()
            if xv.shape != lb.shape:
                continue
            on = ((ub >= _sentinel) & (xv >= _on_side)) | ((lb <= -_sentinel) & (xv <= -_on_side))
            # #2281: the integer analogue. ``Model.integer`` fills an unwritten
            # side with the finite fallback (``0`` / ``1e6``), which -- unlike the
            # ``9.999e19`` corner -- an integer point reaches exactly. A point on
            # it describes the invented box just the same (``min -x`` over
            # ``x >= 0`` integer was certified ``optimal`` at ``x = 1e6``, and the
            # C-6 ``min n`` at ``n = 0``). Within half a unit is "on" for an integer
            # coordinate; the side must still be in the record, which a bound the
            # caller assigns later (``x.ub = 10``, or ``x.lb = 0``) leaves.
            if v._int_default_sides:
                on_int = _np.zeros(xv.shape, dtype=bool)
                if "ub" in v._int_default_sides:
                    on_int |= (ub == _INTEGER_DEFAULT_UB) & (xv > ub - 0.5)
                if "lb" in v._int_default_sides:
                    on_int |= (lb == _INTEGER_DEFAULT_LB) & (xv < lb + 0.5)
                # An entry with ``lb == ub`` is held by a bound the caller wrote (a
                # ``fix()`` pin, or the other side equal to the default), not by
                # the invented one.
                on_int &= lb != ub
                int_hit = int_hit or bool(on_int.any())
                on = on | on_int
            if on.any():
                where = [int(i) for i in _np.flatnonzero(on)[:3]]
                hits.append(name if xv.size == 1 else f"{name}{where}")
        box_bound = False
        if not hits and result.bound is not None:
            b = float(result.bound)
            box_bound = _np.isfinite(b) and abs(b) >= _on_side
            box_bound = box_bound and any(
                bool(_np.any(_np.asarray(v.ub) >= _sentinel))
                or bool(_np.any(_np.asarray(v.lb) <= -_sentinel))
                for v in by_name.values()
            )
        if not (hits or box_bound):
            return
        # A point on the box is always named, even when the result carries no
        # claim to withdraw: a solve stopped by its time limit after its incumbent
        # reached the corner (measured on #1678's own model under CI load: 713
        # nodes in 20 s, x = -9.98e19, no bound) is the same answer about the
        # invented box, and without this warning it was reported only as "the
        # relaxation could not bound this objective". (``box_bound`` implies a
        # bound, so that branch always has something to clear.)
        if hits:
            sides = f"+/-{DEFAULT_VARIABLE_BOUND:g}"
            if int_hit:
                sides += (
                    f", or the default integer lb={_INTEGER_DEFAULT_LB:g} / "
                    f"ub={_INTEGER_DEFAULT_UB:g}"
                )
            what = (
                f"the returned point sits on the default variable bound "
                f"({sides}) for {', '.join(hits[:5])}"
            )
        else:
            what = (
                f"the dual bound {result.bound:g} is of the order of the default "
                f"variable bound (+/-{DEFAULT_VARIABLE_BOUND:g})"
            )
        msg = (
            f"{self.name}: {what}. That bound "
            f"stands in for 'no bound', so the result describes a box the model never "
            f"declared: the problem as posed may be unbounded or have no attained "
            f"optimum. Reporting no dual bound and no certificate "
            f"(#1678, #2281). Declare finite lb/ub for these variables to "
            f"solve a bounded problem."
        )
        _dlogging.getLogger("discopt.solver").warning(msg)
        _warnings.warn(msg, UserWarning, stacklevel=3)
        if result.status == "optimal":
            result.status = "feasible"
        result.gap_certified = False
        result._set_bound(None, valid=False)
        result.gap = None
        result.solver_stats = dict(result.solver_stats or {})
        result.solver_stats["certificate/default_box_withheld"] = 1.0

    def _referenced_variable_names(self) -> Optional[frozenset[str]]:
        """Names of the variables the objective or any constraint touches.

        Returns ``None`` whenever the answer is not certain: no expression
        objective, a builder/``.nl`` model, a non-algebraic constraint (indicator,
        disjunction, SOS, logical), or any node type this walk does not know. A
        caller treats ``None`` as "every variable is referenced", so an
        incomplete walk can only make a guard fire more, never less.
        """
        if self._objective is None or getattr(self, "_nl_repr", None) is not None:
            return None
        if self._builder_linear_objective is not None:
            return None
        if self._builder_quadratic_objective is not None:
            return None
        roots: list = [self._objective.expression]
        for c in self._constraints:
            if type(c) is not Constraint:
                return None
            roots.append(c.body)
        found: set[str] = set()
        seen: set[int] = set()
        stack = roots
        while stack:
            e = stack.pop()
            if id(e) in seen:
                continue
            seen.add(id(e))
            if isinstance(e, Variable):
                found.add(e.name)
            elif isinstance(e, (Constant, Parameter)):
                pass
            elif isinstance(e, IndexExpression):
                stack.append(e.base)
            elif isinstance(e, (BinaryOp, MatMulExpression)):
                stack.extend((e.left, e.right))
            elif isinstance(e, (UnaryOp, SumExpression)):
                stack.append(e.operand)
            elif isinstance(e, (FunctionCall, CustomCall)):
                stack.extend(e.args)
            elif isinstance(e, SumOverExpression):
                stack.extend(e.terms)
            else:
                return None
        return frozenset(found)

    def _reconcile_objective_with_model(self, result: "SolveResult") -> None:
        """Make ``result.objective`` this model's objective at ``result.x``.

        See the call site for the measurement this exists for. Best-effort by
        design in ONE direction only: when the check cannot be made it leaves the
        result exactly as it was (no worse than before) and says so at WARNING,
        so a silently skipped check is visible rather than indistinguishable from
        a passing one. When the check CAN be made, its verdict is final.
        """
        import logging as _logging

        import numpy as _np

        _log = _logging.getLogger(__name__)

        # ``add_linear_objective`` / ``add_quadratic_objective`` leave a zero
        # placeholder in ``_objective``; reconciling against that placeholder
        # "corrected" a correct objective of 3 to 0 (#681 builder tests). The
        # evaluator now lowers the builder block itself via
        # ``_objective_expression`` (#1609), so builder objectives are reconciled
        # like any other. Only a model with no objective at all is skipped.
        if self._objective is None:
            _log.debug("objective reconciliation skipped: this model has no objective.")
            return

        point = result.x
        if point is None or result.objective is None:
            return

        try:
            flat: list[float] = []
            for v in self._variables:
                if v.name not in point:
                    _log.warning(
                        "objective reconciliation skipped: the result carries no value "
                        "for %r, so this model's objective cannot be evaluated at the "
                        "point being reported; leaving objective=%r as the solver "
                        "reported it.",
                        v.name,
                        result.objective,
                    )
                    return
                flat.extend(_np.atleast_1d(_np.asarray(point[v.name], float)).ravel().tolist())
            from discopt._affine_evaluator import post_solve_evaluator

            ev = post_solve_evaluator(self)  # #1743
            f_internal = float(ev.evaluate_objective(_np.asarray(flat, float)))
        except Exception as exc:  # pragma: no cover - evaluator robustness
            _log.warning(
                "objective reconciliation skipped (%s: %s); leaving objective=%r as "
                "the solver reported it.",
                type(exc).__name__,
                exc,
                result.objective,
            )
            return

        f_declared = -f_internal if getattr(ev, "_negate", False) else f_internal
        if not _np.isfinite(f_declared):
            _log.warning(
                "objective reconciliation skipped: this model's objective at the "
                "reported point is %r; leaving objective=%r.",
                f_declared,
                result.objective,
            )
            return

        reported = float(result.objective)
        if abs(f_declared - reported) <= 1e-9 * (1.0 + abs(reported)):
            return
        _is_max = self._objective is not None and self._objective.sense == ObjectiveSense.MAXIMIZE

        _log.warning(
            "%s: reporting this model's objective at the returned point (%.12g) "
            "rather than the solver's internal value (%.12g); they differ by %.3e, "
            "which means the solve ran on a reformulated model whose optimum does "
            "not transfer at this tolerance.",
            self.name,
            f_declared,
            reported,
            f_declared - reported,
        )
        result.objective = f_declared

        # The bound was capped at the incumbent value just replaced. Where the
        # route carried the search's uncapped proved bound, re-cap it at the exact
        # value instead: ``min(proved, f(x))`` (min sense) is at most the optimum,
        # since ``proved`` is a valid bound and ``x`` the returned point. Only ever
        # tightens, and never past the objective.
        from discopt.solver import _recap_bound_at_objective

        _recapped = _recap_bound_at_objective(
            result.bound, f_declared, result._proved_bound, _is_max
        )
        if _recapped is not None and _recapped != result.bound:
            from discopt.solvers import _gap as _gap_mod

            _log.info(
                "%s: re-capping the bound at the exact objective: %.12g -> %.12g (proved %.12g).",
                self.name,
                result.bound,
                _recapped,
                result._proved_bound,
            )
            # Same tree, same proof: the validity claim and provenance carry over
            # (#1244 -- every bound write goes through ``_set_bound``).
            result._set_bound(_recapped, valid=result.bound_valid, source=result.bound_source)
            result.gap = _gap_mod.reported_gap(f_declared, _recapped)

        # The certificate was granted against the number just replaced. Re-test it
        # with the same arbiter every other site uses.
        from discopt.solver import _withhold_stale_certificate

        status, gap, certified, bound = _withhold_stale_certificate(
            result.status,
            result.objective,
            result.bound,
            result.gap,
            bool(getattr(result, "gap_certified", False)),
            _is_max,
            1e-4,
            1e-6,
            f"{self.name}: objective reconciliation",
        )
        result.status, result.gap, result.gap_certified, result.bound = (
            status,
            gap,
            certified,
            bound,
        )

    def sensitivity(
        self,
        wrt=None,
        *,
        order: int = 1,
        method: str = "exact",
        options: Optional[dict] = None,
        at=None,
    ):
        """Solve and return every derivative of the solution -- the unified entry point.

        Where :meth:`solve` answers "what is the optimum", this answers "how does
        the optimum move". One call gives the solution together with ``dx*/dp``,
        ``dλ*/dp``, optionally ``d²x*/dp²``, the total derivative of *any* model
        expression through the solution map, a first-order re-solve, and the JAX
        layer form -- instead of choosing between
        :meth:`SolveResult.gradient`, :func:`discopt.solvers.sipopt.pounce_sensitivity`,
        :func:`discopt.modeling.argmin_layer` and
        :func:`discopt.parametric.compile_expression` and then lining up flat
        indices by hand.

        The derivatives come from the implicit function theorem applied to the KKT
        system at the solution, so they describe the smooth branch the solution
        currently sits on; continuous variables and scalar Parameters only.

        Parameters
        ----------
        wrt : Parameter, str, or sequence, optional
            Parameters (or their names) to differentiate with respect to.
            Defaults to every Parameter the model declares.
        order : int, default 1
            2 also computes ``d²x*/dp²``.
        method : {"exact", "fd"}, default "exact"
            ``"exact"`` differentiates the compiled model symbolically; ``"fd"``
            central-differences the right-hand side as a cross-check.
        options : dict, optional
            POUNCE options for the solve.
        at : SolveResult, dict, or array, optional
            The solution to differentiate at. Defaults to this model's last
            successful :meth:`solve` result, so ``m.solve(); m.sensitivity()``
            describes the solution ``solve`` returned rather than whichever local
            one a fixed start point reaches (#1313). The returned object's
            ``matches_reference`` says whether the two agree, and a mismatch also
            raises a ``RuntimeWarning``.

        Returns
        -------
        discopt.sensitivity.Sensitivity

        Examples
        --------
        >>> s = m.sensitivity(wrt=[cost])           # doctest: +SKIP
        >>> s.d("flow")                             # dflow*/dcost, shaped like flow
        >>> s.d(price * flow)                       # total derivative of revenue
        >>> s.predict({cost: 2.1})                  # linearised re-solve

        See Also
        --------
        discopt.sensitivity.sensitivity : the function form.
        solve : the flag ``solve(sensitivity=True)`` for ``d(obj*)/dp`` alone.
        """
        from discopt.sensitivity import sensitivity as _sensitivity

        return _sensitivity(self, wrt, order=order, method=method, options=options, at=at)

    def _solve_streaming(self, **kwargs) -> Iterator["SolveUpdate"]:
        """Streaming solve that yields updates during B&B.

        Not implemented: no backend produces the :class:`SolveUpdate` feed yet, so
        ``solve(stream=True)`` raises rather than returning a partial answer. The
        message names the parameter because a caller mistaking ``stream`` for
        "print the solver log" is exactly how issue #1178 happened — for that, hook
        the ``discopt`` logger at INFO (see ``discopt.pyomo``'s ``tee`` handling).
        """
        raise NotImplementedError(
            "Model.solve(stream=True) is not implemented: no solver backend yields "
            "SolveUpdate progress. Call solve() without stream= for a SolveResult; "
            "to watch progress, attach a handler to the 'discopt' logger at INFO."
        )

    # ── Infeasibility analysis ──

    def compute_iis(
        self,
        *,
        include_bounds: bool = True,
        include_integrality: bool = False,
        time_limit: float = 30.0,
        total_time_limit: float | None = None,
        portfolio=None,
        workers: int | None = None,
    ):
        """Compute an Irreducible Infeasible Subsystem explaining infeasibility.

        Returns an :class:`~discopt.infeasibility.IISResult` — a minimal set of
        constraints (and, by default, variable bounds) that is infeasible but
        becomes feasible if any single member is removed. Use it to debug *why*
        ``solve()`` returned ``"infeasible"``. Raises ``ValueError`` if the model
        is not provably infeasible. ``include_integrality=True`` (linear models)
        also filters each integer element's integrality, and ``total_time_limit``
        bounds the whole computation (anytime result); ``portfolio``/``workers``
        run several deletion orders in parallel processes and keep the smallest
        result; see :func:`~discopt.infeasibility.compute_iis`.

        >>> res = m.solve()
        >>> if res.status == "infeasible":
        ...     print(m.compute_iis().summary())
        """
        from discopt.infeasibility import compute_iis

        return compute_iis(
            self,
            include_bounds=include_bounds,
            include_integrality=include_integrality,
            time_limit=time_limit,
            total_time_limit=total_time_limit,
            portfolio=portfolio,
            workers=workers,
        )

    def convexity(self, *, time_limit: float | None = 15.0):
        """Report whether the solver can prove this model convex.

        Returns a :class:`~discopt.convexity_report.ConvexityReport`. It runs the
        same exact rewrites (``x*log(x)`` -> ``entropy(x)``, objective epigraph)
        and the same classifier :meth:`solve` dispatches its convex fast path on,
        so the two cannot disagree (#1616). ``is_convex=False`` means *not
        proven*; the classifier is sound but incomplete.

        >>> rep = m.convexity()
        >>> rep.is_convex, rep.rewrites, rep.nonconvex_constraints()
        """
        from discopt.convexity_report import convexity

        return convexity(self, time_limit=time_limit)

    # ── Validation ──

    def _iter_owned_leaves(self):
        """Yield every ``Variable``/``Parameter`` leaf referenced by this model.

        Walks the objective expression and every constraint body (including the
        indicator/disjunctive/SOS/logical constraint families) so the ownership
        guard (M3) sees the same leaves the solver will eventually lower to the
        flat Rust variable vector.
        """
        if self._objective is not None:
            yield from _iter_model_leaves(self._objective.expression)

        def _from_constraint(c):
            if isinstance(c, Constraint):
                yield from _iter_model_leaves(c.body)
            elif isinstance(c, _IndicatorConstraint):
                yield from _iter_model_leaves(c.indicator)
                yield from _from_constraint(c.constraint)
            elif isinstance(c, _DisjunctiveConstraint):
                for disjunct in c.disjuncts:
                    for sub in disjunct:
                        yield from _from_constraint(sub)
            elif isinstance(c, _SOSConstraint):
                yield from _iter_model_leaves(*c.variables)
            elif isinstance(c, _LogicalConstraint):
                yield from _iter_model_leaves(*_logical_backing_vars(c.expression))
            elif hasattr(c, "body"):
                # Unknown arithmetic-bodied constraint type: still walk its body.
                yield from _iter_model_leaves(c.body)

        for c in self._constraints:
            yield from _from_constraint(c)

    def _check_ownership(self):
        """Reject expressions that reference a variable/parameter of another model.

        A :class:`Variable` carries a flat ``_index`` into *its own* model's
        variable vector. When the solver lowers this model it addresses each
        leaf by that flat index, so the precise soundness invariant is:

            ``self._variables[leaf._index] is leaf``

        i.e. the leaf's flat index must address *that very object* in the model
        being solved. A leaf from a foreign model has an index that addresses a
        **different** object (or is out of range) → it would silently **alias by
        flat index** onto this model's same-index variable, a wrong answer rather
        than an error (review finding M3). Raise loudly instead (CLAUDE.md §3).

        This index-slot identity is deliberately *not* an ``owner is self`` test:
        legitimate model rebuilds (e.g. ``reformulate_gdp``) construct a new
        ``Model`` that **shares** the original ``Variable`` objects in the same
        order — index-compatible, so those must pass — while adding new aux
        variables of their own. The identity check accepts both and rejects only
        a genuinely foreign, index-incompatible leaf. One O(DAG) walk per solve.
        """
        # Object-identity membership sets for O(1) lookup. For variables, index
        # equality is the real invariant; the identity set is the fast primary
        # check, with the index-slot check as the precise diagnostic.
        var_ids = {id(v) for v in self._variables}
        param_ids = {id(p) for p in self._parameters}
        n_vars = len(self._variables)
        for leaf in self._iter_owned_leaves():
            if isinstance(leaf, Parameter):
                if id(leaf) in param_ids:
                    continue
            else:  # Variable
                if id(leaf) in var_ids:
                    continue
                idx = getattr(leaf, "_index", None)
                # An index that happens to address this very object is also fine
                # (shared-object rebuilds), but that is already covered by the id
                # set above; reaching here means the object is not in this model.
                if idx is not None and 0 <= idx < n_vars and self._variables[idx] is leaf:
                    continue
            # Foreign leaf: index-incompatible with the model being solved.
            owner = getattr(leaf, "model", None)
            kind = "parameter" if isinstance(leaf, Parameter) else "variable"
            own_name = getattr(owner, "name", None) or "<unknown>"
            self_name = getattr(self, "name", None) or "<unnamed>"
            raise ValueError(
                f"Cross-model reference: {kind} '{leaf.name}' belongs to a "
                f"different model ('{own_name}'), not to model '{self_name}' being "
                f"solved. Variables/parameters carry a flat index local to their "
                f"own model, so mixing them across models would silently alias by "
                f"index and produce a wrong answer. Rebuild the offending "
                f"expression using only variables/parameters declared on model "
                f"'{self_name}'."
            )

    def _unattached_gdp_blocks(self) -> tuple[list, list]:
        """Disjunctive blocks built on this model that never reached it (#1430).

        ``Model.disjunction()`` and ``Model.make_disjunct()`` are the only two
        disjunctive helpers on ``Model`` that do not append to ``_constraints``:
        they are factories whose product must be nested into an attached
        disjunction (``either_or``/``if_else``, or another ``disjunction``) or
        passed to ``add_disjunction``. When it is not, the model the solver sees
        is the RELAXED one and it certifies an optimum for that — the failure
        this predicate exists to catch.

        Returns
        -------
        tuple of (list of _DisjunctiveConstraint, list of Disjunct)
            Only *roots*: a floating disjunction nested inside another floating
            one is the parent's problem, and reporting both would name one
            mistake twice. An unattached disjunct holding **no** constraints is
            not reported — it contributes an unused indicator binary and nothing
            else, so it cannot change an answer, and refusing it would reject the
            legitimate pattern of building blocks in a loop and using a subset.
        """
        # Every disjunction reachable from the model's own constraint list, and
        # transitively through nesting. ``attached`` is what the solve will see.
        attached: set[int] = set()
        # Every disjunction that is nested inside SOME other tracked disjunction,
        # attached or not; used to report roots only.
        nested: set[int] = set()

        def _children(dc):
            # Only descend through a well-formed ``list[list]``. A malformed
            # ``disjuncts`` is a real error, but it is the GDP pass's to report
            # with its own message -- this walk must not pre-empt it with a
            # TypeError raised from inside ``validate``.
            for group in dc.disjuncts if isinstance(dc.disjuncts, (list, tuple)) else ():
                if not isinstance(group, (list, tuple)):
                    continue
                for item in group:
                    if isinstance(item, _DisjunctiveConstraint):
                        yield item

        def _walk(dc, seen: set) -> None:
            # ``seen`` guards a self-referential nesting, which is a user error
            # rather than an impossibility: recursing forever on it would hang
            # ``validate`` instead of reporting the model.
            if id(dc) in seen:
                return
            seen.add(id(dc))
            attached.add(id(dc))
            for child in _children(dc):
                nested.add(id(child))
                _walk(child, seen)

        for c in self._constraints:
            if isinstance(c, _DisjunctiveConstraint):
                _walk(c, set())
        # A floating disjunction can itself nest another floating one; mark those
        # so only the outermost forgotten object is reported.
        for dc in self._gdp_factory_disjunctions:
            if id(dc) in attached:
                continue
            for child in _children(dc):
                nested.add(id(child))

        floating = [
            dc
            for dc in self._gdp_factory_disjunctions
            if id(dc) not in attached and id(dc) not in nested
        ]
        # #1775 G1.2: a block holding only nested disjunctions or local variables
        # carries structure too, and is just as silently lost.
        orphans = [
            d
            for d in self._gdp_factory_disjuncts
            if not d._attached and (d._constraints or d._nested)
        ]
        return floating, orphans

    def _reject_escaped_local_vars(self) -> None:
        """Refuse a variable declared on a Disjunct but used outside it (#1775 G1.2).

        ``Disjunct.variable`` promises the column appears only in that block's rows
        and the disjunctions nested in it, so a consumer may treat it as
        meaningless when the block is not selected (a hull need not disaggregate
        it; a reduced subproblem may drop it). A use anywhere else breaks that
        promise, so refuse rather than let a later consumer act on it.
        """
        blocks = [d for d in self._gdp_factory_disjuncts if d._attached and d._local_vars]
        if not blocks:
            return

        def body_vars(body) -> set[str]:
            # The complete walker: ``gdp_reformulate._collect_variables`` has no arm
            # for ``SumExpression``/``MatMulExpression``/``CustomCall``, so a local
            # variable used through ``dm.sum`` outside its disjunct escaped this
            # guard unseen.
            return {leaf.name for leaf in _iter_model_leaves(body) if isinstance(leaf, Variable)}

        def subtree_rows(d: "Disjunct", out: set[int]) -> None:
            out.update(id(c) for c in d._constraints)
            for kind, item, *_ in d._nested:
                if kind == "block":
                    for inner in item:
                        subtree_rows(inner, out)
                else:
                    stack = [item]
                    while stack:
                        dc = stack.pop()
                        for group in dc.disjuncts:
                            for it in group:
                                if isinstance(it, _DisjunctiveConstraint):
                                    stack.append(it)
                                else:
                                    out.add(id(it))

        # (row id or None, expression, where) -- a use with no row id is never part
        # of a block, so it is outside every one.
        uses: list[tuple[Optional[int], Expression, str]] = []
        outside = "a row outside the block"
        for c in self._constraints:
            if isinstance(c, Constraint):
                uses.append((id(c), c.body, outside))
            elif isinstance(c, _IndicatorConstraint):
                uses.append((id(c.constraint), c.constraint.body, outside))
            elif isinstance(c, _DisjunctiveConstraint):
                stack = [c]
                while stack:
                    dc = stack.pop()
                    for group in dc.disjuncts:
                        for it in group:
                            if isinstance(it, _DisjunctiveConstraint):
                                stack.append(it)
                            else:
                                uses.append((id(it), it.body, outside))
            # #1790: an SOS set or a logic row names its columns directly; neither
            # can sit in a block, so any local column in one has escaped.
            elif isinstance(c, _SOSConstraint):
                uses += [(None, v, "an SOS constraint") for v in c.variables]
            elif isinstance(c, _LogicalConstraint):
                uses += [(None, v, "a logical constraint") for v in _logical_leaves(c.expression)]
        if self._objective is not None:
            uses.append((None, self._objective.expression, "the objective"))
        for d in blocks:
            own: set[int] = set()
            subtree_rows(d, own)
            local = {v.name for v in d._local_vars}
            for row_id, body, where in uses:
                if row_id is not None and row_id in own:
                    continue
                hit = local & body_vars(body)
                if hit:
                    raise ValueError(
                        f"variable {sorted(hit)[0]!r} is declared local to disjunct "
                        f"{d.name!r} (Disjunct.variable) but is used in {where}. A "
                        "local variable may appear only in that disjunct's rows and the "
                        "disjunctions nested in it; declare it with Model.continuous "
                        "(or binary/integer) if it is shared."
                    )

    def _reject_unattached_gdp_blocks(self) -> None:
        """Refuse a model whose disjunctive structure was built but never added.

        #1430. Measured before this guard: ``m.disjunction([[x >= 4, y >= 1],
        [y >= 6, x >= 1]])`` on ``min x + y`` over ``[0, 10]^2`` returned
        ``status="optimal"``, ``objective=0.0``, ``bound=-1e-12`` — the true
        optimum is ``5.0`` — and the ``make_disjunct`` form without
        ``add_disjunction`` returned ``0.0``/``0.0``. Both are false certificates
        for a problem the caller did not pose, produced in silence. Refusing is
        the fix CLAUDE.md §3 asks for; there is no sound way to guess whether the
        caller meant the disjunction to apply.
        """
        floating, orphans = self._unattached_gdp_blocks()
        if not floating and not orphans:
            return
        lines = []
        for dc in floating:
            what = f"Model.disjunction(name={dc.name!r})" if dc.name else "Model.disjunction(...)"
            lines.append(
                f"  - {what}, {len(dc.disjuncts)} disjunct(s): nest it inside a disjunction "
                "that IS on the model, or add it directly with "
                "m.either_or([[...], [...]]) instead of m.disjunction(...)"
            )
        for d in orphans:
            lines.append(
                f"  - Model.make_disjunct({d.name!r}), {len(d._constraints)} constraint(s): "
                f"pass it to m.add_disjunction([...]) — its indicator "
                f"'{d.name}_active' is on the model but its constraints are not"
            )
        raise ValueError(
            f"model {self.name!r}: {len(lines)} disjunctive block(s) were built on this "
            "model but never added to it, so solving it would silently drop them and "
            "certify an optimum for the relaxed problem:\n" + "\n".join(lines)
        )

    def _canonicalize_like_terms(self) -> None:
        """Exact like-term collection of every row and the objective (#2090).

        A body whose like terms binary64 would add inexactly (``t + x - t`` with
        ``t = 2**53 * x`` reads as ``0 * x``) is replaced in place by its exact
        canonical form; every other body is left as the same object. See
        :mod:`discopt.modeling._exact_polynomial`. Run at both solve doors --
        :meth:`validate` and ``solve_model`` -- and cached per row, so a re-solve
        pays one attribute check per row.
        """
        from discopt.modeling._exact_polynomial import canonicalize_model

        canonicalize_model(self)

    def validate(self, *, for_solve: bool = True):
        """
        Validate model consistency.

        Parameters
        ----------
        for_solve
            Also enforce the checks that only the *solve* path needs — currently
            the normalized-``rhs`` rejection (see :func:`_reject_unnormalized_rhs`).
            Consumers that represent a row faithfully rather than solving it pass
            ``False``: the ``.nl`` writer honours ``Constraint.rhs`` (it folds the
            body constant into the r-section row bound) and so does the GAMS writer
            (it emits ``rhs`` verbatim), so a model they can export correctly must
            not be refused just because the solver could not solve it. The LP and
            MPS writers do **not** honour it — measured — and so keep the default.
            Default ``True``, so ``solve`` and direct calls are unchanged.

        Raises
        ------
        ValueError
            If the objective is not set, variable names are not unique,
            variable bounds are inconsistent (lb > ub), a disjunctive block built
            by :meth:`disjunction`/:meth:`make_disjunct` was never attached to the
            model (#1430 — solving it would silently drop the block), or any
            objective/constraint references a variable/parameter owned by a
            *different* model (which would silently alias by flat index —
            finding M3).
        """
        if self._objective is None:
            raise ValueError("No objective set. Call m.minimize() or m.maximize().")

        # #2090: collect every row's and the objective's like terms exactly before
        # anything reads a body, so no consumer sees a row binary64 rounded. Solve
        # path only: a ``for_solve=False`` call is a check, and must not edit rows.
        if for_solve:
            self._canonicalize_like_terms()

        # An atan2 rewrite whose sign assumption has since been widened away is
        # a model that differs from the one the user wrote by pi over part of
        # its box. Catch it here rather than certifying it. (After the objective
        # check: a model with no objective has a more basic problem to report.)
        from discopt.modeling._atan2 import check_preconditions

        check_preconditions(self)

        # Same reasoning for a piecewise input whose bound was widened past the
        # breakpoint span after declaration: the rows would clamp it silently.
        from discopt.modeling._piecewise import check_domains

        check_domains(self)

        # Same reasoning for a robust counterpart whose worst-case direction was
        # read from a Parameter value or variable bound changed since.
        if getattr(self, "_ro_sign_preconditions", None):
            from discopt.ro.formulations._common import check_sign_assumptions

            check_sign_assumptions(self)

        names = set()
        for var in self._variables:
            if var.name in names:
                raise ValueError(f"Duplicate variable name: '{var.name}'")
            names.add(var.name)
            crossed = var.lb > var.ub
            if var.var_type is VarType.INTEGER:
                # #2252: an INTEGER box is stored as the integer range it admits,
                # so a box holding no integer (``lb=1.2, ub=1.8``) is stored as
                # ``[2, 1]``. That is an infeasible model, which the solve proves
                # and reports (#844), not a modeling error. A box the CALLER
                # crossed (``lb=3, ub=2``, or ``lb=1.8, ub=1.2``) still is: the
                # test is on the bounds as written, before the snap.
                crossed = np.asarray(var._declared_bound("lb")) > np.asarray(
                    var._declared_bound("ub")
                )
            if np.any(crossed):
                raise ValueError(f"Variable '{var.name}' has lb > ub at some index")

        # Duplicate constraint names are a results-integrity hazard (M5):
        # ``SolveResult.constraint_duals`` is keyed by constraint name, so two
        # rows sharing a name collide there. WARN (do not reject): indexed/array
        # constraint families legitimately reuse a base name (e.g. a GAMS
        # ``supply(i)`` equation loads as several ``supply`` rows), so a hard
        # error would break valid models. The real fix — disambiguating
        # ``constraint_duals`` for same-named indexed rows — is tracked as a
        # follow-up (#413, M5). Unnamed constraints (``name is None``) are exempt.
        con_names: set = set()
        for ci, c in enumerate(self._constraints):
            # A row the solve path cannot represent must never reach it. This is
            # the collection-level enforcement of ``Constraint``'s normalized form:
            # ``subject_to`` catches the public door, but constraints also arrive by
            # direct ``_constraints.append`` and by internal rebuilds that propagate
            # ``c.rhs`` verbatim, and ``solve`` always comes through here.
            if for_solve and isinstance(c, Constraint):
                _reject_unnormalized_rhs(c, where="Model.validate", index=ci)
            elif for_solve and isinstance(c, (_IndicatorConstraint, _DisjunctiveConstraint)):
                if isinstance(c, _IndicatorConstraint):
                    _require_binary_indicator(
                        c.indicator, f"Model.validate (_constraints[{ci}])"
                    )  # #1844
                # #1858: the rows inside a disjunct or indicator constraint, which
                # can arrive here without passing a construction-time check (a
                # direct append, a disjunct list mutated after ``either_or``).
                _reject_unnormalized_rhs_in(c, where=f"Model.validate (_constraints[{ci}])")
            cname = getattr(c, "name", None)
            if cname is None:
                continue
            if cname in con_names:
                warnings.warn(
                    f"Duplicate constraint name: '{cname}'. result.constraint_duals "
                    "is keyed by name, so rows sharing a name collide there "
                    "(expected for indexed/array constraint families). Give distinct "
                    "names if you need per-row duals. (M5, #413)",
                    stacklevel=2,
                )
            con_names.add(cname)

        self._reject_unattached_gdp_blocks()
        self._reject_escaped_local_vars()
        self._check_ownership()

    # ── Model statistics ──

    @property
    def num_variables(self) -> int:
        return builtins_sum(v.size for v in self._variables)

    @property
    def num_continuous(self) -> int:
        return builtins_sum(v.size for v in self._variables if v.var_type == VarType.CONTINUOUS)

    @property
    def num_integer(self) -> int:
        return builtins_sum(
            v.size for v in self._variables if v.var_type in (VarType.INTEGER, VarType.BINARY)
        )

    def _has_builder_only_rows(self) -> bool:
        """True if the model carries linear rows/objective living only in the builder.

        The fast-construction API (``add_linear_constraints`` / the
        ``Model.constraint`` linear fast path) and ``add_linear_objective`` /
        ``add_quadratic_objective`` emit rows/objective directly into the Rust
        builder; they are **not** mirrored in ``self._constraints`` /
        ``self._objective``. Consumers that read only those Python-side collections
        (classifiers, extractors, exporters, the validation examiner) must consult
        this predicate — a ``True`` return means they would otherwise see a strict
        subset of the model. See ``docs/dev/review-execution-plan.md`` §1 (X-1).
        """
        from discopt.export._common import has_builder_only_rows

        return has_builder_only_rows(self)

    def _num_builder_constraint_rows(self) -> int:
        """Count the scalar constraint rows that live only in the Rust builder."""
        blocks = getattr(self, "_builder_linear_blocks", None)
        if not blocks:
            return 0
        return int(builtins_sum(int(A.shape[0]) for A, *_ in blocks))

    def _objective_expression(self) -> Expression:
        """The expression this model minimizes or maximizes, builder objectives included.

        ``add_linear_objective`` / ``add_quadratic_objective`` hold the real
        objective in the Rust builder and flag ``_objective`` as a placeholder.
        Since #1802 the placeholder's expression *is* the builder objective (see
        :func:`_builder_objective_expression`); this rebuilds it from the retained
        block all the same, so a placeholder ``Objective`` that reached the model by
        another route (a decoded document, a hand-built copy) cannot hand back a
        stale expression. The sense stays on ``_objective``. Raises if there is no
        objective.
        """
        if self._objective is None:
            raise ValueError("Model has no objective set.")
        if not getattr(self._objective, "_is_placeholder", False):
            return self._objective.expression
        lin_blk = self._builder_linear_objective
        quad_blk = self._builder_quadratic_objective
        if lin_blk is not None:
            c, x, constant, _sense = lin_blk
            Q = None
        elif quad_blk is not None:
            Q, c, x, constant, _sense = quad_blk
        else:
            raise ValueError(
                "objective is a builder placeholder but the model retains no builder "
                "objective block to rebuild it from"
            )

        return _builder_objective_expression(c, x, constant, Q)

    def _builder_linear_constraints(self, *, lazy: bool = False) -> list[Constraint]:
        """Materialize the builder-resident linear rows as fresh :class:`Constraint`
        objects **without mutating the model**.

        The fast-construction paths (``add_linear_constraints`` and the
        ``Model.constraint`` linear fast path) record their rows only on
        ``self._builder_linear_blocks`` — never in ``self._constraints``. Consumers
        that build a constraint view from :class:`Constraint` objects (the
        ``NLPEvaluator``, ``_check_constraint_feasibility``, and the #772
        incumbent-verification guard) call this to recover that missing slice, so
        their view reflects the COMPLETE constraint set regardless of which fast path
        produced a row (#840). This is the *read-only* counterpart to
        ``_materialize_builder_linear_rows`` (which relocates the rows in place); both
        share the row→Constraint translation so the two stay identical. Returns an
        empty list once the blocks have been materialized/cleared.

        ``lazy=True`` (#1712) defers each row's ``body``: the constraint's name and
        sense are set, and the body expression is built from the row on its first
        read (:func:`_constraint_getattr`), identical to the eager one. A tape
        evaluator lowers such a row straight from its coefficients and never reads
        the body, which on a 600-row, 90,000-term model saved the 1.0 s that
        building the expressions cost. Every other caller keeps ``lazy=False``.
        """
        from discopt.export._common import iter_builder_linear_rows

        make = _lazy_builder_row_constraint if lazy else _builder_row_constraint
        return [make(row) for row in iter_builder_linear_rows(self)]

    def _materialize_builder_linear_rows(self) -> int:
        """Rewrite builder-resident linear constraint rows as expression constraints.

        The fast-construction API (``add_linear_constraints`` / the
        ``Model.constraint`` linear fast path) records constraint rows only in
        ``self._builder_linear_blocks`` / the Rust builder — they are **not**
        mirrored into ``self._constraints``. The JAX spatial-B&B consumers (the
        ``NLPEvaluator`` feasibility gate and the McCormick relaxer) read only
        ``self._constraints``, so on the nonlinear solve path those rows are
        silently dropped, and the solver can certify a **false optimum** on an
        infeasible incumbent (issue #681).

        This materialises each builder linear row into an equivalent expression
        :class:`Constraint` in ``self._constraints`` and resets the Rust builder so
        the rows are not *also* carried there (which would double-count them in
        ``model_to_repr``). The variable registration and any builder-resident
        objective (``add_linear_objective`` / ``add_quadratic_objective``) are
        preserved by rebuilding the builder and re-applying the objective from its
        retained Python-side block. The result is a single, consistent
        representation every consumer sees — the fast path's documented "the
        resulting model is identical" invariant, now honoured on the nonlinear
        path too.

        Idempotent (a no-op once the blocks are cleared). Returns the number of
        rows materialised. Mathematically model-preserving: it relocates rows
        between two internal representations without changing the feasible set,
        the objective, or ``num_constraints``.
        """
        blocks = getattr(self, "_builder_linear_blocks", None)
        if not blocks:
            return 0

        new_constraints = self._builder_linear_constraints()

        # Reset the Rust builder so it no longer carries the constraint rows
        # (avoids a double-count in ``model_to_repr``), preserving the variable
        # registration and re-applying any builder-resident objective from its
        # retained Python block.
        lin_obj = getattr(self, "_builder_linear_objective", None)
        quad_obj = getattr(self, "_builder_quadratic_objective", None)
        self._builder = None
        self._builder_linear_blocks = []
        # Re-register variables in a fresh builder so ``_builder_idx`` stays valid.
        self._get_builder()
        if lin_obj is not None:
            c_vec, x, constant, sense = lin_obj
            self.add_linear_objective(c_vec, x, constant=constant, sense=sense)
        elif quad_obj is not None:
            Q, c_vec, x, constant, sense = quad_obj
            self.add_quadratic_objective(Q, c_vec, x, constant=constant, sense=sense)

        self._constraints.extend(new_constraints)
        return len(new_constraints)

    @property
    def num_constraints(self) -> int:
        """Total scalar constraint rows, including fast-API / builder-resident rows.

        Counts both expression-path rows in ``self._constraints`` and the
        builder-resident linear rows emitted by ``add_linear_constraints`` / the
        ``Model.constraint`` linear fast path (X-1). Before this fix the fast-path
        rows were invisible, so a model built entirely through the fast API reported
        ``0`` constraints.
        """
        return len(self._constraints) + self._num_builder_constraint_rows()

    def summary(self) -> str:
        """
        Return a human-readable model summary.

        A model with no objective yet is summarized as ``<none set>`` rather
        than raising: ``__repr__`` delegates here, so an unguarded attribute
        access turned merely echoing a half-built model -- the normal thing to
        do in a notebook or a debugger -- into an ``AttributeError``. Building
        the rows first and choosing the objective afterwards is a supported
        order (``validate()`` is what refuses a model that is still missing one
        at solve time), so this state is legitimate, not an error to report.

        Returns
        -------
        str
            Multi-line string with variable counts, constraint count,
            objective sense, and parameter count.
        """
        if self._objective is None:
            objective = "<none set>"
        else:
            objective = f"{self._objective.sense.value} {self._objective.expression}"
        lines = [
            f"Model: {self.name}",
            f"  Variables: {self.num_variables} "
            f"({self.num_continuous} continuous, {self.num_integer} integer/binary)",
            f"  Constraints: {self.num_constraints}",
            f"  Objective: {objective}",
            f"  Parameters: {len(self._parameters)}",
        ]
        return "\n".join(lines)

    def __repr__(self):
        return self.summary()

    # ── Export ──

    def to_mps(self, path: Union[str, None] = None) -> Union[str, None]:
        """Export the model to MPS format.

        Only linear and quadratic models are supported. Nonlinear
        expressions raise ``ValueError``.

        Parameters
        ----------
        path : str, optional
            File path to write. If ``None``, return the MPS string.

        Returns
        -------
        str or None
            MPS string if *path* is ``None``, otherwise ``None``.
        """
        from discopt.export.mps import to_mps

        return to_mps(self, path)

    def to_lp(self, path: Union[str, None] = None) -> Union[str, None]:
        """Export the model to CPLEX LP format.

        Only linear and quadratic models are supported. Nonlinear
        expressions raise ``ValueError``.

        Parameters
        ----------
        path : str, optional
            File path to write. If ``None``, return the LP string.

        Returns
        -------
        str or None
            LP string if *path* is ``None``, otherwise ``None``.
        """
        from discopt.export.lp import to_lp

        return to_lp(self, path)

    def to_gams(
        self,
        path: Union[str, None] = None,
        model_type: Union[str, None] = None,
    ) -> Union[str, None]:
        """Export the model to GAMS (.gms) format.

        Supports all model types including MINLP with nonlinear expressions.

        Parameters
        ----------
        path : str, optional
            File path to write. If ``None``, return the GAMS string.
        model_type : str, optional
            GAMS model type (LP, MIP, NLP, MINLP, etc.).
            Auto-detected from variable types and expression structure if not given.

        Returns
        -------
        str or None
            GAMS string if *path* is ``None``, otherwise ``None``.
        """
        from discopt.export.gams import to_gams

        return to_gams(self, path, model_type)

    def set_initial_point(self, mapping: dict) -> None:
        """Attach a starting point to the model, for export.

        Parameters
        ----------
        mapping : dict
            ``{Variable: value}`` in the same form :meth:`solve`'s
            ``initial_solution`` and :meth:`to_nl`'s ``initial_point`` take
            (scalars, lists or arrays, matching each variable's shape). Values
            are validated, bound-clamped and integrality-rounded by
            :func:`discopt.warm_start.validate_initial_solution`, each with a
            warning. Replaces any point already attached; ``{}`` clears it.

        Notes
        -----
        The point is a hint carried to the exporters -- :meth:`to_nl` writes it
        as the ``.nl`` ``x`` segment. Nothing on the solve path reads it; warm
        starting is still ``solve(initial_solution=...)``, deliberately, so that
        reading a model from a file does not silently change how it is solved
        (#1225).

        A point attached by :func:`from_nl` instead carries the source file's
        values **verbatim**, unclamped, so a round-trip reproduces the file; only
        this setter validates, because only this setter takes user input.
        """
        from discopt.export.nl import _keyed_initial_point

        self._initial_point = _keyed_initial_point(self, mapping) if mapping else {}

    @property
    def initial_point(self) -> dict:
        """The attached starting point as ``{Variable: {element: value}}``.

        Element-keyed rather than array-valued because the point is a *partial*
        map: a ``.nl`` ``x`` segment names only the columns it has a value for
        (AMPL writes an ``x2`` block for the 5-variable ``ex1221``), and there is
        no array encoding of "this element has no guess" that is not a sentinel.
        A scalar variable reads as ``{var: {0: value}}``. Empty when no point is
        attached. The returned dict is a fresh copy; mutate it and nothing
        happens -- use :meth:`set_initial_point`.
        """
        by_var: dict = {}
        for var in self._variables:
            for elem in range(var.size):
                value = self._initial_point.get((var.name, elem))
                if value is not None:
                    by_var.setdefault(var, {})[elem] = value
        return by_var

    def to_nl(
        self,
        path: Union[str, None] = None,
        initial_point: Optional[dict] = None,
    ) -> Union[str, None]:
        """Export the model to AMPL .nl text format.

        Supports all model types including MINLP with nonlinear expressions.
        Produces text-mode .nl files compatible with AMPL-compatible solvers
        (Ipopt, BARON, Couenne, SCIP) and the discopt Rust .nl parser.

        Parameters
        ----------
        path : str, optional
            File path to write. If ``None``, return the .nl string.
        initial_point : dict, optional
            ``{Variable: value}`` starting guess (same form as
            :meth:`solve`'s ``initial_solution``), written as the ``.nl`` ``x``
            section. Variables omitted from the dict get no entry. Leave it
            ``None`` to write the point attached to the model (by
            :func:`from_nl` or :meth:`set_initial_point`), or pass ``{}`` to
            write no ``x`` section even when one is attached.

        Returns
        -------
        str or None
            .nl string if *path* is ``None``, otherwise ``None``.
        """
        from discopt.export.nl import to_nl

        return to_nl(self, path, initial_point=initial_point)

    def _check_name(self, name: str):
        """Ensure a variable/parameter name is unique and not compiler-reserved.

        Consults the persistent ``self._names`` set (kept in sync at every
        registration site) for an O(1) check instead of rebuilding the full name
        set from ``_variables``/``_parameters`` on every declaration (M7 — that
        rebuild was O(n) per call, O(n²) over a model build).

        Also refuses the :data:`GDP_AUX_PREFIX` namespace. That prefix is the
        documented boundary between a user's Boolean *identity* and a
        compiler-generated existential *auxiliary* (#1124 AC-5); a user name
        inside it would collide with a generated selector, leaving two distinct
        variables sharing one name and making name-keyed result lookup
        ambiguous. Refuse loudly rather than silently produce the ambiguity.
        """
        if name in self._names:
            raise ValueError(f"Name '{name}' already used in model")
        if name.startswith(GDP_AUX_PREFIX):
            raise ValueError(
                f"Name {name!r} is reserved: the {GDP_AUX_PREFIX!r} prefix belongs to "
                "GDP compiler auxiliaries (disjunction selectors, Tseitin variables), "
                "which are generated during lowering and are not source-level "
                "identities. Choose a name outside that namespace."
            )

    def save(
        self,
        path,
        *,
        result=None,
        indent: Optional[int] = None,
        provenance: bool = True,
        author: Optional[str] = None,
    ) -> None:
        """Save this model -- and optionally its solve result -- to a file.

        The native round-trippable format: unlike ``.nl`` / ``.gms`` export it
        keeps variable names, carries the non-algebraic relations, and can embed
        the fitted state, so a model reloads tomorrow as the model it was.

        Parameters
        ----------
        path : str or pathlib.Path
            Destination. A ``.gz`` suffix gzips the document; :func:`discopt.load`
            detects compression by magic bytes either way.
        result : SolveResult, optional
            A solve result to store alongside the model. It comes back on the
            reloaded model's ``saved_result`` attribute.
        indent : int, optional
            JSON indent. ``None`` writes compactly; ``2`` is readable and diffs well.
        provenance : bool, default True
            Record what wrote the file and when (:mod:`discopt.provenance`); it
            comes back on the reloaded model's ``provenance`` attribute. Pass
            ``False`` only when byte-for-byte reproducibility matters more, since
            the block is timestamped.
        author : str, optional
            Creator of the model. Recorded only when given here or via
            ``DISCOPT_PROVENANCE_AUTHOR`` -- never guessed.

        Examples
        --------
        >>> m.save("kinetics.dopt", result=result)          # doctest: +SKIP
        >>> m2 = discopt.load("kinetics.dopt")              # doctest: +SKIP
        >>> print(m2.provenance["software"]["version"])     # doctest: +SKIP
        """
        from discopt.serialize import save as _save

        _save(self, path, result=result, indent=indent, provenance=provenance, author=author)


# Internal constraint types (not part of public API)


@dataclass
class _IndicatorConstraint:
    indicator: Variable
    constraint: Constraint
    active_value: int = 1
    name: Optional[str] = None
    # #1615 C-10a: set by ``Model.add_disjunction`` to ``(key, k, n)`` -- this row
    # belongs to disjunct ``k`` of the ``n``-way disjunction ``key`` -- so the GDP
    # pass can lower the block by hull with the user's indicators as selectors
    # when ``gdp_method="hull"``. ``None`` for a plain ``if_then`` row.
    disjunction: Optional[tuple[str, int, int]] = None
    # #1775 G1.2: set on the rows of a block disjunction nested in a Disjunct
    # (``Disjunct.add_disjunction``) to that Disjunct's indicator column: the
    # block is active only when it is, and its indicators sum to it instead of 1.
    parent: Optional[Variable] = field(default=None, compare=False)
    # #1775 G1.4: the declared semantics of the block disjunction this row belongs
    # to (``disjunction`` set). SELECT_ONE or OR; an OR block may select several.
    semantics: "DisjunctionSemantics" = field(
        default=DisjunctionSemantics.SELECT_ONE, compare=False
    )


@dataclass
class _DisjunctiveConstraint:
    disjuncts: list[list[Constraint]]
    name: Optional[str] = None
    # Optional per-disjunction reformulation override ("hull" | "big-m" | ...).
    # When set, it takes precedence over the solver-wide ``gdp_method``. Used by
    # ``Model.if_else`` to force the exact hull (perspective) reformulation,
    # which is robust for nonlinear equality disjuncts where big-M's relaxation
    # bound is unreliable.
    method: Optional[str] = None
    # The declared meaning of this disjunction (issue #1124). Carried on the IR
    # so a lowering can never *infer* the semantics from whichever activation it
    # happens to emit. SELECT_ONE everywhere, OR under big-M (#1775 G1.4); the GDP
    # pass refuses anything else loudly rather than approximating it.
    semantics: DisjunctionSemantics = DisjunctionSemantics.SELECT_ONE
    # #1775 G1.1: the model this disjunction was added to by ``Model.either_or``
    # (``None`` for one built by ``Model.disjunction`` for nesting), and the
    # indicator binaries, allocated on the first read of :attr:`indicators`. Until
    # then the GDP pass creates its own selectors exactly as before, so a model that
    # never reads them lowers bit-identically. Neither field takes part in equality.
    # ``canon=False``: a back-reference, not data -- ``transformations``'
    # structural fingerprint skips it (the indicator columns it allocated are
    # fingerprinted through ``_indicator_vars``).
    _model: Optional["Model"] = field(
        default=None, compare=False, repr=False, metadata={"canon": False}
    )
    # #1775 G1.2: the indicator column of the Disjunct this disjunction is nested
    # in (``Disjunct.subject_to(m.disjunction(...))``), or ``None`` at top level.
    # It applies only when that indicator is 1: its selectors sum to it.
    parent_indicator: Optional[Variable] = field(default=None, compare=False, repr=False)
    _indicator_vars: Optional[tuple[Variable, ...]] = field(default=None, compare=False, repr=False)
    # #1775 G2.6: user big-M values, aligned with ``disjuncts`` (one entry per row;
    # ``None`` = no user value, also for a nested disjunction), or ``None`` when the
    # user gave none. Read by the big-M lowering only; see
    # :mod:`discopt.gdp.user_big_m` for how each value is validated.
    big_m: Optional[tuple[tuple[Optional[float], ...], ...]] = None
    # #1775 G2.6: identifies this disjunction's user Ms across copies of the model
    # (``deepcopy`` keeps it), so ``Model.solve`` can tell whether a lowering read
    # them; see :func:`discopt.gdp.user_big_m.record_use`.
    _big_m_key: Optional[int] = field(default=None, compare=False, repr=False)

    def __repr__(self) -> str:
        # Short on purpose: ``Model.either_or`` returns this object, so a bare call
        # in a notebook cell echoes it, and the dataclass default prints every row.
        rows = [len(d) for d in self.disjuncts]
        return (
            f"_DisjunctiveConstraint(name={self.name!r}, rows per disjunct={rows}, "
            f"semantics={self.semantics.name}, method={self.method!r}, "
            f"indicators={'read' if self._indicator_vars is not None else 'unread'})"
        )

    @property
    def indicators(self) -> tuple["BooleanVar", ...]:
        """One ``BooleanVar`` per disjunct: true exactly when that disjunct is selected.

        Allocated on first read: a binary column ``{name}_{k}_active`` per disjunct
        is added to the model together with an ``exactly(1, ...)`` row, and the GDP
        pass then uses these columns as the disjunction's selectors instead of
        generating its own. So they can be referenced in :meth:`Model.logical`,
        fixed, or priced in the objective (#1775 G1.1, spec M4).

        Same select-one reading as :meth:`Model.add_disjunction`: an indicator at 0
        means "not selected", not "this disjunct's predicate is false".

        Only a disjunction added by :meth:`Model.either_or` has indicators. A nested
        disjunction (built with :meth:`Model.disjunction`) is not on the model and
        raises; its indicators are #1775 G1.2.
        """
        if self._indicator_vars is None:
            model = self._model
            if self.parent_indicator is not None:
                raise ValueError(
                    f"disjunction {self.name or '<anon>'!r} is nested in a Disjunct, "
                    "so it has no indicators of its own here. Nest a block "
                    "disjunction instead (Disjunct.add_disjunction over make_disjunct "
                    "blocks), whose indicators are always model columns."
                )
            if model is None or not any(c is self for c in model._constraints):
                raise ValueError(
                    f"disjunction {self.name or '<anon>'!r} is not a top-level "
                    "Model.either_or disjunction of a model, so it has no indicators. "
                    "For a nested disjunction with indicators, nest Disjunct blocks "
                    "(Disjunct.add_disjunction over make_disjunct blocks), whose "
                    "indicators are always model columns (#1775 G1.2)."
                )
            if self.name is not None:
                base = self.name
            else:  # by identity: dataclass ``==`` would compare the disjuncts
                pos = next(i for i, c in enumerate(model._constraints) if c is self)
                base = f"disjunction{pos}"
            names = [f"{base}_{k}_active" for k in range(len(self.disjuncts))]
            for nm in names:
                model._check_name(nm)
            # ``_eo_`` rather than ``add_disjunction``'s ``_disj_``: an
            # ``add_disjunction(name=base)`` in the same model would otherwise
            # share the row name, and name-keyed lookups become ambiguous.
            row_name = f"_eo_{base}_select"
            if any(getattr(c, "name", None) == row_name for c in model._constraints):
                raise ValueError(f"Name {row_name!r} already used by a row in the model")
            cols = tuple(model.binary(nm) for nm in names)
            if self.semantics.cardinality is SelectorCardinality.AT_LEAST_ONE:
                model.at_least(1, list(cols), name=row_name)  # #1775 G1.4
            else:
                model.exactly(1, list(cols), name=row_name)
            self._indicator_vars = cols
        return tuple(BooleanVar(v) for v in self._indicator_vars)


def _claim_blocks(blocks: list["Disjunct"], owner: str, name: Optional[str]) -> None:
    """Record ``owner`` as the one place ``blocks`` sit, refusing a block that is
    already placed, already lowered, or listed twice (#1790).

    Every check runs before anything is recorded, so a refused call leaves no block
    claimed. A block placed twice would lower to the conjunction of both
    placements: sound, but not the model the user wrote, and Pyomo.GDP (which the
    G0.4 converter targets) forbids it.
    """
    what = f"disjunction {name!r}" if name else "a disjunction"
    seen: set[int] = set()
    for d in blocks:
        if id(d) in seen:
            raise ValueError(f"disjunct {d.name!r} is listed twice in {what}")
        seen.add(id(d))
        where = d._placed_in or ("the model" if d._attached else None)
        if where is not None:
            raise ValueError(
                f"disjunct {d.name!r} cannot go into {what} of {owner}: it is already in "
                f"a disjunction of {where}. A Disjunct block belongs to exactly one "
                "disjunction; make a separate block for each."
            )
    for d in blocks:
        d._placed_in = owner


_BIG_M_KEYS = _itertools.count(1)


def _key_big_m(dc: "_DisjunctiveConstraint") -> None:
    """Give a disjunction with user big-M values its tracking key (#1775 G2.6)."""
    if dc.big_m is not None:
        dc._big_m_key = next(_BIG_M_KEYS)


def _normalize_big_m(
    big_m: Any, disjuncts: list[list], name: Optional[str]
) -> Optional[tuple[tuple[Optional[float], ...], ...]]:
    """``either_or``'s ``big_m`` as one entry per row (#1775 G2.6), or ``None``.

    A number applies to every row; a dict maps a row (by identity) to its M, with
    the key ``None`` as the default for the rows it does not name -- the more
    specific value wins, as in Pyomo's ``bigM`` argument. Each M is a magnitude:
    a ``<=`` row becomes ``body <= M (1 - y)``, a ``>=`` row ``body >= -M (1 - y)``,
    and ``==`` both. Refused: a negative or non-finite M, and a dict key that is
    not a row of this disjunction.
    """
    if big_m is None:
        return None
    label = name or "<anon>"

    def _check(v: Any, what: str) -> float:
        if isinstance(v, bool) or not isinstance(v, (int, float, np.integer, np.floating)):
            raise TypeError(f"either_or {label!r}: big_m for {what} must be a number, got {v!r}")
        f = float(v)
        if not np.isfinite(f) or f < 0.0:
            raise ValueError(
                f"either_or {label!r}: big_m for {what} must be finite and >= 0, got {f!r}"
            )
        return f

    if isinstance(big_m, dict):
        rows = {id(c): c for d in disjuncts for c in d if not isinstance(c, _DisjunctiveConstraint)}
        for key in big_m:
            if key is not None and id(key) not in rows:
                raise ValueError(
                    f"either_or {label!r}: a big_m key is not a row of this disjunction "
                    f"({key!r}). Key big_m by the Constraint objects passed in "
                    "disjuncts, or use the key None for the default."
                )
        default = None if big_m.get(None) is None else _check(big_m[None], "the default (None)")
        per = {id(k): _check(v, repr(k)) for k, v in big_m.items() if k is not None}
        out = tuple(
            tuple(
                None if isinstance(c, _DisjunctiveConstraint) else per.get(id(c), default)
                for c in d
            )
            for d in disjuncts
        )
    else:
        m = _check(big_m, "every row")
        out = tuple(
            tuple(None if isinstance(c, _DisjunctiveConstraint) else m for c in d)
            for d in disjuncts
        )
    return out if any(v is not None for d in out for v in d) else None


def _refuse_empty_disjunction(disjuncts: Any, method: str, name: Optional[str]) -> None:
    # A disjunction selects one of its disjuncts; with none there is nothing to
    # select, and the GDP lowering failed later with a bare ``IndexError``.
    if len(disjuncts) == 0:
        raise ValueError(f"{method}() got no disjuncts for disjunction {name or '<anon>'!r}")


class _BlockMembers(NamedTuple):
    """What ``Model._emit_block_disjunction`` records about a block disjunction
    that takes part in nesting (#1775 G1.2): its indicators in disjunct order, the
    enclosing disjunct's indicator (``None`` at top level), the index in
    ``_constraints`` where its emission began, its user-given name, and its
    declared semantics (#1775 G1.4)."""

    indicators: list[Variable]
    parent: Optional[Variable]
    start: int
    name: Optional[str]
    semantics: DisjunctionSemantics = DisjunctionSemantics.SELECT_ONE


@dataclass
class _SOSConstraint:
    sos_type: int
    variables: list[Variable]
    name: Optional[str] = None


# ─────────────────────────────────────────────────────────────
# Propositional logic for GDP
# ─────────────────────────────────────────────────────────────


class LogicalExpression:
    """Base class for propositional logic expressions over BooleanVars."""

    def __and__(self, other: "LogicalExpression") -> "LogicalAnd":
        return LogicalAnd(self, _wrap_logical(other))

    def __rand__(self, other: "LogicalExpression") -> "LogicalAnd":
        return LogicalAnd(_wrap_logical(other), self)

    def __or__(self, other: "LogicalExpression") -> "LogicalOr":
        return LogicalOr(self, _wrap_logical(other))

    def __ror__(self, other: "LogicalExpression") -> "LogicalOr":
        return LogicalOr(_wrap_logical(other), self)

    def __invert__(self) -> "LogicalNot":
        return LogicalNot(self)

    def __xor__(self, other: "LogicalExpression") -> "LogicalAnd":
        return xor(self, other)

    def __rxor__(self, other: "LogicalExpression") -> "LogicalAnd":
        return xor(other, self)

    def implies(self, other: "LogicalExpression") -> "LogicalImplies":
        """Logical implication: self → other."""
        return LogicalImplies(self, _wrap_logical(other))

    def equivalent_to(self, other: "LogicalExpression") -> "LogicalEquivalent":
        """Logical equivalence: self ↔ other."""
        return LogicalEquivalent(self, _wrap_logical(other))


def _wrap_logical(x):
    """Wrap a BooleanVar or LogicalExpression, raise otherwise."""
    if isinstance(x, LogicalExpression):
        return x
    raise TypeError(f"Expected LogicalExpression, got {type(x).__name__}")


class BooleanVar(LogicalExpression):
    """A boolean decision variable backed by a binary Variable.

    Created via :meth:`Model.boolean`, not directly.
    """

    def __init__(self, variable):
        self.variable = variable

    def __repr__(self) -> str:
        return f"BooleanVar({self.variable.name})"


class BooleanVarArray:
    """Array of BooleanVars backed by a single array-shaped binary Variable."""

    def __init__(self, variable):
        self.variable = variable
        self._size = variable.size

    def __getitem__(self, idx) -> BooleanVar:
        return BooleanVar(self.variable[idx])

    def __len__(self) -> int:
        return int(self._size)

    def __iter__(self):
        for i in range(self._size):
            yield self[i]


@dataclass
class LogicalAnd(LogicalExpression):
    left: LogicalExpression
    right: LogicalExpression


@dataclass
class LogicalOr(LogicalExpression):
    left: LogicalExpression
    right: LogicalExpression


@dataclass
class LogicalNot(LogicalExpression):
    operand: LogicalExpression


@dataclass
class LogicalImplies(LogicalExpression):
    antecedent: LogicalExpression
    consequent: LogicalExpression


@dataclass
class LogicalEquivalent(LogicalExpression):
    left: LogicalExpression
    right: LogicalExpression


@dataclass
class LogicalAtLeast(LogicalExpression):
    k: int
    operands: list


@dataclass
class LogicalAtMost(LogicalExpression):
    k: int
    operands: list


@dataclass
class LogicalExactly(LogicalExpression):
    k: int
    operands: list


@dataclass
class _LogicalConstraint:
    expression: LogicalExpression
    name: Optional[str] = None


def _logical_leaves(expr: LogicalExpression) -> list:
    """The variable expressions behind the ``BooleanVar`` leaves of *expr*.

    Iterative: ``land(...)`` over many arguments is a left-deep chain.
    """
    leaves: list = []
    stack: list = [expr]
    seen: set[int] = set()
    while stack:
        node = stack.pop()
        if id(node) in seen:
            continue
        seen.add(id(node))
        if isinstance(node, BooleanVar):
            leaves.append(node.variable)
        elif isinstance(node, (LogicalAnd, LogicalOr, LogicalEquivalent)):
            stack += [node.left, node.right]
        elif isinstance(node, LogicalImplies):
            stack += [node.antecedent, node.consequent]
        elif isinstance(node, LogicalNot):
            stack.append(node.operand)
        elif isinstance(node, (LogicalAtLeast, LogicalAtMost, LogicalExactly)):
            stack += list(node.operands)
    return leaves


def _logical_children(node: LogicalExpression) -> tuple:
    if isinstance(node, (LogicalAnd, LogicalOr, LogicalEquivalent)):
        return (node.left, node.right)
    if isinstance(node, LogicalImplies):
        return (node.antecedent, node.consequent)
    if isinstance(node, LogicalNot):
        return (node.operand,)
    if isinstance(node, (LogicalAtLeast, LogicalAtMost, LogicalExactly)):
        return tuple(node.operands)
    return ()


def _logical_node_count(expr: LogicalExpression) -> int:
    """Node count of *expr* as a tree, computed iteratively (#1808).

    The GDP lowering (``_to_nnf`` and the CNF pass) recurses once per level of a
    logical expression, so the solve's recursion gate must size these too: a
    loop-built ``Y[0] | Y[1] | ...`` is a left-deep chain. Bottom-up and memoised
    by node identity, like ``factorable_reform._expr_node_count``.
    """
    sizes: dict[int, int] = {}
    held: list = []  # keep every sized node alive: ids cannot recycle
    stack: list = [(expr, False)]
    while stack:
        node, expanded = stack.pop()
        nid = id(node)
        if nid in sizes:
            continue
        children = _logical_children(node)
        if not expanded and children:
            stack.append((node, True))
            stack.extend((c, False) for c in children if id(c) not in sizes)
            continue
        sizes[nid] = 1 + builtins_sum(sizes[id(c)] for c in children)
        held.append(node)
    return sizes[id(expr)]


# Functional-style constructors for logical expressions


def land(*args: LogicalExpression) -> LogicalExpression:
    """Logical AND of multiple BooleanVars/expressions."""
    result = args[0]
    for a in args[1:]:
        result = LogicalAnd(result, a)
    return result


def lor(*args: LogicalExpression) -> LogicalExpression:
    """Logical OR of multiple BooleanVars/expressions."""
    result = args[0]
    for a in args[1:]:
        result = LogicalOr(result, a)
    return result


def lnot(x: LogicalExpression) -> LogicalNot:
    """Logical NOT."""
    return LogicalNot(x)


def xor(a: LogicalExpression, b: LogicalExpression) -> LogicalAnd:
    """Exclusive OR of two boolean expressions (also spelled ``a ^ b``).

    Built from the existing connectives as ``(a | b) & ~(a & b)``, so it lowers
    through the same NNF/CNF path as every other formula; for two BooleanVars
    that is the two clauses ``a + b >= 1`` and ``a + b <= 1``. Chaining
    ``a ^ b ^ c`` is parity (true for an odd count), not "exactly one" -- use
    :func:`exactly` for that.
    """
    a = _wrap_logical(a)
    b = _wrap_logical(b)
    return LogicalAnd(LogicalOr(a, b), LogicalNot(LogicalAnd(a, b)))


def atleast(k: int, *args: LogicalExpression) -> LogicalAtLeast:
    """At least k of the given boolean expressions must be true."""
    operands = list(args[0]) if len(args) == 1 and hasattr(args[0], "__iter__") else list(args)
    return LogicalAtLeast(k, operands)


def atmost(k: int, *args: LogicalExpression) -> LogicalAtMost:
    """At most k of the given boolean expressions may be true."""
    operands = list(args[0]) if len(args) == 1 and hasattr(args[0], "__iter__") else list(args)
    return LogicalAtMost(k, operands)


def exactly(k: int, *args: LogicalExpression) -> LogicalExactly:
    """Exactly k of the given boolean expressions must be true."""
    operands = list(args[0]) if len(args) == 1 and hasattr(args[0], "__iter__") else list(args)
    return LogicalExactly(k, operands)


# ``Model.at_least`` / ``Model.at_most`` are spelled with an underscore; accept the
# same spelling for the logical constructors (#1617).
at_least = atleast
at_most = atmost


# ─────────────────────────────────────────────────────────────
# Disjunct block abstraction
# ─────────────────────────────────────────────────────────────


class Disjunct:
    """A named block of constraints activated by a boolean indicator.

    Created via :meth:`Model.make_disjunct`, not directly.

    Parameters
    ----------
    name : str
        Block name. An indicator boolean ``{name}_active`` is created.
    model : Model
        The parent optimization model.

    Example
    -------
    >>> d1 = m.disjunct("mode_a")
    >>> d1.subject_to(x <= 3)
    >>> d2 = m.disjunct("mode_b")
    >>> d2.subject_to(x >= 7)
    >>> m.add_disjunction([d1, d2])
    """

    def __init__(self, name: str, model: "Model"):
        self.name = name
        self._model = model
        bv = model.boolean(f"{name}_active")
        assert isinstance(bv, BooleanVar)
        self.indicator: "BooleanVar" = bv
        self._constraints: list[Constraint] = []
        # #1775 G1.2: disjunctions nested in this block, in the order added, as
        # ``("block", [Disjunct, ...], name, semantics)`` (``add_disjunction``) or
        # ``("dc", _DisjunctiveConstraint, None, None)`` (``subject_to(m.disjunction(..))``),
        # and the variables declared on it (``variable``).
        self._nested: list[tuple[str, Any, Optional[str], Any]] = []
        self._local_vars: list[Variable] = []
        # #1430: set by ``Model.add_disjunction``. False means this block's
        # constraints live nowhere but here, so a solve would silently omit them.
        self._attached = False
        # #1790: where this block was placed -- "the model" for
        # ``Model.add_disjunction``, else the enclosing block's name. A block sits in
        # exactly one disjunction, as in Pyomo.GDP.
        self._placed_in: Optional[str] = None

    def _require_open(self, what: str) -> None:
        # Model.add_disjunction lowers a block when it is called; anything added to
        # the block afterwards would live nowhere but here and be silently dropped.
        if self._attached:
            raise ValueError(
                f"cannot {what} disjunct {self.name!r}: it was already passed to "
                "add_disjunction, which lowered its contents at that call. Build the "
                "block completely first."
            )

    def subject_to(
        self,
        constraint: Union[Constraint, "_DisjunctiveConstraint", list],
        name: Optional[str] = None,
    ) -> None:
        """Add constraint(s) -- or a nested disjunction -- to this disjunct.

        A disjunction built with :meth:`Model.disjunction` is nested here (#1775
        G1.2): it applies only when this disjunct is selected. For a nested
        disjunction whose disjuncts carry their own indicators, nest Disjunct
        blocks with :meth:`add_disjunction` instead.
        """
        self._require_open("add a constraint to")
        items = constraint if isinstance(constraint, list) else [constraint]
        # #1858: checked for the whole list first, so a refusal adds nothing.
        _reject_unnormalized_rhs_in(items, where=f"Disjunct {self.name!r}.subject_to")
        for item in items:
            if isinstance(item, _DisjunctiveConstraint):
                if item._model is not None or item.parent_indicator is not None:
                    raise ValueError(
                        f"disjunction {item.name or '<anon>'!r} is already on the model "
                        "or nested elsewhere; build a fresh one with Model.disjunction"
                    )
                if any(kind == "dc" and obj is item for kind, obj, *_ in self._nested):
                    raise ValueError(f"disjunction {item.name or '<anon>'!r} is nested twice")
                self._nested.append(("dc", item, None, None))
            else:
                self._constraints.append(item)

    def add_disjunction(
        self,
        disjuncts: list["Disjunct"],
        name: Optional[str] = None,
        *,
        semantics: Union[DisjunctionSemantics, str] = DisjunctionSemantics.SELECT_ONE,
    ) -> None:
        """Nest a disjunction over Disjunct blocks inside this one (#1775 G1.2).

        When this disjunct is selected, exactly one of ``disjuncts`` is selected;
        when it is not, none is (their indicators sum to this one's). The nested
        blocks are lowered together with this one, when it is passed to
        :meth:`Model.add_disjunction`.
        """
        self._require_open("nest a disjunction in")
        resolved = _coerce_disjunction_semantics(semantics)
        _require_semantics_supported(resolved, _BLOCK_ROWS, "Disjunct.add_disjunction()")
        blocks = list(disjuncts)
        for d in blocks:
            if not isinstance(d, Disjunct) or d._model is not self._model:
                raise TypeError("Disjunct.add_disjunction takes Disjunct blocks of the same model")
            if d is self or d._encloses(self):
                # #1790: lowering walks the nesting recursively, so a cycle would
                # recurse without end; refuse it here, where it is built.
                raise ValueError(
                    f"disjunct {d.name!r} cannot be nested in {self.name!r}: that would "
                    f"make a nesting cycle ({d.name!r} is {self.name!r} or encloses it)"
                )
        _claim_blocks(blocks, f"disjunct {self.name!r}", name)
        self._nested.append(("block", blocks, name, resolved))

    def _encloses(self, other: "Disjunct") -> bool:
        for kind, item, *_ in self._nested:
            if kind == "block" and any(d is other or d._encloses(other) for d in item):
                return True
        return False

    def variable(self, name: str, *, kind: str = "continuous", **kwargs) -> "Variable":
        """Declare a variable local to this disjunct (#1775 G1.2, spec M3).

        It is an ordinary model column (``kind`` is ``"continuous"``, ``"binary"``
        or ``"integer"``; ``kwargs`` go to the matching ``Model`` method), and it
        may appear only in this disjunct's rows and the disjunctions nested in it
        -- :meth:`Model.validate` refuses a model that uses it anywhere else. Its
        value means nothing when the disjunct is not selected.
        """
        self._require_open("declare a variable on")
        if kind == "continuous":
            v = self._model.continuous(name, **kwargs)
        elif kind == "binary":
            v = self._model.binary(name, **kwargs)
        elif kind == "integer":
            v = self._model.integer(name, **kwargs)
        else:
            raise ValueError(f"kind must be 'continuous', 'binary' or 'integer', not {kind!r}")
        self._local_vars.append(v)
        return cast(Variable, v)

    @property
    def active(self) -> "BooleanVar":
        """The boolean indicator for this disjunct."""
        return self.indicator

    @property
    def constraints(self) -> list[Constraint]:
        """Constraints in this disjunct."""
        return list(self._constraints)

    @property
    def local_vars(self) -> list["Variable"]:
        """Variables declared on this disjunct with :meth:`variable`."""
        return list(self._local_vars)

    def __repr__(self) -> str:
        extra = f", {len(self._nested)} nested" if self._nested else ""
        return f"Disjunct({self.name!r}, {len(self._constraints)} constraints{extra})"


# ─────────────────────────────────────────────────────────────
# Streaming updates
# ─────────────────────────────────────────────────────────────


@dataclass
class SolveUpdate:
    """
    Intermediate update yielded during a streaming solve.

    Attributes
    ----------
    elapsed : float
        Wall-clock time since solve start (seconds).
    incumbent : float or None
        Best feasible objective found so far.
    lower_bound : float
        Current global lower bound.
    gap : float or None
        Current relative optimality gap.
    node_count : int
        Total B&B nodes explored so far.
    open_nodes : int
        Number of open (unexplored) nodes.
    message : str or None
        LLM commentary if ``llm=True`` was passed to :meth:`Model.solve`.
    """

    elapsed: float
    incumbent: Optional[float]
    lower_bound: float
    gap: Optional[float]
    node_count: int
    open_nodes: int
    message: Optional[str] = None


# ─────────────────────────────────────────────────────────────
# Import functions
# ─────────────────────────────────────────────────────────────


def from_pyomo(pyomo_model) -> Model:
    """
    Import a Pyomo ``ConcreteModel`` as a discopt :class:`Model`.

    The bridge round-trips the Pyomo model through a temporary AMPL ``.nl`` file
    (the same translation the ``SolverFactory('discopt')`` plugin uses) and reads
    it back with :func:`from_nl`. Continuous, integer and binary variables,
    linear/nonlinear constraints, and the objective are supported.

    Parameters
    ----------
    pyomo_model : pyomo.environ.ConcreteModel
        A fully constructed Pyomo model.

    Returns
    -------
    Model
        A discopt ``Model`` ready to ``.solve()``. Its variables/constraints are
        in the ``.nl`` column/row order, which may differ from the Pyomo model's
        declaration order.

    Raises
    ------
    ImportError
        If Pyomo is not installed (``pip install discopt[pyomo]``).
    ValueError
        If the Pyomo model has no variables to import.

    Examples
    --------
    >>> import pyomo.environ as pyo
    >>> m = pyo.ConcreteModel()
    >>> m.x = pyo.Var(bounds=(0, 10))
    >>> m.obj = pyo.Objective(expr=(m.x - 3) ** 2)
    >>> dmodel = dm.from_pyomo(m)  # doctest: +SKIP
    >>> dmodel.solve().objective  # doctest: +SKIP
    0.0
    """
    try:
        import pyomo.environ  # noqa: F401
    except ImportError as exc:  # pragma: no cover - exercised only without pyomo
        raise ImportError(
            "from_pyomo requires Pyomo. Install it with 'pip install discopt[pyomo]'."
        ) from exc

    import os
    import tempfile

    from discopt.pyomo import _writer

    # Round-trip through a temporary .nl file. write_nl disables presolve/scaling so
    # the emitted columns are exactly the model's variables in the original space,
    # which is what from_nl reconstructs into a discopt Model.
    with tempfile.TemporaryDirectory(prefix="discopt_from_pyomo_") as workdir:
        nl_path = os.path.join(workdir, "model.nl")
        cols, _rows, _eliminated = _writer.write_nl(pyomo_model, nl_path)
        if not cols:
            raise ValueError(
                "from_pyomo: the Pyomo model has no variables to import (nothing to solve)."
            )
        return from_nl(nl_path)


# Depth at/above which a left-nested ``+`` chain is rebalanced into a shallow
# tree (#654). A flat N-term sum parsed from a ``.nl`` file is built as a depth-N
# left chain ``(((...(t1+t2)+t3)...)+tN)``; on a dense-quadratic model (qap: ~50k
# products) that is ~43000 deep, and every recursive tree-walk in the pipeline
# (expr->arena conversion, term classification, relaxation build, AD compile)
# recurses N deep and overflows the C stack — which manifests as a *hang*, not a
# clean error. The threshold is set well above any sum a working model carries but
# far below the ~15k-frame stack limit, so only pathologically deep chains (which
# otherwise hang) are touched; shallower sums are returned unchanged and every
# existing model stays byte-identical.
_SUM_REBALANCE_DEPTH = 2048


def _rebalance_deep_sum(expr: "Expression") -> "Expression":
    """Rebalance a deeply left-nested ``+`` chain into a shallow balanced tree.

    Only ``+`` chains are touched: addition is associative *and* commutative, so
    the rebalanced tree is exactly value-equal to the original (a balanced fold of
    the same terms). Chains shorter than :data:`_SUM_REBALANCE_DEPTH` are returned
    unchanged (identity), so the transform is a no-op — and byte-neutral — on every
    model that is not pathologically deep. The left-spine is walked *iteratively*
    (the chain is exactly the structure that would overflow a recursive walk)."""
    if not (isinstance(expr, BinaryOp) and expr.op == "+"):
        return expr
    # Measure the left-spine depth without recursing.
    depth = 0
    cur: Expression = expr
    while isinstance(cur, BinaryOp) and cur.op == "+":
        cur = cur.left
        depth += 1
    if depth < _SUM_REBALANCE_DEPTH:
        return expr
    # Deep chain: collect its terms (left-to-right) iteratively, then balanced-fold.
    terms: list[Expression] = []
    cur = expr
    while isinstance(cur, BinaryOp) and cur.op == "+":
        terms.append(cur.right)
        cur = cur.left
    terms.append(cur)  # deepest-left operand
    terms.reverse()
    while len(terms) > 1:
        terms = [
            terms[i] + terms[i + 1] if i + 1 < len(terms) else terms[i]
            for i in range(0, len(terms), 2)
        ]
    return terms[0]


def model_from_repr(rep, name: str) -> Model:
    """Build a Python :class:`Model` from a Rust ``ModelRepr``.

    Shared by :func:`from_nl` (whose ``rep`` comes from the ``.nl`` parser) and
    by the presolve substitution entry (#844), whose ``rep`` is a *reduced*
    model produced by ``ModelRepr.substitute``. Variables are created in block
    order, so the resulting model's flat variable vector is index-compatible
    with ``rep``'s.

    Complementarity relations are **not** reconstructed here — they live
    outside ``ModelRepr`` and are threaded separately by :func:`from_nl`.

    The ``x``-segment starting point *is* attached here (#1225). It lives
    outside ``ModelRepr`` for the same reason as the complementarities, and for
    a *reduced* ``rep`` it is empty by construction — the Rust side gives every
    transform's output an empty point rather than letting it inherit column
    indices the transform renumbered — so this is uniform without being wrong
    for the presolve caller.
    """
    from discopt._relax.nl_reconstruction import reconstruct_dag

    m = Model(name)

    var_types = rep.var_types()
    var_names = rep.var_names()
    var_shapes = rep.var_shapes()
    for i in range(len(var_names)):
        vt = var_types[i]
        vname = var_names[i]
        lb_vals = rep.var_lb(i)
        ub_vals = rep.var_ub(i)
        shape_list = var_shapes[i]
        shape = tuple(shape_list) if shape_list else ()
        lb = np.array(lb_vals).reshape(shape) if shape else float(lb_vals[0])
        ub = np.array(ub_vals).reshape(shape) if shape else float(ub_vals[0])

        if vt == "continuous":
            m.continuous(vname, shape=shape, lb=lb, ub=ub)
        elif vt == "binary":
            var = m.binary(vname, shape=shape)
            # Preserve the parsed bounds (X-3 / M2 / INT-2): `Model.binary` hardcodes
            # ``[0, 1]``, so a bound-narrowed or fixed binary (e.g. ``lb == ub == 1``,
            # routine Pyomo/presolve output) would silently un-fix, giving the wrong
            # optimum on the round-trip. Clamp the parsed bounds into ``[0, 1]`` (a
            # binary column is 0/1 by definition) and stamp them onto the variable.
            var.lb = np.broadcast_to(np.clip(np.asarray(lb, dtype=np.float64), 0.0, 1.0), shape)
            var.ub = np.broadcast_to(np.clip(np.asarray(ub, dtype=np.float64), 0.0, 1.0), shape)
        elif vt == "integer":
            m.integer(vname, shape=shape, lb=lb, ub=ub)

    # A model whose every row is linear takes its rows as matrix blocks
    # (``DISCOPT_NL_LINEAR_MATRIX``); only the objective is rebuilt as an expression.
    linear_rows = _linear_rows_of_repr(rep) if _nl_linear_matrix_enabled() else None
    if linear_rows is not None:
        from discopt._relax.nl_reconstruction import reconstruct_objective

        objective_expr = reconstruct_objective(rep, m._variables)
        constraint_tuples: list = []
    else:
        objective_expr, constraint_tuples = reconstruct_dag(rep, m._variables)

    # #654: rebalance pathologically deep ``+`` chains (flat sums parsed as depth-N
    # left chains) so downstream recursive tree-walks don't overflow the stack.
    # A no-op below _SUM_REBALANCE_DEPTH, so ordinary models are byte-identical.
    obj_expr: Expression = _rebalance_deep_sum(objective_expr)

    if rep.objective_sense == "minimize":
        m.minimize(obj_expr)
    else:
        m.maximize(obj_expr)

    if linear_rows is not None:
        _add_linear_rows_as_blocks(m, *linear_rows)

    for body, sense, rhs in constraint_tuples:
        body_expr: Expression = _rebalance_deep_sum(body)
        if sense == "<=":
            m.subject_to(body_expr <= rhs)
        elif sense == ">=":
            m.subject_to(body_expr >= rhs)
        elif sense == "==":
            m.subject_to(body_expr == rhs)

    _attach_repr_initial_point(m, rep)

    return m


def _nl_linear_matrix_enabled() -> bool:
    """``DISCOPT_NL_LINEAR_MATRIX`` (default ON; ``=0`` restores expression rows).

    A model read from a file whose every row is linear gets its rows as fast-API
    matrix blocks (:func:`_linear_rows_of_repr`) instead of one Python expression tree
    per row: the same rows in the same order, a representation change, not a model
    change. Those trees were walked by ~10 independent set-up passes: on MIPLIB's
    reblock420 (15k rows) set-up before the MILP engine took 9.8 s of a 20 s budget
    (2026-11-13, ``highs-mip-replacement-plan.md`` §8.9). The opt-out is for A/B
    measurement and as an escape hatch.
    """
    import os as _os

    raw = _os.environ.get("DISCOPT_NL_LINEAR_MATRIX", "1").strip().lower()
    if raw in ("1", "true", "yes", "on", ""):
        return True
    if raw in ("0", "false", "no", "off"):
        return False
    raise ValueError(f"DISCOPT_NL_LINEAR_MATRIX={raw!r} is not recognized (expected 1 or 0)")


def _linear_rows_of_repr(rep):
    """``(A, senses, rhs)`` when ``rep`` is an LP/MILP -- a linear objective and every
    constraint linear -- else ``None``.

    Each row is read off the arena's exact quadratic decomposition (as
    ``extract_lp_data``'s repr rung reads it): linear exactly when its quadratic map
    is empty; the row's constant moves to the right-hand side. ``A`` is CSR over the
    model's flat columns, rows in ``rep``'s order, exact zeros dropped.
    """
    import scipy.sparse as sp

    m = rep.n_constraints
    # LP/MILP only: a quadratic or nonlinear objective goes down routes (QP, spatial,
    # the arena tape) that treat builder-resident rows differently.
    if m == 0 or not rep.is_objective_linear():
        return None
    indptr = [0]
    cols: list = []
    vals: list = []
    senses: list[str] = []
    rhs = np.empty(m, dtype=np.float64)
    for i in range(m):
        form = rep.constraint_quadratic_form(i)
        if form is None or len(form[0]) != 0:
            return None
        ci, cd, const = form[3], form[4], float(form[5])
        for j, v in zip(ci, cd):
            if v != 0.0:
                cols.append(int(j))
                vals.append(float(v))
        indptr.append(len(cols))
        senses.append(rep.constraint_sense(i))
        rhs[i] = float(rep.constraint_rhs(i)) - const
    if any(s not in ("<=", ">=", "==") for s in senses):
        return None
    A = sp.csr_matrix(
        (np.asarray(vals, dtype=np.float64), np.asarray(cols, dtype=np.int64), indptr),
        shape=(m, rep.n_vars),
    )
    return A, senses, rhs


def _add_linear_rows_as_blocks(m: "Model", A, senses: list, rhs: np.ndarray) -> None:
    """Add ``A x (senses) rhs`` to ``m`` as fast-API blocks over all its variables, one
    block per maximal run of equal senses, so the rows keep their order (the builder
    and every consumer read blocks in order). Rows are unnamed, as ``subject_to``
    leaves them.

    A ``>=`` row is added as ``-a x <= -rhs``: ``subject_to(body >= rhs)`` stores
    ``rhs - body <= 0``, so this is the row the expression path hands the solver, and
    the standard form comes out identical, not merely equivalent (negation is exact).
    """
    import scipy.sparse as sp

    ge = np.array([s == ">=" for s in senses])
    if ge.any():
        flip = sp.diags(np.where(ge, -1.0, 1.0))
        A = (flip @ A).tocsr()
        rhs = np.where(ge, -rhs, rhs)
        senses = ["<=" if s == ">=" else s for s in senses]
    x = VarBlock(m._variables) if len(m._variables) > 1 else m._variables[0]
    start, n = 0, len(senses)
    while start < n:
        end = start + 1
        while end < n and senses[end] == senses[start]:
            end += 1
        m.add_linear_constraints(A[start:end], x, senses[start], rhs[start:end])
        start = end


def _attach_repr_initial_point(m: Model, rep) -> None:
    """Attach ``rep``'s column-indexed starting point to ``m``'s variables.

    ``rep.initial_point()`` is ``[(column, value), …]`` over the *flat* scalar
    column space. Variables were created above in block order, so that space is
    the model's own flat variable vector (the contract stated in
    :func:`model_from_repr`'s docstring) and a running offset resolves each
    column to its ``(variable, element)``.

    Values are carried **verbatim** — no bound clamping, no integrality
    rounding. They are a faithful copy of what the source file said, and
    re-exporting them has to reproduce it; the clamping belongs to
    :meth:`Model.set_initial_point`, which takes user input instead.

    A column outside the model's variables would mean the parser and this
    builder disagree about the column space, so it raises rather than being
    skipped: silently dropping it would attach a starting point that is quietly
    missing entries.
    """
    entries = rep.initial_point()
    if not entries:
        return

    # Flat column -> (variable, element), built once.
    columns: list[tuple[str, int]] = []
    for var in m._variables:
        for elem in range(var.size):
            columns.append((var.name, elem))

    keyed: dict[tuple[str, int], float] = {}
    for column, value in entries:
        if not 0 <= column < len(columns):
            raise ValueError(
                f"initial-point column {column} is outside the model's "
                f"{len(columns)} scalar variables; the .nl parser and the model "
                "builder disagree about the column space"
            )
        keyed[columns[column]] = float(value)
    m._initial_point = keyed


def from_nl(path: str) -> Model:
    """
    Import a model from AMPL .nl format.

    Uses the Rust .nl parser for speed. Variables, bounds, constraints,
    and objective are extracted from the binary .nl representation.

    Parameters
    ----------
    path : str
        Path to the ``.nl`` file.

    Returns
    -------
    Model
        A Model ready to solve. The NLP evaluation is delegated to the
        the standard ``NLPEvaluator`` with JAX autodiff.

    Examples
    --------
    >>> model = dm.from_nl("problem.nl")
    >>> result = model.solve()
    """
    import os

    from discopt._relax.nl_reconstruction import reconstruct_complementarities
    from discopt._rust import parse_nl_file

    # Digest the bytes BEFORE parsing: if the file changes in between, the digest
    # describes the old content, and the solver's check below then refuses the file
    # rather than accepting a parse of something else.
    source_digest = nl_file_sha256(path)
    nl_repr = parse_nl_file(path)

    model_name = os.path.splitext(os.path.basename(path))[0]
    m = model_from_repr(nl_repr, model_name)

    # Complementarity (type-5) rows: lower each ``body ⊥ x`` relation through the
    # exact GDP disjunction machinery instead of adding it as an ordinary
    # constraint (#658). The complementarity rows are absent from
    # ``constraint_tuples`` above (consumed by the relation), so there is no
    # double-add.
    compl_pairs = reconstruct_complementarities(nl_repr, m._variables)
    for k, (body, var_index, flag) in enumerate(compl_pairs):
        _add_nl_complementarity(m, body, var_index, flag, index=k)

    # SOS1/SOS2 sets carried as ``sosno``/``ref`` variable suffixes (#1921). The
    # parser used to read past every suffix, so the sets were silently dropped and
    # a solve returned points of the relaxation as optima of the model.
    n_sos = _add_nl_sos_sets(m, nl_repr)

    # Keep nl_repr for backward compatibility (Rust evaluator for validation)
    m._nl_repr = nl_repr
    # Record the source path so the solver can hand POUNCE the original .nl for
    # native-AD node NLP solves (discopt.solvers.nlp_native), bypassing the JAX
    # callback bridge. The .nl column order is the model's variable order here,
    # so the native problem aligns with the evaluator's flat x (identity map).
    #
    # Suppressed when the model carried complementarities: the GDP lowering above
    # added selector binaries / auxiliaries and disjunction constraints that the
    # in-memory model has but the original .nl does not, so POUNCE reading the raw
    # .nl would solve a structurally different (under-constrained) problem. The
    # ``to_nl`` fallback emits the reformulated model instead, staying consistent
    # with the JAX evaluator.
    #
    # The digest goes with the path because the path alone says nothing about what
    # is there now: ``nlp_native`` reads the file only while its bytes still hash to
    # this, so a copy of the model that moved (pickle, ``Model.save``) or a file
    # edited since cannot hand POUNCE a different problem.
    # The same holds for SOS sets: their reformulation adds selector binaries and
    # rows the raw .nl does not have (POUNCE ignores the suffixes).
    if not compl_pairs and not n_sos:
        m._source_nl_path = os.path.abspath(path)
        m._source_nl_sha256 = source_digest

    return m


# Suffixes that encode SOS constraints in a way :func:`_add_nl_sos_sets` does not
# interpret: AMPL's piecewise-linear SOS2 encoding (``sos``/``sosref``, written
# when ``pl_linearize`` is off). Reading past them would drop constraints, so a
# file that carries one is refused (#1921).
_NL_UNSUPPORTED_SOS_SUFFIXES = ("sos", "sosref")


def _add_nl_sos_sets(m: "Model", rep) -> int:
    """Declare the SOS sets of a ``.nl`` file's ``sosno``/``ref`` suffixes.

    AMPL convention (also SCIP's and Couenne's readers): the integer variable
    suffix ``sosno`` names the set a column belongs to -- a positive value is an
    SOS1 set, a negative value an SOS2 set, ``0`` no set -- and the real variable
    suffix ``ref`` gives each member's weight, which orders the set. Each set
    becomes one :meth:`Model.sos1` / :meth:`Model.sos2` over its members sorted by
    weight. Returns the number of sets added.

    Refuses (``ValueError``) whatever it cannot read faithfully, instead of
    dropping a constraint: an SOS-encoding suffix it does not interpret, an SOS2
    member without a ``ref`` weight or with a tied weight (the order of an SOS2
    set is part of the constraint), and a column outside the model.
    """
    suffixes = rep.suffixes()
    if not suffixes:
        return 0

    sosno: dict[int, float] = {}
    ref: dict[int, float] = {}
    for kind, name, entries in suffixes:
        entity = kind & 3
        if name in _NL_UNSUPPORTED_SOS_SUFFIXES:
            raise ValueError(
                f"the .nl file carries the '{name}' suffix (AMPL's piecewise-linear "
                "SOS encoding), which discopt does not interpret; reading past it "
                "would silently drop SOS constraints (#1921). Re-export the model "
                "with piecewise-linear terms linearized (AMPL option pl_linearize 1)."
            )
        if name not in ("sosno", "ref"):
            continue
        if entity != 0:
            raise ValueError(
                f"the .nl file carries a '{name}' suffix on a non-variable entity "
                f"(kind {kind}); SOS sets are declared on variables (#1921)"
            )
        target = sosno if name == "sosno" else ref
        for index, value in entries:
            target[int(index)] = float(value)

    sets: dict[int, list[int]] = {}
    for column, value in sosno.items():
        if value != int(value):
            raise ValueError(f"non-integer sosno {value} on column {column}")
        if int(value) != 0:
            sets.setdefault(int(value), []).append(column)
    if not sets:
        return 0

    columns: list[Variable] = []
    for var in m._variables:
        if var.size != 1:
            raise ValueError(
                "SOS suffixes need one variable per .nl column; got a block variable "
                f"'{var.name}' of size {var.size}"
            )
        columns.append(var)

    for set_id in sorted(sets, key=lambda k: (abs(k), k)):
        members = sets[set_id]
        sos_type = 1 if set_id > 0 else 2
        for column in members:
            if not 0 <= column < len(columns):
                raise ValueError(
                    f"SOS set {set_id}: column {column} is outside the model's "
                    f"{len(columns)} variables"
                )
        if sos_type == 2:
            missing = [c for c in members if c not in ref]
            if missing:
                raise ValueError(
                    f"SOS2 set {abs(set_id)}: columns {missing} have no 'ref' weight, "
                    "so the set's order is undefined (#1921)"
                )
            weights = [ref[c] for c in members]
            if len(set(weights)) != len(weights):
                raise ValueError(
                    f"SOS2 set {abs(set_id)}: tied 'ref' weights, so the set's order "
                    "is undefined (#1921)"
                )
        # SOS1 is order-free; ordering by weight (ties and gaps by column) keeps the
        # declaration deterministic.
        members = sorted(members, key=lambda c: (ref.get(c, float("inf")), c))
        vars_ = [columns[c] for c in members]
        name = f"sos{sos_type}_{abs(set_id)}"
        if sos_type == 1:
            m.sos1(vars_, name=name)
        else:
            m.sos2(vars_, name=name)
    return len(sets)


def nl_file_sha256(path: str) -> str:
    """SHA-256 hex digest of a file's bytes (the ``_source_nl_sha256`` record)."""
    import hashlib

    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _add_nl_complementarity(
    m: "Model", body: "Expression", var_index: int, flag: int, *, index: int = 0
) -> None:
    r"""Lower one ``.nl`` complementarity row exactly.

    The row ``5 flag i`` asserts the mixed complementarity relation
    ``body ⊥ x ∈ [lb, ub]`` with ``x = m._variables[i - 1]``: at ``x = lb`` the
    body is ``>= 0``, at ``x = ub`` it is ``<= 0``, strictly between it is ``0``.
    The complementarity is against the variable's **bound**, not against 0.

    ``flag`` records which of the variable's bounds are finite. AMPL MP
    ``ComplInfo`` (``include/mp/nl-reader.h``) names the bits after the body
    bound they imply: ``INF_UB = 1`` (finite variable lower bound ⇒ body upper
    bound ``+inf``, so ``body >= 0``) and ``INF_LB = 2`` (finite variable upper
    bound ⇒ body lower bound ``-inf``, so ``body <= 0``). AMPL relies on this:
    it drops a body variable's own 0 bound as implied by the relation. Measured
    with AMPL on ``3 <= x <= Infinity complements y``: row ``5 1 1``, ``x``
    written ``>= 3``, ``y``'s ``>= 0`` bound omitted (#2056).

    discopt's primitive is :math:`0 \le a \perp b \ge 0`. The single-bounded
    forms map onto it exactly:

    * ``flag == 1`` (``x >= lb``): ``a = body``, ``b = x - lb``;
    * ``flag == 2`` (``x <= ub``): ``a = -body``, ``b = ub - x``.

    The doubly-bounded and free forms are general box relations and go through
    :meth:`Model.mcp`, which splits them into NCP halves (#2058):

    * ``flag == 3`` (``lb <= x <= ub``): ``body ⊥ x in [lb, ub]``. The split
      needs a finite interval enclosure of ``body``; without one the row is
      refused (AMPL omits a body variable's bound the relation implies, so a
      file may need bounds restored before it can be lowered);
    * ``flag == 0`` (``x`` free): ``body == 0``.

    A flag that disagrees with the variable's finite bounds is a malformed file
    and is refused. Ferris, Fourer and Gay (SIAM J. Optim. 9(4), 1999) give the
    AMPL semantics.
    """
    from discopt.constants import DEFAULT_VARIABLE_BOUND

    x = m._variables[var_index]
    lb_arr = np.asarray(x.lb, dtype=float)
    ub_arr = np.asarray(x.ub, dtype=float)
    if lb_arr.size != 1 or ub_arr.size != 1:
        raise ValueError(
            f"from_nl: complementarity row {index} names variable {x.name!r}, which "
            f"is not scalar (shape {lb_arr.shape}); a .nl variable is always scalar."
        )
    xlb = float(lb_arr.reshape(-1)[0])
    xub = float(ub_arr.reshape(-1)[0])
    # A side at the default-bound sentinel means "unbounded", exactly as the .nl
    # convention reads a magnitude >= 1e20 (see ``_downgrade_defaulted_box``).
    _sentinel = DEFAULT_VARIABLE_BOUND * (1.0 - 1e-12)
    lb_finite = bool(np.isfinite(xlb)) and abs(xlb) < _sentinel
    ub_finite = bool(np.isfinite(xub)) and abs(xub) < _sentinel
    expected_flag = int(lb_finite) | (2 * int(ub_finite))

    if flag not in (0, 1, 2, 3):
        raise ValueError(
            f"from_nl: complementarity row {index} on variable {x.name!r} has "
            f"flag={flag}, which is not an AMPL MP ComplInfo value in {{0, 1, 2, 3}}."
        )
    if flag != expected_flag:
        raise ValueError(
            f"from_nl: complementarity row {index} is malformed: flag={flag} says the "
            f"complementary variable {x.name!r} has "
            f"{_describe_compl_flag(flag)}, but its bounds are [{xlb:g}, {xub:g}] "
            f"({_describe_compl_flag(expected_flag)}). AMPL derives the flag from "
            "the variable's bounds, so the two must agree; the relation the file "
            "intends is ambiguous and is not guessed (#2056)."
        )
    # Name the relation after its ``.nl`` row. Two things depend on it: the rows
    # generated below are named from it (an unnamed relation falls back to
    # ``compl0`` for *every* pair, since the fallback counts within the single
    # pair handed to the lowering — a name collision across a multi-pair file),
    # and the provenance record #1147 carries through the rebuilding passes is
    # identifiable in an error message without parsing generated identifiers.
    rel_name = f"nl_compl{index}"
    if flag == 3:
        m.mcp(body, x, lb=xlb, ub=xub, method="gdp", name=rel_name)
        return
    if flag == 0:
        m.mcp(body, x, lb=-np.inf, ub=np.inf, method="gdp", name=rel_name)
        return

    # Orient both sides nonnegative and measure the variable from its bound.
    # ``x - lb`` and ``ub - x`` are >= 0 by the variable's own bound, and are 0
    # exactly when ``x`` sits at that bound, which is when the MCP lets the body
    # be nonzero.
    if flag == 1:
        a = body
        b = x - xlb if xlb != 0.0 else x
    else:  # flag == 2
        a = -body
        b = xub - x
    m.complementarity(a, b, method="gdp", name=rel_name)


def _describe_compl_flag(flag: int) -> str:
    """Human-readable bound pattern for an AMPL ``ComplInfo`` flag."""
    return {
        0: "no finite bound",
        1: "only a finite lower bound",
        2: "only a finite upper bound",
        3: "finite lower and upper bounds",
    }[flag]


def from_gams(path: str) -> Model:
    """
    Import a model from GAMS .gms format.

    Parses GAMS source text and builds a discopt Model.  Supports the
    MINLP subset: Sets, Scalars, Parameters, Tables, Variables
    (positive/binary/integer/free), Equations with ``=e=``/``=l=``/``=g=``,
    bounds (``.lo``/``.up``/``.fx``), ``sum``/``prod`` over indexed domains,
    and nonlinear functions (``exp``, ``log``, ``sin``, ``cos``, ``sqrt``,
    ``power``, ``sqr``, ...).

    Parameters
    ----------
    path : str
        Path to the ``.gms`` file.

    Returns
    -------
    Model

    Examples
    --------
    >>> model = dm.from_gams("process_synthesis.gms")
    >>> result = model.solve()
    """
    from discopt.modeling.gams_parser import parse_gams_file

    result: Model = parse_gams_file(path)
    return result


def from_description(
    description: str,
    data: Optional[dict] = None,
    llm_model: str = "claude-sonnet-5",
    validate: bool = True,
    explain: bool = True,
) -> Model:
    """
    Create a model from a natural language description using an LLM.

    The LLM generates a discopt Model via function calling (not free-form
    code generation), ensuring type safety.

    Parameters
    ----------
    description : str
        Natural language problem description.
    data : dict, optional
        Named data arrays (DataFrames, numpy arrays, dicts) available
        to the formulation agent.
    llm_model : str, default "claude-sonnet-5"
        LLM model to use for formulation.
    validate : bool, default True
        Validate the generated model before returning.
    explain : bool, default True
        Print the LLM's explanation of the formulation.

    Returns
    -------
    Model

    Raises
    ------
    NotImplementedError
        LLM formulation is a Phase 2 feature.

    Examples
    --------
    >>> model = dm.from_description(
    ...     "Minimize total shipping cost from 3 warehouses to 5 customers.",
    ...     data={"supply": [100, 150, 200], "demand": [80, 60, 70, 40, 50]},
    ... )
    """
    from discopt.llm import is_available

    if not is_available():
        raise ImportError(
            "LLM formulation requires litellm. Install with: pip install discopt[llm]"
        )

    from discopt.llm.prompts import FORMULATE_SYSTEM, FORMULATE_USER
    from discopt.llm.provider import complete_with_tools
    from discopt.llm.serializer import serialize_data_schema
    from discopt.llm.tools import (
        TOOL_DEFINITIONS,
        ModelBuilder,
        execute_tool_calls,
    )

    data_text = serialize_data_schema(data) if data else ""
    user_msg = FORMULATE_USER.format(description=description, data_schema=data_text)
    messages: list[dict] = [
        {"role": "system", "content": FORMULATE_SYSTEM},
        {"role": "user", "content": user_msg},
    ]

    builder = ModelBuilder()
    if data:
        builder._namespace.update(data)

    max_turns = 10
    for _ in range(max_turns):
        response = complete_with_tools(
            messages=messages,
            tools=TOOL_DEFINITIONS,
            model=llm_model,
            max_tokens=4096,
            timeout=30.0,
        )

        # complete_with_tools returns the message directly
        msg = response
        msg_dict = msg.model_dump(exclude_none=True) if hasattr(msg, "model_dump") else msg
        messages.append(msg_dict)

        tool_calls = getattr(msg, "tool_calls", None)
        if not tool_calls:
            break

        tool_results = execute_tool_calls(tool_calls, builder)
        messages.extend(tool_results)

    if builder.model is None:
        raise ValueError("LLM did not create a model")

    if validate:
        builder.model.validate()

    if explain and messages:
        last = messages[-1]
        content = last.get("content", "") if isinstance(last, dict) else ""
        if content:
            print(f"LLM explanation: {content}")

    return builder.model
