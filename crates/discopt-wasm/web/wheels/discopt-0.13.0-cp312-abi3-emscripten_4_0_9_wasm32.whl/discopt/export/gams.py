"""
GAMS (.gms) export for discopt models.

Walks the discopt expression DAG and emits valid GAMS source text.
Supports MINLP models with nonlinear expressions, binary/integer variables,
and all standard math functions.
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np

from discopt.constants import DEFAULT_VARIABLE_BOUND, bound_is_open
from discopt.export import _arrays
from discopt.export._common import binary_box_is_default, refuse_non_algebraic_relations
from discopt.modeling.core import (
    BinaryOp,
    Constant,
    Expression,
    FunctionCall,
    IndexExpression,
    MatMulExpression,
    Model,
    ObjectiveSense,
    Parameter,
    SumExpression,
    SumOverExpression,
    UnaryOp,
    Variable,
    VarType,
)


def _starting_level(lb: float, ub: float) -> float:
    """A strictly-interior starting level for a GAMS variable.

    GAMS defaults every level to 0 and evaluates the model AT that point during
    generation, so a model containing ``log(x)`` or ``a / x`` aborts before the
    solver ever runs:

        **** Exec Error at line 121: division by zero (0)
        **** Exec Error at line 122: log: FUNC DOMAIN: x < 0
        **** SOLVE ... ABORTED, EXECERROR = 5

    Measured on MINLPLib's ``4stufen`` (log of a ratio of differences), where the
    exported model was syntactically valid and still unusable. ``domlim`` does
    not help: these fire during model generation, not solver iterations.
    MINLPLib's own ``.gms`` files ship starting levels for the same reason, so
    emitting them is the faithful choice, not a thumb on the scale.

    Mirrors the interior-point rule used for the analytic separation probe:
    midpoint of a finite box, one unit in from a half-open side, origin when
    fully free.
    """
    lo_f, hi_f = not bound_is_open(lb), not bound_is_open(ub)
    if lo_f and hi_f:
        return 0.5 * (lb + ub)
    if lo_f:
        return lb + 1.0
    if hi_f:
        return ub - 1.0
    return 0.0


# Width at which the writer breaks a statement across lines (#1739). GAMS
# rejects any input line longer than 80000 characters
#
#     ****  98  Non-blank character(s) beyond max input line length (80000)
#
# and a declaration list or a dense equation is ONE line per statement, so a
# model with a few thousand rows (a 52-period planning MILP: a 131,440-char
# `Equations` line) produced a `.gms` file that does not compile. GAMS is free
# format -- a statement runs to its `;` across any number of lines -- so the
# fix is to wrap. 255 is far inside the limit and keeps the file readable.
_MAX_LINE = 255
_CONT_INDENT = "    "


def _declaration(keyword: str, names: list[str]) -> list[str]:
    """``keyword a, b, c;`` -- or, when that is too long, one name per line.

    A declaration is wrapped only between names, never inside a domain such as
    ``x(s1, s2)``: GAMS reads unquoted text after a declared name as its
    explanatory text, so a break in the wrong place changes what is declared.
    """
    one_line = f"{keyword} {', '.join(names)};"
    if len(one_line) <= _MAX_LINE:
        return [one_line]
    body = [f"{_CONT_INDENT}{nm}," for nm in names]
    body[-1] = body[-1][:-1] + ";"
    return [keyword, *body]


def _wrap_line(line: str, width: int = _MAX_LINE) -> list[str]:
    """Split one emitted line outside quotes so no piece exceeds ``width``.

    Continuation lines are indented, which matters for correctness and not
    only looks: GAMS reads a ``*`` in column 1 as a comment and a ``$`` as a
    dollar-control line, and a break before ``* x`` in ``a * x`` would otherwise
    comment out the rest of the equation. A comment line is wrapped as further
    comment lines. A single token longer than ``width`` (none exists: GAMS
    identifiers are at most 63 characters) is left whole rather than split.
    """
    if len(line) <= width:
        return [line]
    if line.startswith("*"):
        text = line[1:].strip()
        step = width - 2
        return [f"* {text[k : k + step]}" for k in range(0, len(text), step)]

    # (separator-before, text) pieces. A break may fall at a space or right
    # after an opening parenthesis: the left-deep fold `dm.sum` scalarizes to
    # writes a run of one `(` per term with no whitespace in it.
    pieces: list[tuple[str, str]] = []
    start = 0
    sep = ""
    quote: str | None = None
    for k, ch in enumerate(line):
        if quote is not None:
            if ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch
        elif ch == " ":
            if k > start:
                pieces.append((sep, line[start:k]))
            start, sep = k + 1, " "
        elif ch == "(":
            pieces.append((sep, line[start : k + 1]))
            start, sep = k + 1, ""
    if start < len(line):
        pieces.append((sep, line[start:]))

    out: list[str] = []
    cur = ""
    for sep, tok in pieces:
        if not cur:
            cur = (_CONT_INDENT if out else "") + tok
        elif len(cur) + len(sep) + len(tok) <= width:
            cur += sep + tok
        else:
            out.append(cur)
            cur = _CONT_INDENT + tok
    if cur:
        out.append(cur)
    return out


def to_gams(
    model: Model,
    path: str | Path | None = None,
    model_type: str | None = None,
    *,
    initial_point: dict | None = None,
) -> str | None:
    """Export a discopt Model to GAMS (.gms) format.

    Parameters
    ----------
    model : Model
        A discopt optimization model.
    path : str or Path, optional
        If provided, write the .gms string to this file and return ``None``.
        Otherwise return the .gms string.
    model_type : str, optional
        GAMS model type (LP, MIP, NLP, MINLP, etc.).  Auto-detected if not given.
    initial_point : dict, optional
        ``{Variable: value}`` starting guess, in the form :func:`to_nl`'s
        ``initial_point`` and :meth:`Model.solve`'s ``initial_solution`` take
        (validated, bound-clamped and integrality-rounded the same way). Written
        as each element's ``.l`` level (#1620 B-14). The three-way contract is
        :func:`to_nl`'s: ``None`` (the default) writes the point attached to the
        model (``from_nl``'s ``x`` segment, :meth:`Model.set_initial_point`), a
        non-empty dict wins, and ``{}`` writes no supplied point.

        An element with no supplied value gets the interior *fallback* level of
        :func:`_starting_level` (box midpoint, one unit in from a half-open
        side) when it is a scalar variable: GAMS evaluates the model at the
        levels during generation, and at its default level 0 a ``log(x)`` or
        ``a / x`` aborts the solve before the solver runs. That fallback is a
        domain-safety default, not a guess anyone chose -- pass a point to
        replace it.

    Returns
    -------
    str or None
        The GAMS source if *path* is ``None``, otherwise ``None``.
    """
    # ``for_solve=False``: like the ``.nl`` writer, this one *honours*
    # ``Constraint.rhs`` — it emits it verbatim as the equation's right-hand side
    # (``{body} =g= {c.rhs};``) — so a row the solve path refuses as
    # unrepresentable (#909) still exports faithfully. Measured:
    # ``Constraint(w, ">=", 5.0)`` emits ``c1.. w =g= 5.0;``.
    # NOTE: the LP and MPS writers deliberately do *not* do this — see the comment
    # on their ``model.validate()`` calls.
    model.validate(for_solve=False)
    # A disjunction/indicator/SOS/logic row is not an algebraic row; refuse it
    # by name rather than die on ``con.body`` in the equation writer (#1218).
    # This writer emits plain GAMS equations, not an EMP/JAMS disjunctive model.
    refuse_non_algebraic_relations(model, "GAMS")
    if initial_point is None:
        point = dict(getattr(model, "_initial_point", None) or {})
    elif initial_point:
        from discopt.export.nl import _keyed_initial_point

        point = _keyed_initial_point(model, initial_point)
    else:
        point = {}
    writer = _GamsWriter(model, model_type, point)
    text = writer.write()
    if path is not None:
        Path(path).write_text(text)
        return None
    return text


class _GamsWriter:
    def __init__(
        self,
        model: Model,
        model_type: str | None,
        initial_point: dict[tuple[str, int], float] | None = None,
    ):
        self.model = model
        # (name, element) -> level the caller supplied (#1620 B-14).
        self._initial_point = dict(initial_point or {})
        self._model_type = model_type
        self._set_counter = 0
        # Map Variable -> (set_names, set_elements) for indexed variables
        self._var_sets: dict[str, list[tuple[str, list[str]]]] = {}

    def write(self) -> str:
        lines: list[str] = []
        lines.append(f"* GAMS export of discopt model: {self.model.name}")
        lines.append("")

        # Generate sets from variable shapes
        self._generate_sets(lines)

        # Variables (including synthetic obj_var)
        self._write_variables(lines)

        # Equations declarations + definitions
        self._write_equations(lines)

        # Model and Solve
        self._write_model_solve(lines)

        lines.append("")
        return "\n".join(piece for line in lines for piece in _wrap_line(line))

    def _generate_sets(self, lines: list[str]):
        """Generate GAMS Set declarations from variable shapes."""
        # Track unique dimension sizes to avoid duplicate sets
        dim_sets: dict[int, str] = {}  # size -> set_name

        for var in self.model._variables:
            if var.shape == () or var.shape == (1,):
                continue
            var_set_info: list[tuple[str, list[str]]] = []
            for dim_idx, dim_size in enumerate(var.shape):
                if dim_size in dim_sets:
                    set_name = dim_sets[dim_size]
                    elems = [str(k + 1) for k in range(dim_size)]
                else:
                    self._set_counter += 1
                    set_name = f"s{self._set_counter}"
                    elems = [str(k + 1) for k in range(dim_size)]
                    dim_sets[dim_size] = set_name
                    elem_str = ", ".join(elems)
                    lines.append(f"Set {set_name} / {elem_str} /;")
                var_set_info.append((set_name, elems))
            self._var_sets[var.name] = var_set_info

        if dim_sets:
            lines.append("")

    def _write_variables(self, lines: list[str]):
        """Write variable declarations and bounds."""
        # Group by type
        groups: dict[str, list[Variable]] = {
            "free": [],
            "positive": [],
            "binary": [],
            "integer": [],
        }
        for var in self.model._variables:
            if var.var_type == VarType.BINARY:
                groups["binary"].append(var)
            elif var.var_type == VarType.INTEGER:
                groups["integer"].append(var)
            elif np.all(np.asarray(var.lb) >= 0) and np.any(
                np.asarray(var.lb) < DEFAULT_VARIABLE_BOUND
            ):
                groups["positive"].append(var)
            else:
                groups["free"].append(var)

        has_obj = self.model._objective is not None

        type_kw = {
            "free": "Free Variables",
            "positive": "Positive Variables",
            "binary": "Binary Variables",
            "integer": "Integer Variables",
        }

        for gtype, vars_list in groups.items():
            names: list[str] = []
            # Prepend synthetic obj_var to free group
            if gtype == "free" and has_obj:
                names.append("obj_var")
            for var in vars_list:
                if var.name in self._var_sets:
                    dom = ", ".join(s[0] for s in self._var_sets[var.name])
                    names.append(f"{var.name}({dom})")
                else:
                    names.append(var.name)
            if names:
                lines.extend(_declaration(type_kw[gtype], names))

        lines.append("")

        # Write bounds for non-default bounds
        for var in self.model._variables:
            if var.var_type == VarType.BINARY and binary_box_is_default(var.lb, var.ub):
                # 0-1 is implicit in the `Binary Variables` declaration; only a
                # supplied level is written.
                self._write_given_levels(lines, var)
                continue
            # A pinned binary (EX-3) falls through to the ordinary bound path
            # below, which emits the explicit `.lo`/`.up` that GAMS needs to
            # honor the pin — the declaration alone would restore the 0-1 box.
            lb_arr = np.asarray(var.lb)
            ub_arr = np.asarray(var.ub)
            if var.shape == () or var.shape == (1,):
                # `float()` of a length-1 (not 0-d) array raises
                # "only 0-dimensional arrays can be converted to Python scalars"
                # on numpy >= 2, so a shape-(1,) variable -- which this branch
                # deliberately treats as a scalar -- could not be exported at all.
                # `to_gams()` failed outright for EVERY single-output embedded
                # network (16 of 40 cases in the #1215 NN harness, all and only
                # output size 1), and GAMS is the only route to a full-licence
                # BARON. `ravel()[0]` reads the single element for both shapes.
                lb_val = float(np.ravel(lb_arr)[0])
                ub_val = float(np.ravel(ub_arr)[0])
                if not bound_is_open(lb_val):
                    lines.append(f"{var.name}.lo = {lb_val};")
                if not bound_is_open(ub_val):
                    lines.append(f"{var.name}.up = {ub_val};")
                given = self._initial_point.get((var.name, 0))
                lvl = float(given) if given is not None else _starting_level(lb_val, ub_val)
                if lvl != 0.0 or given is not None:
                    lines.append(f"{var.name}.l = {lvl!r};")
            else:
                # X-2 (#413) / EX-4: an array-variable block is NOT a scalar.
                # The previous code only emitted a bound when it was UNIFORM
                # across every element (`np.all(arr == arr.flat[0])`); on
                # heterogeneous per-element bounds it silently dropped the bound
                # *entirely*, exporting e.g. a DAE model with pinned initial
                # conditions as an unbounded (or default-Positive) variable —
                # GAMS then solves a different model than discopt. Emit the
                # uniform case compactly over the whole domain and, when
                # heterogeneous, emit one line per element at its 1-based label.
                self._write_array_bound(lines, var, lb_arr, "lo")
                self._write_array_bound(lines, var, ub_arr, "up")
                self._write_given_levels(lines, var)

        lines.append("")

    def _write_given_levels(self, lines: list[str], var: Variable) -> None:
        """Emit ``.l`` for every element of ``var`` the caller supplied a level for."""
        for k in range(var.size):
            given = self._initial_point.get((var.name, k))
            if given is None:
                continue
            if var.name in self._var_sets:
                lines.append(f"{var.name}.l({self._element_label(var, k)}) = {float(given)!r};")
            else:
                lines.append(f"{var.name}.l = {float(given)!r};")

    def _element_label(self, var: Variable, k: int) -> str:
        """1-based, quoted GAMS label(s) for flat element ``k`` of ``var``.

        Multi-dimensional variables produce a comma-separated tuple of labels
        matching the declared set domains (e.g. ``'1', '2'``); flat/1-D
        variables produce a single ``'k+1'``.
        """
        idx = np.unravel_index(k, var.shape)
        return ", ".join(f"'{i + 1}'" for i in np.atleast_1d(idx))

    def _write_array_bound(self, lines, var, arr, kind):
        """Emit ``.lo``/``.up`` bounds for an array variable, per element.

        ``kind`` is ``"lo"`` or ``"up"``; a bound is emitted unless it is open
        (``bound_is_open``: non-finite or at the declared-no-bound box). Uniform
        bounds are compacted to one domain-wide assignment; heterogeneous bounds
        are written one element at a time so no per-element bound is ever dropped
        (X-2 / EX-4).
        """
        flat = np.asarray(arr, dtype=np.float64).ravel()
        if flat.size == 0:
            return
        has_dom = var.name in self._var_sets
        dom = ", ".join(s[0] for s in self._var_sets[var.name]) if has_dom else None

        if np.all(flat == flat[0]):
            val = float(flat[0])
            if not bound_is_open(val):
                target = f"{var.name}.{kind}({dom})" if has_dom else f"{var.name}.{kind}"
                lines.append(f"{target} = {val};")
            return

        # Heterogeneous: one assignment per element at its 1-based label. When
        # the variable was declared over a set domain we address elements by
        # label; otherwise (no set info) fall back to a plain scalar name, which
        # only occurs for the degenerate size-1 arrays handled above.
        for k in range(flat.size):
            val = float(flat[k])
            if bound_is_open(val):
                continue
            if has_dom:
                lines.append(f"{var.name}.{kind}({self._element_label(var, k)}) = {val};")
            else:
                lines.append(f"{var.name}.{kind} = {val};")

    def _write_equations(self, lines: list[str]):
        """Write equation declarations and definitions."""
        from discopt.export._common import iter_builder_linear_rows

        obj = self.model._objective
        constraints = self.model._constraints
        # X-1: fast-API / builder-resident linear rows (`add_linear_constraints` /
        # the `Model.constraint` fast path) live only in the Rust builder. Without
        # them the GAMS export would emit an empty model.
        builder_rows = iter_builder_linear_rows(self.model)

        # Expand array-structured bodies ONCE, up front. One `Constraint` with an
        # array body (`A @ x <= b`, `dm.exp(x) <= b`) is many GAMS equations, and
        # the declaration loop and the definition loop below must agree on how
        # many and what they are called -- so they are both driven from this one
        # list rather than each re-deriving it from `constraints`.
        #
        # Before this, `gams.py` had no expansion at all: `_expr_to_gams` walked
        # straight into an array `Constant` and died with `TypeError: only
        # 0-dimensional arrays can be converted to Python scalars`. That refused
        # the vectorised form of a model, which is the one that reaches
        # solve-ready 36x faster than the per-element idiom (perf-plan §41), and
        # GAMS is the only route to a full-licence BARON.
        rows: list[tuple[str, Expression, str, float]] = []
        for i, c in enumerate(constraints):
            base = c.name or f"c{i + 1}"
            bodies = _arrays.scalarize_body(c.body, self._resolve_var_index)
            if len(bodies) == 1:
                rows.append((self._sanitize_eq_name(base) or base, bodies[0], c.sense, c.rhs))
            else:
                # Row `k` of a family is `{base}_{k}`, ZERO-based -- the same rule
                # `lp.py`, `mps.py` and the Rust builder row naming all use. This
                # numbered from 1, making GAMS the only one of the four formats
                # where row k of family `c` was not called `c_k`, so the same
                # model exported to `.lp` and to `.gms` disagreed on every
                # expanded row's name.
                #
                # It also meant that vectorising an emitter -- replacing N
                # per-element constraints named `c_0 … c_{N-1}` with one family
                # named `c` -- silently SHIFTED every GAMS row name by one, while
                # leaving `.nl` and LP byte-identical. That is exactly what #1215's
                # NN-emitter work hit, and it is invisible to any check that does
                # not diff GAMS (perf-plan §56/§57).
                #
                # GAMS's own set labels are 1-based (`x('1')`), which is presumably
                # where the +1 came from, but an equation NAME is not a set label.
                for k, body in enumerate(bodies):
                    nm = self._sanitize_eq_name(f"{base}_{k}") or f"c{i + 1}_{k}"
                    rows.append((nm, body, c.sense, c.rhs))

        # Declare equations
        eq_names = ["obj_eq"]
        for nm, _, _, _ in rows:
            eq_names.append(nm)
        for j, brow in enumerate(builder_rows):
            eq_names.append(self._sanitize_eq_name(brow.name) or f"blk{j + 1}")
        lines.extend(_declaration("Equations", eq_names))
        lines.append("")

        # Objective equation: obj_var =e= expr. A builder-resident objective
        # (`add_linear_objective` / `add_quadratic_objective`, X-1) leaves a zero
        # placeholder in `model._objective` — recover its real terms rather than
        # emit `obj_var =e= 0`.
        from discopt.export._common import builder_objective

        builder_obj = builder_objective(self.model)
        if builder_obj is not None:
            obj_str = self._builder_objective_expr(builder_obj)
            lines.append(f"obj_eq.. obj_var =e= {obj_str};")
            lines.append("")
        elif obj is not None:
            # Scalar-VALUED but array-STRUCTURED objectives (`-dm.sum(x)`,
            # `dm.sum(A @ x)`) need the same expansion; a vector-valued one is
            # refused rather than truncated to element zero.
            obj_body = _arrays.scalarize_objective(obj.expression, self._resolve_var_index)
            obj_expr_str = self._expr_to_gams(obj_body)
            lines.append(f"obj_eq.. obj_var =e= {obj_expr_str};")
            lines.append("")

        # Constraint equations
        gams_sense = {"<=": "=l=", ">=": "=g=", "==": "=e="}
        for name, body, sense, rhs in rows:
            op = gams_sense.get(sense)
            if op is not None:
                lines.append(f"{name}.. {self._expr_to_gams(body)} {op} {rhs};")

        # Builder-resident linear equations, emitted with variable names + 1-based
        # element references (matching the GAMS index convention above).
        gams_op = {"<=": "=l=", ">=": "=g=", "==": "=e="}
        for j, brow in enumerate(builder_rows):
            name = self._sanitize_eq_name(brow.name) or f"blk{j + 1}"
            lhs = self._builder_row_lhs(brow.terms)
            lines.append(f"{name}.. {lhs} {gams_op[brow.sense]} {self._fmt_num(brow.rhs)};")

        lines.append("")

    def _resolve_var_index(self, expr: IndexExpression) -> int | None:
        """Flat slot for ``x[i]`` / ``x[i, j]``, or ``None`` when not resolvable.

        Only used by :func:`_arrays.needs_scalarize` to decide whether a body is
        already scalar and can skip the recursive expansion pass -- which is what
        keeps a deep ``sum()`` chain off the recursion limit. The value itself is
        never used here, so any non-``None`` answer means "this index is a single
        scalar element".
        """
        if not isinstance(expr.base, Variable):
            return None
        idx = expr.index
        if isinstance(idx, int):
            return idx if 0 <= idx < expr.base.size else None
        if isinstance(idx, tuple) and all(isinstance(i, int) for i in idx):
            shape = expr.base.shape
            if len(idx) != len(shape):
                return None
            flat = 0
            for dim, i in enumerate(idx):
                if not 0 <= i < shape[dim]:
                    return None
                stride = 1
                for d2 in range(dim + 1, len(shape)):
                    stride *= shape[d2]
                flat += i * stride
            return flat
        return None

    def _flat_index_ref(self, gidx: int) -> str:
        """Render flat variable index ``gidx`` as a GAMS variable/element reference.

        Walks ``model._variables`` in the same order that
        ``export._common.variable_flat_offsets`` assigns flat indices.
        """
        offset = 0
        for var in self.model._variables:
            n = max(var.size, 1) if var.shape != () else 1
            if offset <= gidx < offset + n:
                local = gidx - offset
                if var.shape == () or var.shape == (1,):
                    return var.name
                idx = np.unravel_index(local, var.shape)
                idx_str = ", ".join(f"'{i + 1}'" for i in idx)
                return f"{var.name}({idx_str})"
            offset += n
        raise ValueError(f"Flat variable index {gidx} out of range for GAMS export.")

    def _builder_objective_expr(self, builder_obj) -> str:
        """Render a recovered builder objective (linear + optional quadratic) for GAMS."""
        linear, quad, constant, _sense = builder_obj
        parts: list[str] = []

        def _emit(coeff: float, ref: str) -> None:
            sign = "+" if coeff >= 0 else "-"
            mag = abs(coeff)
            term = ref if mag == 1.0 else f"{self._fmt_num(mag)}*{ref}"
            parts.append(f"{sign} {term}" if parts else (f"-{term}" if coeff < 0 else term))

        for gidx in sorted(linear):
            _emit(linear[gidx], self._flat_index_ref(gidx))
        if quad:
            for i, j in sorted(quad):
                # extract_quadratic convention: coefficient of x_i x_j. GAMS gets the
                # raw product term; the diagonal (i == j) becomes x_i * x_i.
                ri, rj = self._flat_index_ref(i), self._flat_index_ref(j)
                _emit(quad[(i, j)], f"{ri}*{rj}")
        if constant != 0.0:
            _emit(constant, "1")
        return " ".join(parts) if parts else "0"

    def _builder_row_lhs(self, terms: list) -> str:
        """Render a builder row's ``sum(coeff * var[idx])`` as a GAMS expression."""
        parts: list[str] = []
        for var, local, coeff in terms:
            if var.shape == () or var.shape == (1,):
                ref = var.name
            else:
                idx = np.unravel_index(local, var.shape)
                idx_str = ", ".join(f"'{i + 1}'" for i in idx)
                ref = f"{var.name}({idx_str})"
            sign = "+" if coeff >= 0 else "-"
            mag = abs(coeff)
            term = ref if mag == 1.0 else f"{self._fmt_num(mag)}*{ref}"
            parts.append(f"{sign} {term}" if parts else (f"-{term}" if coeff < 0 else term))
        return " ".join(parts) if parts else "0"

    @staticmethod
    def _sanitize_eq_name(name: str | None) -> str | None:
        if not name:
            return None
        return name.replace(" ", "_").replace("-", "_").replace("[", "_").replace("]", "")

    @staticmethod
    def _sanitize_model_name(name: str | None) -> str:
        """A legal GAMS identifier for the ``Model``/``Solve`` statements.

        GAMS identifiers must start with a letter and may contain only letters,
        digits and underscores. The model name was previously emitted verbatim,
        so any model whose name starts with a digit produced GAMS that does not
        compile:

            Model 4stufen / all /;
            ****        $2
            ****   2  Identifier expected

        Hit on MINLPLib's ``4stufen`` (1 of 66 in the in-repo corpus, 1 of 1610 in
        the full snapshot) while benchmarking discopt against GAMS subsolvers.
        The ``.gms`` was written successfully and only failed downstream, which is
        the bad way to fail -- an export is meant to be usable.
        """
        base = re.sub(r"[^A-Za-z0-9_]", "_", (name or "").strip()) or "discopt_model"
        if not base[0].isalpha():
            base = f"m_{base}"
        return base

    @staticmethod
    def _fmt_num(value: float) -> str:
        if value == int(value) and abs(value) < 1e15:
            return str(int(value))
        return f"{value:.15g}"

    def _write_model_solve(self, lines: list[str]):
        """Write Model and Solve statements."""
        from discopt.export._common import builder_objective

        mtype = self._model_type or self._detect_model_type()
        builder_obj = builder_objective(self.model)
        if builder_obj is not None:
            is_min = not str(builder_obj[3]).lower().startswith("max")
        else:
            is_min = bool(
                self.model._objective and self.model._objective.sense == ObjectiveSense.MINIMIZE
            )
        sense = "minimizing" if is_min else "maximizing"

        mname = self._sanitize_model_name(self.model.name)
        lines.append(f"Model {mname} / all /;")
        lines.append(f"Solve {mname} using {mtype} {sense} obj_var;")

    def _detect_model_type(self) -> str:
        """Auto-detect GAMS model type from variable types and expression structure."""
        from discopt.export._common import builder_objective

        has_integer = any(
            v.var_type in (VarType.BINARY, VarType.INTEGER) for v in self.model._variables
        )
        # A builder-resident quadratic objective is nonlinear even though the
        # placeholder expression is not (X-1).
        builder_obj = builder_objective(self.model)
        builder_quad = builder_obj is not None and builder_obj[1]
        has_nonlinear = self._has_nonlinear() or bool(builder_quad)
        if has_integer and has_nonlinear:
            return "MINLP"
        if has_integer:
            return "MIP"
        if has_nonlinear:
            return "NLP"
        return "LP"

    def _has_nonlinear(self) -> bool:
        """Check if any expression in the model is nonlinear."""
        exprs = []
        if self.model._objective:
            exprs.append(self.model._objective.expression)
        for c in self.model._constraints:
            exprs.append(c.body)
        return any(self._expr_is_nonlinear(e) for e in exprs)

    def _expr_is_nonlinear(self, expr: Expression) -> bool:
        if isinstance(expr, FunctionCall):
            return True
        if isinstance(expr, BinaryOp):
            if expr.op == "**":
                return True
            if expr.op == "*":
                # bilinear if both sides contain variables
                lv = self._contains_var(expr.left)
                rv = self._contains_var(expr.right)
                if lv and rv:
                    return True
            return self._expr_is_nonlinear(expr.left) or self._expr_is_nonlinear(expr.right)
        if isinstance(expr, UnaryOp):
            return self._expr_is_nonlinear(expr.operand)
        if isinstance(expr, (SumExpression, SumOverExpression)):
            if isinstance(expr, SumExpression):
                return self._expr_is_nonlinear(expr.operand)
            return any(self._expr_is_nonlinear(t) for t in expr.terms)
        return False

    def _contains_var(self, expr: Expression) -> bool:
        if isinstance(expr, Variable):
            return True
        if isinstance(expr, IndexExpression):
            return self._contains_var(expr.base)
        if isinstance(expr, BinaryOp):
            return self._contains_var(expr.left) or self._contains_var(expr.right)
        if isinstance(expr, UnaryOp):
            return self._contains_var(expr.operand)
        if isinstance(expr, FunctionCall):
            return any(self._contains_var(a) for a in expr.args)
        return False

    # ── Expression to GAMS string ──────────────────────────────

    _FUNC_MAP = {
        "exp": "exp",
        "log": "log",
        "log2": "log2",
        "log10": "log10",
        "sqrt": "sqrt",
        "sin": "sin",
        "cos": "cos",
        "tan": "tan",
        "asin": "arcsin",
        "acos": "arccos",
        "atan": "arctan",
        "sinh": "sinh",
        "cosh": "cosh",
        "tanh": "tanh",
        "abs": "abs",
        "sign": "sign",
        "min": "min",
        "max": "max",
        "sigmoid": "sigmoid",
    }

    @staticmethod
    def _num_to_gams(val: float) -> str:
        """A numeric literal, exact (``repr`` round-trips) and GAMS-legal.

        A negative literal is parenthesised: GAMS rejects two operators in a row
        (error 445), so ``(x - -2)`` must be written ``(x - (-2))``.
        """
        if not np.isfinite(val):
            raise ValueError(f"Cannot write the non-finite constant {val!r} into a GAMS equation.")
        txt = str(int(val)) if val == int(val) and abs(val) < 1e15 else repr(val)
        return f"({txt})" if val < 0 else txt

    @staticmethod
    def _parameter_element(param: Parameter, index) -> float:
        """The current value of ``param`` (or of ``param[index]``) as a scalar.

        A ``Parameter`` is "a value fixed during a single solve", and GAMS
        export -- like ``.nl`` export -- writes a SNAPSHOT at its current value.
        This used to fall through to ``<unsupported:Parameter>`` and write that
        text into the equation (#1503). A non-scalar selection is refused rather
        than truncated to one element.
        """
        val = np.asarray(param.value, dtype=np.float64)
        if index is None:
            if val.size != 1:
                raise ValueError(
                    f"Cannot write array parameter {param.name!r} of shape "
                    f"{val.shape} to GAMS without indexing; index it element-wise "
                    f"(e.g. p[i]) so each use is scalar."
                )
            return float(val.reshape(-1)[0])
        if val.shape in ((), (1,)):
            flat = index[0] if isinstance(index, tuple) and len(index) == 1 else index
            if flat != 0:
                raise ValueError(f"Index {index!r} is out of range for parameter {param.name!r}")
            return float(val.reshape(-1)[0])
        try:
            elem = np.asarray(val[index])
        except (IndexError, TypeError) as exc:
            raise ValueError(
                f"Cannot resolve parameter index {param.name}[{index!r}]: shape {val.shape}"
            ) from exc
        if elem.ndim != 0:
            raise ValueError(
                f"Parameter index {param.name}[{index!r}] selects a non-scalar of "
                f"shape {elem.shape}; index it element-wise so each use is scalar."
            )
        return float(elem)

    def _expr_to_gams(self, expr: Expression) -> str:
        if isinstance(expr, Constant):
            if expr.value.ndim != 0:
                raise ValueError(
                    f"Cannot write an array constant of shape {expr.value.shape} "
                    "into a scalar GAMS equation."
                )
            return self._num_to_gams(float(expr.value))

        if isinstance(expr, Parameter):
            return self._num_to_gams(self._parameter_element(expr, None))

        if isinstance(expr, Variable):
            return expr.name

        if isinstance(expr, IndexExpression) and isinstance(expr.base, Parameter):
            return self._num_to_gams(self._parameter_element(expr.base, expr.index))

        if isinstance(expr, IndexExpression):
            base = self._expr_to_gams(expr.base)
            # GAMS is 1-based and requires quoted set labels for concrete element
            # references (f_pipe('1'), not f_pipe(1)). Symbolic indices (set/alias
            # names from a loop) are emitted bare via _expr_to_gams.
            if isinstance(expr.index, tuple):
                idx_str = ", ".join(
                    f"'{i + 1}'" if isinstance(i, int) else self._expr_to_gams(i)
                    for i in expr.index
                )
            elif isinstance(expr.index, int):
                idx_str = f"'{expr.index + 1}'"
            else:
                idx_str = self._expr_to_gams(expr.index)
            return f"{base}({idx_str})"

        if isinstance(expr, BinaryOp) and expr.op in ("+", "-"):
            # Walk the LEFT spine iteratively rather than recursing per term.
            #
            # The array scalarizer expands `dm.sum(x)` over `x` of shape `(n,)`
            # into a left-deep fold `((x[0] + x[1]) + x[2]) + ...` of depth n, so
            # recursing here raised RecursionError at roughly 1000 terms -- i.e.
            # `m.minimize(dm.sum(x))`, one of the commonest objectives there is,
            # could not be exported to GAMS at all. GAMS is the only route to a
            # full-license BARON, so that also blocked BARON comparison for any
            # such model.
            #
            # The emitted TEXT is unchanged: rebuilding left to right reproduces
            # the same nesting the recursion produced, `(((a + b) + c) + d)`.
            # Only the left spine is flattened, which is the shape the scalarizer
            # builds; a right-deep chain still recurses, and nothing in discopt
            # emits one.
            spine: list = []
            # Annotated: the loop narrows `node` to `BinaryOp`, and `node.left`
            # is an `Expression`, so an unannotated `node` cannot be re-bound.
            node: Expression = expr
            while isinstance(node, BinaryOp) and node.op in ("+", "-"):
                spine.append((node.op, node.right))
                node = node.left
            out = self._expr_to_gams(node)
            for op, right_node in reversed(spine):
                out = f"({out} {op} {self._expr_to_gams(right_node)})"
            return out

        if isinstance(expr, BinaryOp):
            left = self._expr_to_gams(expr.left)
            right = self._expr_to_gams(expr.right)
            if expr.op == "**":
                # GAMS power(x, n) requires an INTEGER exponent; a fractional or
                # symbolic exponent must use rPower(x, r) (== x ** r, base >= 0).
                if isinstance(expr.right, Constant) and float(expr.right.value) == int(
                    float(expr.right.value)
                ):
                    return f"power({left}, {right})"
                return f"rPower({left}, {right})"
            return f"({left} {expr.op} {right})"

        if isinstance(expr, UnaryOp):
            operand = self._expr_to_gams(expr.operand)
            if expr.op == "neg":
                return f"(-{operand})"
            if expr.op == "abs":
                return f"abs({operand})"
            return f"{expr.op}({operand})"

        if isinstance(expr, FunctionCall):
            fn = expr.func_name.lower()
            # Decompose functions GAMS doesn't have natively
            if fn == "log1p":
                inner = self._expr_to_gams(expr.args[0])
                return f"log(1 + {inner})"
            if fn == "softplus":
                inner = self._expr_to_gams(expr.args[0])
                return f"log(1 + exp({inner}))"
            if fn == "log2":
                inner = self._expr_to_gams(expr.args[0])
                return f"(log({inner}) / log(2))"
            if fn == "erf":
                # GAMS has no erf: its errorf is the standard normal CDF Φ, and
                # erf(a) = 2·Φ(a·√2) − 1 (#1288).
                inner = self._expr_to_gams(expr.args[0])
                return f"(2 * errorf(({inner}) * sqrt(2)) - 1)"
            # No blanket passthrough of an unmapped name. Emitting
            # `expr.func_name` verbatim wrote whatever the node happened to carry
            # into the .gms file: a name GAMS does not have (`entropy(x)`), or one
            # it has with a different arity -- a one-argument node named `mod`
            # was written as `mod(y)`, but GAMS's mod takes two. Either way
            # the writer reported success and produced a file that is not the model
            # (issue #1237; same class as the GAMS parser's silent acceptance on
            # the way in). Refuse instead, naming the function.
            gams_fn = self._FUNC_MAP.get(fn)
            if gams_fn is None:
                raise ValueError(
                    f"Unknown function in GAMS export: {expr.func_name!r}. The "
                    "writer has no GAMS spelling for it, and emitting the name "
                    "verbatim would produce a .gms file that is not this model. "
                    "Refusing rather than writing something GAMS will misread."
                )
            args_str = ", ".join(self._expr_to_gams(a) for a in expr.args)
            return f"{gams_fn}({args_str})"

        if isinstance(expr, SumExpression):
            return f"({self._expr_to_gams(expr.operand)})"

        if isinstance(expr, SumOverExpression):
            terms = " + ".join(self._expr_to_gams(t) for t in expr.terms)
            return f"({terms})"

        if isinstance(expr, MatMulExpression):
            # flatten matmul to explicit sum of products
            return f"({self._expr_to_gams(expr.left)} * {self._expr_to_gams(expr.right)})"

        # Refuse anything else (e.g. an opaque ``dm.custom`` node) instead of
        # writing a placeholder into the equation text: a ``.gms`` file that is
        # not the model is worse than no file (#1503).
        raise ValueError(f"Cannot write expression type {type(expr).__name__} to GAMS: {expr!r}")
