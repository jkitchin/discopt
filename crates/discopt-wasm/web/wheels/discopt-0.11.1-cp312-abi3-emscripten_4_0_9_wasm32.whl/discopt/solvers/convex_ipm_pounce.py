"""POUNCE's dedicated convex LP/QP interior-point method (``lp-ipm`` / ``qp-ipm``).

The other POUNCE matrix backends (:mod:`discopt.solvers.lp_pounce`,
:mod:`discopt.solvers.qp_pounce`) hand an LP or QP to POUNCE's general
**NLP** engine — the filter line-search interior-point method — through
LP/QP-shaped callbacks. This module instead calls :func:`pounce.qp.solve_qp`,
the specialised convex solver (Mehrotra predictor-corrector with presolve) that
POUNCE's own ``solver_selection=lp-ipm`` / ``qp-ipm`` reach. It backs
``Model.solve(solver="pounce")`` (#1533), whose purpose is that a pure LP or a
convex QP is answered by that algorithm and by nothing else.

Both entry points follow the shared matrix contracts
(:func:`discopt.solvers.lp_simplex.solve_lp` / ``qp_pounce.solve_qp``): same
signature, same :class:`~discopt.solvers.LPResult` / ``QPResult`` with
HiGHS-convention duals, so ``solver._solve_lp_matrix`` and
``solver._solve_qp_matrix`` apply their primal-feasibility and KKT guards to the
returned point unchanged.

Certificates
------------
POUNCE's convex engine reports ``primal_infeasible`` and ``dual_infeasible``
(unbounded) from its own detection. Neither is turned into a certificate on that
say-so alone, by the same rule the NLP-engine routes follow (#1309, #940):

* ``primal_infeasible`` becomes ``INFEASIBLE`` only when the exact Rust simplex
  (:func:`lp_pounce._simplex_feasibility_verdict`) proves the linear system
  empty; otherwise ``ERROR``.
* ``dual_infeasible`` becomes ``UNBOUNDED`` only when an improving recession ray
  is verified exactly (:func:`lp_pounce._certify_unbounded_ray`) **and** the
  simplex exhibits a feasible point; otherwise ``ERROR``.

Both checks only *withhold* a verdict; neither can produce an answer the IPM did
not, so the route never silently becomes a simplex solve.

Bounds
------
A declared bound at or beyond :func:`lp_pounce.finite_bound_threshold` is handed
to the engine as infinite, exactly as on the other POUNCE routes. That includes
the ``±9.999e19`` box a column declared without bounds receives, which, kept
finite, costs the IPM several times the iterations. The caller passes
``relaxes_huge_bounds=True`` to the matrix route so an ``UNBOUNDED`` verdict over
such a relaxed box is not certified (#850).

Objective scale
---------------
The engine's stopping test is not invariant to the scale of the objective: the
same 2080-column production LP that stops at a primal residual of 5.5e-9 with its
costs in dollars stops at 4.9e-6 with the costs in cents (x100) -- 3.5x over the
per-row test ``_matrix_solution_feasible`` applies -- and the solve came back
``error`` (#1537). A QP ``1e8*x + x**2/2`` on ``[0, 10]`` ended in
``numerical_failure``. :func:`_solve` therefore hands the engine
``sigma*P, sigma*c`` with ``sigma`` the power of two that brings the largest
objective coefficient to at most 1 (:func:`objective_scale`), and maps the
answer back: ``x`` is unchanged, objective and every dual divide by ``sigma``.
A power of two makes both directions exact, and ``sigma = 1`` (no change at all)
for every objective whose coefficients are already at most 1.

The engine's ``tol`` is an **absolute** bound on its KKT residual (POUNCE
``QpOptions::tol``, default ``1e-8``; a scale-relative arm opens only below the
finite-precision floor). Dual infeasibility and complementarity are linear in
the objective, so a solve of ``sigma*objective`` stopped at ``tol`` is stopped at
``tol/sigma`` in the caller's units -- 8192x looser on ``3200*j**2``, where the
mapped-back complementarity of 6.6e-6 failed the #1384 stationarity guard and
the solve came back ``error``. ``tol*sigma`` (:func:`engine_tol`) is the engine
tolerance that holds the caller's ``tol`` in the caller's units -- down to a
floor of ``16*eps`` (:data:`_ENGINE_TOL_FLOOR`), below which the scaled problem
(coefficients at most 1) cannot resolve its residual and the engine runs to
``iteration_limit``.

Handing it ``tol*sigma`` unconditionally cost iterations for nothing on LPs whose
complementarity bottoms out at roundoff (#1658). The engine measures
complementarity on the recomputed slack, so it cannot fall below about
``eps * |row activity| * |dual|``; on a 10-flow blending LP with a contract row
tight at every feasible point (no strict interior, ``sigma = 2**-7``) that floor
is ~5e-9 in engine units, ``tol*sigma`` asked for 7.8e-11, and the engine ran 59
iterations to its stall exit where 16 reached the same point (caller-unit
complementarity 6.6e-7 vs 6.0e-7). The primal residual, which the issue
suspected, was 1-2e-11 and passed. So :func:`_solve` runs the engine at the
caller's ``tol`` first and re-runs it at ``tol*sigma``, warm-started from that
point, only when the mapped-back residual fails :func:`caller_unit_converged`:
primal absolute, dual infeasibility and complementarity against ``tol`` times
the stationarity scale ``max(1, |c|, |Px|, |y|, |z|)`` (Ipopt's ``s_d``, the
yardstick the #1384 guard applies). The ``3200*j**2`` class above fails that test
and takes the re-run; the blending LP passes it and does not. The floor only
ever loosens the request; the #1384 stationarity guard downstream still judges
every point the engine returns.

Column scale
------------
qp-ipm's iteration count depended on the units of the variables (#1683). The
linear-MPC QP ``x[k+1] = 0.95 x[k] + (0.1/UA) u[k]``, ``u in [-2UA, 2UA]``,
objective ``sum x**2 + 0.01 sum u**2 / UA**2`` is the same problem for every
``UA``, yet at N = 200 it took 13 iterations at ``UA = 1`` and 115 at
``UA = 6e4`` (94 vs 14 at N = 1200); ``pounce.qp.solve_qp`` has no scaling
argument. For a QP, :func:`_solve` therefore hands the engine the substitution
``x = d * xt``: ``D P D``, ``d * c``, ``A D``, ``G D``, ``lb / d``, ``ub / d``,
with ``d`` from :func:`column_scale` (power-of-two Ruiz on the columns of
``[P; A; G]``), and maps back ``x = d * xt``, ``z_lb = zt_lb / d``,
``z_ub = zt_ub / d``; ``y``, ``z`` and the objective are unchanged. Every ``d_j``
is a power of two, so both directions are exact. A warm start is mapped forward
the same way. Measured after: 13 iterations at every ``UA`` in
``{1, 1e3, 6e4, 1e6}`` and at both N.

The scale is **one-sided** (``d >= 1``): only columns whose entries are small
(a variable in large units) are scaled up. The engine's dual residual maps back
as ``r_j / (sigma * d_j)``, so ``d_j >= 1`` never amplifies it and ``tol*sigma``
still holds the caller's ``tol`` in caller units. A two-sided scale was measured
and rejected: on QPLIB_8938 a ``d_j = 2**-11`` column sent the caller-unit dual
residual to 5.0e-8 (3.9e-12 unscaled), and the re-solve that would restore it
must ask the engine for ``tol*sigma*min(d)`` = 4.9e-12 -- below the 1.1e-11
row-residual floor, which the engine's single ``tol`` also has to meet -- and ran
18 -> 219 iterations to the limit.

Because the engine's residuals are then in scaled coordinates, they are not
used: :func:`caller_residuals` recomputes POUNCE's own residual definitions on
the caller's data at the point the route returns, and :func:`caller_unit_converged`,
the solve report and the downstream #1384 / #1596 guards (which recompute from
``x`` and the multipliers on the caller's matrices anyway) all judge that. A QP
whose columns are already unit-scaled gets ``d = None`` and is handed over
unchanged. ``DISCOPT_POUNCE_QP_COLSCALE=0`` (:data:`COLSCALE_ENV`) restores the
unscaled hand-off; it is an opt-out for A/B, not a pending graduation.

Graduation panel (CLAUDE.md §5, flag OFF vs ON, interleaved, every incumbent
re-checked with ``check_feasibility`` at 1e-6). Plain convex QPLIB, 9 instances
that route to qp-ipm: bit-identical in both arms (their columns are already
balanced, ``d = None``). The same QPLIB instances with variables re-expressed in
random units (``x' = 10**U(lo, hi) * x``, 16 pairs that reach qp-ipm): total
IPM iterations 1141 -> 751, 10 better / 2 same / 4 worse; QPLIB_8785 went from
time_limit to certified optimal, and on QPLIB_8495 the OFF arm stopped at a
feasible point of objective 210935 while the ON arm reached the true 42857.
No instance lost certification, every certified bound stayed at or below its
incumbent, and objectives that both arms returned agree to <= 1.5e-8 relative.
"""

from __future__ import annotations

import math
import time
from collections.abc import Mapping
from types import SimpleNamespace
from typing import Any, List, Optional, Tuple, Union

import numpy as np
import scipy.sparse as sp

from discopt._relax.convexity import eigenvalue as _eig
from discopt._relax.convexity.eigenvalue import exact_psd as _exact_psd  # noqa: F401 (re-export)
from discopt._relax.convexity.eigenvalue import psd_certified
from discopt.solvers import LPResult, QPResult, SolveStatus
from discopt.solvers.lp_pounce import (
    _INF,
    PHASE1_FEASIBLE,
    PHASE1_INFEASIBLE,
    POUNCE_AVAILABLE,
    _certify_unbounded_ray,
    _simplex_feasibility_verdict,
    _stack_constraints,
    finite_bound_threshold,
)

#: Options the convex engine understands. Anything else is refused by
#: :func:`convex_engine_options` rather than dropped: the NLP engine's options
#: (``mu_strategy``, ``linear_solver``, ...) name machinery this algorithm does
#: not have, and silently ignoring one would leave the caller believing it was
#: set (the M6 rule ``Model.solve`` applies to unknown keyword names).
CONVEX_OPTION_KEYS: frozenset[str] = frozenset(
    {"tol", "max_iter", "max_wall_time", "print_level", "tau", "tau_max"}
)

#: The convex engine's own ``qp_*`` options, under their CLI names, which
#: ``pounce.qp.solve_qp`` takes as keyword arguments from pounce-solver 0.13
#: (gh#990, asked for by #1615) and discopt forwards unchanged (#1985).
#: ``qp_presolve``/``qp_crossover`` cannot be combined with a warm start (POUNCE's
#: warm path solves the unreduced problem and runs no crossover).
QP_ENGINE_OPTION_KEYS: frozenset[str] = frozenset(
    {"qp_presolve", "qp_reg", "qp_hsde", "qp_equilibrate", "qp_crossover"}
)


def _engine_takes(key: str) -> bool:
    """Whether the installed ``pounce.qp.solve_qp`` takes ``key`` as an argument."""
    import inspect

    from pounce.qp import solve_qp as _pounce_solve_qp

    return key in inspect.signature(_pounce_solve_qp).parameters


def _engine_switch_on(value: Any) -> bool:
    """A ``qp_*`` switch value that turns the feature on (``True`` / ``"yes"``)."""
    if isinstance(value, str):
        return value.strip().lower() == "yes"
    return bool(value) if value is not None else False


class IndefiniteQPError(ValueError):
    """The QP's Hessian was not PROVED positive semidefinite.

    Raised by :func:`solve_qp` when :func:`certify_psd` cannot prove ``Q`` PSD, and
    when POUNCE's own PSD check refuses it. The ``solver="pounce"`` route catches it
    and solves the QP with the NLP engine instead, reporting a local result.
    """


#: The thresholds of :func:`certify_psd`, which since #1679 live with the shared
#: predicate :func:`~discopt._relax.convexity.eigenvalue.psd_certified` (see the
#: constants there for the measurements behind them). Aliased, not copied.
_EXACT_PSD_MAX_N = _eig.PSD_CERT_EXACT_MAX_N
_EXACT_PSD_SPARSE_ROW_NNZ = _eig.PSD_CERT_SPARSE_ROW_NNZ
_EXACT_PSD_UPDATE_BUDGET = _eig.PSD_PROVED_EXACT_BUDGET
_EIG_PSD_MAX_N = _eig.PSD_CERT_EIG_MAX_N


def certify_psd(Q: np.ndarray) -> bool:
    """True only when ``Q`` (symmetrized) is PROVED positive semidefinite (#1533 review).

    POUNCE's own check accepts ``lam_min >= -1e-8 * max|Q_ij|``, which admits an
    indefinite Hessian whose negative curvature is small against its largest entry
    but not against the box (``-1e-9 x**2 + y**2`` on ``x in [-1e4, 1e4]``): the
    convex IPM then stops at a saddle and the route would certify it ``optimal``.
    So convexity is decided here, before the QP arm can label anything optimal.

    #1679: this is :func:`discopt._relax.convexity.eigenvalue.psd_certified`, the
    same predicate the exact QP objective certificate behind ``Model.convexity()``
    and the default solver's convex fast path use, so the two can no longer
    disagree on a Hessian (they did: ``m.convexity()`` accepted the float Gram
    matrix of a rank-deficient least-squares model -- indefinite in exact
    arithmetic -- that this proof refused). See that function for the procedure.
    """
    return psd_certified(Q)


#: The iterate blocks ``pounce.qp.solve_qp(warm_start=...)`` reads: the primal
#: point, the equality (``y``) and inequality (``z``) multipliers, and the lower /
#: upper bound multipliers.
_WARM_START_KEYS = ("x", "y", "z", "z_lb", "z_ub")


def _warm_start_arrays(warm_start: Any, n: int, n_eq: int, n_ub: int) -> dict:
    """``warm_start`` (a primal array, or a mapping over :data:`_WARM_START_KEYS`)
    as validated float arrays in the caller's units (#1615 B-01b, #1679).

    POUNCE silently ignores a start whose dimensions do not match, so a mismatch is
    refused here instead -- including a multiplier block, which would otherwise be
    dropped while the call appears to have used it.
    """
    if isinstance(warm_start, Mapping):
        unknown = sorted(set(warm_start) - set(_WARM_START_KEYS))
        if unknown:
            raise ValueError(f"warm_start has keys {unknown}; it accepts {list(_WARM_START_KEYS)}")
        if warm_start.get("x") is None:
            raise ValueError("a warm_start mapping needs the primal point 'x'")
        items = {k: v for k, v in warm_start.items() if v is not None}
    else:
        items = {"x": warm_start}
    sizes = {"x": n, "y": n_eq, "z": n_ub, "z_lb": n, "z_ub": n}
    out = {}
    for k, v in items.items():
        arr = np.asarray(v, dtype=np.float64).ravel()
        if arr.shape != (sizes[k],):
            raise ValueError(f"warm_start[{k!r}] has {arr.size} entries; this QP needs {sizes[k]}")
        if not np.all(np.isfinite(arr)):
            raise ValueError(f"warm_start[{k!r}] has non-finite entries")
        out[k] = arr
    return out


def convex_engine_options(options: Optional[dict]) -> dict:
    """Validate ``options`` for the convex engine and return a copy.

    Raises:
        ValueError: on a key outside :data:`CONVEX_OPTION_KEYS`.
    """
    opts = dict(options or {})
    # #1985: the engine's own ``qp_*`` knobs are forwarded when the installed POUNCE
    # takes them (pounce-solver >= 0.13); on an older one they stay refused below.
    forwarded = {k for k in opts if k in QP_ENGINE_OPTION_KEYS and _engine_takes(k)}
    unknown = sorted(k for k in opts if k not in CONVEX_OPTION_KEYS and k not in forwarded)
    # #1615 A-17/A-24: before pounce-solver 0.13, the convex engine's own knobs
    # (``qp_crossover``, ``qp_presolve``, ``qp_hsde``, ...) were POUNCE options file
    # / CLI options that ``pounce.qp.solve_qp`` exposed no argument for. Say where
    # they do work rather than lump them in with NLP options.
    # #1679: some ``qp_*`` CLI options *are* reachable -- ``pounce.qp.solve_qp`` takes
    # ``qp_tau`` / ``qp_tau_max`` as ``tau`` / ``tau_max``, and discopt forwards
    # those. Name the spelling that works instead of claiming there is none.
    renamed = {k: k[3:] for k in unknown if k.startswith("qp_") and k[3:] in CONVEX_OPTION_KEYS}
    if renamed:
        spelled = ", ".join(f"{k!r} -> {v!r}" for k, v in sorted(renamed.items()))
        raise ValueError(
            f"pounce_options {sorted(renamed)} are the POUNCE command-line spellings of "
            f"options that pounce.qp.solve_qp, which solver='pounce' calls for this "
            f"model, takes under another name. Pass them as: {spelled}. Refused rather "
            f"than silently renamed. That engine accepts {sorted(CONVEX_OPTION_KEYS)}."
        )
    too_old = [k for k in unknown if k in QP_ENGINE_OPTION_KEYS]
    if too_old:
        import pounce

        raise ValueError(
            f"pounce_options {too_old} are options of POUNCE's convex QP engine that "
            f"pounce.qp.solve_qp, which solver='pounce' calls for this model, takes "
            f"only from pounce-solver 0.13; the installed pounce-solver "
            f"{getattr(pounce, '__version__', '?')} does not, so the setting cannot be "
            f"applied. Refused rather than ignored. Upgrade pounce-solver, or export "
            f"the model and run the CLI: m.to_nl('model.nl'), then "
            f"`pounce model.nl {too_old[0]}=...`."
        )
    cli_only = [k for k in unknown if k.startswith("qp_")]
    if cli_only:
        raise ValueError(
            f"pounce_options {cli_only} are not options pounce.qp.solve_qp, which "
            f"solver='pounce' calls for this model, takes, so the setting cannot be "
            f"applied from discopt. Refused rather than ignored. If it is an option of "
            f"POUNCE's command line, export the model and run the CLI: "
            f"m.to_nl('model.nl'), then `pounce model.nl {cli_only[0]}=...`. From "
            f"discopt that engine accepts "
            f"{sorted(CONVEX_OPTION_KEYS | QP_ENGINE_OPTION_KEYS)}."
        )
    if unknown:
        raise ValueError(
            f"pounce_options {unknown} are not options of POUNCE's convex LP/QP "
            f"interior-point method (lp-ipm / qp-ipm), which this model was routed "
            f"to. That engine accepts {sorted(CONVEX_OPTION_KEYS | QP_ENGINE_OPTION_KEYS)}. "
            f"Options such as "
            f"mu_strategy or linear_solver belong to the NLP engine, which "
            f"solver='pounce' uses for nonlinear and nonconvex models. Refused rather "
            f"than ignored, so a setting never appears to apply when it does not."
        )
    return opts


def _engine_box(
    bounds: Optional[List[Tuple[float, float]]], n: int, default_lb: float
) -> Tuple[np.ndarray, np.ndarray]:
    """Box with every ``|b| >= finite_bound_threshold()`` mapped to ``±inf``."""
    if bounds is not None:
        if len(bounds) != n:
            raise ValueError(f"bounds has {len(bounds)} entries but c has {n} elements")
        lb = np.array([b[0] for b in bounds], dtype=np.float64)
        ub = np.array([b[1] for b in bounds], dtype=np.float64)
    else:
        lb = np.full(n, default_lb, dtype=np.float64)
        ub = np.full(n, np.inf, dtype=np.float64)
    thr = finite_bound_threshold()
    lb = np.where(lb <= -thr, -np.inf, lb)
    ub = np.where(ub >= thr, np.inf, ub)
    return lb, ub


def _sentinel(v: np.ndarray) -> np.ndarray:
    """``±inf`` -> the ``±1e20`` sentinel the discopt LP helpers expect."""
    return np.asarray(np.clip(v, -_INF, _INF), dtype=np.float64)


def _print_trace(selector: str, res: Any) -> None:
    """The per-iteration convergence trace, in the spirit of Ipopt's log."""
    print(f"POUNCE {selector} (convex interior-point method)")
    print(
        f"{'iter':>4}  {'objective':>14}  {'inf_pr':>9}  {'inf_du':>9}  "
        f"{'mu':>9}  {'alpha_pr':>8}  {'alpha_du':>8}"
    )
    for it in res.iterates:
        print(
            f"{int(it['iter']):>4}  {float(it['objective']):>14.7e}  "
            f"{float(it['primal_infeasibility']):>9.2e}  "
            f"{float(it['dual_infeasibility']):>9.2e}  {float(it['mu']):>9.2e}  "
            f"{float(it['alpha_primal']):>8.2e}  {float(it['alpha_dual']):>8.2e}"
        )
    print(f"status: {res.status}   iterations: {int(res.iters)}   objective: {res.obj!r}")


def objective_scale(P, c: np.ndarray) -> float:
    """The power of two ``sigma <= 1`` that brings ``max(|P|, |c|)`` to at most 1.

    ``1.0`` when every objective coefficient is already at most 1 in magnitude,
    or the objective is zero. See the module docstring ("Objective scale").
    """
    mags = [float(np.max(np.abs(c))) if c.size else 0.0]
    if P is not None:
        data = P.data if sp.issparse(P) else np.asarray(P)
        if np.size(data):
            mags.append(float(np.max(np.abs(data))))
    m = max(mags)
    if not math.isfinite(m) or m <= 1.0:
        return 1.0
    return math.ldexp(1.0, -math.ceil(math.log2(m)))


#: POUNCE ``QpOptions::default().tol`` (``pounce-convex/src/ipm.rs``), which the
#: Python surface does not expose. ``test_engine_default_tol_is_mirrored`` pins it:
#: ``tol=None`` and ``tol=_ENGINE_DEFAULT_TOL`` must give the identical solve.
_ENGINE_DEFAULT_TOL = 1e-8


#: The smallest engine ``tol`` :func:`engine_tol` asks for. Measured 2026-10-04 on
#: ten solves (``test_1537_pounce_objective_scale.py``: the production LP with
#: costs x1e-2..x1e8, ``1e8*x + x**2/2`` bounded and free, ``k/2*j**2`` with
#: ``k`` = 6400, 1e6, 1e8): ``1*eps`` sends the x1e6 and x1e8 LPs to
#: ``iteration_limit``; ``4*eps`` to ``20*eps`` pass all ten; ``64*eps`` loses
#: ``k = 1e8`` to the stationarity guard. ``16*eps`` sits ~4x inside both edges.
_ENGINE_TOL_FLOOR = 16.0 * float(np.finfo(np.float64).eps)


def engine_tol(tol: Optional[float], sigma: float) -> Optional[float]:
    """The engine tolerance that keeps ``tol`` in the caller's units under ``sigma``.

    ``None`` (the engine default) passes through when ``sigma == 1``, so an
    unscaled solve is bit-for-bit what it was. See the module docstring.
    """
    if sigma == 1.0:
        return tol
    want = (_ENGINE_DEFAULT_TOL if tol is None else float(tol)) * sigma
    return max(want, _ENGINE_TOL_FLOOR)


def _stationarity_scale_caller(res: Any, P, c: np.ndarray) -> float:
    """The yardstick a mapped-back KKT residual is measured against (#1658).

    ``max(1, |c|, |P x|, |y|, |z|)`` in the caller's units: the magnitude of the
    largest term entering the stationarity residual ``P x + c + A'y - z``, which
    is Ipopt's ``s_d`` (Wachter & Biegler 2006, eq. 5) and the yardstick the
    #1384 guard downstream (``solver._qp_stationarity_scale``) applies. The
    ``max(1, ...)`` floor makes an O(1) instance an absolute test.
    """
    mags = [1.0]
    if c is not None and np.size(c):
        mags.append(float(np.max(np.abs(c))))
    x = getattr(res, "x", None)
    if P is not None and x is not None and np.size(x):
        Px = P @ np.asarray(x, dtype=np.float64)
        if np.size(Px):
            mags.append(float(np.max(np.abs(Px))))
    for key in ("y", "z", "z_lb", "z_ub"):
        v = getattr(res, key, None)
        if v is not None and np.size(v):
            mags.append(float(np.max(np.abs(v))))
    m = max(mags)
    return m if math.isfinite(m) else 1.0


def caller_unit_converged(res: Any, P, c: np.ndarray, tol: float) -> bool:
    """Whether the caller-unit result ``res`` meets ``tol`` (#1658).

    The primal residual is tested absolutely (``sigma`` does not touch it); dual
    infeasibility and complementarity, which carry the objective's units, against
    ``tol`` times :func:`_stationarity_scale_caller`. A result with no residual
    breakdown is not judged converged here, so it gets the ``tol*sigma`` re-solve.
    """
    resid = getattr(res, "residuals", None) or {}
    pr = resid.get("primal_infeasibility")
    du = resid.get("dual_infeasibility")
    co = resid.get("complementarity")
    if pr is None or du is None or co is None:
        return False
    yard = tol * _stationarity_scale_caller(res, P, c)
    return float(pr) <= tol and float(du) <= yard and float(co) <= yard


#: Opt-out for the power-of-two column equilibration of the qp-ipm hand-off
#: (#1683). See the module docstring ("Column scale"); ``=0`` restores the
#: unscaled hand-off bit for bit.
COLSCALE_ENV = "DISCOPT_POUNCE_QP_COLSCALE"

#: Ruiz passes :func:`column_scale` makes at most. Each pass halves every column's
#: log2 distance from unit norm, so ten passes reach the rounding fixed point from
#: any column norm within ``2**±1000``; on every QP measured (#1683) it stops on
#: "no exponent changed" in 2-7 passes.
_COLSCALE_ROUNDS = 10

#: ``|log2 d_j|`` is clamped here so ``lb/d``, ``ub/d`` and ``x*d`` can neither
#: overflow nor fall into the subnormal range for any finite bound the route hands
#: the engine (``|b| < finite_bound_threshold() = 1e15``, about ``2**50``).
_COLSCALE_MAX_EXP = 60


def colscale_enabled() -> bool:
    """Whether the qp-ipm hand-off is column-equilibrated (``DISCOPT_POUNCE_QP_COLSCALE``)."""
    from discopt.solver_tuning import _env_flag

    return _env_flag(COLSCALE_ENV, default=True)


def _col_absmax(M, n: int) -> np.ndarray:
    """``max_i |M_ij|`` per column (``0`` for an empty column)."""
    if M is None:
        return np.zeros(n)
    if sp.issparse(M):
        if M.nnz == 0:
            return np.zeros(n)
        out = abs(sp.csc_matrix(M)).max(axis=0).toarray()
    else:
        arr = np.asarray(M, dtype=np.float64)
        if arr.size == 0:
            return np.zeros(n)
        out = np.max(np.abs(arr), axis=0)
    return np.asarray(out, dtype=np.float64).ravel()


def _scale_cols(M, d: np.ndarray):
    """``M @ diag(d)``, exact because every ``d_j`` is a power of two."""
    if M is None:
        return None
    if sp.issparse(M):
        return sp.csr_matrix(M) @ sp.diags(d)
    return np.asarray(M, dtype=np.float64) * d[None, :]


def _scale_sym(P, d: np.ndarray):
    """``diag(d) @ P @ diag(d)``, exact because every ``d_j`` is a power of two."""
    if P is None:
        return None
    if sp.issparse(P):
        Dg = sp.diags(d)
        return sp.csr_matrix(Dg @ sp.csr_matrix(P) @ Dg)
    return np.asarray(P, dtype=np.float64) * d[:, None] * d[None, :]


def column_scale(P, A, G, n: int) -> Optional[np.ndarray]:
    """Power-of-two Ruiz column equilibration of ``[P; A; G]`` (#1683).

    Returns ``d`` (every entry an exact power of two) such that the columns of
    ``D P D``, ``A D`` and ``G D`` have infinity norm in ``[2**-0.5, 2**0.5)`` up
    to the coupling ``P`` introduces, or ``None`` when no column moves (``d = 1``),
    so a QP that is already unit-scaled is handed over unchanged. A column with no
    entry in any of the three matrices keeps ``d_j = 1``.
    """
    e = np.zeros(n, dtype=np.int64)
    a_nrm = [_col_absmax(A, n), _col_absmax(G, n)]
    for _ in range(_COLSCALE_ROUNDS):
        d = np.ldexp(1.0, e)
        nrm = np.maximum(a_nrm[0], a_nrm[1]) * d
        if P is not None:
            nrm = np.maximum(nrm, _col_absmax(_scale_sym(P, d), n))
        live = (nrm > 0) & np.isfinite(nrm)
        step = np.zeros(n, dtype=np.int64)
        # round(-log2(nrm)/2): the exponent that brings the column norm to ~1.
        step[live] = np.rint(-0.5 * np.log2(nrm[live])).astype(np.int64)
        # One-sided (``d >= 1``): see the docstring.
        new = np.clip(e + step, 0, _COLSCALE_MAX_EXP)
        if np.array_equal(new, e):
            break
        e = new
    if not np.any(e):
        return None
    return np.ldexp(1.0, e)


def caller_residuals(
    x: np.ndarray,
    y,
    z,
    z_lb,
    z_ub,
    P,
    c: np.ndarray,
    A,
    b,
    G,
    h,
    lb: np.ndarray,
    ub: np.ndarray,
) -> dict:
    """POUNCE's ``QpResiduals`` recomputed on the caller's (unscaled) data (#1683).

    Same definitions as ``pounce-convex``'s ``kkt_residuals``: primal
    ``max(|Ax-b|, max(0, Gx-h), bound violation)``, dual
    ``||Px + c + A'y + G'z - z_lb + z_ub||_inf`` and complementarity
    ``max |z_i * slack_i|`` over inequality rows and finite bounds. A
    column-equilibrated engine reports these in its own coordinates, where an
    infinity norm of a per-column-scaled residual has no exact inverse; the
    caller-unit test (:func:`caller_unit_converged`) and the solve report need
    them in the caller's.
    """
    x = np.asarray(x, dtype=np.float64)
    n = x.size
    zero = np.zeros(0)
    pr = [0.0]
    grad = np.array(c, dtype=np.float64)
    if P is not None:
        grad = grad + np.asarray(P @ x, dtype=np.float64).ravel()
    comp = [0.0]
    if A is not None and b is not None and np.size(b):
        pr.append(float(np.max(np.abs(np.asarray(A @ x).ravel() - b))))
        if y is not None:
            grad = grad + np.asarray(A.T @ np.asarray(y, dtype=np.float64)).ravel()
    if G is not None and h is not None and np.size(h):
        slack = h - np.asarray(G @ x).ravel()
        pr.append(float(np.max(np.maximum(-slack, 0.0))))
        if z is not None:
            zz = np.asarray(z, dtype=np.float64).ravel()
            grad = grad + np.asarray(G.T @ zz).ravel()
            comp.append(float(np.max(np.abs(zz * slack))))
    flb, fub = np.isfinite(lb), np.isfinite(ub)
    bound_viol = max(
        float(np.max(np.where(flb, lb - x, 0.0), initial=0.0)),
        float(np.max(np.where(fub, x - ub, 0.0), initial=0.0)),
    )
    pr.append(bound_viol)
    zl = zero if z_lb is None else np.asarray(z_lb, dtype=np.float64).ravel()
    zu = zero if z_ub is None else np.asarray(z_ub, dtype=np.float64).ravel()
    if zl.size == n:
        grad = grad - zl
        comp.append(float(np.max(np.abs(np.where(flb, zl * (x - np.where(flb, lb, 0.0)), 0.0)))))
    if zu.size == n:
        grad = grad + zu
        comp.append(float(np.max(np.abs(np.where(fub, zu * (np.where(fub, ub, 0.0) - x), 0.0)))))
    du = float(np.max(np.abs(grad))) if grad.size else 0.0
    out = {
        "primal_infeasibility": max(pr),
        "bound_violation": bound_viol,
        "dual_infeasibility": du,
        "complementarity": max(comp),
    }
    out["kkt_error"] = max(out["primal_infeasibility"], du, out["complementarity"])
    return out


def _unscale_columns(res: Any, d: np.ndarray, caller: dict) -> Any:
    """``res`` (already in the caller's objective units) mapped back through ``x = d*xt``.

    ``x`` multiplies by ``d`` and the bound multipliers divide by it; the row
    multipliers ``y``, ``z`` and the objective do not change. All exact (``d`` is
    a power of two). The residuals are recomputed on the caller's data
    (:func:`caller_residuals`) at the point the route returns -- ``x`` projected
    onto the caller's box, as :func:`_onto_box` does -- rather than taken from
    the engine, whose dual residual is measured in the scaled coordinates. The
    trace's per-iteration ``dual_infeasibility`` stays in engine coordinates (its
    infinity norm has no exact inverse); the objective it records is invariant.
    """
    x = np.asarray(res.x, dtype=np.float64) * d
    z_lb = None if res.z_lb is None else np.asarray(res.z_lb, dtype=np.float64) / d
    z_ub = None if res.z_ub is None else np.asarray(res.z_ub, dtype=np.float64) / d
    resid = caller_residuals(
        _onto_box(x, caller["lb"], caller["ub"]),
        res.y,
        res.z,
        z_lb,
        z_ub,
        caller["P"],
        caller["c"],
        caller["A"],
        caller["b"],
        caller["G"],
        caller["h"],
        caller["lb"],
        caller["ub"],
    )
    out = SimpleNamespace(**{k: getattr(res, k) for k in _RESULT_FIELDS if hasattr(res, k)})
    out.x = x
    out.z_lb = z_lb
    out.z_ub = z_ub
    out.residuals = resid
    out.kkt_error = resid["kkt_error"]
    out.column_scale = d
    return out


#: The ``QpResult`` fields the route reads; :func:`_unscale_columns` copies these.
_RESULT_FIELDS = (
    "status",
    "success",
    "iters",
    "x",
    "obj",
    "y",
    "z",
    "z_lb",
    "z_ub",
    "kkt_error",
    "residuals",
    "iterates",
    "scaling_warning",
    "objective_scale",
)


def _merge_attempts(first: Any, second: Any) -> Any:
    """``second`` as the answer, carrying the work of both engine runs (#1658).

    ``iters`` is the total the caller paid for; ``iterates`` concatenates the two
    traces so a printed trace or a solve report shows the re-solve rather than
    hiding it.
    """
    out = SimpleNamespace(**vars(second))
    out.iters = int(first.iters or 0) + int(second.iters or 0)
    out.iterates = list(first.iterates or []) + list(second.iterates or [])
    out.retried_at_scaled_tol = True
    return out


def _unscale_result(res: Any, sigma: float) -> Any:
    """``res`` of the engine solve of ``sigma * objective``, in the caller's units.

    ``x`` and the primal residual do not depend on the objective; the objective,
    every multiplier, the dual residual and complementarity (``z * slack``) are
    linear in it. ``kkt_error`` is the max of the three residuals, so it is
    recomputed from the rescaled parts rather than divided as a whole.
    """
    if sigma == 1.0:
        return res
    inv = 1.0 / sigma  # exact: sigma is a power of two
    resid = dict(res.residuals or {})
    for key in ("dual_infeasibility", "complementarity"):
        if resid.get(key) is not None:
            resid[key] = float(resid[key]) * inv
    parts = [
        float(v)
        for k in ("primal_infeasibility", "dual_infeasibility", "complementarity")
        if (v := resid.get(k)) is not None
    ]
    if parts:
        kkt = max(parts)
    elif res.kkt_error is not None:
        kkt = float(res.kkt_error) * max(1.0, inv)  # no breakdown: the safe upper bound
    else:
        kkt = None
    if "kkt_error" in resid:
        resid["kkt_error"] = kkt

    def mult(v):
        return None if v is None else np.asarray(v, dtype=np.float64) * inv

    iterates = [
        {
            **it,
            **{
                k: float(it[k]) * inv
                for k in ("objective", "dual_infeasibility")
                if it.get(k) is not None
            },
        }
        for it in (res.iterates or [])
    ]
    return SimpleNamespace(
        status=res.status,
        success=getattr(res, "success", None),
        iters=res.iters,
        x=res.x,
        obj=None if res.obj is None else float(res.obj) * inv,
        y=mult(res.y),
        z=mult(res.z),
        z_lb=mult(res.z_lb),
        z_ub=mult(res.z_ub),
        kkt_error=kkt,
        residuals=resid,
        iterates=iterates,
        scaling_warning=getattr(res, "scaling_warning", None),
        objective_scale=sigma,
    )


def _solve(
    P: Optional[np.ndarray],
    c: np.ndarray,
    A_ub,
    b_ub,
    A_eq,
    b_eq,
    lb: np.ndarray,
    ub: np.ndarray,
    time_limit: Optional[float],
    options: Optional[dict],
    solve_report: bool = False,
    start: Optional[dict] = None,
) -> Tuple[
    str,
    Any,
    float,
    Optional[np.ndarray],
    Optional[np.ndarray],
    Optional[np.ndarray],
    Optional[dict],
]:
    """Run :func:`pounce.qp.solve_qp` once; map nothing yet.

    Returns ``(raw_status, result, wall, A, cl, cu, report)`` where ``A, cl, cu``
    is the stacked row system the certificate checks need (``None`` on an
    ``optimal`` status, which never reaches those checks -- #1619) and ``report`` is the
    ``pounce.solve-report/v1`` document when ``solve_report`` is set (#1534),
    else ``None``.
    """
    from pounce.qp import solve_qp as _pounce_solve_qp

    opts = convex_engine_options(options)
    n = len(c)
    print_level = int(opts.pop("print_level", 0) or 0)
    max_wall = opts.pop("max_wall_time", None)
    budgets = [float(t) for t in (time_limit, max_wall) if t is not None]
    limit = min(budgets) if budgets else None

    G = None if A_ub is None else (A_ub if sp.issparse(A_ub) else np.asarray(A_ub, float))
    A = None if A_eq is None else (A_eq if sp.issparse(A_eq) else np.asarray(A_eq, float))
    h = None if b_ub is None else np.asarray(b_ub, dtype=np.float64).ravel()
    b = None if b_eq is None else np.asarray(b_eq, dtype=np.float64).ravel()

    # Module docstring, "Column scale" (#1683): QP only, ``d = None`` when no column
    # moves, so an already unit-scaled QP is handed over exactly as before.
    d = column_scale(P, A, G, n) if P is not None and colscale_enabled() else None
    caller = {"P": P, "c": c, "A": A, "b": b, "G": G, "h": h, "lb": lb, "ub": ub}
    P_s, c_s, A, G, lb_eng, ub_eng = P, c, A, G, lb, ub
    if d is not None:
        P_s, c_s = _scale_sym(P, d), c * d
        A, G = _scale_cols(A, d), _scale_cols(G, d)
        lb_eng, ub_eng = lb / d, ub / d

    sigma = objective_scale(P_s, c_s)  # module docstring, "Objective scale" (#1537)
    P_eng = P_s if P_s is None or sigma == 1.0 else P_s * sigma
    c_eng = c_s if sigma == 1.0 else c_s * sigma

    started_unix_nanos = time.time_ns()
    t0 = time.perf_counter()
    caller_tol = _ENGINE_DEFAULT_TOL if opts.get("tol") is None else float(opts["tol"])
    # #1985: the forwarded ``qp_*`` knobs, passed only when set, so a solve without
    # them is the call it was before.
    engine_kw = {k: opts[k] for k in sorted(QP_ENGINE_OPTION_KEYS) if k in opts}
    # POUNCE refuses presolve or crossover on its warm path; the ``tol*sigma``
    # re-solve below then starts cold so the requested setting still applies.
    no_warm = [k for k in ("qp_presolve", "qp_crossover") if _engine_switch_on(engine_kw.get(k))]
    if no_warm and start is not None:
        raise ValueError(
            f"pounce_options {no_warm} cannot be combined with a warm start: POUNCE's "
            f"warm-started path solves the unreduced problem and runs no crossover. "
            f"Drop the warm start or the option."
        )

    def _run(tol_eng, warm, budget):
        try:
            return _pounce_solve_qp(
                P=P_eng,
                c=c_eng,
                A=A,
                b=b,
                G=G,
                h=h,
                lb=lb_eng,
                ub=ub_eng,
                tol=tol_eng,
                max_iter=opts.get("max_iter"),
                time_limit=budget,
                collect_iterates=print_level > 0 or solve_report,
                method="ipm",
                tau=opts.get("tau"),
                tau_max=opts.get("tau_max"),
                # #1615 B-01b: a primal start seeds the IPM; it does not change the
                # solution (the objective scale touches only the duals, not ``x``).
                warm_start=warm,
                **engine_kw,
            )
        except ValueError as exc:
            # POUNCE's PSD guard: the convex engine refuses an indefinite P before
            # iterating. Re-raised as a distinct type so the route can tell it from
            # a malformed-input error, which must still propagate.
            if P is not None and "positive semidefinite" in str(exc):
                raise IndefiniteQPError(str(exc)) from exc
            raise

    # #1658: the caller's ``tol`` first (module docstring, "Objective scale"); the
    # ``tol*sigma`` re-solve, warm-started from that point, only when it fails the
    # caller-unit test.
    # ``start`` is in the caller's units; the engine solves ``sigma * objective``, so
    # its multipliers are ``sigma`` times the caller's (``x`` does not depend on it).
    # Under the column scale ``x = d*xt`` the engine's ``xt`` is ``x/d`` and its bound
    # multipliers are ``d`` times the caller's; the row multipliers do not move.
    warm0 = None
    if start is not None:
        warm0 = {}
        for k, v in start.items():
            arr = np.asarray(v, dtype=np.float64)
            if k == "x":
                warm0[k] = arr if d is None else arr / d
            elif k in ("z_lb", "z_ub") and d is not None:
                warm0[k] = arr * d * sigma
            else:
                warm0[k] = arr * sigma

    def _to_caller(engine_res):
        out = _unscale_result(engine_res, sigma)
        return out if d is None else _unscale_columns(out, d, caller)

    raw = _run(opts.get("tol"), warm0, limit)
    res = _to_caller(raw)
    # ``d >= 1``, so the column scale never amplifies the engine's dual residual on
    # its way back (``r_j / (sigma * d_j)``) and ``tol*sigma`` is still the engine
    # tolerance that holds ``tol`` in caller units (module docstring, "Column scale").
    if (
        sigma != 1.0
        and res.status == "optimal"
        and not caller_unit_converged(res, P, c, caller_tol)
    ):
        spent = time.perf_counter() - t0
        budget = None if limit is None else max(0.0, limit - spent)
        retry = _to_caller(
            _run(engine_tol(opts.get("tol"), sigma), None if no_warm else raw, budget)
        )
        # A re-solve that did not finish (its budget, an engine failure) leaves the
        # first ``optimal`` standing; the #1384 guard downstream still judges it.
        res = _merge_attempts(res, retry if retry.status == "optimal" else res)
    wall = time.perf_counter() - t0
    if print_level > 0:
        _print_trace("lp-ipm" if P is None else "qp-ipm", res)

    # The stacked DENSE row system is what the infeasible / unbounded certificate
    # checks in ``_verdict_status`` consume, and nothing else does. Build it only on
    # the status that reaches them (#1619): on an ``optimal`` solve it was an
    # (m, n) float64 copy of sparse input -- 64 MB on the 2000-row chain LP of
    # #1619 -- that was then thrown away.
    A_rows: Optional[np.ndarray] = None
    cl: Optional[np.ndarray] = None
    cu: Optional[np.ndarray] = None
    if res.status != "optimal":
        A_rows, cl, cu = _stack_constraints(A_ub, b_ub, A_eq, b_eq, n)
    n_rows = (0 if A_ub is None or b_ub is None else int(A_ub.shape[0])) + (
        0 if A_eq is None or b_eq is None else int(A_eq.shape[0])
    )
    report = None
    if solve_report:
        from discopt.solvers._pounce_report import convex_report

        report = convex_report(
            res,
            wall_time=wall,
            n_constraints=n_rows,
            started_unix_nanos=started_unix_nanos,
        )
    return res.status, res, wall, A_rows, cl, cu, report


def _verdict_status(
    raw: str,
    c: np.ndarray,
    A: np.ndarray,
    cl: np.ndarray,
    cu: np.ndarray,
    lb: np.ndarray,
    ub: np.ndarray,
    Q: Optional[np.ndarray],
) -> Tuple[SolveStatus, str]:
    """Map a non-optimal engine status, verifying any certificate it implies.

    Returns ``(status, reason)``; ``reason`` names the engine's own status and,
    when a verdict is withheld, the check that withheld it (#1618 A-09).
    """
    lbs, ubs = _sentinel(lb), _sentinel(ub)
    if raw == "primal_infeasible":
        if _simplex_feasibility_verdict(A, cl, cu, lbs, ubs) == PHASE1_INFEASIBLE:
            return SolveStatus.INFEASIBLE, ""
        return SolveStatus.ERROR, (
            "the engine reported 'primal_infeasible', but the exact simplex did not "
            "prove the constraint system empty, so 'infeasible' is not certified"
        )
    if raw == "dual_infeasible":
        from discopt.solvers import pounce_option_defaults

        ray = _certify_unbounded_ray(c, A, cl, cu, lbs, ubs, pounce_option_defaults(), Q=Q)
        if not ray:
            return SolveStatus.ERROR, (
                "the engine reported 'dual_infeasible' (objective unbounded), but no "
                "improving recession ray passed the exact-arithmetic check, so "
                "'unbounded' is not certified"
            )
        if _simplex_feasibility_verdict(A, cl, cu, lbs, ubs) == PHASE1_FEASIBLE:
            return SolveStatus.UNBOUNDED, ""
        return SolveStatus.ERROR, (
            "the engine reported 'dual_infeasible' and an improving recession ray was "
            "verified, but the exact simplex did not exhibit a feasible point, so "
            "'unbounded' is not certified"
        )
    if raw == "time_limit":
        return SolveStatus.TIME_LIMIT, ""
    if raw in ("iteration_limit", "optimal_inaccurate"):
        # Reached for ``optimal_inaccurate`` only from :func:`solve_lp`: the LP matrix
        # route publishes an ``optimal`` point's objective as its bound with no
        # certificate of its own, so a point the engine could not converge to ``tol``
        # is not handed to it. :func:`solve_qp` passes it on to its #1596 certificate.
        return SolveStatus.ITERATION_LIMIT, f"the engine reported {raw!r}"
    return SolveStatus.ERROR, f"the engine reported {raw!r}"


def _kkt_parts(res: Any, n_ub: int) -> Tuple[np.ndarray, np.ndarray]:
    """HiGHS-convention row duals and reduced costs from a POUNCE ``QpResult``.

    POUNCE's Lagrangian is ``½x'Px + c'x + y'(Ax-b) + z'(Gx-h) - z_lb'(x-lb) +
    z_ub'(x-ub)``; HiGHS reports ``∂obj/∂rhs``, which is ``-z`` for the ``G``
    (``A_ub``) rows and ``-y`` for the equality rows, stacked inequality rows
    first. Reduced costs are ``z_lb - z_ub`` (``c + P x - A'y_h``).
    """
    z = np.asarray(res.z, dtype=np.float64).ravel()[:n_ub]
    y = np.asarray(res.y, dtype=np.float64).ravel()
    dual = -np.concatenate([z, y])
    rc = np.asarray(res.z_lb, dtype=np.float64) - np.asarray(res.z_ub, dtype=np.float64)
    return dual, rc


def _onto_box(x, lb: np.ndarray, ub: np.ndarray) -> np.ndarray:
    """The engine's point projected onto its own simple bounds (#1537).

    The interior-point method's final iterate can sit a rounding error outside a
    bound it was handed: ``min 1e8*x + x**2/2`` over ``x >= 0`` returned
    ``x = -1.2e-16`` and published the objective ``-1.2e-8``, below the true
    optimum 0, at a point outside the declared box. The box is the one constraint
    that can be met exactly, so the point is clipped onto it (``lb``/``ub`` are the
    engine's: a bound it treated as infinite is not imposed). Nothing is trusted
    from the clip -- the route's feasibility guard and certificate run on the
    clipped point.
    """
    return np.asarray(np.clip(np.asarray(x, dtype=np.float64), lb, ub), dtype=np.float64)


def solve_lp(
    c: np.ndarray,
    A_ub: Optional[Union[np.ndarray, sp.spmatrix]] = None,
    b_ub: Optional[np.ndarray] = None,
    A_eq: Optional[Union[np.ndarray, sp.spmatrix]] = None,
    b_eq: Optional[np.ndarray] = None,
    bounds: Optional[List[Tuple[float, float]]] = None,
    warm_basis: Optional[object] = None,
    time_limit: Optional[float] = None,
    options: Optional[dict] = None,
    solve_report: bool = False,
) -> LPResult:
    """Solve ``min c'x`` s.t. ``A_ub x <= b_ub``, ``A_eq x = b_eq`` with POUNCE's lp-ipm.

    ``bounds`` default to ``(0, +inf)`` (the shared LP contract). ``warm_basis``
    is accepted for signature compatibility and ignored: an IPM has no basis.
    ``options`` must be a subset of :data:`CONVEX_OPTION_KEYS`.
    ``solve_report=True`` attaches the solve's ``pounce.solve-report/v1``
    document as ``LPResult.solve_report`` (#1534), built by
    :func:`discopt.solvers._pounce_report.convex_report`.
    """
    del warm_basis
    if not POUNCE_AVAILABLE:
        raise ImportError("pounce is required. Install it with:\n  pip install pounce-solver")
    c_arr = np.asarray(c, dtype=np.float64).ravel()
    n = len(c_arr)
    lb, ub = _engine_box(bounds, n, default_lb=0.0)
    raw, res, wall, A, cl, cu, report = _solve(
        None, c_arr, A_ub, b_ub, A_eq, b_eq, lb, ub, time_limit, options, solve_report
    )
    iters = int(res.iters)
    if raw != "optimal":
        assert A is not None and cl is not None and cu is not None
        status, why = _verdict_status(raw, c_arr, A, cl, cu, lb, ub, None)
        return LPResult(
            status=status,
            iterations=iters,
            wall_time=wall,
            ray_verified=True if status == SolveStatus.UNBOUNDED else None,
            solve_report=report,
            message=why,
        )
    n_ub = 0 if A_ub is None else int(A_ub.shape[0])
    dual, rc = _kkt_parts(res, n_ub)
    x = _onto_box(res.x, lb, ub)
    return LPResult(
        status=SolveStatus.OPTIMAL,
        x=x,
        objective=float(c_arr @ x),
        dual_values=dual,
        reduced_costs=rc,
        rc_absum=np.abs(np.asarray(res.z_lb)) + np.abs(np.asarray(res.z_ub)),
        iterations=iters,
        wall_time=wall,
        solve_report=report,
    )


def solve_qp(
    Q: np.ndarray,
    c: np.ndarray,
    A_ub: Optional[Union[np.ndarray, sp.spmatrix]] = None,
    b_ub: Optional[np.ndarray] = None,
    A_eq: Optional[Union[np.ndarray, sp.spmatrix]] = None,
    b_eq: Optional[np.ndarray] = None,
    bounds: Optional[List[Tuple[float, float]]] = None,
    integrality: Optional[np.ndarray] = None,
    time_limit: Optional[float] = None,
    gap_tolerance: float = 1e-4,
    options: Optional[dict] = None,
    solve_report: bool = False,
    warm_start: Union[np.ndarray, Mapping, None] = None,
) -> QPResult:
    """Solve ``min ½x'Qx + c'x`` s.t. linear rows with POUNCE's qp-ipm.

    ``bounds`` default to free variables (the shared QP contract).
    ``solve_report=True`` attaches the solve's ``pounce.solve-report/v1``
    document as ``QPResult.solve_report`` (#1534). ``warm_start`` seeds the
    interior-point iteration and never changes the answer: a primal point of
    length ``n`` (#1615 B-01b), or a mapping with ``x`` and any of the
    multiplier blocks ``y`` (``A_eq`` rows), ``z`` (``A_ub`` rows), ``z_lb``,
    ``z_ub`` in the caller's objective units -- e.g. a previous result's
    :attr:`QPResult.warm_start_state` (#1679).

    Raises:
        IndefiniteQPError: ``Q`` is not PSD (POUNCE's own check).
        ValueError: any integer-marked variable, or an unknown option.
    """
    del gap_tolerance  # a continuous QP has no gap to close
    if not POUNCE_AVAILABLE:
        raise ImportError("pounce is required. Install it with:\n  pip install pounce-solver")
    if integrality is not None and np.any(np.asarray(integrality) == 1):
        raise ValueError("POUNCE's convex QP IPM is continuous; integrality is not supported.")
    # #1619 A-22: a sparse Q stays sparse (POUNCE takes scipy.sparse P).
    Q_arr: Any = sp.csr_matrix(Q) if sp.issparse(Q) else np.asarray(Q, dtype=np.float64)
    c_arr = np.asarray(c, dtype=np.float64).ravel()
    n = len(c_arr)
    if Q_arr.shape != (n, n):
        raise ValueError(f"Q has shape {Q_arr.shape} but c has {n} elements")
    if not certify_psd(Q_arr):
        raise IndefiniteQPError(
            "discopt could not prove the QP Hessian positive semidefinite, so the "
            "convex QP IPM may not certify its answer."
        )
    lb, ub = _engine_box(bounds, n, default_lb=-np.inf)
    start = None
    if warm_start is not None:
        n_eq = 0 if A_eq is None or b_eq is None else int(A_eq.shape[0])
        n_ub = 0 if A_ub is None or b_ub is None else int(A_ub.shape[0])
        start = _warm_start_arrays(warm_start, n, n_eq, n_ub)
    raw, res, wall, A, cl, cu, report = _solve(
        Q_arr, c_arr, A_ub, b_ub, A_eq, b_eq, lb, ub, time_limit, options, solve_report, start
    )
    iters = int(res.iters)
    # ``optimal_inaccurate`` is the engine's own ``optimal`` iterate re-judged on its
    # normalized KKT measure (POUNCE gh#984) and found above ``tol`` -- a converged
    # point, not an iteration cap. It goes to the caller as a candidate, exactly as
    # ``optimal`` does: on this route the engine's label never certified anything.
    # ``solver._solve_qp_matrix`` refuses it unless it is primal feasible and passes
    # the #1384 stationarity guard, and publishes a bound only when the #1596
    # certificate, which charges the unconverged complementarity, closes the gap;
    # otherwise it is an uncertified ``feasible`` point. Mapping it to
    # ``ITERATION_LIMIT`` dropped the point and named a cap the engine never hit:
    # the 1e-6-scaled row of #1617 stopped after 17 iterations as
    # ``optimal_inaccurate`` under pounce ``main`` and as ``optimal`` under the
    # 0.12.0 wheel, with bit-identical iterates.
    if raw not in ("optimal", "optimal_inaccurate"):
        assert A is not None and cl is not None and cu is not None
        # The ray certificate stacks Q under the (already dense) rows; it runs
        # only on this non-optimal path, so densifying a sparse Q here is the
        # same trade the rows make (#1619).
        Q_dense = Q_arr.toarray() if sp.issparse(Q_arr) else Q_arr
        status, why = _verdict_status(raw, c_arr, A, cl, cu, lb, ub, Q_dense)
        return QPResult(
            status=status,
            iterations=iters,
            wall_time=wall,
            solve_report=report,
            message=why,
        )
    n_ub = 0 if A_ub is None else int(A_ub.shape[0])
    dual, rc = _kkt_parts(res, n_ub)
    x = _onto_box(res.x, lb, ub)
    return QPResult(
        status=SolveStatus.OPTIMAL,
        x=x,
        objective=float(0.5 * x @ (Q_arr @ x) + c_arr @ x),
        dual_values=dual,
        reduced_costs=rc,
        iterations=iters,
        wall_time=wall,
        kkt_error=res.kkt_error,
        solve_report=report,
        message="" if raw == "optimal" else f"the engine reported {raw!r}",
        warm_start_state={
            k: np.array(v, dtype=np.float64)
            for k in _WARM_START_KEYS
            if (v := getattr(res, k, None)) is not None
        },
    )
