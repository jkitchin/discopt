"""Generalized Benders Decomposition (Geoffrion 1972): convex-NLP recourse.

On a **convex** MINLP, prefer **Outer Approximation**
(:func:`discopt.solvers.oa.solve_oa`): its per-constraint linearizations dominate
GBD's single aggregated cut (Duran & Grossmann 1986), so OA usually needs fewer
major iterations. GBD is preferable only when the per-iteration master must stay
small. The Decomposition Advisor ranks OA above GBD automatically for convex
models.

Where classical Benders (``solver.py``) handles a *linear* recourse LP, GBD
handles a **convex nonlinear** recourse subproblem. The two-stage problem
(internally minimizing) is::

    min  f(x, y)
    s.t. g(x, y) <= 0            (coupling / recourse constraints)
         x in X                  (complicating / first-stage; may be integer)
         y in Y                  (continuous recourse)

For a fixed first-stage point ``x̂`` the **recourse value function** is

    v(x̂) = min_y f(x̂, y)  s.t.  g(x̂, y) <= 0,

a *convex* function of ``x`` when ``f`` and every ``g_i`` are jointly convex.
Solving the recourse NLP yields a recourse point ``ŷ`` and (sign-projected,
dual-feasible) multipliers ``μ``. The **optimality cut** is built from the
**Lagrangian dual value**, not the NLP primal ``f(x̂, ŷ)``. With the Lagrangian
``L(x, y) = f(x, y) + μ^T g(x, y)`` (jointly convex on a convex model), the
joint-subgradient inequality at ``(x̂, ŷ)`` gives, for *every* master point x,

    v(x) >= min_y L(x, y) >= [L(x̂, ŷ) + m_y] + ∇_x L^T (x - x̂),

    where  m_y = min over the recourse box of  ∇_y L^T (y - ŷ)   (closed form),

so the cut

    eta >= [L(x̂, ŷ) + m_y] + ∇_x L^T (x - x̂)

is a valid global underestimator for *any* recourse point ``ŷ`` — it does not
require the NLP to have solved to optimality. This mirrors classical Benders'
complete-dual cut and is the analogue that closes the theoretical gap an anchor
at the (possibly inexact) NLP primal would leave: ``L(x̂, ŷ) <= f(x̂, ŷ)`` and
``m_y <= 0``, so the anchor never exceeds the primal, and both corrections vanish
at a converged KKT point (``anchor = v(x̂)``, tight). The master

That cut is always *sound*, but it is only *informative* when ``μ`` is finite.
When the recourse subproblem is **degenerate at its solution** — Slater's
condition fails, i.e. the feasible set has empty interior — no finite multiplier
exists, the returned one diverges, and ``∇_x L = ∇_x f + μ^T ∇_x g`` diverges with
it: the cut stays tight *at* ``x̂`` and goes vacuous one step away, so the master
bound stalls and GBD exits ``iteration_limit`` instead of ``optimal`` (issue
#946). Because the multiplier cannot be repaired, the fix is a second cut that
does not use it. On an **all-0/1 first stage** we also emit the **integer
L-shaped optimality cut** (Laporte & Louveaux 1993)

    eta >= anchor - (anchor - L) * Δ(x, x̂),
    Δ(x, x̂) = Σ_{x̂_j=1}(1 - x_j) + Σ_{x̂_j=0} x_j   (Hamming distance to x̂),

where ``L`` is a rigorous global lower bound on the objective over the declared
box (the closed-form box minimum, ``_box_min_linear``, of the convex objective's
— or Lagrangian's — subgradient underestimator, so it is a *computed* bound, not
an assumed one, and it is only ever improved by taking the max over iterations).
The cut is exact at ``x̂`` (``Δ = 0`` reproduces the multiplier-free anchor) and
drops to ``L`` at every other 0/1 point (``Δ >= 1``), so it is valid regardless of
how the multiplier behaves; ``L`` is clamped to ``min(L, anchor)`` so the
coefficient ``anchor - L`` can never turn negative and tilt the cut upward. Being
exact at every visited 0/1 point, it also gives the binary-master case finite
convergence, which the Lagrangian cut alone does not have. A non-binary first
stage has no comparably cheap exact cut; there the honest outcome is the current
one, and GBD says so (a logged warning naming the degenerate recourse, and an
early stop once the master starts re-proposing a point it has already cut).

The master

    min_x  eta   s.t.  master-only rows,  GBD cuts,  x integral,  eta >= floor

therefore yields a rigorous lower bound. When the recourse is *infeasible* at a
0/1 first-stage point we exclude that point with a **no-good cut** (rigorous: a
point whose recourse is infeasible cannot be part of any feasible solution).
Infeasibility is **certified by a feasibility-phase NLP** before any point is
excluded (:mod:`._feasibility`): the recourse NLP failing is not proof of
infeasibility (the backend reports a local infeasibility verdict as an error,
indistinguishable from a numerical failure), so a transient solver failure at the
optimum must never trigger an excluding cut. A recourse solve that fails without
the phase-1 NLP certifying infeasibility is retried once from a perturbed start;
if it still fails, the solve downgrades to heuristic mode (``bound=None``) rather
than risk cutting off the optimum. A *master-only nonlinear* constraint is
rejected up front (it cannot be enforced by the recourse NLP, which sees the
master variables fixed).

Soundness is gated on convexity: the reported ``bound`` is valid only when the
objective and all constraints are convex (checked with
``classify_oa_cut_convexity``); otherwise the solver runs heuristically and
reports ``bound=None`` so the ``incorrect_count <= 0`` gate is never threatened.
The bound is also withheld (``bound=None``) when a recourse variable is unbounded
in the active descent direction — the closed-form ``m_y`` is then ``-inf`` (no
finite rigorous cut), so the cut falls back to the primal anchor purely to keep
the search progressing, and the solve is flagged non-rigorous rather than
reporting an unsound bound. The remaining dependency, shared with every convex
(MI)NLP method here (e.g. Outer Approximation), is the convexity classifier
itself: a model the classifier wrongly accepts as convex would get an
unwarranted bound. The classifier is conservative (it errs toward ``bound=None``)
and is exercised by the decomposition test suite.
"""

from __future__ import annotations

import logging
import time
from typing import NamedTuple

import numpy as np

from discopt.decomposition._linear import relative_gap, solution_dict
from discopt.decomposition.benders._feasibility import certify_recourse_feasibility
from discopt.decomposition.structure import (
    DecompositionStructure,
    detect_decomposition,
    flat_bounds,
)
from discopt.modeling.core import Model, ObjectiveSense, SolveResult, VarType
from discopt.solvers import SolveStatus
from discopt.solvers.lp_backend import names_decomposition_route

logger = logging.getLogger(__name__)

_ETA_FLOOR = -1e12
_BIG = 1e20

# A gradient component below this is treated as stationary and contributes
# nothing to a closed-form box minimum (matches the pre-#946 ``m_y`` loop).
#
# It MUST stay below the recourse NLP's own dual tolerance (1e-8). The skip
# happens *before* the column's bound is examined, so on an unbounded column it
# reports 0 where the exact box minimum is -inf — an error of up to
# ``_STATIONARY_TOL * 1e20`` in the *unsafe* direction (an inflated anchor, and
# an inflated ``floor``, which is what the integer L-shaped cut divides by).
# Below the NLP tolerance that is sound rather than lucky: an unbounded column
# is interior at the recourse solution, so KKT stationarity makes its exact
# gradient component zero and the exact contribution zero too; a component the
# solver did *not* drive to stationarity lands above the tolerance and correctly
# returns ``finite=False``. Raising this above 1e-8 breaks that argument.
_STATIONARY_TOL = 1e-9

# Diagnostic only (issue #946): how far the Lagrangian cut may swing across the
# master box, relative to the objective scale, before the multiplier behind it
# is reported as degenerate. Measured on the issue's reproducer, whose two arms
# differ only in the recourse NLP's ``bound_relax_factor``: a finite multiplier
# gives a swing of 5.7e4 x the objective scale, the diverging one 7.9e8. This
# ratio drives a log message and an early stop, never a cut or a bound — the
# integer L-shaped cut below is added on its own merits, not on this test.
_DEGENERATE_CUT_RATIO = 1e6


class _Recourse(NamedTuple):
    """Outcome of one recourse classification at a fixed first-stage point.

    ``kind`` is ``'opt'`` / ``'infeas_certified'`` / ``'fail'`` (see
    :func:`solve_gbd._recourse`), or the internal ``'nofeas'`` that
    ``_attempt_recourse`` returns for a single failed solve and that
    ``_recourse`` always resolves into one of the other three. The remaining
    fields are meaningful only for ``'opt'``.
    """

    kind: str
    v: float | None = None
    x_full: np.ndarray | None = None
    anchor: float | None = None
    s: np.ndarray | None = None
    #: True when ``anchor`` is the rigorous closed-form Lagrangian bound rather
    #: than the primal fallback used when the recourse box minimum is -inf.
    rigorous: bool = True
    #: Rigorous global lower bound on the objective over the declared box, or
    #: None when a variable is unbounded in the active descent direction.
    floor: float | None = None
    #: True when the returned multiplier makes the Lagrangian cut vacuous away
    #: from x̂ (near-degenerate recourse; diagnostic only).
    degenerate: bool = False


def _box_min_linear(
    grad: np.ndarray,
    x_ref: np.ndarray,
    cols,
    lb: np.ndarray,
    ub: np.ndarray,
) -> tuple[float, bool]:
    """Closed-form ``min over the box of grad^T (z - x_ref)`` restricted to *cols*.

    Returns ``(value, finite)``. ``finite`` is False when some column with a
    non-stationary gradient component is unbounded in the descent direction, so
    the true minimum is ``-inf`` and no finite underestimator exists; ``value``
    is then meaningless. "Non-stationary" is ``_STATIONARY_TOL``, whose comment
    explains why that threshold is what makes this sound on unbounded columns.
    """
    total = 0.0
    for j in cols:
        gj = float(grad[j])
        if not np.isfinite(gj):
            # #1491: an infinite/undefined slope gives no first-order bound.
            return 0.0, False
        if abs(gj) < _STATIONARY_TOL:  # stationary component: no contribution
            continue
        target = lb[j] if gj > 0 else ub[j]
        if not np.isfinite(target) or abs(target) >= 1e19:
            return 0.0, False
        total += gj * (target - x_ref[j])
    return total, True


def _master_columns(model: Model, structure: DecompositionStructure):
    """Return (master_cols, sub_cols, master_int) flat-index partition.

    Mirrors ``solver._partition_columns`` but lives here to keep GBD
    self-contained. Integer variables must be first-stage (the recourse NLP
    needs continuous KKT multipliers).
    """
    complicating = set(structure.complicating_vars)
    master_cols: list[int] = []
    sub_cols: list[int] = []
    master_int: list[bool] = []
    off = 0
    for v in model._variables:
        is_master = v.name in complicating
        is_int = v.var_type in (VarType.BINARY, VarType.INTEGER)
        for _ in range(v.size):
            if is_master:
                master_cols.append(off)
                master_int.append(is_int)
            elif is_int:
                raise NotImplementedError(
                    f"Variable {v.name!r} is integer but in the recourse subproblem; "
                    "GBD requires all integer variables to be first-stage "
                    "(mark them with model.first_stage(...))."
                )
            else:
                sub_cols.append(off)
            off += 1
    return (
        np.array(master_cols, dtype=int),
        np.array(sub_cols, dtype=int),
        np.array(master_int, dtype=bool),
    )


@names_decomposition_route("benders/gbd: discopt generalized Benders decomposition")
def solve_gbd(
    model: Model,
    *,
    structure: DecompositionStructure | None = None,
    time_limit: float = 3600.0,
    gap_tolerance: float = 1e-4,
    max_iterations: int = 100,
    nlp_solver: str = "pounce",
    **_ignored,
) -> SolveResult:
    """Solve a two-stage convex MINLP with nonlinear recourse by GBD.

    Parameters
    ----------
    model : Model
        Convex objective/constraints, continuous recourse, integer variables (if
        any) first-stage. Master-only constraints must be linear.
    structure : DecompositionStructure, optional
        Auto-detected when omitted (complicating vars default to integers).

    Returns
    -------
    SolveResult
        With a rigorous lower ``bound`` when the model is convex; ``bound=None``
        otherwise (heuristic mode).
    """
    from discopt._relax.convexity import classify_oa_cut_convexity
    from discopt._relax.gdp_reformulate import _extract_body_coeffs, _is_linear
    from discopt._tape_nlp_evaluator import make_evaluator
    from discopt.modeling.core import Constraint
    from discopt.solvers.lp_backend import get_decomposition_master_solver
    from discopt.solvers.nlp_ipopt import _infer_constraint_bounds

    t0 = time.time()
    # #977: the GBD master is a *linear* MILP, so it is pinned to the exact-vertex
    # simplex B&B and NOT routed by ``nlp_solver``, which selects the engine for the
    # *NLP recourse* subproblem. Reusing it here sent the master to the
    # POUNCE-IPM-backed B&B, whose returned points are interior, not vertices.
    #
    # Measured on the master rows the engine was handed (identical arrays in and
    # out, so any error in the cut coefficients cancels exactly — that is what
    # distinguished the two candidate root causes in #977): the IPM path leaves row
    # residuals up to 5.9e-06, six times the repo's declared ``abs=1e-6``, where the
    # simplex is exact to ~1e-14 on the same input. Two consequences, both fixed by
    # this line: the master could hand back a point violating its own optimality cut
    # (the #952 exit gate then correctly refuses it, which is how #977 surfaced), and
    # the master objective — which *is* the GBD lower ``bound`` — was an
    # analytic-centre value that drifted above the incumbent it certifies, breaking
    # ``bound <= incumbent``. ``get_milp_solver`` still falls back to POUNCE when the
    # Rust simplex binding is unavailable, so POUNCE-only installs keep working.
    #
    # Scope note (#977 -> #986, resolved): the same conflation existed in
    # *classical* Benders (``solver.py``) and in the Lagrangian solver/node
    # bounder. Pinning those masters here was tried in #977, reverted when CI
    # showed classical Benders then stalling out at ``iteration_limit``, and
    # completed in #986 once the mechanism was measured. It is **not** the
    # degenerate-recourse-dual weakness #977 guessed at (that hypothesis was
    # falsified: at every stalling iteration the optimality cuts classify as
    # converged, ``eta_b >= Q_b``). An exact master returns a vertex whose sub-ulp
    # violation of its own variable bounds is scaled by the recourse row
    # coefficients into ``r - A_x x_hat``, which makes a gated recourse row pair
    # inconsistent by ~1e-14; an exact presolve then reports the recourse
    # INFEASIBLE at a feasible point. #986 clamps the master point to its bounds
    # and takes the recourse duals from the exact oracle. All four masters now
    # run on the exact-vertex engine.
    # #1614 D-26: HiGHS when available (an exact-vertex engine, as #986 requires).
    milp, _ = get_decomposition_master_solver()

    if structure is None:
        structure = detect_decomposition(model)
    mcols, scols, master_int = _master_columns(model, structure)
    n_master = len(mcols)
    if n_master == 0:
        raise NotImplementedError(
            "GBD needs at least one first-stage (complicating) variable. Annotate "
            "them with model.first_stage(...), or give the model integer variables."
        )
    if len(scols) == 0:
        raise NotImplementedError(
            "GBD needs at least one recourse (second-stage) variable; this model "
            "has none. Solve it directly with Model.solve()."
        )

    evaluator = make_evaluator(model)  # #1063: canonical funnel, not the JAX ctor
    n_vars = evaluator.n_variables
    lb_all, ub_all = flat_bounds(model)

    # Per-constraint-row (cl, cu) for projecting recourse multipliers into the
    # dual-feasible orthant. discopt normalizes constraints to ``g_raw <= 0``
    # form (cu=0, cl=-inf), so the projection is mu >= 0 for inequalities and
    # free for equalities (cl=cu) — see ``_project_mu``.
    if evaluator.n_constraints:
        _cl, _cu = _infer_constraint_bounds(evaluator)
    else:
        _cl = _cu = np.zeros(0)

    def _project_mu(mu: np.ndarray) -> np.ndarray:
        """Project recourse multipliers into the dual-feasible orthant so that
        ``mu^T g_raw <= 0`` holds on the feasible set (weak-duality requirement
        for a rigorous Lagrangian cut). For ``g_raw <= cu`` (cl=-inf): mu >= 0;
        for ``g_raw >= cl`` (cu=+inf): mu <= 0; equality (cl=cu): free."""
        if mu.size != _cl.size:
            return mu
        out = mu.copy()
        lower_inf = _cl <= -1e19
        upper_inf = _cu >= 1e19
        only_upper = lower_inf & ~upper_inf  # g_raw <= cu  -> mu >= 0
        only_lower = upper_inf & ~lower_inf  # g_raw >= cl  -> mu <= 0
        out[only_upper] = np.maximum(out[only_upper], 0.0)
        out[only_lower] = np.minimum(out[only_lower], 0.0)
        return np.asarray(out, dtype=np.float64)

    sense = model._objective.sense if model._objective is not None else ObjectiveSense.MINIMIZE
    sense_flip = 1.0 if sense == ObjectiveSense.MINIMIZE else -1.0

    # Convexity gate: a rigorous bound requires a convex value function.
    oa_conv = classify_oa_cut_convexity(model)
    is_convex = oa_conv.objective_is_convex and all(oa_conv.constraint_mask)

    # Master-only constraints (no recourse variable) become linear master rows;
    # constraints touching recourse variables live in the recourse NLP. A
    # master-only nonlinear constraint is unsupported in v1.
    A_m_rows: list[np.ndarray] = []
    b_m_rows: list[float] = []  # A_m x <= b_m
    sub_mask = np.zeros(n_vars, dtype=bool)
    sub_mask[scols] = True
    # An all-0/1 master can enforce a master-only nonlinear constraint rigorously
    # via no-good cuts (finitely many points); a non-binary master cannot, so
    # such a constraint is rejected up front rather than failing mid-solve (C2).
    all_binary_master = bool(
        np.all(master_int) and all(lb_all[i] >= -1e-9 and ub_all[i] <= 1 + 1e-9 for i in mcols)
    )
    for c in model._constraints:
        if not isinstance(c, Constraint):
            raise NotImplementedError(
                f"GBD supports only algebraic constraints (got {type(c).__name__})."
            )
        coeffs = _extract_body_coeffs(c.body, model, n_vars) if _is_linear(c.body) else None
        if coeffs is None:
            # Nonlinear constraint. It is handled inside the recourse NLP only if
            # it actually touches a recourse variable; a *master-only* nonlinear
            # constraint would silently degrade to a per-point feasibility check
            # (one no-good cut at a time, or a mid-solve error). Reject it up
            # front (C2) — the module docstring documents this restriction.
            from discopt._relax.gdp_reformulate import _collect_variables

            support_names = set(_collect_variables(c.body))
            complicating_names = set(structure.complicating_vars)
            if support_names and support_names <= complicating_names and not all_binary_master:
                raise NotImplementedError(
                    "GBD v1 does not support a master-only nonlinear constraint "
                    f"({getattr(c, 'name', None) or 'unnamed'!r}) with a non-binary "
                    "first-stage: it references only first-stage variables and cannot "
                    "be enforced by the recourse NLP. Model it so it also involves a "
                    "recourse variable, or solve the model with Model.solve()."
                )
            continue  # nonlinear, touches recourse: handled inside the recourse NLP
        vec = np.asarray(coeffs[0], dtype=np.float64)
        if np.any(np.abs(vec[sub_mask]) > 0):
            continue  # touches a recourse variable: handled inside the recourse NLP
        # master-only linear row
        off = float(coeffs[1])
        mrow = vec[mcols]
        if c.sense == "<=":
            A_m_rows.append(mrow)
            b_m_rows.append(-off)
        elif c.sense == ">=":
            A_m_rows.append(-mrow)
            b_m_rows.append(off)
        else:  # ==
            A_m_rows.append(mrow)
            b_m_rows.append(-off)
            A_m_rows.append(-mrow)
            b_m_rows.append(off)

    A_m = np.array(A_m_rows) if A_m_rows else np.zeros((0, n_master))
    b_m = np.array(b_m_rows) if b_m_rows else np.zeros(0)

    master_bounds = [(float(lb_all[i]), float(ub_all[i])) for i in mcols]

    # Accumulated cuts on (x, eta): coeff_x (n_master,), coeff_eta, rhs (<=).
    cut_x: list[np.ndarray] = []
    cut_eta: list[float] = []
    cut_rhs: list[float] = []

    def _solve_master(with_eta: bool):
        ncol = n_master + (1 if with_eta else 0)
        c = np.zeros(ncol)
        if with_eta:
            c[-1] = 1.0  # min eta
        rows, rhs = [], []
        if A_m.shape[0]:
            pad = np.zeros((A_m.shape[0], ncol))
            pad[:, :n_master] = A_m
            rows.append(pad)
            rhs.append(b_m)
        if cut_x:
            cm = np.zeros((len(cut_x), ncol))
            for k in range(len(cut_x)):
                cm[k, :n_master] = cut_x[k]
                if with_eta:
                    cm[k, -1] = cut_eta[k]
            rows.append(cm)
            rhs.append(np.array(cut_rhs))
        A_ub = np.vstack(rows) if rows else None
        b_ub = np.concatenate(rhs) if rhs else None
        bounds = list(master_bounds)
        integrality = np.zeros(ncol, dtype=np.int32)
        integrality[:n_master] = master_int.astype(np.int32)
        if with_eta:
            bounds.append((_ETA_FLOOR, _BIG))
        return milp(
            c,
            A_ub=A_ub,
            b_ub=b_ub,
            bounds=bounds,
            integrality=integrality,
            time_limit=max(1.0, time_limit - (time.time() - t0)),
            gap_tolerance=gap_tolerance,
        )

    def _attempt_recourse(x_hat: np.ndarray, perturb: bool) -> _Recourse:
        """One recourse-NLP solve at the fixed x̂. Returns a ``kind='opt'``
        :class:`_Recourse` (see :func:`_recourse` for the anchor derivation) or
        ``kind='nofeas'`` when the solve produced no primal-feasible recourse
        point."""
        sub_lb = lb_all.copy()
        sub_ub = ub_all.copy()
        sub_lb[mcols] = x_hat
        sub_ub[mcols] = x_hat
        from discopt.solvers.oa import _BoundsProxy, _is_primal_feasible

        if nlp_solver == "ipopt":
            from discopt.solvers.nlp_ipopt import solve_nlp
        else:
            from discopt.solvers.nlp_pounce import solve_nlp

        proxy = _BoundsProxy(evaluator, sub_lb, sub_ub)
        x0 = np.clip(0.5 * (sub_lb + sub_ub), -1e8, 1e8)
        if perturb:
            # Deterministic interior perturbation of the recourse start (fixed h).
            span = np.where(np.isfinite(sub_ub - sub_lb), sub_ub - sub_lb, 0.0)
            span = np.clip(span, 0.0, 2e8)
            h = np.cos(np.arange(n_vars, dtype=np.float64) + 1.0)
            x0 = np.clip(x0 + 0.1 * span * h, sub_lb, sub_ub)
        try:
            res = solve_nlp(proxy, x0, options={"print_level": 0, "max_iter": 300})  # type: ignore[arg-type]
        except Exception:
            return _Recourse("nofeas")

        feasible = res.x is not None and (
            res.status == SolveStatus.OPTIMAL or _is_primal_feasible(evaluator, res.x)
        )
        if not feasible:
            return _Recourse("nofeas")

        x_full = np.asarray(res.x, dtype=np.float64)
        v = float(evaluator.evaluate_objective(x_full))
        mu = (
            np.asarray(res.multipliers, dtype=np.float64)
            if res.multipliers is not None
            else np.zeros(evaluator.n_constraints)
        )
        grad = np.asarray(evaluator.evaluate_gradient(x_full), dtype=np.float64)
        if evaluator.n_constraints and mu.size == evaluator.n_constraints:
            mu_p = _project_mu(mu)
            jac = np.asarray(evaluator.evaluate_jacobian(x_full), dtype=np.float64)
            grad_lag = grad + jac.T @ mu_p
            g_raw = np.asarray(evaluator.evaluate_constraints(x_full), dtype=np.float64)
            l0 = v + float(mu_p @ g_raw)
        else:
            # No usable multipliers (none returned, or a size mismatch): drop the
            # mu^T g term, i.e. use mu = 0. This is still a sound underestimator
            # — it is the *unconstrained-recourse* Lagrangian (min_y f over the
            # box, ignoring g), and min_y f <= min_{y feasible} f = v_true since
            # the box is a superset of the feasible set. The cut is just weaker.
            grad_lag = grad
            l0 = v
        if not (np.isfinite(l0) and np.all(np.isfinite(grad_lag))):
            # #1491: no Lagrangian subgradient cut exists at a point of infinite or
            # undefined slope (sqrt at 0). Treat it like a failed recourse: x̂ is
            # not excluded and the bound is withheld, never cut from a NaN/inf row.
            return _Recourse("fail", rigorous=False)
        s = grad_lag[mcols]

        # m_y = min over the recourse box of grad_y L^T (y - y*) (closed form).
        m_y, finite_anchor = _box_min_linear(grad_lag, x_full, scols, lb_all, ub_all)
        # Rigorous anchor when the box minimum is finite. When a recourse
        # variable is unbounded in the active descent direction the box minimum
        # is -inf (no finite rigorous cut), so we fall back to the primal value
        # to keep the search progressing and flag ``rigorous=False`` — the
        # reported bound is then withheld (heuristic mode), never an unsound one.
        anchor = (l0 + m_y) if finite_anchor else v

        # Rigorous global lower bound on the objective over the *whole declared
        # box*, i.e. on v_true(x) at every master point x (#946). Same
        # convexity argument as the anchor, applied over all columns instead of
        # the recourse ones: for a convex h, h(z) >= h(z*) + grad h^T (z - z*)
        # everywhere, so the closed-form box minimum of the right-hand side
        # underestimates h on the box. Two candidates, both valid, best wins:
        # the objective itself (needs only f convex), and the Lagrangian (valid
        # on the feasible set because the projected mu makes mu^T g_raw <= 0
        # there — the same weak-duality step the anchor already relies on).
        floor: float | None = None
        m_all, finite_all = _box_min_linear(grad, x_full, range(n_vars), lb_all, ub_all)
        if finite_all and np.isfinite(v):
            floor = v + m_all
        m_all_lag, finite_all_lag = _box_min_linear(grad_lag, x_full, range(n_vars), lb_all, ub_all)
        if finite_all_lag and np.isfinite(l0):
            cand = l0 + m_all_lag
            floor = cand if floor is None else max(floor, cand)
        if floor is not None and not np.isfinite(floor):
            floor = None

        # Degeneracy diagnostic: how far this cut swings across the master box
        # relative to the objective scale. A diverging multiplier shows up here
        # as a swing many orders above the objective's own magnitude, i.e. a cut
        # that is tight at x̂ and vacuous one step away.
        swing = 0.0
        for k, j in enumerate(mcols):
            sj = abs(float(s[k]))
            col_span = float(ub_all[j] - lb_all[j])
            if sj < _STATIONARY_TOL or not np.isfinite(col_span) or col_span >= 1e19:
                continue
            swing = max(swing, sj * col_span)
        obj_scale = max(1.0, abs(v), abs(anchor), float(np.max(np.abs(grad))) if grad.size else 0.0)
        degenerate = swing > _DEGENERATE_CUT_RATIO * obj_scale

        return _Recourse(
            kind="opt",
            v=v,
            x_full=x_full,
            anchor=anchor,
            s=s,
            rigorous=finite_anchor,
            floor=floor,
            degenerate=degenerate,
        )

    def _recourse(x_hat: np.ndarray) -> _Recourse:
        """Fix master vars at x̂ and classify the recourse (C1-safe).

        Returns a :class:`_Recourse` whose ``kind`` is one of:

        - ``'opt'`` — a primal-feasible
          recourse point ``x_full`` with value ``v`` and the rigorous
          Lagrangian-dual cut data ``(anchor, s)``. With sign-projected
          (dual-feasible) multipliers ``mu`` and ``L(x,y) = f + mu^T g`` (jointly
          convex on a convex model), the joint-subgradient inequality at
          ``(x̂, y*)`` gives, for every master point x,
          ``v_true(x) >= [L(x̂,y*) + m_y] + grad_x L^T (x - x̂)`` where
          ``m_y = min over the recourse box of grad_y L^T (y - y*)`` is the
          closed-form box minimum. So the anchor is a valid lower bound for any
          approximate recourse solution. ``floor`` carries the rigorous global
          objective lower bound used by the integer L-shaped cut, and
          ``degenerate`` flags a multiplier that makes the Lagrangian cut
          vacuous away from x̂ (#946).
        - ``'infeas_certified'`` — a **feasibility-phase NLP** certified
          that no recourse point exists at x̂ (``t* > feas_tol`` at phase-1
          optimality). Only then may the master exclude x̂.
        - ``'fail'`` — the recourse solve failed *and* the phase-1 NLP did
          not certify infeasibility (it reported feasible, or itself failed to
          converge). x̂ must **not** be excluded; the caller downgrades to
          heuristic mode. This is the C1 fix: a transient NLP failure at the
          optimum can no longer be mistaken for infeasibility.
        """
        first = _attempt_recourse(x_hat, perturb=False)
        if first.kind == "opt":
            return first
        # The recourse solve found no feasible point. Certify *why* before
        # excluding x̂: distinguish genuine infeasibility from a solver failure.
        verdict, _info = certify_recourse_feasibility(
            evaluator,
            _cl,
            _cu,
            _pinned_bounds(x_hat),
            _pinned_upper(x_hat),
            nlp_solver=nlp_solver,
            feas_tol=1e-6,
        )
        if verdict == "infeasible":
            return _Recourse("infeas_certified")
        # Phase-1 says the recourse is (probably) feasible, or gave no verdict:
        # the first solve failed for another reason. Retry once from a perturbed
        # start before giving up.
        second = _attempt_recourse(x_hat, perturb=True)
        if second.kind == "opt":
            return second
        return _Recourse("fail", rigorous=False)

    def _pinned_bounds(x_hat: np.ndarray) -> np.ndarray:
        b = lb_all.copy()
        b[mcols] = x_hat
        return np.asarray(b)

    def _pinned_upper(x_hat: np.ndarray) -> np.ndarray:
        b = ub_all.copy()
        b[mcols] = x_hat
        return np.asarray(b)

    def _add_opt_cut(x_hat, anchor, s):
        # eta >= anchor + s^T (x - x̂)  ->  s^T x - eta <= s^T x̂ - anchor
        cut_x.append(s.copy())
        cut_eta.append(-1.0)
        cut_rhs.append(float(s @ x_hat) - anchor)

    # Best (largest) rigorous global lower bound on the objective over the box
    # seen so far. Every candidate is independently valid, so the running max is
    # valid too; it is the ``L`` of the integer L-shaped cut (#946).
    obj_floor: float | None = None

    def _register_floor(candidate: float | None) -> None:
        nonlocal obj_floor
        if candidate is None:
            return
        obj_floor = candidate if obj_floor is None else max(obj_floor, candidate)

    def _add_lshaped_cut(x_hat, anchor: float, s: np.ndarray, rigorous: bool) -> bool:
        """Integer L-shaped optimality cut at a 0/1 master point (#946).

        ``eta >= anchor_z - (anchor_z - L) * Δ(x, ẑ)`` with ``Δ`` the Hamming
        distance to the rounded point ẑ and ``L = obj_floor`` a rigorous global
        lower bound on the objective. Valid because ``Δ = 0`` only at ẑ — where
        the right-hand side is the rigorous Lagrangian bound ``anchor_z <=
        v_true(ẑ)`` — while every other 0/1 point has ``Δ >= 1`` and so a
        right-hand side ``<= L <= v_true(x)``. Unlike the Lagrangian cut it
        never touches the multiplier, so a degenerate recourse cannot make it
        vacuous.

        ``anchor_z = anchor + s^T (ẑ - x̂)`` is the Lagrangian cut read off at ẑ:
        the master returns x̂ within its integrality tolerance of ẑ rather than
        exactly at it, and the anchor alone bounds ``v_true`` only at x̂. The
        correction is zero whenever the master returns an exact 0/1 point (the
        usual case) and rigorous when it does not.

        Requires an all-0/1 first stage (``Δ`` is only a flip count there), a
        convex model (both the anchor and ``L`` rest on convexity), and the
        rigorous anchor — the primal fallback ``anchor = f(x̂, ŷ)`` is an *upper*
        bound on ``v_true(x̂)`` and would cut off the true value there.
        Returns True when a cut was added.
        """
        if not (all_binary_master and is_convex and rigorous):
            return False
        if obj_floor is None or obj_floor <= _ETA_FLOOR or not np.isfinite(anchor):
            # No finite floor, or one weaker than the master's own eta bound:
            # the cut would carry no information the master does not already have.
            return False
        z = np.round(x_hat).astype(float)
        anchor_z = float(anchor) + float(s @ (z - x_hat))
        if not np.isfinite(anchor_z) or anchor_z <= _ETA_FLOOR:
            return False
        # Clamp: the floor is a lower bound on v_true(x) for every x and the
        # anchor one at ẑ only, so nothing orders them. A floor above the anchor
        # would make the coefficient negative and tilt the cut *upward* with the
        # flip count, which is not valid; using min(L, anchor_z) keeps it >= 0.
        spread = max(0.0, anchor_z - float(obj_floor))
        a = np.where(z >= 0.5, 1.0, -1.0)
        # Δ = n_ones - a^T x, so eta >= anchor_z - spread*Δ becomes
        # spread * a^T x - eta <= spread * n_ones - anchor_z.
        cut_x.append(spread * a)
        cut_eta.append(-1.0)
        cut_rhs.append(spread * float(z.sum()) - anchor_z)
        return True

    def _add_nogood_cut(x_hat) -> bool:
        # Exclude a 0/1 master point with infeasible recourse:
        # sum_{x̂=1}(1-x_j) + sum_{x̂=0} x_j >= 1
        #   -> sum_{x̂=1} x_j - sum_{x̂=0} x_j <= (#ones) - 1
        if not all_binary_master:
            return False
        z = np.round(x_hat).astype(int)
        a = np.where(z == 1, 1.0, -1.0)
        cut_x.append(a)
        cut_eta.append(0.0)
        cut_rhs.append(float(z.sum()) - 1.0)
        return True

    # ── initialize from a feasible master point (no eta) ──
    init = _solve_master(with_eta=False)
    if init.status == SolveStatus.INFEASIBLE:
        return SolveResult(status="infeasible", wall_time=time.time() - t0, gap_certified=True)
    if init.status != SolveStatus.OPTIMAL or init.x is None:
        return SolveResult(status="error", wall_time=time.time() - t0)
    x_hat = np.asarray(init.x[:n_master], dtype=np.float64)

    best_ub = np.inf
    incumbent_full: np.ndarray | None = None
    status = "iteration_limit"
    # The reported bound is rigorous only if every optimality cut used the
    # closed-form Lagrangian anchor; an unbounded-recourse fallback to the primal
    # anchor downgrades the solve to heuristic mode (bound withheld).
    bound_rigorous = True

    # Set when a recourse solve fails without the phase-1 NLP certifying
    # infeasibility (C1): x̂ is not excluded, and the reported bound is withheld.
    heuristic_fail = False

    # #946 diagnostics: whether a degenerate recourse multiplier was ever seen,
    # and whether the multiplier-free integer L-shaped cut was available to
    # compensate. Used only to explain a non-certifying exit.
    degenerate_seen = False
    lshaped_added = 0
    visited: list[np.ndarray] = []

    rec = _recourse(x_hat)
    if rec.kind == "opt":
        assert rec.anchor is not None and rec.s is not None and rec.v is not None
        _register_floor(rec.floor)
        _add_opt_cut(x_hat, rec.anchor, rec.s)
        lshaped_added += int(_add_lshaped_cut(x_hat, rec.anchor, rec.s, rec.rigorous))
        degenerate_seen = degenerate_seen or rec.degenerate
        bound_rigorous = bound_rigorous and rec.rigorous
        best_ub = rec.v
        incumbent_full = rec.x_full
        visited.append(x_hat.copy())
    elif rec.kind == "infeas_certified":
        if not _add_nogood_cut(x_hat):
            raise NotImplementedError(
                "GBD recourse is certified infeasible at a non-binary first-stage "
                "point and no feasibility cut is available; GBD v1 supports "
                "infeasible recourse only for 0/1 first-stage variables "
                "(relatively complete recourse otherwise)."
            )
    else:  # "fail": recourse unsolved, infeasibility NOT certified — do not cut.
        logger.warning(
            "GBD recourse solve failed at the initial master point without "
            "certifying infeasibility; downgrading to heuristic mode (bound withheld)."
        )
        bound_rigorous = False
        heuristic_fail = True

    for _it in range(max_iterations):
        if heuristic_fail:
            break
        if time.time() - t0 > time_limit:
            status = "time_limit"
            break
        mres = _solve_master(with_eta=True)
        if mres.status == SolveStatus.INFEASIBLE:
            status = "infeasible"
            best_ub = np.inf
            incumbent_full = None
            break
        if mres.x is None:
            status = "error"
            break
        x_hat = np.asarray(mres.x[:n_master], dtype=np.float64)
        lb = mres.bound if mres.bound is not None else mres.objective
        lower_bound = float(lb) if lb is not None else None

        rec = _recourse(x_hat)
        repeat = False
        if rec.kind == "opt":
            assert rec.anchor is not None and rec.s is not None and rec.v is not None
            if rec.v < best_ub:
                best_ub = rec.v
                incumbent_full = rec.x_full
            _register_floor(rec.floor)
            _add_opt_cut(x_hat, rec.anchor, rec.s)
            lshaped_added += int(_add_lshaped_cut(x_hat, rec.anchor, rec.s, rec.rigorous))
            degenerate_seen = degenerate_seen or rec.degenerate
            bound_rigorous = bound_rigorous and rec.rigorous
            repeat = any(np.allclose(x_hat, seen, rtol=0.0, atol=1e-9) for seen in visited)
            visited.append(x_hat.copy())
        elif rec.kind == "infeas_certified":
            if not _add_nogood_cut(x_hat):
                raise NotImplementedError(
                    "GBD recourse certified infeasible at a non-binary first-stage "
                    "point; no feasibility cut available (GBD v1)."
                )
        else:  # "fail": do not exclude x̂; stop and report heuristically.
            logger.warning(
                "GBD recourse solve failed at a master point without certifying "
                "infeasibility; stopping in heuristic mode (bound withheld)."
            )
            bound_rigorous = False
            heuristic_fail = True
            break

        # Certify optimality from the gap only when the master bound is rigorous
        # (convex model, no primal-anchor fallback) — otherwise the lower bound
        # may be contaminated and could prematurely certify a suboptimal point.
        if is_convex and bound_rigorous and np.isfinite(best_ub) and lower_bound is not None:
            gap = relative_gap(best_ub, lower_bound)
            if gap <= gap_tolerance:
                status = "optimal"
                break

        # Stall (#946): the master re-proposed a point it has already cut, so
        # the last cut carried no information about eta there and the next
        # iteration would repeat this one. Spending the remaining budget on it
        # changes nothing, so stop and say why instead of exhausting it
        # silently. The status stays ``iteration_limit`` — the honest outcome —
        # and the bound reported below is the same one the full budget would
        # have produced.
        if repeat:
            logger.warning(
                "GBD master re-proposed an already-cut first-stage point after %d "
                "iteration(s); the optimality cut there carries no usable eta "
                "information%s. Stopping early with a valid but uncertified bound. %s",
                _it + 1,
                " (recourse multiplier is degenerate: the recourse subproblem has "
                "empty interior at this point, so no finite multiplier exists)"
                if degenerate_seen
                else "",
                "The multiplier-free integer L-shaped cut needs an all-0/1 first "
                "stage and a finite objective floor; it is unavailable here."
                if lshaped_added == 0
                else "",
            )
            break

    # A recourse solve that failed without a feasibility verdict leaves the
    # search unable to progress: report the incumbent heuristically, or error
    # out when there is none. The bound is already withheld (bound_rigorous=False).
    if heuristic_fail and incumbent_full is None:
        return SolveResult(status="error", wall_time=time.time() - t0)

    # Final master lower bound — reported only when rigorous.
    bound: float | None = None
    if is_convex and bound_rigorous:
        final = _solve_master(with_eta=True)
        if final.status == SolveStatus.OPTIMAL:
            lb = final.bound if final.bound is not None else final.objective
            if lb is not None:
                bound = float(lb)

    if status == "infeasible":
        return SolveResult(status="infeasible", wall_time=time.time() - t0, gap_certified=True)

    objective = None if not np.isfinite(best_ub) else best_ub
    if status == "iteration_limit" and objective is not None and bound is not None:
        if relative_gap(objective, bound) <= gap_tolerance:
            status = "optimal"

    # Explain a lost certificate rather than leaving it to be rediscovered
    # (#946): a degenerate recourse gives cuts that are tight at their own
    # first-stage point and vacuous elsewhere, so the master bound stalls.
    if status == "iteration_limit" and degenerate_seen:
        logger.warning(
            "GBD did not certify optimality (status=%s, bound=%r, incumbent=%r): the "
            "recourse subproblem is degenerate at one or more first-stage points "
            "(empty interior, so no finite multiplier exists) and its Lagrangian cut "
            "is vacuous away from that point. %s The bound reported is valid, only "
            "weak.",
            status,
            bound,
            objective,
            f"{lshaped_added} multiplier-free integer L-shaped cut(s) were added alongside it."
            if lshaped_added
            else "No multiplier-free cut was available: the integer L-shaped cut needs "
            "an all-0/1 first stage, a convex model and a finite objective floor over "
            "the declared box.",
        )

    reported_obj = None if objective is None else objective * sense_flip
    reported_bound = None if bound is None else bound * sense_flip
    reported_gap: float | None = None
    if reported_obj is not None and reported_bound is not None:
        reported_gap = abs(relative_gap(reported_obj, reported_bound))

    x_dict = solution_dict(model, incumbent_full) if incumbent_full is not None else None

    return SolveResult(
        status=status,
        objective=reported_obj,
        bound=reported_bound,
        gap=reported_gap,
        x=x_dict,
        wall_time=time.time() - t0,
        node_count=0,
        gap_certified=(status == "optimal" and is_convex),
    )


__all__ = ["solve_gbd"]
