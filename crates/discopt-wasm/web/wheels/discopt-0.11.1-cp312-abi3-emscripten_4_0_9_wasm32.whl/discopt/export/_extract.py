"""
Expression linearization and quadratic extraction helpers.

These walk the expression DAG to extract linear and quadratic coefficients,
raising ``ValueError`` for any nonlinear terms that cannot be represented
in MPS or LP format.
"""

from __future__ import annotations

import numpy as np

from discopt._flat_index import flat_index_in_shape
from discopt.modeling.core import (
    BinaryOp,
    Constant,
    Expression,
    IndexExpression,
    Model,
    SumExpression,
    SumOverExpression,
    UnaryOp,
    Variable,
    VarType,
)


def flatten_variables(
    model: Model,
) -> list[tuple[str, VarType, tuple[int, ...], float, float]]:
    """Flatten all model variables into a list of scalar entries.

    Each entry is ``(name, var_type, original_shape, lb, ub)`` where
    *name* is a unique scalar name like ``x`` for scalars or ``x_0``,
    ``x_1`` for arrays.

    Returns
    -------
    list of tuple
        One entry per scalar variable component.
    """
    flat: list[tuple[str, VarType, tuple[int, ...], float, float]] = []
    for var in model._variables:
        if var.shape == () or var.shape == (1,):
            flat.append(
                (var.name, var.var_type, var.shape, float(var.lb.flat[0]), float(var.ub.flat[0]))
            )
        else:
            for k in range(var.size):
                idx = np.unravel_index(k, var.shape)
                suffix = "_".join(str(i) for i in idx)
                name = f"{var.name}_{suffix}"
                flat.append(
                    (name, var.var_type, var.shape, float(var.lb.flat[k]), float(var.ub.flat[k]))
                )
    return flat


class _VarOffsets:
    """O(1) ``Variable`` -> flat-column-offset lookup, built once per export.

    ``_var_index`` used to rescan ``model_vars`` from the start for *every*
    variable occurrence, recomputing the running offset as it went — O(terms x
    vars) for the whole walk. On a model whose body is one long sum that is
    quadratic in the model size, and it dominated everything else: measured on
    an ``n``-term mixed-sign sum, ``to_mps`` took 0.069 / 0.264 / 1.120 /
    4.329 s at n = 1000 / 2000 / 4000 / 8000 — a clean x4-per-doubling — with
    ``Variable.shape`` accessed 3.6e7 times for n=6000 (79% of total runtime by
    ``cProfile``, against 1 constraint row, so the cost was entirely this scan).
    Building the offset map once makes the same walk linear.

    First occurrence wins, exactly as the old ``v is expr`` loop returned on its
    first match; identity (``id``) is the key because that loop compared with
    ``is``, and the source list is held so the ids stay live.
    """

    __slots__ = ("_offsets", "_vars")

    def __init__(self, model_vars: list[Variable]) -> None:
        offsets: dict[int, int] = {}
        offset = 0
        for v in model_vars:
            offsets.setdefault(id(v), offset)
            offset += max(v.size, 1) if v.shape != () else 1
        self._offsets = offsets
        self._vars = model_vars

    def get(self, var: Variable) -> int | None:
        return self._offsets.get(id(var))


def _var_index(
    expr: Expression,
    flat_vars: list[tuple[str, VarType, tuple[int, ...], float, float]],
    model_vars: _VarOffsets,
) -> int:
    """Resolve an expression to a flat variable index.

    Handles both ``Variable`` (scalar) and ``IndexExpression`` (array element).

    Raises
    ------
    ValueError
        If the expression is not a simple variable reference.
    """
    if isinstance(expr, Variable):
        offset = model_vars.get(expr)
        if offset is not None:
            if expr.shape == () or expr.shape == (1,):
                return offset
            raise ValueError(
                f"Array variable '{expr.name}' used without indexing. "
                "Only scalar variables or indexed elements can appear "
                "in linear/quadratic expressions for export."
            )
        raise ValueError(f"Variable '{expr.name}' not found in model")

    if isinstance(expr, IndexExpression):
        base = expr.base
        if not isinstance(base, Variable):
            raise ValueError("Nonlinear expression: nested indexing is not supported for export.")
        offset = model_vars.get(base)
        if offset is not None:
            idx = expr.index
            # A sliced/partial subscript (e.g. the DAE transcriber's
            # ``var[:, 1:]``) addresses many scalars, so no single flat index
            # exists; an out-of-range one names none. Negative indices are
            # normalised the numpy way rather than read as ``offset + idx``,
            # which named another variable's column (#1952, the #941 pattern).
            flat_idx = flat_index_in_shape(idx, tuple(base.shape or ()))
            if flat_idx is None:
                raise ValueError(
                    f"Non-scalar subscript {idx!r} on variable "
                    f"'{base.name}' (shape {base.shape}) cannot be exported "
                    "as a single variable reference; only fully scalar, "
                    "in-range indices are supported here."
                )
            return offset + flat_idx
        raise ValueError(f"Variable '{base.name}' not found in model")

    raise ValueError("Expression is not a variable reference.")


def extract_linear_terms(
    expr: Expression,
    flat_vars: list[tuple[str, VarType, tuple[int, ...], float, float]],
    model_vars: list[Variable] | None = None,
) -> tuple[dict[int, float], float]:
    """Extract linear coefficients from an expression.

    Parameters
    ----------
    expr : Expression
        The expression to decompose.
    flat_vars : list
        Flattened variable list from :func:`flatten_variables`.
    model_vars : list of Variable, optional
        Model variable list. If ``None``, reconstructed from flat_vars names.

    Returns
    -------
    coefficients : dict[int, float]
        Maps flat variable index to coefficient.
    constant : float
        Constant term.

    Raises
    ------
    ValueError
        If the expression contains nonlinear terms.
    """
    if model_vars is None:
        # Must be provided; fall back to extracting from a model
        raise ValueError("model_vars must be provided")

    coeffs: dict[int, float] = {}
    const = _extract_linear_recursive(expr, coeffs, 1.0, flat_vars, _VarOffsets(model_vars))
    return coeffs, const


def _scalar_constant(value: np.ndarray, context: str) -> float:
    """Collapse a constant array to a single scalar, or raise.

    A constant in a scalar-required position must be genuinely scalar: a
    0-d array or a 1-element array (which broadcasts to a scalar). A
    multi-element array cannot be silently collapsed to its first element
    (finding EX-7, #413) — that produces a wrong exported model — so we
    raise loudly instead. Reduction contexts (``sum``) must not route here;
    they sum the full array via :func:`_eval_constant_array` instead.
    """
    if value.ndim == 0 or value.size == 1:
        return float(value.reshape(()) if value.ndim == 0 else value.flat[0])
    raise ValueError(
        f"Array-valued constant of shape {value.shape} appears in a scalar "
        f"position ({context}) and cannot be collapsed to a single value. "
        "Wrap it in a reduction (e.g. sum(...)) or index a single element."
    )


def _eval_constant_array(expr: Expression) -> np.ndarray:
    """Evaluate a constant (variable-free) expression to its full ndarray.

    Unlike :func:`_get_constant_value`, this preserves array shape and
    broadcasting so a reduction context can sum every element rather than
    silently keeping only the first (finding EX-7, #413). Callers must have
    established ``_is_constant(expr)`` first.
    """
    result: np.ndarray
    if isinstance(expr, Constant):
        result = expr.value
    elif isinstance(expr, UnaryOp):
        if expr.op != "neg":
            raise ValueError(f"Cannot evaluate unary '{expr.op}' as constant.")
        result = -_eval_constant_array(expr.operand)
    elif isinstance(expr, BinaryOp):
        left = _eval_constant_array(expr.left)
        right = _eval_constant_array(expr.right)
        if expr.op == "+":
            result = left + right
        elif expr.op == "-":
            result = left - right
        elif expr.op == "*":
            result = left * right
        elif expr.op == "/":
            result = left / right
        elif expr.op == "**":
            result = left**right
        else:
            raise ValueError(f"Cannot evaluate binary '{expr.op}' as constant.")
    elif isinstance(expr, SumOverExpression):
        result = np.asarray(sum(_eval_constant_array(t).sum() for t in expr.terms), dtype=float)
    elif isinstance(expr, SumExpression):
        result = np.asarray(_eval_constant_array(expr.operand).sum(), dtype=float)
    else:
        raise ValueError(f"Expression type '{type(expr).__name__}' is not constant.")
    return result


# ── additive-spine flattening ───────────────────────────────────────────────
#
# The array scalarizer expands a reduction such as `dm.sum(x)` over `x` of shape
# `(n,)` into a LEFT-DEEP `+` fold: `((x[0] + x[1]) + x[2]) + ...`, depth `n`.
# Descending that one Python frame per term hit the default recursion limit at
# roughly 1000 terms, so `m.minimize(dm.sum(x))` -- one of the commonest
# objectives there is -- raised `RecursionError` from `to_lp`, `to_mps` and
# `to_gams` for any model with ~1000 variables. `.nl` was unaffected, which is
# why it went unnoticed.
#
# The fold is NOT changed here: both `.nl` writers mirror its exact shape and the
# emitted bytes depend on it (`docs/dev/performance-plan.md` §46). Only the
# TRAVERSAL becomes iterative -- the spine of `+`/`-` nodes is flattened onto a
# worklist, and every other node type still goes through the ordinary recursive
# handler at its own (shallow) depth.


def _flatten_additive(expr: Expression, multiplier: float) -> list:
    """Flatten a `+`/`-` spine into `[(leaf, signed multiplier), ...]`.

    Leaves are returned in left-to-right order, so a caller that accumulates into
    a dict sees terms in the same sequence the recursive version did.
    """
    out: list = []
    stack: list = [(expr, multiplier)]
    while stack:
        node, mult = stack.pop()
        if isinstance(node, BinaryOp) and node.op in ("+", "-"):
            right_mult = mult if node.op == "+" else -mult
            # Pushed right-then-left so the left operand pops first.
            stack.append((node.right, right_mult))
            stack.append((node.left, mult))
            continue
        out.append((node, mult))
    return out


def _extract_linear_recursive(
    expr: Expression,
    coeffs: dict[int, float],
    multiplier: float,
    flat_vars: list,
    model_vars: _VarOffsets,
) -> float:
    """Extract linear terms. Returns the constant contribution.

    The `+`/`-` spine is walked iteratively (see :func:`_flatten_additive`); every
    other node type recurses as before.
    """
    if isinstance(expr, BinaryOp) and expr.op in ("+", "-"):
        total = 0.0
        for leaf, mult in _flatten_additive(expr, multiplier):
            total += _extract_linear_recursive(leaf, coeffs, mult, flat_vars, model_vars)
        return total

    if isinstance(expr, Constant):
        return multiplier * _scalar_constant(expr.value, "constant term")

    if isinstance(expr, Variable) or isinstance(expr, IndexExpression):
        idx = _var_index(expr, flat_vars, model_vars)
        coeffs[idx] = coeffs.get(idx, 0.0) + multiplier
        return 0.0

    if isinstance(expr, UnaryOp):
        if expr.op == "neg":
            return _extract_linear_recursive(
                expr.operand, coeffs, -multiplier, flat_vars, model_vars
            )
        raise ValueError(
            f"Nonlinear expression: unary operation '{expr.op}' "
            "cannot be exported to MPS/LP format."
        )

    if isinstance(expr, BinaryOp):
        if expr.op == "+":
            c1 = _extract_linear_recursive(expr.left, coeffs, multiplier, flat_vars, model_vars)
            c2 = _extract_linear_recursive(expr.right, coeffs, multiplier, flat_vars, model_vars)
            return c1 + c2

        if expr.op == "-":
            c1 = _extract_linear_recursive(expr.left, coeffs, multiplier, flat_vars, model_vars)
            c2 = _extract_linear_recursive(expr.right, coeffs, -multiplier, flat_vars, model_vars)
            return c1 + c2

        if expr.op == "*":
            # One side must be constant for linearity
            if _is_constant(expr.left):
                val = _get_constant_value(expr.left)
                return _extract_linear_recursive(
                    expr.right, coeffs, multiplier * val, flat_vars, model_vars
                )
            if _is_constant(expr.right):
                val = _get_constant_value(expr.right)
                return _extract_linear_recursive(
                    expr.left, coeffs, multiplier * val, flat_vars, model_vars
                )
            # Both sides have variables: nonlinear for linear extraction
            raise ValueError(
                "Nonlinear expression: product of two variable expressions "
                "cannot be exported as linear. Use extract_quadratic_terms "
                "for quadratic support."
            )

        if expr.op == "/":
            if _is_constant(expr.right):
                val = _get_constant_value(expr.right)
                if val == 0:
                    raise ValueError("Division by zero in expression.")
                return _extract_linear_recursive(
                    expr.left, coeffs, multiplier / val, flat_vars, model_vars
                )
            raise ValueError(
                "Nonlinear expression: division by a variable expression "
                "cannot be exported to MPS/LP format."
            )

        if expr.op == "**":
            raise ValueError(
                "Nonlinear expression: exponentiation cannot be exported as a linear expression."
            )

        raise ValueError(f"Unknown binary operation '{expr.op}'.")

    if isinstance(expr, SumOverExpression):
        total_const = 0.0
        for term in expr.terms:
            total_const += _extract_linear_recursive(
                term, coeffs, multiplier, flat_vars, model_vars
            )
        return total_const

    if isinstance(expr, SumExpression):
        # A pure-constant operand is reduced over all its elements: sum the
        # full array rather than routing a multi-element Constant into the
        # scalar handler (finding EX-7, #413).
        if _is_constant(expr.operand):
            return multiplier * float(_eval_constant_array(expr.operand).sum())
        return _extract_linear_recursive(expr.operand, coeffs, multiplier, flat_vars, model_vars)

    raise ValueError(
        f"Expression type '{type(expr).__name__}' cannot be exported "
        "to MPS/LP format. Only linear and quadratic expressions are supported."
    )


def extract_quadratic_terms(
    expr: Expression,
    flat_vars: list[tuple[str, VarType, tuple[int, ...], float, float]],
    model_vars: list[Variable] | None = None,
) -> tuple[dict[tuple[int, int], float], dict[int, float], float]:
    """Extract quadratic and linear coefficients from an expression.

    Parameters
    ----------
    expr : Expression
        The expression to decompose.
    flat_vars : list
        Flattened variable list from :func:`flatten_variables`.
    model_vars : list of Variable, optional
        If ``None``, extracted from the first variable found.

    Returns
    -------
    quad_terms : dict[tuple[int, int], float]
        Maps ``(var_i, var_j)`` with ``i <= j`` to coefficient.
    linear_terms : dict[int, float]
        Maps flat variable index to linear coefficient.
    constant : float
        Constant term.

    Raises
    ------
    ValueError
        If the expression contains terms beyond quadratic.
    """
    if model_vars is None:
        raise ValueError("model_vars must be provided")

    quad: dict[tuple[int, int], float] = {}
    linear: dict[int, float] = {}
    const = _extract_quad_recursive(expr, quad, linear, 1.0, flat_vars, _VarOffsets(model_vars))
    return quad, linear, const


def _extract_quad_recursive(
    expr: Expression,
    quad: dict[tuple[int, int], float],
    linear: dict[int, float],
    multiplier: float,
    flat_vars: list,
    model_vars: _VarOffsets,
) -> float:
    """Extract quadratic and linear terms. Returns the constant contribution.

    The `+`/`-` spine is walked iteratively (see :func:`_flatten_additive`); every
    other node type recurses as before.
    """
    if isinstance(expr, BinaryOp) and expr.op in ("+", "-"):
        total = 0.0
        for leaf, mult in _flatten_additive(expr, multiplier):
            total += _extract_quad_recursive(leaf, quad, linear, mult, flat_vars, model_vars)
        return total

    if isinstance(expr, Constant):
        return multiplier * _scalar_constant(expr.value, "constant term")

    if isinstance(expr, (Variable, IndexExpression)):
        idx = _var_index(expr, flat_vars, model_vars)
        linear[idx] = linear.get(idx, 0.0) + multiplier
        return 0.0

    if isinstance(expr, UnaryOp):
        if expr.op == "neg":
            return _extract_quad_recursive(
                expr.operand, quad, linear, -multiplier, flat_vars, model_vars
            )
        raise ValueError(f"Nonlinear expression: unary '{expr.op}' cannot be exported.")

    if isinstance(expr, BinaryOp):
        if expr.op == "+":
            c1 = _extract_quad_recursive(expr.left, quad, linear, multiplier, flat_vars, model_vars)
            c2 = _extract_quad_recursive(
                expr.right, quad, linear, multiplier, flat_vars, model_vars
            )
            return c1 + c2

        if expr.op == "-":
            c1 = _extract_quad_recursive(expr.left, quad, linear, multiplier, flat_vars, model_vars)
            c2 = _extract_quad_recursive(
                expr.right, quad, linear, -multiplier, flat_vars, model_vars
            )
            return c1 + c2

        if expr.op == "*":
            if _is_constant(expr.left):
                val = _get_constant_value(expr.left)
                return _extract_quad_recursive(
                    expr.right,
                    quad,
                    linear,
                    multiplier * val,
                    flat_vars,
                    model_vars,
                )
            if _is_constant(expr.right):
                val = _get_constant_value(expr.right)
                return _extract_quad_recursive(
                    expr.left,
                    quad,
                    linear,
                    multiplier * val,
                    flat_vars,
                    model_vars,
                )

            # Product of two variable expressions: extract linear from each
            # and combine. Both must be purely linear (no quad * quad).
            left_lin: dict[int, float] = {}
            left_const = _extract_linear_from_quad(expr.left, left_lin, 1.0, flat_vars, model_vars)
            right_lin: dict[int, float] = {}
            right_const = _extract_linear_from_quad(
                expr.right, right_lin, 1.0, flat_vars, model_vars
            )

            # var_i * var_j terms
            for i, ci in left_lin.items():
                for j, cj in right_lin.items():
                    key = (min(i, j), max(i, j))
                    quad[key] = quad.get(key, 0.0) + multiplier * ci * cj

            # var * const terms
            for i, ci in left_lin.items():
                if right_const != 0.0:
                    linear[i] = linear.get(i, 0.0) + multiplier * ci * right_const
            for j, cj in right_lin.items():
                if left_const != 0.0:
                    linear[j] = linear.get(j, 0.0) + multiplier * cj * left_const

            # const * const
            return multiplier * left_const * right_const

        if expr.op == "/":
            if _is_constant(expr.right):
                val = _get_constant_value(expr.right)
                if val == 0:
                    raise ValueError("Division by zero in expression.")
                return _extract_quad_recursive(
                    expr.left,
                    quad,
                    linear,
                    multiplier / val,
                    flat_vars,
                    model_vars,
                )
            raise ValueError(
                "Nonlinear expression: division by variable expression cannot be exported."
            )

        if expr.op == "**":
            # x**2 is quadratic
            if _is_constant(expr.right):
                power = _get_constant_value(expr.right)
                if power == 2.0:
                    # base must be linear
                    base_lin: dict[int, float] = {}
                    base_const = _extract_linear_from_quad(
                        expr.left, base_lin, 1.0, flat_vars, model_vars
                    )
                    # (sum ci*xi + k)^2 = sum ci*cj*xi*xj + 2*k*sum ci*xi + k^2
                    items = list(base_lin.items())
                    for a, (i, ci) in enumerate(items):
                        for b, (j, cj) in enumerate(items):
                            if a <= b:
                                key = (min(i, j), max(i, j))
                                coeff = ci * cj
                                if a != b:
                                    coeff *= 2.0  # off-diagonal counted once
                                quad[key] = quad.get(key, 0.0) + multiplier * coeff
                    for i, ci in items:
                        if base_const != 0.0:
                            linear[i] = linear.get(i, 0.0) + multiplier * 2.0 * ci * base_const
                    return multiplier * base_const * base_const
                if power == 1.0:
                    return _extract_quad_recursive(
                        expr.left,
                        quad,
                        linear,
                        multiplier,
                        flat_vars,
                        model_vars,
                    )
                if power == 0.0:
                    return multiplier
            raise ValueError(
                "Nonlinear expression: exponentiation with power != 0, 1, 2 "
                "cannot be exported to MPS/LP format."
            )

        raise ValueError(f"Unknown binary operation '{expr.op}'.")

    if isinstance(expr, SumOverExpression):
        total = 0.0
        for term in expr.terms:
            total += _extract_quad_recursive(term, quad, linear, multiplier, flat_vars, model_vars)
        return total

    if isinstance(expr, SumExpression):
        # Reduce a pure-constant operand over all elements (finding EX-7, #413).
        if _is_constant(expr.operand):
            return multiplier * float(_eval_constant_array(expr.operand).sum())
        return _extract_quad_recursive(
            expr.operand, quad, linear, multiplier, flat_vars, model_vars
        )

    raise ValueError(
        f"Expression type '{type(expr).__name__}' cannot be exported. "
        "Only linear and quadratic expressions are supported."
    )


def _extract_linear_from_quad(
    expr: Expression,
    coeffs: dict[int, float],
    multiplier: float,
    flat_vars: list,
    model_vars: _VarOffsets,
) -> float:
    """Extract only linear terms for use inside quadratic product expansion.

    Same as _extract_linear_recursive but raises if quadratic terms appear.
    """
    return _extract_linear_recursive(expr, coeffs, multiplier, flat_vars, model_vars)


def _is_constant(expr: Expression) -> bool:
    """Check whether an expression contains no variables."""
    if isinstance(expr, Constant):
        return True
    if isinstance(expr, (Variable, IndexExpression)):
        return False
    if isinstance(expr, UnaryOp):
        return _is_constant(expr.operand)
    if isinstance(expr, BinaryOp):
        return _is_constant(expr.left) and _is_constant(expr.right)
    if isinstance(expr, SumOverExpression):
        return all(_is_constant(t) for t in expr.terms)
    if isinstance(expr, SumExpression):
        return _is_constant(expr.operand)
    return False


def _get_constant_value(expr: Expression) -> float:
    """Evaluate a constant expression (no variables) to a float."""
    if isinstance(expr, Constant):
        return _scalar_constant(expr.value, "constant coefficient/operand")
    if isinstance(expr, UnaryOp):
        if expr.op == "neg":
            return -_get_constant_value(expr.operand)
        raise ValueError(f"Cannot evaluate unary '{expr.op}' as constant.")
    if isinstance(expr, BinaryOp):
        left = _get_constant_value(expr.left)
        right = _get_constant_value(expr.right)
        if expr.op == "+":
            return left + right
        if expr.op == "-":
            return left - right
        if expr.op == "*":
            return left * right
        if expr.op == "/":
            return left / right
        if expr.op == "**":
            return float(left**right)
        raise ValueError(f"Cannot evaluate binary '{expr.op}' as constant.")
    if isinstance(expr, (SumExpression, SumOverExpression)):
        # A reduction of a constant collapses to a genuine scalar (its sum),
        # so it is well-defined even in a scalar-required position.
        return float(_eval_constant_array(expr).sum())
    raise ValueError(f"Expression type '{type(expr).__name__}' is not constant.")
