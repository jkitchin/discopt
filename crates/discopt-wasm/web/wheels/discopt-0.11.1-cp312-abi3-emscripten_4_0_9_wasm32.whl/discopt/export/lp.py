"""
CPLEX LP format export for discopt models.

Produces a human-readable LP file with sections: Minimize/Maximize,
Subject To, Bounds, Generals, Binaries, End.

Only linear and quadratic models are supported. Nonlinear expressions
raise ``ValueError``.
"""

from __future__ import annotations

from pathlib import Path

from discopt.export._arrays import scalarize_body, scalarize_objective
from discopt.export._common import (
    binary_box_is_default,
    builder_objective,
    iter_builder_linear_rows,
    legal_unique_names,
    refuse_non_algebraic_relations,
)
from discopt.export._extract import (
    extract_linear_terms,
    extract_quadratic_terms,
    flatten_variables,
)
from discopt.modeling.core import (
    Model,
    ObjectiveSense,
    VarType,
)


def to_lp(model: Model, path: str | Path | None = None) -> str | None:
    """Export a discopt Model to CPLEX LP format.

    Parameters
    ----------
    model : Model
        A discopt optimization model. Must be linear or quadratic;
        nonlinear expressions raise ``ValueError``.
    path : str or Path, optional
        If provided, write the LP string to this file path and
        return ``None``. Otherwise return the LP string.

    Returns
    -------
    str or None
        The LP string if *path* is ``None``, otherwise ``None``.

    Raises
    ------
    ValueError
        If the model contains nonlinear (non-quadratic) expressions.
    """
    # Default ``for_solve=True`` is deliberate: unlike the ``.nl`` and GAMS
    # writers, this one does *not* honour ``Constraint.rhs``. The row's right-hand
    # side below is ``-const``, recovered from the *body* alone, so a non-zero
    # ``rhs`` is silently dropped. Measured (#909): ``Constraint(w, ">=", 5.0)``
    # emitted ``c0: w >= 0`` — a silently wrong model. Keeping the refusal turns
    # that into a loud error; do not relax it without teaching the row builder
    # below to fold ``con.rhs`` in.
    model.validate()
    # A disjunction/indicator/SOS/logic row is not an algebraic row; refuse it
    # by name rather than die on ``con.body`` in the row loop below (#1218).
    refuse_non_algebraic_relations(model, "LP")
    flat_vars = flatten_variables(model)
    # Whitespace-tokenised format: names are made legal AND distinct, or a
    # reader sees a different model (#1613 C-03a). See `legal_unique_names`.
    var_names = legal_unique_names([name for name, _, _, _, _ in flat_vars], "lp")
    mvars = model._variables

    lines: list[str] = []

    # Comment header
    lines.append(f"\\ Problem: {model.name}")
    lines.append("")

    # Objective section. A builder-resident objective (`add_linear_objective` /
    # `add_quadratic_objective`, X-1) leaves a zero placeholder in `model._objective`
    # — recover its real coefficients and sense rather than emit `obj: 0`.
    assert model._objective is not None
    builder_obj = builder_objective(model)
    if builder_obj is not None:
        obj_linear, obj_quad_map, obj_const, builder_sense = builder_obj
        obj_quad = obj_quad_map or {}
        is_min = not str(builder_sense).lower().startswith("max")
    else:
        # Scalar-VALUED but array-STRUCTURED objectives (`-dm.sum(x)`,
        # `dm.sum(A @ x)`) need expanding before the extractor can walk them;
        # a vector-valued one is refused rather than truncated to element zero.
        obj_expr = scalarize_objective(model._objective.expression)
        obj_quad, obj_linear, obj_const = extract_quadratic_terms(
            obj_expr, flat_vars, model_vars=mvars
        )
        is_min = model._objective.sense == ObjectiveSense.MINIMIZE

    if is_min:
        lines.append("Minimize")
    else:
        lines.append("Maximize")

    obj_str = _format_linear_expr(obj_linear, var_names, obj_const)
    if not obj_str:
        obj_str = "0"
    lines.append(f"  obj: {obj_str}")

    # Quadratic objective
    if obj_quad:
        lines.append("  + [ ")
        q_terms: list[str] = []
        for (i, j), coeff in sorted(obj_quad.items()):
            if coeff == 0.0:
                continue
            # LP format quadratic section: coefficients are doubled
            # because the form is 0.5 * x'Qx, so we write 2*coeff
            c = 2.0 * coeff
            vi = var_names[i]
            vj = var_names[j]
            if i == j:
                q_terms.append(_format_coeff(c, len(q_terms) == 0) + f" {vi} ^ 2")
            else:
                q_terms.append(_format_coeff(c, len(q_terms) == 0) + f" {vi} * {vj}")
        lines.append("    " + " ".join(q_terms))
        lines.append("  ] / 2")

    lines.append("")

    # Subject To section. Emit both expression-path rows and fast-API /
    # builder-resident rows (X-1: rows from `add_linear_constraints` / the
    # `Model.constraint` fast path live only in the Rust builder; without them the
    # LP would have an empty `Subject To`).
    lines.append("Subject To")
    rows: list[tuple[str, dict[int, float], str, float]] = []
    for i, con in enumerate(model._constraints):
        base = con.name if con.name else f"c{i}"
        # An array-valued body is many LP rows. Without this expansion the
        # extractor walked straight into an unindexed shaped variable and
        # refused the whole model -- which locked the vectorised form of a
        # model out of LP entirely (performance-plan §41).
        bodies = scalarize_body(con.body)
        for k, body in enumerate(bodies):
            con_name = base if len(bodies) == 1 else f"{base}_{k}"
            lin, const = extract_linear_terms(body, flat_vars, model_vars=mvars)
            rows.append((con_name, lin, con.sense, -const))
    for j, brow in enumerate(iter_builder_linear_rows(model)):
        con_name = brow.name if brow.name else f"b{j}"
        rows.append((con_name, dict(brow.coeffs), brow.sense, brow.rhs))

    # `obj` (the objective's label) is reserved so a row cannot share it.
    row_names = legal_unique_names([r[0] for r in rows], "lp", ("obj",))
    rows = [(nm, *r[1:]) for nm, r in zip(row_names, rows)]
    for con_name, lin, sense_str, rhs in rows:
        expr_str = _format_linear_expr(lin, var_names, 0.0)
        if not expr_str:
            expr_str = "0"
        if sense_str == "<=":
            lp_sense = "<="
        elif sense_str == ">=":
            lp_sense = ">="
        elif sense_str == "==":
            lp_sense = "="
        else:
            raise ValueError(f"Unknown constraint sense: {sense_str}")
        lines.append(f"  {con_name}: {expr_str} {lp_sense} {_fmt_val(rhs)}")

    lines.append("")

    # Bounds section
    lines.append("Bounds")
    for vname, (_raw_name, vtype, _shape, lb, ub) in zip(var_names, flat_vars):
        if vtype == VarType.BINARY and binary_box_is_default(lb, ub):
            # Binary bounds are implicit (0 <= x <= 1) only while the box is
            # the declared one. A pinned binary falls through and gets an
            # explicit bound line, which overrides the `Binaries` listing's
            # implicit 0-1 (EX-3).
            continue
        if lb <= -1e19 and ub >= 1e19:
            lines.append(f"  {vname} Free")
        elif lb <= -1e19:
            lines.append(f"  -Inf <= {vname} <= {_fmt_val(ub)}")
        elif ub >= 1e19:
            lines.append(f"  {_fmt_val(lb)} <= {vname} <= +Inf")
        else:
            lines.append(f"  {_fmt_val(lb)} <= {vname} <= {_fmt_val(ub)}")

    lines.append("")

    # Generals (integer variables)
    int_vars = [nm for nm, (_, vt, _, _, _) in zip(var_names, flat_vars) if vt == VarType.INTEGER]
    if int_vars:
        lines.append("Generals")
        lines.append("  " + " ".join(int_vars))
        lines.append("")

    # Binaries
    bin_vars = [nm for nm, (_, vt, _, _, _) in zip(var_names, flat_vars) if vt == VarType.BINARY]
    if bin_vars:
        lines.append("Binaries")
        lines.append("  " + " ".join(bin_vars))
        lines.append("")

    lines.append("End")

    lp_str = "\n".join(piece for line in lines for piece in _wrap_line(line)) + "\n"

    if path is not None:
        Path(path).write_text(lp_str)
        return None
    return lp_str


# Width at which a row is continued on the next line (#1739). LP readers cap
# the physical line, not the row: CPLEX at 560 characters, lp_solve at 510
# (255 in 5.0/5.1). A row, an objective or a `Generals`/`Binaries` list was one
# line, so a dense model wrote lines of 100k+ characters (a 10,000-term row:
# 102,234) that those readers reject or truncate. HiGHS does not care, which is
# why the in-repo round trips never saw it. 255 is inside every limit above.
_MAX_LINE = 255


def _wrap_line(line: str, width: int = _MAX_LINE) -> list[str]:
    """Continue ``line`` on further lines so no piece exceeds ``width``.

    Breaks go only where the reader cannot misread them: before a ``+``/``-``
    term sign in an expression row, and between names in a ``Generals`` /
    ``Binaries`` list (a line of names only). A coefficient is never split from
    its variable, nor ``x * y`` / ``x ^ 2`` apart. Continuations are indented.
    A backslash comment line is continued as further comment lines.
    """
    if len(line) <= width:
        return [line]
    indent = line[: len(line) - len(line.lstrip())] or " "
    if line.lstrip().startswith("\\"):
        text = line.lstrip()[1:].strip()
        step = width - 2
        return [f"\\ {text[k : k + step]}" for k in range(0, len(text), step)]

    # Group tokens into unbreakable chunks (one term, or one name), then pack
    # chunks greedily.
    tokens = line.split()
    name_list = not any(t in ("+", "-", ":", "<=", ">=", "=", "<", ">") for t in tokens)
    chunks: list[str] = []
    for tok in tokens:
        if chunks and not (name_list or tok in ("+", "-")):
            chunks[-1] += " " + tok
        else:
            chunks.append(tok)
    out: list[str] = []
    cur = line[: len(line) - len(line.lstrip())] + chunks[0]
    for chunk in chunks[1:]:
        if len(cur) + 1 + len(chunk) > width:
            out.append(cur)
            cur = indent + "  " + chunk
        else:
            cur += " " + chunk
    out.append(cur)
    return out


def _format_linear_expr(
    coeffs: dict[int, float],
    var_names: list[str],
    constant: float,
) -> str:
    """Format a linear expression as an LP-format string."""
    parts: list[str] = []

    # Constant first if nonzero
    if constant != 0.0:
        parts.append(_fmt_val(constant))

    for idx in sorted(coeffs.keys()):
        c = coeffs[idx]
        if c == 0.0:
            continue
        vname = var_names[idx]
        parts.append(_format_coeff(c, len(parts) == 0) + f" {vname}")

    return " ".join(parts)


def _format_coeff(c: float, is_first: bool) -> str:
    """Format a coefficient with appropriate sign."""
    if is_first:
        if c == 1.0:
            return ""
        if c == -1.0:
            return "-"
        return _fmt_val(c)
    else:
        if c == 1.0:
            return "+"
        if c == -1.0:
            return "-"
        if c > 0:
            return f"+ {_fmt_val(c)}"
        return f"- {_fmt_val(abs(c))}"


def _fmt_val(value: float) -> str:
    """Format a numeric value for LP output."""
    if value == int(value) and abs(value) < 1e15:
        return str(int(value))
    return f"{value:.15g}"
