"""Utilities for multi-objective optimization.

Provides:

* :func:`ideal_point` -- per-objective best values, computed by ``k`` single-
  objective solves.
* :func:`nadir_point` -- payoff-table estimate of the worst Pareto value per
  objective.
* :func:`evaluate_expression` -- evaluate a discopt ``Expression`` at a
  solution dict, used to cross-evaluate objectives at anchor points.
* :func:`normalize_objectives` -- affine ideal/nadir normalization for
  scalarizations and indicators.

Sense handling conventions
--------------------------

Objectives are passed to scalarizers in their natural sense (an Expression)
plus a parallel ``senses`` list of ``"min"`` / ``"max"`` strings. All internal
math converts to an all-minimize convention by negating maximize objectives,
but results stored in :class:`~discopt.mo.pareto.ParetoFront` retain original
senses.
"""

from __future__ import annotations

from typing import Iterable, Optional

import numpy as np


def _as_senses(
    senses: Optional[Iterable[str]],
    k: int,
) -> list[str]:
    """Normalize the ``senses`` argument into a length-``k`` list of strings."""
    if senses is None:
        return ["min"] * k
    out = list(senses)
    if len(out) != k:
        raise ValueError(f"senses has length {len(out)}, expected {k}")
    for s in out:
        if s not in ("min", "max"):
            raise ValueError(f"sense must be 'min' or 'max', got {s!r}")
    return out


def _flatten_solution(model, x_dict: dict[str, np.ndarray]) -> np.ndarray:
    """Concatenate per-variable arrays into the flat layout used by dag_compiler."""
    parts: list[np.ndarray] = []
    for v in model._variables:
        if v.name not in x_dict:
            raise KeyError(
                f"Solution dict missing variable {v.name!r}; available keys: {sorted(x_dict)}"
            )
        arr = np.asarray(x_dict[v.name], dtype=np.float64).reshape(-1)
        if arr.size != v.size:
            raise ValueError(f"Variable {v.name} expected {v.size} values, got {arr.size}")
        parts.append(arr)
    if not parts:
        return np.zeros(0, dtype=np.float64)
    return np.concatenate(parts)


def _scalar(value) -> float:
    arr = np.asarray(value, dtype=np.float64)
    if arr.size != 1:
        raise ValueError(f"an objective must be scalar-valued; this one has shape {arr.shape}")
    return float(arr.reshape(()))


def evaluate_expression(expr, model, x_dict: dict[str, np.ndarray]) -> float:
    """Evaluate a scalar discopt Expression at a given solution.

    Lowers ``expr`` to the POUNCE tape with the model's current parameter values
    and evaluates it at the flat solution vector. No JAX: the JAX DAG compiler is
    used only for an expression the tape cannot lower (#1873).

    .. note::

       This lowers ``expr`` afresh on every call. Inside a scalarization sweep
       the same ``k`` objective expressions are evaluated many times; use an
       :class:`ObjectiveEvaluator` (via :func:`objective_evaluator`) to lower each
       objective once and reuse it, which is what the sweep helpers do (MO5).
    """
    from discopt._point_eval import evaluate_at

    x_flat = _flatten_solution(model, x_dict)
    return _scalar(evaluate_at(expr, model, x_flat))


class ObjectiveEvaluator:
    """Lower a fixed list of objective expressions once and reuse them.

    :func:`evaluate_expression` re-lowers its expression on every call. During a
    scalarization sweep the same ``k`` objectives are cross-evaluated at every
    accepted point and, ``k`` times per anchor, for the payoff table -- a full
    re-lowering each time of expressions that never change (MO5). This helper
    lowers each objective once per parameter snapshot
    (:class:`discopt._point_eval.PointEvaluator`) and reuses it.

    The tape bakes parameter values in, so the evaluator re-reads
    ``model._parameters`` on every :meth:`at` call and re-lowers only when a value
    changed: scalarizers that mutate ``Parameter.value`` between solves
    (epsilon-constraint, Tchebycheff, NBI, NNC) see the current values.

    The evaluator is keyed by object identity (``id(expr)``); pass the same
    ``Expression`` objects used to build the sweep.
    """

    def __init__(self, model, objectives: list) -> None:
        from discopt._point_eval import PointEvaluator

        self._model = model
        self._objectives = list(objectives)
        self._eval = PointEvaluator(model)

    def at(self, index: int, x_dict: dict[str, np.ndarray]) -> float:
        """Evaluate objective ``index`` at solution ``x_dict``."""
        x_flat = _flatten_solution(self._model, x_dict)
        return _scalar(self._eval(self._objectives[index], x_flat))

    def vector_at(self, x_dict: dict[str, np.ndarray]) -> np.ndarray:
        """Evaluate all objectives at ``x_dict``, returning a ``(k,)`` array."""
        x_flat = _flatten_solution(self._model, x_dict)
        return np.array(
            [_scalar(self._eval(e, x_flat)) for e in self._objectives],
            dtype=np.float64,
        )


def objective_evaluator(model, objectives: list) -> ObjectiveEvaluator:
    """Build a reusable :class:`ObjectiveEvaluator` for ``objectives``."""
    return ObjectiveEvaluator(model, objectives)


def ideal_point(
    model,
    objectives: list,
    *,
    senses: Optional[Iterable[str]] = None,
    warm_start: bool = True,
    **solve_kwargs,
) -> tuple[np.ndarray, list[dict[str, np.ndarray]]]:
    r"""Compute the ideal point and per-objective anchor solutions.

    For each objective ``f_i`` in order, sets the model objective to
    ``minimize f_i`` (or ``maximize f_i``) and solves, restoring the original
    model objective at the end. Returns the vector of per-objective best
    values (in original senses) and the list of anchor solution dicts.

    Parameters
    ----------
    model : discopt.modeling.Model
        Model carrying the decision variables and constraints. Any existing
        objective is restored before return.
    objectives : list of Expression
        Length-``k`` list of objective expressions.
    senses : iterable of {"min", "max"}, optional
        One sense per objective; default is all ``"min"``.
    warm_start : bool, default True
        Pass each anchor's solution as ``initial_solution`` to the next anchor
        solve.
    \*\*solve_kwargs : dict
        Forwarded to :meth:`discopt.modeling.Model.solve`.

    Returns
    -------
    ideal : numpy.ndarray
        Shape ``(k,)`` array of best per-objective values.
    anchors : list of dict
        ``anchors[i]`` is the variable-value dict at the optimum of ``f_i``.

    Raises
    ------
    RuntimeError
        If any of the ``k`` single-objective solves fails to return a
        feasible solution.
    """
    senses_list = _as_senses(senses, len(objectives))
    saved_objective = model._objective
    ideal = np.zeros(len(objectives), dtype=np.float64)
    anchors: list[dict[str, np.ndarray]] = []
    last_x: Optional[dict[str, np.ndarray]] = None

    try:
        for i, (expr, sense) in enumerate(zip(objectives, senses_list)):
            if sense == "min":
                model.minimize(expr)
            else:
                model.maximize(expr)

            kwargs = dict(solve_kwargs)
            if warm_start and last_x is not None and "initial_solution" not in kwargs:
                kwargs["initial_solution"] = _x_to_var_dict(model, last_x)

            result = model.solve(**kwargs)
            if result.x is None or result.objective is None:
                raise RuntimeError(
                    f"ideal-point solve for objective {i} failed: status={result.status}"
                )
            ideal[i] = float(result.objective)
            anchors.append({k: np.asarray(v).copy() for k, v in result.x.items()})
            last_x = result.x
    finally:
        model._objective = saved_objective

    return ideal, anchors


def _x_to_var_dict(model, x_dict: dict[str, np.ndarray]) -> dict:
    """Convert a name-keyed solution dict to the Variable-keyed form that
    :meth:`Model.solve` accepts as ``initial_solution``."""
    name_to_var = {v.name: v for v in model._variables}
    return {name_to_var[n]: x_dict[n] for n in x_dict if n in name_to_var}


def nadir_point(
    model,
    objectives: list,
    anchors: list[dict[str, np.ndarray]],
    *,
    senses: Optional[Iterable[str]] = None,
    evaluator: Optional["ObjectiveEvaluator"] = None,
) -> np.ndarray:
    """Payoff-table estimate of the nadir point.

    Evaluates every objective ``f_j`` at every anchor solution ``x^{(i)}*``
    and takes, for each ``j``, the worst value across anchors (max for
    minimization, min for maximization). This is the standard approximation
    for ``k = 2`` and a (potentially loose) heuristic for ``k >= 3``
    [Miettinen 1999].

    Parameters
    ----------
    model : discopt.modeling.Model
        Model carrying the decision variables and constraints.
    objectives : list of Expression
        Length-``k`` list of objective expressions.
    anchors : list of dict
        Solution dicts returned by :func:`ideal_point`, length ``k``.
    senses : iterable of {"min", "max"}, optional
        One sense per objective; default is all ``"min"``.
    evaluator : ObjectiveEvaluator, optional
        Pre-built evaluator over the same ``objectives`` (compiled once). If
        omitted, a fresh one is built. Passing a shared evaluator avoids
        recompiling the objectives (MO5).

    Returns
    -------
    numpy.ndarray
        Shape ``(k,)`` nadir estimate in original senses.
    """
    senses_list = _as_senses(senses, len(objectives))
    k = len(objectives)
    if len(anchors) != k:
        raise ValueError(f"Expected {k} anchors, got {len(anchors)}")

    if evaluator is None:
        evaluator = ObjectiveEvaluator(model, objectives)
    payoff = np.zeros((k, k), dtype=np.float64)  # payoff[i, j] = f_j at anchor i
    for i in range(k):
        payoff[i, :] = evaluator.vector_at(anchors[i])

    nadir = np.zeros(k, dtype=np.float64)
    for j in range(k):
        col = payoff[:, j]
        nadir[j] = float(col.max() if senses_list[j] == "min" else col.min())
    return nadir


def lexicographic_payoff(
    model,
    objectives: list,
    *,
    senses: Optional[Iterable[str]] = None,
    warm_start: bool = True,
    lex_tol: float = 1e-6,
    **solve_kwargs,
) -> tuple[np.ndarray, np.ndarray, list[dict[str, np.ndarray]]]:
    r"""Lexicographic payoff table (AUGMECON2, Mavrotas & Florios 2013).

    For each objective ``i`` taken as the lexicographic primary, this solves a
    sequence of ``k`` optimizations: first optimize ``f_i``; then, holding
    ``f_i`` fixed at its optimum (via a tolerance constraint), optimize the
    remaining objectives in order, each time fixing the previous ones. The
    resulting anchor is guaranteed Pareto-optimal, so the payoff-table rows do
    not contain the alternative-optima "junk" that inflates (or, for ``k >= 3``,
    can truncate) a plain single-objective payoff table [Miettinen 1999].

    This is the AUGMECON2 replacement for :func:`ideal_point` +
    :func:`nadir_point` (which build a *simple*, non-lexicographic payoff). It
    returns the ideal vector, the ``(k, k)`` payoff matrix
    (``payoff[i, j] = f_j`` at anchor ``i``), and the anchor solution dicts.

    Parameters
    ----------
    model : discopt.modeling.Model
        Model carrying the decision variables and constraints. Any existing
        objective is restored before return; the tolerance constraints added
        for the lexicographic passes are removed before return.
    objectives : list of Expression
        Length-``k`` list of objective expressions.
    senses : iterable of {"min", "max"}, optional
        One sense per objective; default is all ``"min"``.
    warm_start : bool, default True
        Warm-start each solve from the previous one.
    lex_tol : float, default 1e-6
        Absolute tolerance used to pin an already-optimized objective at its
        optimum during the subsequent lexicographic passes.
    \*\*solve_kwargs : dict
        Forwarded to :meth:`discopt.modeling.Model.solve`.

    Returns
    -------
    ideal : numpy.ndarray
        Shape ``(k,)`` best per-objective value (the diagonal of the payoff
        table), in original senses.
    payoff : numpy.ndarray
        Shape ``(k, k)`` payoff matrix, ``payoff[i, j] = f_j`` at anchor ``i``.
    anchors : list of dict
        ``anchors[i]`` is the (Pareto-optimal) anchor for lexicographic
        primary ``i``.

    Raises
    ------
    RuntimeError
        If any lexicographic solve fails to return a feasible solution.
    """
    senses_list = _as_senses(senses, len(objectives))
    k = len(objectives)
    signs = [1.0 if s == "min" else -1.0 for s in senses_list]
    saved_objective = model._objective
    tracked_cons: list = []  # lexicographic tolerance constraints, by identity
    # Compile each objective once and reuse across all lexicographic passes and
    # the payoff-table fill (MO5). The lexicographic passes add constraints (not
    # parameters), so the parameter index captured here stays valid.
    evaluator = ObjectiveEvaluator(model, objectives)

    def _drop_tracked() -> None:
        # Remove exactly the tolerance constraints we added, by identity (MO8),
        # rather than a positional slice that could also drop rows appended by
        # something else during a solve.
        ids = {id(c) for c in tracked_cons}
        model._constraints[:] = [c for c in model._constraints if id(c) not in ids]
        tracked_cons.clear()

    payoff = np.zeros((k, k), dtype=np.float64)
    anchors: list[Optional[dict[str, np.ndarray]]] = [None] * k
    last_x: Optional[dict[str, np.ndarray]] = None

    def _solve(expr, sense):
        nonlocal last_x
        if sense == "min":
            model.minimize(expr)
        else:
            model.maximize(expr)
        kwargs = dict(solve_kwargs)
        if warm_start and last_x is not None and "initial_solution" not in kwargs:
            kwargs["initial_solution"] = _x_to_var_dict(model, last_x)
        result = model.solve(**kwargs)
        if result.x is None or result.objective is None:
            raise RuntimeError(f"lexicographic payoff solve failed: status={result.status}")
        last_x = result.x
        return result

    try:
        # Lexicographic order for primary i: [i, then the rest in index order].
        for i in range(k):
            order = [i] + [j for j in range(k) if j != i]
            fixed_bounds: list[tuple[int, float]] = []
            result = None
            for pos, j in enumerate(order):
                result = _solve(objectives[j], senses_list[j])
                fj_opt = evaluator.at(j, result.x)
                # Pin f_j at its optimum for the subsequent passes, in the
                # min-convention: sign_j * f_j <= sign_j * fj_opt + lex_tol.
                if pos < len(order) - 1:
                    con = signs[j] * objectives[j] <= signs[j] * fj_opt + lex_tol
                    model.subject_to(con, name=f"_mo_lex_{i}_{j}")
                    tracked_cons.append(con)
                    fixed_bounds.append((j, fj_opt))
            # The inner loop always ran at least once (k >= 1) and _solve
            # raises on failure, so result carries a feasible solution here.
            assert result is not None and result.x is not None
            # Record the payoff row from the final (fully-refined) anchor.
            anchors[i] = {kk: np.asarray(v).copy() for kk, v in result.x.items()}
            payoff[i, :] = evaluator.vector_at(result.x)
            # Drop this primary's lexicographic tolerance constraints before
            # the next primary.
            _drop_tracked()
    finally:
        model._objective = saved_objective
        _drop_tracked()

    ideal = np.array([payoff[i, i] for i in range(k)], dtype=np.float64)
    return ideal, payoff, [a for a in anchors if a is not None]


def nadir_from_payoff(
    payoff: np.ndarray,
    *,
    senses: Optional[Iterable[str]] = None,
) -> np.ndarray:
    """Nadir estimate from a payoff matrix (column-worst per objective)."""
    payoff = np.asarray(payoff, dtype=np.float64)
    k = payoff.shape[1]
    senses_list = _as_senses(senses, k)
    nadir = np.zeros(k, dtype=np.float64)
    for j in range(k):
        col = payoff[:, j]
        nadir[j] = float(col.max() if senses_list[j] == "min" else col.min())
    return nadir


def normalize_objectives(
    objectives: np.ndarray,
    ideal: np.ndarray,
    nadir: np.ndarray,
    *,
    senses: Optional[Iterable[str]] = None,
    epsilon: float = 1e-12,
) -> np.ndarray:
    """Affine normalize objectives into ``[0, 1]`` using the ideal/nadir range.

    Converts each objective so that 0 corresponds to the ideal and 1 to the
    nadir, regardless of sense. The output is always oriented so that smaller
    is better.

    Parameters
    ----------
    objectives : numpy.ndarray
        Array of shape ``(n, k)`` or ``(k,)``.
    ideal, nadir : numpy.ndarray
        Length-``k`` reference vectors in original senses.
    senses : iterable of {"min", "max"}, optional
        Defaults to all ``"min"``.
    epsilon : float
        Small floor on the denominator to avoid division by zero when ideal
        and nadir coincide.

    Returns
    -------
    numpy.ndarray
        Normalized array with the same shape as *objectives*.
    """
    objectives = np.asarray(objectives, dtype=np.float64)
    k = objectives.shape[-1]
    senses_list = _as_senses(senses, k)
    signs = np.array([1.0 if s == "min" else -1.0 for s in senses_list], dtype=np.float64)
    span = signs * (nadir - ideal)
    span = np.where(np.abs(span) < epsilon, epsilon, span)
    return np.asarray(signs * (objectives - ideal) / span, dtype=np.float64)
