"""
GAMS (.gms) parser for MINLP models.

Hand-written recursive-descent parser that reads GAMS source and builds
a discopt Model.  Targets the subset of GAMS needed for MINLP:

  Sets, Scalars, Parameters, Tables, Variables (positive/binary/integer/free),
  Equations with =e=/=l=/=g=, bounds (.lo/.up/.fx), sum/prod over indexed
  domains, nonlinear functions (exp, log, sin, cos, sqrt, power, sqr, ...),
  Model, Solve ... using MINLP minimizing/maximizing.
"""

from __future__ import annotations

import math
import re
import warnings
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from discopt.modeling.core import Model

import numpy as np


def _gams_round(x: float, ndigits: int = 0) -> float:
    """GAMS ``round(x, n)``: half away from zero (#1288).

    Python's :func:`round` rounds half to even, so ``round(2.5)`` is 2 where GAMS
    gives 3 — a folded bound that differs from the model that was written.

    Non-finite input passes through, as :func:`round` did: a GAMS source may hold
    ``INF``/``NA``, and :func:`math.floor` raises on both (``OverflowError`` for
    an infinity, ``ValueError`` for a NaN) rather than returning them. Folding
    ``round(INF)`` must not be how ``from_gams`` reports a crash.
    """
    if not math.isfinite(x):
        return x
    scale = 10.0**ndigits
    scaled = abs(x) * scale
    if not math.isfinite(scaled):
        # ``ndigits`` large enough to overflow the scaling: ``x`` already carries
        # no fractional part that many digits in, so it is its own rounding.
        # Reached through the scaling, never through ``x`` itself, which is finite
        # by the guard above.
        return x
    return float(math.copysign(math.floor(scaled + 0.5), x) / scale)


def _gams_errorf(x: float) -> float:
    """GAMS ``errorf(x)``: the standard normal CDF, ``(1 + erf(x/√2))/2`` (#1288)."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _fold_constant(expr) -> float | None:
    """Value of a scalar expression built only from constants and arithmetic.

    ``None`` whenever anything else appears (a variable, a function call, an array
    constant), so a caller folds only what is certainly a number: ``floor(-2.5)``
    reaches :meth:`GamsParser._map_func` as ``neg(2.5)``, not as a ``Constant``.
    """
    from discopt.modeling import core as dm

    if isinstance(expr, dm.Constant):
        value = np.asarray(expr.value)
        return float(value) if value.shape == () else None
    if isinstance(expr, dm.UnaryOp) and expr.op == "neg":
        v = _fold_constant(expr.operand)
        return None if v is None else -v
    if isinstance(expr, dm.BinaryOp) and expr.op in ("+", "-", "*", "/", "**"):
        lv = _fold_constant(expr.left)
        rv = _fold_constant(expr.right)
        if lv is None or rv is None:
            return None
        if expr.op == "+":
            return lv + rv
        if expr.op == "-":
            return lv - rv
        if expr.op == "*":
            return lv * rv
        if expr.op == "/":
            return lv / rv if rv != 0.0 else None
        try:
            result = lv**rv
        except (OverflowError, ZeroDivisionError):
            return None
        return float(result) if isinstance(result, float) else None
    return None


# ── Token types ────────────────────────────────────────────────
class _Tok:
    IDENT = "IDENT"
    NUMBER = "NUMBER"
    STRING = "STRING"
    SYMBOL = "SYMBOL"
    EOF = "EOF"


@dataclass
class Token:
    kind: str
    value: str
    line: int = 0
    col: int = 0


# ── Lexer ──────────────────────────────────────────────────────
_NUM_RE = re.compile(r"[+-]?(?:\d+\.?\d*|\.\d+)(?:[Ee][+-]?\d+)?")
_IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_STRING_RE = re.compile(r'"[^"]*"|\'[^\']*\'')


_SET_DIRECTIVE_RE = re.compile(
    r"^\$(?:if\s+not\s+set\s+(?P<guard>\w+)\s+\$)?"
    r"(?:set|setglobal|setlocal)\s+(?P<name>\w+)\s*(?P<value>.*?)\s*$",
    re.I,
)
_COMPILE_VAR_RE = re.compile(r"%([A-Za-z_][\w.]*)%")


def _substitute_compile_vars(src: str) -> str:
    """Apply ``$set`` compile-time variables to ``%name%`` references.

    MINLPLib writes ``$if not set NLP $set NLP NLP`` and then ``Solve m using
    %NLP% ...``. The tokenizer used to drop every ``%`` it met, which read that
    as ``NLP`` only by accident; it now refuses unknown characters (#1666), so
    the substitution GAMS performs is done here. Control lines are left for the
    tokenizer to skip, and so is a ``$ontext`` block. A reference to a variable
    no ``$set`` defined is refused.
    """
    defined: dict[str, str] = {}
    out: list[str] = []
    in_text = False
    for line in src.split("\n"):
        head = line.lstrip().lower()
        if line.startswith("$"):
            if head.startswith("$ontext"):
                in_text = True
            elif head.startswith("$offtext"):
                in_text = False
            m = _SET_DIRECTIVE_RE.match(line)
            if m and not in_text:
                guard = m.group("guard")
                if guard is None or guard.lower() not in defined:
                    value = m.group("value")
                    if len(value) >= 2 and value[0] == value[-1] and value[0] in "'\"":
                        value = value[1:-1]
                    defined[m.group("name").lower()] = value
            out.append(line)
            continue
        if in_text or "%" not in line:
            out.append(line)
            continue

        def sub(m: re.Match, lineno: int = len(out) + 1) -> str:
            name = m.group(1).lower()
            if name not in defined:
                raise GamsParseError(
                    f"Undefined compile-time variable %{m.group(1)}% at line {lineno}"
                )
            return defined[name]

        out.append(_COMPILE_VAR_RE.sub(sub, line))
    return "\n".join(out)


def _tokenize(src: str) -> list[Token]:
    src = _substitute_compile_vars(src)
    tokens: list[Token] = []
    i = 0
    line = 1
    col = 1
    n = len(src)
    while i < n:
        ch = src[i]
        # newline
        if ch == "\n":
            i += 1
            line += 1
            col = 1
            continue
        # whitespace. A tab advances to the next 8-column stop, so a table laid
        # out with tabs keeps its values under their column headers (#1666).
        if ch == "\t":
            i += 1
            col += 8 - (col - 1) % 8
            continue
        if ch in " \r":
            i += 1
            col += 1
            continue
        # line comment  * at start-ish or $
        if ch == "*" and (col == 1 or (i > 0 and src[i - 1] == "\n")):
            while i < n and src[i] != "\n":
                i += 1
            continue
        if ch == "$":
            # dollar control line — skip unless it's a dollar condition
            # inside an expression (handled by parser).  At line start it's
            # a control directive we skip.
            if col == 1:
                directive = _IDENT_RE.match(src, i + 1)
                if directive and directive.group().lower() == "ontext":
                    # A $ontext ... $offtext block is a comment: skip to the
                    # line after $offtext rather than reading it as statements.
                    end = re.compile(r"^\$offtext\b.*$", re.I | re.M).search(src, i)
                    if end is None:
                        raise GamsParseError(f"$ontext at line {line} has no matching $offtext")
                    line += src.count("\n", i, end.end())
                    i = end.end()
                    continue
                while i < n and src[i] != "\n":
                    i += 1
                continue
            # otherwise treat $ as a symbol for dollar conditions
            tokens.append(Token(_Tok.SYMBOL, "$", line, col))
            i += 1
            col += 1
            continue
        # string literal
        m = _STRING_RE.match(src, i)
        if m and ch in ('"', "'"):
            tokens.append(Token(_Tok.STRING, m.group()[1:-1], line, col))
            col += m.end() - m.start()
            i = m.end()
            continue
        # two-char symbols  =e= =l= =g= .. **
        if i + 2 < n and src[i : i + 3] in ("=e=", "=l=", "=g=", "=E=", "=L=", "=G="):
            tokens.append(Token(_Tok.SYMBOL, src[i : i + 3].lower(), line, col))
            i += 3
            col += 3
            continue
        if i + 1 < n and src[i : i + 2] == "**":
            tokens.append(Token(_Tok.SYMBOL, "**", line, col))
            i += 2
            col += 2
            continue
        if i + 1 < n and src[i : i + 2] == "..":
            tokens.append(Token(_Tok.SYMBOL, "..", line, col))
            i += 2
            col += 2
            continue
        # number (but not if preceded by ident char — that's part of ident)
        if ch.isdigit() or (ch == "." and i + 1 < n and src[i + 1].isdigit()):
            m = _NUM_RE.match(src, i)
            if m:
                tokens.append(Token(_Tok.NUMBER, m.group(), line, col))
                col += m.end() - m.start()
                i = m.end()
                continue
        # identifier
        if ch.isalpha() or ch == "_":
            m = _IDENT_RE.match(src, i)
            if m:
                tokens.append(Token(_Tok.IDENT, m.group(), line, col))
                col += m.end() - m.start()
                i = m.end()
                continue
        # single char symbols
        if ch in "()[]{},.;:+-*/=<>":
            tokens.append(Token(_Tok.SYMBOL, ch, line, col))
            i += 1
            col += 1
            continue
        # slash
        if ch == "/":
            tokens.append(Token(_Tok.SYMBOL, "/", line, col))
            i += 1
            col += 1
            continue
        # A character no rule reads is refused: skipping it silently changed
        # what the model meant (#1666).
        raise GamsParseError(f"Unexpected character {ch!r} at line {line}, column {col}")
    tokens.append(Token(_Tok.EOF, "", line, col))
    return tokens


# ── AST node types ─────────────────────────────────────────────
@dataclass
class GamsSet:
    name: str
    elements: list[str]
    description: str = ""
    domain: list[str] = field(default_factory=list)


@dataclass
class GamsScalar:
    name: str
    value: float = 0.0
    description: str = ""


@dataclass
class GamsParameter:
    name: str
    domain: list[str] = field(default_factory=list)
    data: dict = field(default_factory=dict)  # tuple-key -> float
    description: str = ""


@dataclass
class GamsTable:
    name: str
    domain: list[str] = field(default_factory=list)
    data: dict = field(default_factory=dict)
    description: str = ""


@dataclass
class GamsVariable:
    name: str
    var_type: str = "free"  # free, positive, negative, binary, integer
    domain: list[str] = field(default_factory=list)
    description: str = ""


@dataclass
class GamsEquation:
    name: str
    domain: list[str] = field(default_factory=list)
    description: str = ""


@dataclass
class GamsEquationDef:
    name: str
    domain: list[str] = field(default_factory=list)
    dollar_cond: object = None  # optional filter expression
    lhs: object = None  # expression AST
    sense: str = "=e="  # =e=, =l=, =g=
    rhs: object = None  # expression AST


@dataclass
class GamsBound:
    var_name: str
    suffix: str  # lo, up, fx, l
    domain: list[str] = field(default_factory=list)
    dollar_cond: object = None
    expr: object = None


@dataclass
class GamsModel:
    name: str
    equations: list[str] = field(default_factory=list)  # or ["all"]


@dataclass
class GamsSolve:
    model_name: str
    model_type: str = "minlp"
    sense: str = "minimizing"
    objective_var: str = ""


# Expression AST nodes
@dataclass
class ExprNum:
    value: float


@dataclass
class ExprRef:
    name: str


@dataclass
class ExprIndex:
    name: str
    indices: list  # list of expression ASTs


@dataclass
class ExprAttr:
    """A ``<name>.<attr>`` reference, ``m.modelstat`` or ``x.l(i)`` (#2002).

    GAMS lets an expression read an attribute of a model (``modelstat``,
    ``objval``, ...) or of a variable (``l``, ``lo``, ``up``, ...). Parsing it
    as a bare ``ExprRef(name)`` left ``.attr`` in the token stream and
    desynchronized the parser. The reader does not evaluate attributes: a
    post-solve reporting assignment that reads one is skipped (it cannot
    affect the generated model), and anywhere else it is refused by name.
    """

    name: str
    attr: str
    indices: list = field(default_factory=list)


@dataclass
class ExprLabel:
    """A quoted set-element label, ``'1'`` in ``x('1')`` (#1503).

    Only meaningful as an index of an indexed reference; anywhere else in an
    expression it is refused, since a label is not a number.
    """

    value: str


@dataclass
class ExprBinOp:
    op: str
    left: object
    right: object


@dataclass
class ExprUnaryMinus:
    operand: object


@dataclass
class ExprFunc:
    func: str
    args: list


@dataclass
class ExprSum:
    index_names: list[str]
    dollar_cond: object  # optional
    body: object


@dataclass
class ExprProd:
    index_names: list[str]
    dollar_cond: object
    body: object


@dataclass
class ExprSMinMax:
    """``smin(i, expr)`` / ``smax(i, expr)`` -- a min/max over set elements.

    #1333: this used to parse into ``ExprFunc(op, [body])``, which DISCARDED
    the index names and the ``$`` condition. With them gone the constant
    evaluator could not fold it, returned None, and the ``$``-condition sites
    read None as "include the row" -- so ``c1$(smin(i, d(i)) > 10)..`` with
    ``smin = 1`` generated a row GAMS does not, and the solve returned 3.0 for
    a model whose optimum is -5. Keeping the index set makes it foldable over
    constant data; over an ENDOGENOUS body it is still refused by name in the
    equation-body builder (#1325), which is a different, sound refusal.
    """

    op: str  # "smin" | "smax"
    index_names: list[str]
    dollar_cond: object  # optional
    body: object


@dataclass
class ExprCard:
    set_name: str


@dataclass
class ExprOrd:
    set_name: str


# ── Recursive-descent parser ──────────────────────────────────
class GamsParseError(Exception):
    pass


def _iter_ast(node):
    """Yield every AST node reachable from *node* (dataclass fields and lists)."""
    stack = [node]
    while stack:
        cur = stack.pop()
        if isinstance(cur, list | tuple):
            stack.extend(cur)
            continue
        if not hasattr(cur, "__dataclass_fields__"):
            continue
        yield cur
        for f in cur.__dataclass_fields__:
            stack.append(getattr(cur, f))


def _contains_attr(node) -> bool:
    return any(isinstance(n, ExprAttr) for n in _iter_ast(node))


def _references_name(node, name: str) -> bool:
    """Does the expression AST *node* reference symbol *name* (case-insensitive)?"""
    key = name.lower()
    return any(
        isinstance(n, ExprRef | ExprIndex | ExprAttr) and n.name.lower() == key
        for n in _iter_ast(node)
    )


def _attr_error(node: "ExprAttr") -> "GamsParseError":
    return GamsParseError(
        f"Attribute reference '{node.name}.{node.attr}' is not supported by the GAMS "
        "reader here; it only skips post-solve reporting assignments that read one."
    )


def _check_min_max_arity(fn: str, nargs: int) -> None:
    """Refuse a GAMS ``min``/``max`` call with fewer than two arguments.

    #1325: both evaluation arms reach this, so the one-argument form can no
    longer mean one thing when its argument folds to a constant and crash with a
    numpy ``TypeError`` when it does not.
    """
    if nargs < 2:
        raise GamsParseError(
            f"GAMS {fn}() takes two or more arguments, got {nargs}. "
            f"The {fn} of a single value is that value; write it directly."
        )


class _Parser:
    """Recursive-descent parser for GAMS .gms files."""

    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.pos = 0
        # Collected declarations
        self.sets: dict[str, GamsSet] = {}
        self.aliases: dict[str, str] = {}  # alias -> original set
        self.scalars: dict[str, GamsScalar] = {}
        self.parameters: dict[str, GamsParameter] = {}
        self.tables: dict[str, GamsTable] = {}
        self.variables: dict[str, GamsVariable] = {}
        self.equations: dict[str, GamsEquation] = {}
        self.equation_defs: list[GamsEquationDef] = []
        self.bounds: list[GamsBound] = []
        self.models: dict[str, GamsModel] = {}
        self.solves: list[GamsSolve] = []
        self.post_solve_reports: list = []
        self.options: dict[str, str] = {}
        self.param_assigns: list[tuple] = []  # (name, domain, dollar, expr)
        self.loop_stmts: list[tuple] = []  # (kind, index_names, body_tokens)

    # ── Helpers ──

    def _cur(self) -> Token:
        return self.tokens[self.pos]

    def _peek(self, offset: int = 0) -> Token:
        idx = self.pos + offset
        if idx < len(self.tokens):
            return self.tokens[idx]
        return self.tokens[-1]

    def _advance(self) -> Token:
        t = self.tokens[self.pos]
        if self.pos < len(self.tokens) - 1:
            self.pos += 1
        return t

    def _expect(self, kind: str, value: str | None = None) -> Token:
        t = self._cur()
        if t.kind != kind:
            raise GamsParseError(
                f"Expected {kind}({value!r}) at line {t.line}, got {t.kind}({t.value!r})"
            )
        if value is not None and t.value.lower() != value.lower():
            raise GamsParseError(f"Expected {value!r} at line {t.line}, got {t.value!r}")
        return self._advance()

    def _match_ident(self, value: str) -> bool:
        t = self._cur()
        return t.kind == _Tok.IDENT and t.value.lower() == value.lower()

    def _match_sym(self, value: str) -> bool:
        t = self._cur()
        return t.kind == _Tok.SYMBOL and t.value == value

    def _at_end(self) -> bool:
        return self._cur().kind == _Tok.EOF

    def _skip_semi(self):
        if self._match_sym(";"):
            self._advance()

    # ── Labels and explanatory text (#1666) ──

    @staticmethod
    def _touches(a: Token, b: Token) -> bool:
        """Does ``b`` start where ``a`` ends, with no whitespace between?"""
        return a.kind != _Tok.STRING and a.line == b.line and b.col == a.col + len(a.value)

    def _read_label_parts(self) -> list[str]:
        """Read one data label and return its per-dimension parts.

        A GAMS label is a quoted string or an unbroken run of letters, digits,
        ``_``, ``-`` and ``+``; ``.`` joins the parts of a multi-dimensional key.
        The tokenizer splits ``san-diego`` into three tokens and reads ``1.2`` as
        one NUMBER, so the label is rebuilt from tokens that touch and then split
        at its dots. Reading ``san-diego`` as two labels built a different model
        with no diagnostic (#1666).
        """
        parts: list[str] = []
        while True:
            t = self._cur()
            if t.kind == _Tok.STRING:
                parts.append(self._advance().value)
            elif t.kind in (_Tok.IDENT, _Tok.NUMBER):
                run = [self._advance()]
                while True:
                    nxt = self._cur()
                    if not self._touches(run[-1], nxt):
                        break
                    if nxt.kind in (_Tok.IDENT, _Tok.NUMBER):
                        run.append(self._advance())
                    elif (
                        nxt.kind == _Tok.SYMBOL
                        and nxt.value in ("-", "+", ".")
                        and self._peek(1).kind in (_Tok.IDENT, _Tok.NUMBER, _Tok.STRING)
                        and self._touches(nxt, self._peek(1))
                    ):
                        run.append(self._advance())
                    else:
                        break
                raw = "".join(tok.value for tok in run)
                pieces = raw.split(".")
                if any(not piece for piece in pieces):
                    raise GamsParseError(f"Malformed label {raw!r} at line {t.line}")
                parts.extend(pieces)
            else:
                raise GamsParseError(
                    f"Expected a label at line {t.line}, column {t.col}, got {t.value!r}"
                )
            if self._match_sym("."):
                self._advance()
                continue
            return parts

    def _parse_decl_text(self, *, whole_line: bool = False) -> str:
        """Explanatory text after a declared name (and domain), quoted or not.

        GAMS lets the text go unquoted: it runs to the end of the line, or to the
        ``/`` that opens the data, or to the ``,`` that starts the next item.
        Reading the words as more declared names misassigned every declaration
        after them (#1666). ``whole_line`` is a Table's text, which ends only at
        the end of the line.
        """
        line = self.tokens[self.pos - 1].line
        if self._cur().kind == _Tok.STRING and self._cur().line == line:
            return self._advance().value
        words: list[str] = []
        while True:
            t = self._cur()
            if t.kind == _Tok.EOF or t.line != line:
                break
            if t.kind == _Tok.SYMBOL and (
                t.value in ("/", ";") or (t.value == "," and not whole_line)
            ):
                break
            words.append(self._advance().value)
        return " ".join(words)

    # ── Keywords ──

    _SET_KW = {"set", "sets"}
    _SCALAR_KW = {"scalar", "scalars"}
    _PARAM_KW = {"parameter", "parameters"}
    _TABLE_KW = {"table", "tables"}
    _VAR_KW = {"variable", "variables"}
    _EQ_KW = {"equation", "equations"}
    _MODEL_KW = {"model"}
    _SOLVE_KW = {"solve"}
    _OPTION_KW = {"option", "options"}
    _DISPLAY_KW = {"display"}
    _ABORT_KW = {"abort"}
    _ALIAS_KW = {"alias"}
    _VARTYPE_KW = {
        "positive",
        "negative",
        "free",
        "binary",
        "integer",
        "semicont",
        "semiint",
        "sos1",
        "sos2",
    }
    _UNSUPPORTED_KW = {
        "put",
        "file",
        "execute",
        "system",
        "acronym",
        "acronyms",
    }

    def _cur_kw(self) -> str | None:
        t = self._cur()
        if t.kind != _Tok.IDENT:
            return None
        return t.value.lower()

    # ── Top-level parse ──

    def parse(self):
        while not self._at_end():
            kw = self._cur_kw()
            if kw in self._SET_KW:
                self._parse_set_decl()
            elif kw in self._ALIAS_KW:
                self._parse_alias()
            elif kw in self._SCALAR_KW:
                self._parse_scalar_decl()
            elif kw in self._PARAM_KW:
                self._parse_param_decl()
            elif kw in self._TABLE_KW:
                self._parse_table_decl()
            elif kw in self._VARTYPE_KW:
                self._parse_variable_decl()
            elif kw in self._VAR_KW:
                self._parse_variable_decl()
            elif kw in self._EQ_KW:
                self._parse_equation_decl()
            elif kw in self._MODEL_KW:
                self._parse_model_decl()
            elif kw in self._SOLVE_KW:
                self._parse_solve_stmt()
            elif kw in self._OPTION_KW:
                self._parse_option_stmt()
            elif kw in self._DISPLAY_KW:
                self._skip_to_semi()
            elif kw in self._ABORT_KW:
                self._skip_to_semi()
            elif kw == "loop":
                self._parse_loop_stmt()
            elif kw == "for":
                self._parse_loop_stmt()  # for has same structure as loop
            elif kw == "while":
                self._parse_while_stmt()
            elif kw == "repeat":
                self._parse_repeat_stmt()
            elif kw in ("if", "ifthen"):
                self._parse_if_stmt()
            elif kw in self._UNSUPPORTED_KW:
                t = self._cur()
                warnings.warn(
                    f"GAMS '{t.value}' statement at line {t.line} is not supported "
                    f"and was skipped. The resulting model may be incomplete.",
                    stacklevel=2,
                )
                self._skip_to_semi()
            elif self._is_equation_def():
                self._parse_equation_def()
            elif self._is_bound_assign():
                self._parse_bound_assign()
            elif self._is_param_assign():
                self._parse_param_assign_stmt()
            else:
                t = self._cur()
                if t.kind == _Tok.IDENT:
                    warnings.warn(
                        f"Unrecognized GAMS statement '{t.value}' at line {t.line} "
                        f"was skipped. The resulting model may be incomplete.",
                        stacklevel=2,
                    )
                self._advance()

    def _skip_to_semi(self):
        while not self._at_end() and not self._match_sym(";"):
            self._advance()
        self._skip_semi()

    # ── Flow control (loop, if, for, while, repeat) ──

    def _parse_loop_stmt(self):
        """Parse: loop(set_name, body_statements) ;

        Executes body_statements for each element in the set.  The body
        may contain parameter assignments or bound assignments.
        """
        self._advance()  # skip 'loop' / 'for'
        self._expect(_Tok.SYMBOL, "(")
        # Parse index set(s)
        index_names = self._parse_index_list_for_loop()
        self._expect(_Tok.SYMBOL, ",")
        # Parse body statements until closing paren
        body_tokens = self._collect_balanced_tokens("(", ")")
        self._expect(_Tok.SYMBOL, ")")
        self._skip_semi()
        # Store for later execution during model build
        self.loop_stmts.append(("loop", index_names, body_tokens))

    def _parse_if_stmt(self):
        """Parse: if(condition, true_body [, else_body]) ;"""
        self._advance()  # skip 'if'
        self._expect(_Tok.SYMBOL, "(")
        # Collect entire if body until matching close paren
        body_tokens = self._collect_balanced_tokens("(", ")")
        self._expect(_Tok.SYMBOL, ")")
        self._skip_semi()
        self.loop_stmts.append(("if", [], body_tokens))

    def _parse_while_stmt(self):
        """Parse: while(condition, body) ; — skip with warning."""
        t = self._cur()
        warnings.warn(
            f"GAMS 'while' statement at line {t.line} is not fully supported "
            f"and was skipped. The resulting model may be incomplete.",
            stacklevel=2,
        )
        self._advance()
        self._skip_to_semi()

    def _parse_repeat_stmt(self):
        """Parse: repeat(body, condition) ; — skip with warning."""
        t = self._cur()
        warnings.warn(
            f"GAMS 'repeat' statement at line {t.line} is not fully supported "
            f"and was skipped. The resulting model may be incomplete.",
            stacklevel=2,
        )
        self._advance()
        self._skip_to_semi()

    def _parse_index_list_for_loop(self) -> list[str]:
        """Parse index names in a loop header, handling (i,j) or just i."""
        names: list[str] = []
        if self._match_sym("("):
            self._advance()
            while not self._match_sym(")"):
                if self._cur().kind == _Tok.IDENT:
                    names.append(self._advance().value)
                elif self._match_sym(","):
                    self._advance()
                else:
                    self._advance()
            self._expect(_Tok.SYMBOL, ")")
        else:
            names.append(self._expect(_Tok.IDENT).value)
        return names

    def _collect_balanced_tokens(self, open_ch: str, close_ch: str) -> list[Token]:
        """Collect tokens until matching close, respecting nesting."""
        depth = 0
        collected: list[Token] = []
        while not self._at_end():
            t = self._cur()
            if t.kind == _Tok.SYMBOL and t.value == open_ch:
                depth += 1
            elif t.kind == _Tok.SYMBOL and t.value == close_ch:
                if depth == 0:
                    break
                depth -= 1
            collected.append(self._advance())
        return collected

    # ── Lookahead helpers ──

    def _is_equation_def(self) -> bool:
        """name(..) .. expr =e= expr ;"""
        if self._cur().kind != _Tok.IDENT:
            return False
        # scan ahead for ".."
        j = self.pos + 1
        while j < len(self.tokens) and j < self.pos + 30:
            t = self.tokens[j]
            if t.kind == _Tok.SYMBOL and t.value == "..":
                return True
            if t.kind == _Tok.SYMBOL and t.value == ";":
                return False
            j += 1
        return False

    def _is_bound_assign(self) -> bool:
        """name.lo/up/fx(...) = expr ;"""
        if self._cur().kind != _Tok.IDENT:
            return False
        j = self.pos + 1
        if j < len(self.tokens) and self.tokens[j].value == ".":
            j2 = j + 1
            if j2 < len(self.tokens) and self.tokens[j2].value.lower() in (
                "lo",
                "up",
                "fx",
                "l",
                "m",
                "prior",
                "scale",
            ):
                return True
        return False

    def _is_param_assign(self) -> bool:
        """name(...) = expr ; where name is a known param or scalar."""
        if self._cur().kind != _Tok.IDENT:
            return False
        name = self._cur().value.lower()
        if name in {k.lower() for k in self.scalars} | {k.lower() for k in self.parameters}:
            return True
        return False

    # ── Set declarations ──

    def _parse_set_decl(self):
        self._advance()  # skip 'set'/'sets'
        while not self._at_end() and not self._match_sym(";"):
            name_tok = self._expect(_Tok.IDENT)
            name = name_tok.value
            # optional domain
            domain: list[str] = []
            if self._match_sym("("):
                domain = self._parse_domain()
            desc = self._parse_decl_text()
            # data in /.../
            elements: list[str] = []
            if self._match_sym("/"):
                self._advance()  # skip /
                elements = self._parse_set_elements()
                self._expect(_Tok.SYMBOL, "/")
            self.sets[name] = GamsSet(name, elements, desc, domain)
            # optional comma between items
            if self._match_sym(","):
                self._advance()

        self._skip_semi()

    def _parse_set_elements(self) -> list[str]:
        elements: list[str] = []
        while not self._at_end() and not self._match_sym("/"):
            tok = self._cur()
            parts = self._read_label_parts()
            if len(parts) != 1:
                raise GamsParseError(
                    f"Multi-dimensional set element {'.'.join(parts)!r} at line "
                    f"{tok.line} is not supported"
                )
            if self._match_sym("*"):  # range  a1*a5
                self._advance()
                end = self._read_label_parts()
                if len(end) != 1:
                    raise GamsParseError(f"Malformed set range at line {tok.line}")
                elements.extend(self._expand_range(parts[0], end[0]))
            else:
                elements.append(parts[0])
            # The rest of the line up to ',' or '/' is the element's text.
            self._parse_decl_text()
            if self._match_sym(","):
                self._advance()
        return elements

    def _expand_range(self, start: str, end: str) -> list[str]:
        """Expand 1*5 or i1*i5 style ranges."""
        try:
            return [str(x) for x in range(int(start), int(end) + 1)]
        except ValueError:
            pass
        # try prefix+number pattern
        m1 = re.match(r"([A-Za-z_]*)(\d+)$", start)
        m2 = re.match(r"([A-Za-z_]*)(\d+)$", end)
        if m1 and m2 and m1.group(1) == m2.group(1):
            prefix = m1.group(1)
            return [f"{prefix}{x}" for x in range(int(m1.group(2)), int(m2.group(2)) + 1)]
        raise GamsParseError(f"Cannot expand set range {start}*{end}")

    # ── Alias ──

    def _parse_alias(self):
        self._advance()  # skip 'alias'
        self._expect(_Tok.SYMBOL, "(")
        names: list[str] = []
        while not self._match_sym(")"):
            if self._cur().kind == _Tok.IDENT:
                names.append(self._advance().value)
            elif self._match_sym(","):
                self._advance()
            else:
                self._advance()
        self._expect(_Tok.SYMBOL, ")")
        self._skip_semi()
        if len(names) >= 2:
            original = names[0]
            for alias_name in names[1:]:
                self.aliases[alias_name] = original

    # ── Scalars ──

    def _parse_scalar_decl(self):
        self._advance()  # skip 'scalar'/'scalars'
        while not self._at_end() and not self._match_sym(";"):
            name = self._expect(_Tok.IDENT).value
            desc = self._parse_decl_text()
            val = 0.0
            if self._match_sym("/"):
                self._advance()
                if self._cur().kind == _Tok.NUMBER:
                    val = float(self._advance().value)
                elif self._match_sym("-"):
                    self._advance()
                    val = -float(self._expect(_Tok.NUMBER).value)
                elif self._match_sym("+"):
                    self._advance()
                    val = float(self._expect(_Tok.NUMBER).value)
                self._expect(_Tok.SYMBOL, "/")
            self.scalars[name] = GamsScalar(name, val, desc)
            if self._match_sym(","):
                self._advance()
        self._skip_semi()

    # ── Domain parsing ──

    def _parse_domain(self) -> list[str]:
        """Parse (i, j, k) domain list, consuming parens.

        Entries may be set/alias names (``x.lo(s1)``) or concrete quoted
        element labels (``x.lo('1')`` / ``x.lo('1', '2')``). A quoted label is
        captured verbatim; downstream (`_apply_bounds`) treats any entry that is
        not a known set name as a literal single element, which is how
        heterogeneous per-element bounds emitted by `to_gams` round-trip (X-2,
        #413).
        """
        self._expect(_Tok.SYMBOL, "(")
        names: list[str] = []
        while not self._match_sym(")"):
            if self._cur().kind in (_Tok.IDENT, _Tok.STRING):
                names.append(self._advance().value)
            elif self._match_sym(","):
                self._advance()
            else:
                self._advance()
        self._expect(_Tok.SYMBOL, ")")
        return names

    # ── Parameters ──

    def _parse_param_decl(self):
        self._advance()  # skip 'parameter'/'parameters'
        while not self._at_end() and not self._match_sym(";"):
            name = self._expect(_Tok.IDENT).value
            domain: list[str] = []
            if self._match_sym("("):
                domain = self._parse_domain()
            desc = self._parse_decl_text()
            data: dict = {}
            if self._match_sym("/"):
                self._advance()
                data = self._parse_param_data()
                self._expect(_Tok.SYMBOL, "/")
            self.parameters[name] = GamsParameter(name, domain, data, desc)
            if self._match_sym(","):
                self._advance()
        self._skip_semi()

    def _parse_param_data(self) -> dict:
        """``label[.label] value`` records between the slashes of a Parameter.

        #1333: the label/value split used to be a one-token lookahead --
        "this NUMBER is a label if an IDENT or NUMBER follows it". A SIGNED
        value breaks that, because the tokenizer emits ``-`` as its own SYMBOL:
        in ``/1 2, 2 -1, 3 4/`` the record ``2 -1`` failed the test, so ``2``
        was read as a VALUE under the empty key and ``-1`` overwrote it. The
        model silently lost ``a('2') = -1`` (and kept a phantom empty-key entry)
        -- ``sum(a)`` came back 6 where GAMS gives 5. Alphabetic labels were
        unaffected, which is why it went unseen. Five of the issue's six data
        forms were wrong, including the newline-separated one.

        A record is one label (dotted for a multi-dimensional key) followed by
        its value, so that is what this reads. The one ambiguity a label chain
        cannot settle by itself is a bare number with nothing after it --
        ``Parameter p /3.5/`` -- which is a VALUE with no label; it is decided
        by looking for the value that a label must be followed by.
        """
        data: dict = {}
        while not self._at_end() and not self._match_sym("/"):
            start = self.pos
            keys: list[str] = []
            if self._cur().kind in (_Tok.IDENT, _Tok.NUMBER, _Tok.STRING) and not (
                self._cur_is_inf()
            ):
                keys = self._read_label_parts()
            if keys and not self._value_follows():
                # No value after the label. An IDENT label keeps GAMS's
                # value-less form (``/a, b, c/`` -> 0.0); a lone NUMBER was the
                # value itself, under the empty key.
                if self.pos == start + 1 and self.tokens[start].kind == _Tok.NUMBER:
                    self.pos = start
                    keys = []
            val_line = self._cur().line
            val = self._read_signed_value() if self._value_follows() else 0.0
            key = tuple(keys) if len(keys) > 1 else (keys[0] if keys else ("",))
            data[key] = val
            if self._match_sym(","):
                self._advance()
            elif not self._match_sym("/") and self._cur().line == val_line:
                t = self._cur()
                raise GamsParseError(
                    f"Unexpected {t.value!r} after a data record at line {t.line}, column {t.col}"
                )
        return data

    def _cur_is_inf(self) -> bool:
        t = self._cur()
        return t.kind == _Tok.IDENT and t.value.lower() == "inf"

    def _read_signed_value(self) -> float:
        """A data value: an optionally signed number or ``inf``."""
        neg = False
        if self._match_sym("-"):
            self._advance()
            neg = True
        elif self._match_sym("+"):
            self._advance()
        if self._cur_is_inf():
            self._advance()
            val = float("inf")
        else:
            val = float(self._expect(_Tok.NUMBER).value)
        return -val if neg else val

    def _value_follows(self) -> bool:
        """Is the parser sitting on a numeric value (with an optional sign)?"""
        if self._match_sym("-") or self._match_sym("+"):
            nxt = self._peek(1)
            return nxt.kind == _Tok.NUMBER or (
                nxt.kind == _Tok.IDENT and nxt.value.lower() == "inf"
            )
        return self._cur().kind == _Tok.NUMBER or self._cur_is_inf()

    # ── Tables ──

    def _parse_table_decl(self):
        """``Table name(domain) text`` followed by a header line and data rows.

        GAMS places a table by layout, so this reads it by line: the first body
        line (and each line starting ``+``) holds column labels, every other line
        is a row label followed by values, and a value belongs to the column
        whose label it sits under. Collecting only IDENT headers lost numeric
        labels entirely, and assigning values left to right moved a value past a
        blank cell into the wrong column (#1666). A value under no column label
        is refused.
        """
        self._advance()  # skip 'table'
        name = self._expect(_Tok.IDENT).value
        domain: list[str] = []
        if self._match_sym("("):
            domain = self._parse_domain()
        desc = self._parse_decl_text(whole_line=True)
        lines: list[list[Token]] = []
        while not self._at_end() and not self._match_sym(";"):
            t = self._advance()
            if lines and lines[-1][0].line == t.line:
                lines[-1].append(t)
            else:
                lines.append([t])
        self._expect(_Tok.SYMBOL, ";")

        data: dict = {}
        headers: list[tuple[list[str], int, int]] | None = None
        rows_seen: set[tuple[str, ...]] = set()  # per header block
        for toks in lines:
            if toks[0].kind == _Tok.SYMBOL and toks[0].value == "+":
                headers = self._table_header(toks[1:])
                rows_seen = set()
                continue
            if headers is None:
                headers = self._table_header(toks)
                continue
            row = self._table_row(name, domain, toks, headers, data)
            key = tuple(part.lower() for part in row)
            if row and key in rows_seen:
                raise GamsParseError(
                    f"Table '{name}': row {'.'.join(row)!r} at line {toks[0].line} "
                    f"repeats a row of the same block"
                )
            rows_seen.add(key)
        self.tables[name] = GamsTable(name, domain, data, desc)

    def _table_labels(self, toks: list[Token]) -> list[tuple[list[str], int, int]]:
        """Split one table line into labels with their column spans."""
        sub = _Parser([*toks, Token(_Tok.EOF, "", -1, 0)])
        out = []
        while not sub._at_end():
            first = sub._cur()
            parts = sub._read_label_parts()
            last = sub.tokens[sub.pos - 1]
            width = len(last.value) + (2 if last.kind == _Tok.STRING else 0)
            out.append((parts, first.col, last.col + width))
        return out

    def _table_header(self, toks: list[Token]) -> list[tuple[list[str], int, int]]:
        if not toks:
            raise GamsParseError("Table continuation '+' has no column labels")
        return self._table_labels(toks)

    def _table_row(self, name, domain, toks, headers, data):
        line = toks[0].line
        n_col = len(headers[0][0])
        has_label = not domain or len(domain) > n_col
        row: list[str] = []
        k = 0
        if has_label:
            sub = _Parser([*toks, Token(_Tok.EOF, "", -1, 0)])
            row = sub._read_label_parts()
            k = sub.pos
        values: list[tuple[float, int, int]] = []
        while k < len(toks):
            start = toks[k]
            sign = 1.0
            if start.kind == _Tok.SYMBOL and start.value in ("-", "+") and k + 1 < len(toks):
                sign = -1.0 if start.value == "-" else 1.0
                k += 1
            t = toks[k]
            if t.kind == _Tok.NUMBER:
                val = float(t.value)
            elif t.kind == _Tok.IDENT and t.value.lower() == "inf":
                val = float("inf")
            else:
                raise GamsParseError(
                    f"Table '{name}': expected a number at line {line}, column {t.col}, "
                    f"got {t.value!r}"
                )
            values.append((sign * val, start.col, t.col + len(t.value)))
            k += 1
        for val, v0, v1 in values:
            under = [parts for parts, h0, h1 in headers if v0 < h1 and h0 < v1]
            if len(under) != 1:
                raise GamsParseError(
                    f"Table '{name}': the value {val:g} at line {line}, column {v0} "
                    f"does not sit under exactly one column label"
                )
            key = [*row, *under[0]]
            if domain and len(key) != len(domain):
                raise GamsParseError(
                    f"Table '{name}' has {len(domain)} dimensions but line {line} "
                    f"gives the key {'.'.join(key)!r}"
                )
            data[tuple(key) if len(key) > 1 else key[0]] = val
        return row

    # ── Variables ──

    def _parse_variable_decl(self):
        var_type = "free"
        explicit_type = False
        kw = self._cur_kw()
        if kw in self._VARTYPE_KW:
            var_type = kw
            explicit_type = True
            self._advance()
        # optional 'variable'/'variables' keyword
        if self._cur_kw() in self._VAR_KW:
            self._advance()
        while not self._at_end() and not self._match_sym(";"):
            name = self._expect(_Tok.IDENT).value
            domain: list[str] = []
            if self._match_sym("("):
                domain = self._parse_domain()
            desc = self._parse_decl_text()
            existing = self.variables.get(name)
            if existing is None:
                self.variables[name] = GamsVariable(name, var_type, domain, desc)
            else:
                self._redeclare_variable(existing, var_type, explicit_type, domain, desc)
            if self._match_sym(","):
                self._advance()
        self._skip_semi()

    def _redeclare_variable(
        self,
        gv: GamsVariable,
        var_type: str,
        explicit_type: bool,
        domain: list[str],
        desc: str,
    ) -> None:
        """Apply a repeated declaration of ``gv`` (#1986).

        GAMS lets a type statement repeat only a variable's name
        (``Variables x(i,j); Positive Variable x;`` -- GAMS's own
        ``trnsport.gms``). That sets the type and keeps the domain. Replacing
        the symbol dropped ``(i,j)`` and read the model as a scalar ``x``,
        which solved ``infeasible``. A repeated declaration whose domain or
        type conflicts with the first is refused rather than guessed at.
        """
        if domain and domain != gv.domain:
            raise GamsParseError(
                f"variable {gv.name!r} is redeclared with domain ({', '.join(domain)}) "
                f"but was declared with domain ({', '.join(gv.domain)}); GAMS rejects "
                "a domain change on redeclaration"
            )
        if explicit_type and var_type != gv.var_type:
            if gv.var_type != "free":
                raise GamsParseError(
                    f"variable {gv.name!r} is redeclared as {var_type} but was "
                    f"declared {gv.var_type}; a conflicting type redeclaration is "
                    "not supported"
                )
            gv.var_type = var_type
        if desc and not gv.description:
            gv.description = desc

    # ── Equations declaration ──

    def _parse_equation_decl(self):
        self._advance()  # skip 'equation'/'equations'
        while not self._at_end() and not self._match_sym(";"):
            name = self._expect(_Tok.IDENT).value
            domain: list[str] = []
            if self._match_sym("("):
                domain = self._parse_domain()
            desc = self._parse_decl_text()
            self.equations[name] = GamsEquation(name, domain, desc)
            if self._match_sym(","):
                self._advance()
        self._skip_semi()

    # ── Equation definitions ──

    def _parse_equation_def(self):
        name = self._expect(_Tok.IDENT).value
        domain: list[str] = []
        if self._match_sym("("):
            domain = self._parse_domain()
        dollar_cond = None
        if self._match_sym("$"):
            dollar_cond = self._parse_dollar_cond()
        self._expect(_Tok.SYMBOL, "..")
        lhs = self._parse_expr()
        sense_tok = self._advance()
        sense = sense_tok.value.lower()
        rhs = self._parse_expr()
        self._skip_semi()
        self.equation_defs.append(GamsEquationDef(name, domain, dollar_cond, lhs, sense, rhs))

    # ── Bound assignments ──

    def _parse_bound_assign(self):
        var_name = self._expect(_Tok.IDENT).value
        self._expect(_Tok.SYMBOL, ".")
        suffix = self._expect(_Tok.IDENT).value.lower()
        domain: list[str] = []
        if self._match_sym("("):
            domain = self._parse_domain()
        dollar_cond = None
        if self._match_sym("$"):
            dollar_cond = self._parse_dollar_cond()
        self._expect(_Tok.SYMBOL, "=")
        expr = self._parse_expr()
        self._skip_semi()
        self.bounds.append(GamsBound(var_name, suffix, domain, dollar_cond, expr))

    # ── Parameter assignment ──

    def _parse_param_assign_stmt(self):
        name = self._expect(_Tok.IDENT).value
        domain: list[str] = []
        if self._match_sym("("):
            domain = self._parse_domain()
        dollar_cond = None
        if self._match_sym("$"):
            dollar_cond = self._parse_dollar_cond()
        self._expect(_Tok.SYMBOL, "=")
        expr = self._parse_expr()
        self._skip_semi()
        if self.solves and (_contains_attr(expr) or _contains_attr(dollar_cond)):
            # Post-solve reporting (``MODELSTAT = m.modelstat;``, #2002): it
            # reads the solve's results, and GAMS executes it after the model
            # is generated, so it cannot change the model this reader builds.
            # Kept for inspection, never evaluated.
            self.post_solve_reports.append((name, domain, dollar_cond, expr))
            return
        self.param_assigns.append((name, domain, dollar_cond, expr))

    # ── Model / Solve / Option ──

    def _parse_model_decl(self):
        self._advance()  # skip 'model'
        name = self._expect(_Tok.IDENT).value
        self._parse_decl_text()  # explanatory text
        self._expect(_Tok.SYMBOL, "/")
        eqs: list[str] = []
        if self._match_ident("all"):
            eqs = ["all"]
            self._advance()
        else:
            while not self._match_sym("/"):
                if self._cur().kind == _Tok.IDENT:
                    eqs.append(self._advance().value)
                elif self._match_sym(","):
                    self._advance()
                else:
                    self._advance()
        self._expect(_Tok.SYMBOL, "/")
        self._skip_semi()
        self.models[name] = GamsModel(name, eqs)

    def _parse_solve_stmt(self):
        self._advance()  # skip 'solve'
        model_name = self._expect(_Tok.IDENT).value
        self._expect(_Tok.IDENT, "using")
        model_type = self._expect(_Tok.IDENT).value.lower()
        # Optimization solves carry a sense keyword + objective variable
        # ("... minimizing z"). Objectiveless model types — CNS (Constrained
        # Nonlinear System) and MCP (Mixed Complementarity Problem) — have
        # neither; they are pure feasibility / square-system solves. Only consume
        # the sense + objective when a sense keyword actually follows, so an
        # objectiveless solve parses as a feasibility problem (no objective set)
        # instead of failing on the missing "minimizing"/"maximizing" token.
        sense = "minimizing"
        obj_var = ""
        cur = self._cur()
        if cur.kind == _Tok.IDENT and cur.value.lower() in ("minimizing", "maximizing"):
            sense = self._advance().value.lower()
            obj_var = self._expect(_Tok.IDENT).value
        self._skip_semi()
        self.solves.append(GamsSolve(model_name, model_type, sense, obj_var))

    def _parse_option_stmt(self):
        self._advance()  # skip 'option'
        key = self._expect(_Tok.IDENT).value
        self._expect(_Tok.SYMBOL, "=")
        val = self._advance().value
        self._skip_semi()
        self.options[key] = val

    # ── Dollar condition ──

    def _parse_dollar_cond(self):
        self._advance()  # skip $
        if self._match_sym("("):
            self._advance()
            expr = self._parse_expr()
            self._expect(_Tok.SYMBOL, ")")
            return expr
        return self._parse_atom()

    # ── Expression parser (operator precedence, explicit stack) ──
    #
    # Grammar (unchanged from the recursive-descent version this replaces):
    #
    #     expr  := add [cmp add]           cmp: < > <= >= = <>
    #     add   := mul (('+'|'-') mul)*
    #     mul   := unary (('*'|'/') unary)*
    #     unary := ('-'|'+') power | power
    #     power := atom ['**' unary]
    #     atom  := number | '(' expr ')' | name | name(...) | func(...) | sum(...)
    #
    # It was written as one Python function per level, so every parenthesis
    # cost ~6 frames and nesting ~170 deep raised RecursionError. ``to_gams``
    # writes exactly that: ``dm.sum`` over n terms scalarizes to a left-deep
    # fold that prints as n opening parentheses, so the reader could not read
    # the writer's output back for n in the low hundreds (#1739). Here
    # parentheses, operators and signs live on explicit stacks; only function
    # arguments, index lists and ``sum``-style bodies still recurse, and their
    # depth is the nesting of calls in the source, not the number of terms.

    _CMP_OPS = frozenset(("<", ">", "<=", ">=", "=", "<>"))
    # Binary precedence; ``**`` is right-associative. A prefix sign binds
    # tighter than ``*`` and looser than ``**`` (``-a**b`` is ``-(a**b)``,
    # ``-a*b`` is ``(-a)*b``).
    _BIN_PREC = {"+": 2, "-": 2, "*": 3, "/": 3, "**": 5, **{op: 1 for op in _CMP_OPS}}
    _NEG_PREC = 4

    def _parse_expr(self):
        vals: list = []
        # ("(", "") | ("neg", "") | ("bin", op)
        ops: list[tuple[str, str]] = []
        cmp_seen = [False]  # one entry per open parenthesis, plus the outer level

        def prec(entry) -> int:
            kind, op = entry
            return self._NEG_PREC if kind == "neg" else self._BIN_PREC[op]

        def reduce_top() -> None:
            kind, op = ops.pop()
            if kind == "neg":
                vals.append(ExprUnaryMinus(vals.pop()))
            else:
                right = vals.pop()
                vals.append(ExprBinOp(op, vals.pop(), right))

        def push_binary(op: str) -> None:
            p = self._BIN_PREC[op]
            right_assoc = op == "**"
            while ops and ops[-1][0] != "(":
                q = prec(ops[-1])
                if q > p or (q == p and not right_assoc):
                    reduce_top()
                else:
                    break
            ops.append(("bin", op))

        while True:
            # Operand position: optional sign (not two in a row), then '(' or an atom.
            sign_ok = True
            while True:
                t = self._cur()
                if t.kind == _Tok.SYMBOL and t.value in ("-", "+") and sign_ok:
                    self._advance()
                    if t.value == "-":
                        ops.append(("neg", ""))
                    sign_ok = False
                elif t.kind == _Tok.SYMBOL and t.value == "(":
                    self._advance()
                    ops.append(("(", ""))
                    cmp_seen.append(False)
                    sign_ok = True
                else:
                    vals.append(self._parse_atom())
                    break

            # Operator position: close parentheses, then a binary operator or stop.
            while True:
                t = self._cur()
                v = t.value if t.kind == _Tok.SYMBOL else None
                if v == ")" and len(cmp_seen) > 1:
                    self._advance()
                    while ops[-1][0] != "(":
                        reduce_top()
                    ops.pop()
                    cmp_seen.pop()
                    continue
                if v == "**":
                    push_binary("**")
                elif v in ("*", "/") and not (v == "*" and self._peek(1).value == "*"):
                    push_binary(v)
                elif v in ("+", "-"):
                    push_binary(v)
                elif v in self._CMP_OPS and not cmp_seen[-1]:
                    cmp_seen[-1] = True
                    push_binary(v)
                else:
                    if len(cmp_seen) > 1:
                        self._expect(_Tok.SYMBOL, ")")  # raises: unclosed '('
                    while ops:
                        reduce_top()
                    return vals[0]
                self._advance()
                break

    # GAMS built-in functions
    _GAMS_FUNCS = {
        "exp",
        "log",
        "log2",
        "log10",
        "sqrt",
        "sqr",
        "abs",
        "sin",
        "cos",
        "tan",
        "arcsin",
        "arccos",
        "arctan",
        "sinh",
        "cosh",
        "tanh",
        "power",
        "rpower",
        "sign",
        "signpower",
        "min",
        "max",
        "ceil",
        "floor",
        "round",
        "mod",
        "uniform",
        "normal",
        "errorf",
        "sigmoid",
    }

    _INDEXED_OPS = {"sum", "prod", "smin", "smax"}

    def _parse_atom(self):
        t = self._cur()

        # number literal
        if t.kind == _Tok.NUMBER:
            self._advance()
            return ExprNum(float(t.value))

        # parenthesized expression
        if t.kind == _Tok.SYMBOL and t.value == "(":
            self._advance()
            expr = self._parse_expr()
            self._expect(_Tok.SYMBOL, ")")
            return expr

        # identifier: could be func, indexed op, indexed ref, or simple ref
        if t.kind == _Tok.IDENT:
            name_lower = t.value.lower()

            # indexed operations: sum, prod, smin, smax
            if name_lower in self._INDEXED_OPS:
                return self._parse_indexed_op(name_lower)

            # card(set), ord(set)
            if name_lower == "card":
                self._advance()
                self._expect(_Tok.SYMBOL, "(")
                sname = self._expect(_Tok.IDENT).value
                self._expect(_Tok.SYMBOL, ")")
                return ExprCard(sname)
            if name_lower == "ord":
                self._advance()
                self._expect(_Tok.SYMBOL, "(")
                sname = self._expect(_Tok.IDENT).value
                self._expect(_Tok.SYMBOL, ")")
                return ExprOrd(sname)

            # built-in functions
            if name_lower in self._GAMS_FUNCS and self._peek(1).value == "(":
                return self._parse_func_call()

            # attribute reference: name.attr or name.attr(i,j) (#2002)
            if (
                self._peek(1).kind == _Tok.SYMBOL
                and self._peek(1).value == "."
                and self._peek(2).kind == _Tok.IDENT
            ):
                self._advance()  # name
                self._advance()  # '.'
                attr = self._advance().value.lower()
                indices: list = []
                if self._match_sym("("):
                    indices = self._parse_indexed_ref_indices()
                return ExprAttr(t.value, attr, indices)

            # indexed reference: name(i,j)
            if self._peek(1).value == "(":
                # check if this is a function call on expressions
                # vs an indexed variable/param reference
                # heuristic: if name is a known variable/param/set, it's indexing
                return self._parse_indexed_ref()

            # simple name reference
            self._advance()
            return ExprRef(t.value)

        raise GamsParseError(f"Unexpected token {t.kind}({t.value!r}) at line {t.line}")

    def _parse_indexed_op(self, op_name: str):
        self._advance()  # skip sum/prod/smin/smax
        self._expect(_Tok.SYMBOL, "(")
        # parse index list
        index_names = self._parse_index_list()
        # optional dollar condition
        dollar_cond = None
        if self._match_sym("$"):
            dollar_cond = self._parse_dollar_cond()
        self._expect(_Tok.SYMBOL, ",")
        body = self._parse_expr()
        self._expect(_Tok.SYMBOL, ")")
        if op_name == "sum":
            return ExprSum(index_names, dollar_cond, body)
        elif op_name == "prod":
            return ExprProd(index_names, dollar_cond, body)
        else:
            # #1333: keep the index names and the condition. They used to be
            # dropped here (``ExprFunc(op_name, [body])``), which is what made
            # the construct unfoldable and let it fail open in a condition.
            return ExprSMinMax(op_name, index_names, dollar_cond, body)

    def _parse_index_list(self) -> list[str]:
        names: list[str] = []
        if self._match_sym("("):
            self._advance()
            while not self._match_sym(")"):
                if self._cur().kind == _Tok.IDENT:
                    names.append(self._advance().value)
                elif self._match_sym(","):
                    self._advance()
                else:
                    self._advance()
            self._expect(_Tok.SYMBOL, ")")
        else:
            names.append(self._expect(_Tok.IDENT).value)
        return names

    def _parse_func_call(self):
        func_name = self._advance().value.lower()
        self._expect(_Tok.SYMBOL, "(")
        args: list = []
        while not self._match_sym(")"):
            args.append(self._parse_expr())
            if self._match_sym(","):
                self._advance()
        self._expect(_Tok.SYMBOL, ")")
        return ExprFunc(func_name, args)

    def _parse_indexed_ref(self):
        name = self._advance().value
        return ExprIndex(name, self._parse_indexed_ref_indices())

    def _parse_indexed_ref_indices(self) -> list:
        self._expect(_Tok.SYMBOL, "(")
        indices: list = []
        while not self._match_sym(")"):
            # A quoted element label, ``x('1')`` -- the form ``to_gams`` itself
            # writes for every element of an array variable (#1503). It is an
            # index position only; a label is never an arithmetic operand.
            if self._cur().kind == _Tok.STRING and self._peek(1).value in (",", ")"):
                indices.append(ExprLabel(self._advance().value))
            else:
                indices.append(self._parse_expr())
            if self._match_sym(","):
                self._advance()
        self._expect(_Tok.SYMBOL, ")")
        return indices


# ── Model builder: parsed GAMS AST → discopt Model ────────────
class _ModelBuilder:
    """Convert parsed GAMS declarations into a discopt Model."""

    def __init__(self, parser: _Parser):
        self.p = parser
        # resolved set elements as ordered lists
        self.set_elements: dict[str, list[str]] = {}
        # resolved parameter values: name -> {tuple_key: float}
        self.param_values: dict[str, dict] = {}
        # scalar values: name -> float
        self.scalar_values: dict[str, float] = {}
        # discopt variable references: (var_name, *indices) -> Expression
        from discopt.modeling.core import Variable

        self.dvar_map: dict[str, Variable] = {}
        self.model: Model | None = None
        self._initial_values: dict = {}  # var_name -> {flat_idx: float} or float

    def build(self) -> Model:
        from discopt.modeling.core import Model

        # 1. Resolve sets (including aliases)
        self._resolve_sets()
        # 1b. Every data label must lie in its declared domain (#1666)
        self._check_data_domains()
        # 2. Resolve scalars and parameters
        self._resolve_scalars()
        self._resolve_parameters()
        # 3. Execute loop/if statements (may modify params, scalars, bounds)
        self._execute_loops()
        # 4. Create discopt model
        solve = self.p.solves[0] if self.p.solves else None
        model_name = solve.model_name if solve else "gams_model"
        m = Model(model_name)
        self.model = m
        # 5. Create variables (a substitutable objective variable is not one, #2002)
        self._subst_obj_var = self._substitutable_objective_var(solve)
        self._create_variables(m)
        # 6. Build equations (constraints + objective)
        self._build_equations(m, solve)
        # 7. Apply bounds (lo, up, fx) and initial values (l)
        self._apply_bounds(m)
        # 7b. Semicontinuous / semi-integer: needs the final bounds.
        self._lower_semi_variables(m)
        # 8. Store initial values on the model
        if self._initial_values:
            m._gams_initial_values = self._initial_values  # type: ignore[attr-defined]
        return m

    def _resolve_sets(self):
        for name, gs in self.p.sets.items():
            self.set_elements[name] = gs.elements
        # aliases point to the same elements
        for alias, original in self.p.aliases.items():
            if original in self.set_elements:
                self.set_elements[alias] = self.set_elements[original]

    def _check_data_domains(self):
        """Refuse data whose labels are not members of the declared domain.

        GAMS rejects such data at compile time ($170 domain violation). Accepting
        it is how a misread label used to vanish: a mangled ``san`` or a
        description word read as a label became an entry no equation ever looked
        up, and the model solved with that data missing (#1666). Labels are
        case-insensitive in GAMS, so each one is rewritten to the spelling its
        set declared -- otherwise ``Seattle`` data never reached the ``seattle``
        rows. A ``*`` (universe) domain position is not checked.
        """

        def canon(owner: str, domain: list[str], key) -> tuple[str, ...]:
            parts = key if isinstance(key, tuple) else (key,)
            if parts == ("",) or len(parts) != len(domain):
                raise GamsParseError(
                    f"'{owner}' is declared over ({', '.join(domain)}) but has the data "
                    f"key {'.'.join(parts) or '(none)'!r}"
                )
            out = []
            for part, dom in zip(parts, domain):
                if dom == "*":
                    out.append(part)
                    continue
                elems = self._lookup_set_elements(dom)
                if elems is None:
                    raise GamsParseError(f"'{owner}' is declared over the unknown set '{dom}'")
                spelled = {e.lower(): e for e in elems}.get(part.lower())
                if spelled is None:
                    raise GamsParseError(
                        f"'{owner}': the label {part!r} is not an element of the set '{dom}'"
                    )
                out.append(spelled)
            return tuple(out)

        def fix(owner: str, domain: list[str], data: dict) -> dict:
            fixed = {}
            for key, val in data.items():
                parts = canon(owner, domain, key)
                new_key = parts if len(parts) > 1 else parts[0]
                if new_key in fixed:
                    raise GamsParseError(f"'{owner}': the key {new_key!r} is given twice")
                fixed[new_key] = val
            return fixed

        for gs in self.p.sets.values():
            if gs.domain:
                elems = [canon(gs.name, gs.domain, e)[0] for e in gs.elements]
                gs.elements[:] = elems
        for gp in self.p.parameters.values():
            if gp.domain:
                gp.data = fix(gp.name, gp.domain, gp.data)
        for gt in self.p.tables.values():
            if gt.domain:
                gt.data = fix(gt.name, gt.domain, gt.data)

    def _resolve_scalars(self):
        for name, gs in self.p.scalars.items():
            self.scalar_values[name] = gs.value

    def _resolve_parameters(self):
        for name, gp in self.p.parameters.items():
            self.param_values[name] = dict(gp.data)
        for name, gt in self.p.tables.items():
            self.param_values[name] = dict(gt.data)
        # Process assignment statements for known params/scalars
        for pname, domain, dollar, expr in self.p.param_assigns:
            self._apply_param_assign(pname, domain, dollar, expr, {})

    def _lookup_set_elements(self, name: str) -> list[str] | None:
        """Resolve a set/alias name to its element list, or None if unknown."""
        resolved = self.p.aliases.get(name, name)
        if resolved in self.set_elements:
            return self.set_elements[resolved]
        for k, v in self.set_elements.items():
            if k.lower() == resolved.lower():
                return v
        return None

    def _apply_param_assign(self, pname: str, domain: list[str], dollar, expr, env: dict):
        """Execute one parameter/scalar assignment statement.

        Handles scalar targets (``s = expr``) and indexed targets
        (``p(i) = expr``, ``p('a') = expr``), iterating free domain positions
        over their set elements; loop indices arrive pre-bound in ``env``.
        An assignment whose $-condition or right-hand side cannot be
        evaluated raises :class:`GamsParseError` — silently dropping it
        would build a wrong model with no diagnostic (#745).
        """
        import itertools

        if not domain:
            if dollar is not None:
                cond = self._eval_dollar_cond(dollar, env)
                if cond is None:
                    raise GamsParseError(f"Cannot evaluate $-condition on assignment to '{pname}'")
                if cond == 0.0:
                    return
            val = self._eval_const_expr_with_env(expr, env)
            if val is None:
                raise GamsParseError(
                    f"Cannot evaluate right-hand side of assignment to '{pname}'; "
                    f"refusing to silently drop the assignment"
                )
            if pname in self.scalar_values:
                self.scalar_values[pname] = val
                return
            gp = self.p.parameters.get(pname)
            if gp is not None and gp.domain:
                raise GamsParseError(f"Assignment to indexed parameter '{pname}' without a domain")
            # scalar (0-dim) parameter declared via Parameter
            self.scalar_values[pname] = val
            self.param_values[pname] = {("",): val}
            return

        # Indexed target: fix loop-bound positions, iterate free set positions,
        # and treat non-set entries as concrete element labels (p('a') = ...).
        index_sets: list[list[str]] = []
        for d in domain:
            if d in env:
                index_sets.append([env[d]])
            else:
                elems = self._lookup_set_elements(d)
                if elems is not None:
                    index_sets.append(list(elems))
                else:
                    index_sets.append([d])
        for combo in itertools.product(*index_sets):
            local_env = dict(env)
            for d, elem in zip(domain, combo):
                local_env[d] = elem
            if dollar is not None:
                cond = self._eval_dollar_cond(dollar, local_env)
                if cond is None:
                    raise GamsParseError(f"Cannot evaluate $-condition on assignment to '{pname}'")
                if cond == 0.0:
                    continue
            val = self._eval_const_expr_with_env(expr, local_env)
            if val is None:
                raise GamsParseError(
                    f"Cannot evaluate right-hand side of assignment to "
                    f"'{pname}({', '.join(combo)})'; refusing to silently drop "
                    f"the assignment"
                )
            key: object = tuple(combo) if len(combo) > 1 else combo[0]
            self.param_values.setdefault(pname, {})[key] = val

    def _execute_loops(self):
        """Execute loop/if statements, modifying scalars, params, and bounds."""
        import itertools

        for kind, index_names, body_tokens in self.p.loop_stmts:
            if kind == "loop":
                # Resolve index sets
                index_sets = []
                for iname in index_names:
                    resolved = iname
                    if iname in self.p.aliases:
                        resolved = self.p.aliases[iname]
                    if resolved in self.set_elements:
                        index_sets.append(self.set_elements[resolved])
                    elif iname in self.set_elements:
                        index_sets.append(self.set_elements[iname])
                    else:
                        warnings.warn(
                            f"Unknown set '{iname}' in loop — skipping loop body.",
                            stacklevel=2,
                        )
                        break
                else:
                    for combo in itertools.product(*index_sets):
                        env = {}
                        for iname, val in zip(index_names, combo):
                            env[iname] = val
                        self._execute_body(body_tokens, env)
            elif kind == "if":
                # Simple if: parse condition from first part of body,
                # evaluate, and execute remainder if true.
                # For now, execute body unconditionally and let
                # individual assignments handle correctness.
                self._execute_body(body_tokens, {})

    def _execute_body(self, tokens: list, env: dict):
        """Execute body tokens from a loop, processing assignments and bounds."""
        # Re-parse the body tokens as a mini-program
        body_parser = _Parser(tokens + [Token(_Tok.EOF, "", 0, 0)])
        body_parser.sets = dict(self.p.sets)
        body_parser.aliases = dict(self.p.aliases)
        body_parser.scalars = dict(self.p.scalars)
        body_parser.parameters = dict(self.p.parameters)
        body_parser.tables = dict(self.p.tables)
        body_parser.variables = dict(self.p.variables)
        body_parser.equations = dict(self.p.equations)
        body_parser.parse()

        # Process any param assignments from the body
        for pname, domain, dollar, expr in body_parser.param_assigns:
            self._apply_param_assign(pname, domain, dollar, expr, env)

        # Process any bound assignments from the body
        for b in body_parser.bounds:
            val = self._eval_const_expr_with_env(b.expr, env)
            if val is not None:
                # Store for later application after variables are created
                self.p.bounds.append(
                    GamsBound(b.var_name, b.suffix, b.domain, b.dollar_cond, ExprNum(val))
                )

    def _eval_const_expr_with_env(self, expr, env: dict) -> float | None:
        """Evaluate a constant expression with loop-index substitution.

        Returns None when the expression is not a compile-time constant
        (e.g. it references a variable). Callers decide whether None is a
        signal ("this is not constant", used when probing) or an error
        (assignment statements refuse loudly rather than dropping, #745).
        The ``env`` maps loop/domain index names to concrete set elements;
        it is threaded through every recursion so compound expressions like
        ``ord(i) * 10`` fold correctly inside loops and indexed assignments.
        """
        import itertools

        if isinstance(expr, ExprNum):
            return expr.value
        if isinstance(expr, ExprAttr):
            raise _attr_error(expr)
        if isinstance(expr, ExprRef):
            if expr.name in env:
                # Resolve to scalar value if it's a scalar ref
                elem = env[expr.name]
                if elem in self.scalar_values:
                    return self.scalar_values[elem]
                # Try as a number
                try:
                    return float(elem)
                except (ValueError, TypeError):
                    pass
            if expr.name in self.scalar_values:
                return self.scalar_values[expr.name]
            return None
        if isinstance(expr, ExprIndex):
            # Resolve indexed param with env substitution
            if expr.name in self.param_values:
                indices = []
                for idx in expr.indices:
                    if isinstance(idx, ExprLabel):
                        indices.append(idx.value)
                    elif isinstance(idx, ExprRef) and idx.name in env:
                        indices.append(env[idx.name])
                    else:
                        v = self._eval_const_expr_with_env(idx, env)
                        if v is not None:
                            indices.append(str(int(v)) if v == int(v) else str(v))
                        else:
                            return None
                pdata = self.param_values[expr.name]
                key = tuple(indices) if len(indices) > 1 else indices[0]
                if key in pdata:
                    return float(pdata[key])
                tkey = tuple(indices)
                if tkey in pdata:
                    return float(pdata[tkey])
                # GAMS semantics: unset parameter entries read as 0
                return 0.0
            return None
        if isinstance(expr, ExprUnaryMinus):
            v = self._eval_const_expr_with_env(expr.operand, env)
            return -v if v is not None else None
        if isinstance(expr, ExprBinOp):
            lv = self._eval_const_expr_with_env(expr.left, env)
            rv = self._eval_const_expr_with_env(expr.right, env)
            if lv is None or rv is None:
                return None
            if expr.op == "+":
                return lv + rv
            if expr.op == "-":
                return lv - rv
            if expr.op == "*":
                return float(lv * rv)
            if expr.op == "/":
                return float(lv / rv) if rv != 0 else None
            if expr.op == "**":
                return float(lv**rv)
            # Comparison operators return 1.0 (true) or 0.0 (false)
            if expr.op == "<":
                return 1.0 if lv < rv else 0.0
            if expr.op == ">":
                return 1.0 if lv > rv else 0.0
            if expr.op == "<=":
                return 1.0 if lv <= rv else 0.0
            if expr.op == ">=":
                return 1.0 if lv >= rv else 0.0
            if expr.op == "=" or expr.op == "==":
                return 1.0 if lv == rv else 0.0
            if expr.op == "<>":
                return 1.0 if lv != rv else 0.0
        if isinstance(expr, ExprFunc):
            raw_args = [self._eval_const_expr_with_env(a, env) for a in expr.args]
            if any(a is None for a in raw_args):
                return None
            fargs: list[float] = [a for a in raw_args if a is not None]
            fn = expr.func.lower()
            if fn == "exp":
                return math.exp(fargs[0])
            if fn == "log":
                return math.log(fargs[0])
            if fn == "log2":
                return math.log2(fargs[0])
            if fn == "log10":
                return math.log10(fargs[0])
            if fn == "sqrt":
                return math.sqrt(fargs[0])
            if fn == "sqr":
                return float(fargs[0] ** 2)
            if fn == "abs":
                return float(abs(fargs[0]))
            if fn == "power":
                return float(fargs[0] ** fargs[1])
            if fn == "rpower":
                # GAMS rPower(x, y) = x**y, defined for x >= 0 only (a negative
                # base is a GAMS execution error); leave that unevaluable rather
                # than let Python return a complex number.
                if fargs[0] < 0:
                    return None
                return float(fargs[0] ** fargs[1])
            if fn == "sin":
                return math.sin(fargs[0])
            if fn == "cos":
                return math.cos(fargs[0])
            if fn == "tan":
                return math.tan(fargs[0])
            if fn == "arcsin":
                return math.asin(fargs[0])
            if fn == "arccos":
                return math.acos(fargs[0])
            if fn == "arctan":
                return math.atan(fargs[0])
            if fn == "sinh":
                return math.sinh(fargs[0])
            if fn == "cosh":
                return math.cosh(fargs[0])
            if fn == "tanh":
                return math.tanh(fargs[0])
            # GAMS min/max take two or more arguments. Checked in BOTH arms
            # (#1325): this one used to accept ``min(4)`` and return 4 while the
            # endogenous arm crashed on the same text with a bare numpy
            # ``TypeError`` about ``np.minimum``, so one spelling of one
            # construct gave two unrelated answers depending on whether its
            # argument happened to be constant.
            if fn in ("min", "max"):
                _check_min_max_arity(fn, len(fargs))
                return float(min(fargs)) if fn == "min" else float(max(fargs))
            if fn == "ceil":
                return float(math.ceil(fargs[0]))
            if fn == "floor":
                return float(math.floor(fargs[0]))
            if fn == "round":
                ndigits = int(fargs[1]) if len(fargs) > 1 else 0
                return _gams_round(fargs[0], ndigits)
            if fn == "errorf":
                return _gams_errorf(fargs[0])
            if fn == "mod":
                # GAMS mod(a, b) = a - b*trunc(a/b), which is fmod semantics
                return float(math.fmod(fargs[0], fargs[1])) if fargs[1] != 0 else None
            if fn == "sign":
                return float((fargs[0] > 0) - (fargs[0] < 0))
            if fn == "signpower":
                a, p = fargs[0], fargs[1]
                return float(math.copysign(abs(a) ** p, a)) if a != 0 else 0.0
            if fn == "sigmoid":
                return float(1.0 / (1.0 + math.exp(-fargs[0])))
            # uniform/normal are nondeterministic — leave them unevaluable
            # (None) so assignment sites refuse loudly instead of folding silently.
            return None
        if isinstance(expr, (ExprSum, ExprProd)):
            is_sum = isinstance(expr, ExprSum)
            index_sets = []
            for iname in expr.index_names:
                elems = self._lookup_set_elements(iname)
                if elems is None:
                    return None
                index_sets.append(elems)
            acc = 0.0 if is_sum else 1.0
            for combo in itertools.product(*index_sets):
                local_env = dict(env)
                for iname, elem in zip(expr.index_names, combo):
                    local_env[iname] = elem
                if expr.dollar_cond is not None:
                    cond = self._eval_dollar_cond(expr.dollar_cond, local_env)
                    if cond is None:
                        return None
                    if cond == 0.0:
                        continue
                v = self._eval_const_expr_with_env(expr.body, local_env)
                if v is None:
                    return None
                acc = acc + v if is_sum else acc * v
            return acc
        if isinstance(expr, ExprSMinMax):
            index_sets = []
            for iname in expr.index_names:
                elems = self._lookup_set_elements(iname)
                if elems is None:
                    return None
                index_sets.append(elems)
            values: list[float] = []
            for combo in itertools.product(*index_sets):
                local_env = dict(env)
                for iname, elem in zip(expr.index_names, combo):
                    local_env[iname] = elem
                if expr.dollar_cond is not None:
                    cond = self._eval_dollar_cond(expr.dollar_cond, local_env)
                    if cond is None:
                        return None
                    if cond == 0.0:
                        continue
                v = self._eval_const_expr_with_env(expr.body, local_env)
                if v is None:
                    return None
                values.append(v)
            if not values:
                # GAMS gives +INF for an empty smin and -INF for an empty smax.
                # Reporting that as a foldable number would let it flow into
                # arithmetic; leave it unevaluable so the caller refuses.
                return None
            return float(min(values)) if expr.op == "smin" else float(max(values))

        if isinstance(expr, ExprOrd):
            sname = expr.set_name
            if sname in env:
                elem = env[sname]
                elems = self._lookup_set_elements(sname)
                if elems is not None and elem in elems:
                    return float(elems.index(elem) + 1)
                # Loop index named differently from its set: search all sets
                for other in self.set_elements.values():
                    if elem in other:
                        return float(other.index(elem) + 1)
            return None
        if isinstance(expr, ExprCard):
            elems = self.set_elements.get(expr.set_name, [])
            return float(len(elems))
        return None

    def _eval_const_expr(self, expr) -> float | None:
        """Evaluate a constant expression (no variables, no loop indices)."""
        return self._eval_const_expr_with_env(expr, {})

    def _row_is_excluded(self, cond, env: dict, eq_name: str | None) -> bool:
        """Does *cond* switch this equation row OFF? Refuses when it cannot tell.

        #1333: this was ``cond_val is not None and cond_val == 0.0``, so an
        UNEVALUABLE condition fell through to "generate the row". That fails
        open, in the direction that adds constraints GAMS does not generate:
        ``c1$(smin(i, d(i)) > 10).. x1 =g= 3`` with ``smin = 1`` produced a row
        GAMS omits, and the solve returned 3.0 for a model whose optimum is -5
        -- a wrong answer, reported as ``optimal``, from a valid GAMS file.

        A condition decides whether a constraint EXISTS, so "I could not tell"
        has no safe default: including the row cuts off feasible points and
        omitting it drops a restriction. Refuse (CLAUDE.md §3).
        """
        cond_val = self._eval_const_expr(cond)
        if cond_val is None:
            cond_val = self._eval_dollar_cond(cond, env)
        if cond_val is None:
            where = f"equation {eq_name!r}" if eq_name else "an equation"
            raise GamsParseError(
                f"the $-condition on {where} could not be evaluated, so whether "
                "the row exists is undetermined. Generating it anyway would add a "
                "constraint GAMS may not generate (and omitting it would drop one "
                "GAMS does), so neither default is sound. Rewrite the condition "
                "over constant data, or state the restriction directly."
            )
        return cond_val == 0.0

    def _eval_dollar_cond(self, expr, env: dict) -> float | None:
        """Evaluate a dollar condition with loop index substitution.

        Returns 1.0 (true) or 0.0 (false) if evaluable, None otherwise.
        Handles common patterns like set membership checks.
        """
        if isinstance(expr, ExprRef):
            name = expr.name
            if name in env:
                return 1.0  # index variable exists → true
            # Check if it's a set used as a membership test
            if name in self.set_elements:
                return 1.0
            return None
        if isinstance(expr, ExprIndex):
            # e.g., connected(i,j) — look up in parameter data
            if expr.name in self.param_values:
                indices = []
                for idx in expr.indices:
                    if isinstance(idx, ExprLabel):
                        indices.append(idx.value)
                    elif isinstance(idx, ExprRef) and idx.name in env:
                        indices.append(env[idx.name])
                    else:
                        return None
                pdata = self.param_values[expr.name]
                # Try tuple key first, then bare string for 1D params
                key = tuple(indices) if len(indices) > 1 else (indices[0],)
                if key in pdata:
                    return float(pdata[key])
                # 1D params may use bare string keys
                if len(indices) == 1 and indices[0] in pdata:
                    return float(pdata[indices[0]])
                return 0.0  # missing entry → false/zero
            return None
        if isinstance(expr, ExprOrd):
            # ord(i) — resolve from env
            sname = expr.set_name
            if sname in env:
                elem_val = env[sname]
                for set_name, elems in self.set_elements.items():
                    if elem_val in elems:
                        return float(elems.index(elem_val) + 1)
            return None
        if isinstance(expr, ExprBinOp):
            lv = self._eval_dollar_cond(expr.left, env)
            rv = self._eval_dollar_cond(expr.right, env)
            if lv is None or rv is None:
                return None
            if expr.op == "+":
                return lv + rv
            if expr.op == "-":
                return lv - rv
            if expr.op == "*":
                return lv * rv
            if expr.op == "/":
                return lv / rv if rv != 0 else None
            if expr.op == "<":
                return 1.0 if lv < rv else 0.0
            if expr.op == ">":
                return 1.0 if lv > rv else 0.0
            if expr.op == "<=":
                return 1.0 if lv <= rv else 0.0
            if expr.op == ">=":
                return 1.0 if lv >= rv else 0.0
            if expr.op in ("=", "=="):
                return 1.0 if lv == rv else 0.0
            if expr.op == "<>":
                return 1.0 if lv != rv else 0.0
            return None
        if isinstance(expr, ExprNum):
            return expr.value
        if isinstance(expr, ExprCard):
            elems = self.set_elements.get(expr.set_name, [])
            return float(len(elems))
        # Fallback to constant evaluation (keep the loop-index env)
        return self._eval_const_expr_with_env(expr, env)

    def _substitutable_objective_var(self, solve) -> str | None:
        """The objective variable, when substituting its definition out is exact.

        ``Solve m minimizing z`` with ``obj.. z =e= expr`` means: minimize
        ``z`` subject to every equation. Minimizing ``expr`` directly and
        dropping both ``z`` and ``obj`` is the same problem only when ``obj``
        is ``z``'s sole appearance and ``z`` is a free scalar with no declared
        bound -- the ``gmoObjType_Fun`` reduction ``model_from_gmo`` makes. Any
        bound (``z.lo = 2``), a second appearance, or a defining equation that
        also mentions ``z`` on its expression side, and the substitution would
        silently drop a restriction (#2002: a 2.0 optimum reported as 0.0);
        the builder then keeps ``z`` and every equation and minimizes ``z``.
        """
        if solve is None or not solve.objective_var:
            return None
        key = solve.objective_var.lower()
        name = next((n for n in self.p.variables if n.lower() == key), None)
        if name is None:
            return None
        gv = self.p.variables[name]
        if gv.domain or gv.var_type.lower() != "free":
            return None
        if any(
            b.var_name.lower() == key and b.suffix not in ("l", "m", "prior", "scale")
            for b in self.p.bounds
        ):
            return None
        defining = []
        for eqdef in self.p.equation_defs:
            if self._is_obj_equation(eqdef, name):
                if eqdef.domain or eqdef.dollar_cond is not None:
                    return None
                if _references_name(self._objective_side(eqdef, name), name):
                    return None
                defining.append(eqdef)
            elif _references_name([eqdef.lhs, eqdef.rhs, eqdef.dollar_cond], name):
                return None
        return name if len(defining) == 1 else None

    def _create_variables(self, m):
        self._semi_vars: list = []
        for name, gv in self.p.variables.items():
            if name == getattr(self, "_subst_obj_var", None):
                continue
            shape = self._domain_shape(gv.domain)
            vtype = gv.var_type.lower()
            if vtype == "binary":
                var = m.binary(name, shape=shape)
            elif vtype == "integer":
                # GAMS's default integer box is [0, +INF] (measured on GAMS 53.2:
                # `n.up` = +INF). An invented ub=1e6 certified 1e6 as the optimum
                # of `max n s.t. n <= 2e6`.
                var = m.integer(name, shape=shape, lb=0, ub=1e20)
            elif vtype == "positive":
                var = m.continuous(name, shape=shape, lb=0.0)
            elif vtype == "negative":
                var = m.continuous(name, shape=shape, ub=0.0)
            elif vtype == "semicont":
                # `x = 0 or lo <= x <= up` (#1613 C-03c). Created with GAMS's
                # default box; `_lower_semi_variables` imposes the disjunction
                # once the `.lo`/`.up` assignments are known. Reading it as a
                # plain `continuous(lb=0)` silently changed the feasible set.
                # GAMS's default box for semicont/semiint is [1, +inf]
                # (measured on GAMS 53.2: `x.lo` = 1, `x.up` = +INF).
                var = m.continuous(name, shape=shape, lb=1.0)
                self._semi_vars.append((name, var))
            elif vtype == "semiint":
                # No invented ub=1e6: an unset `.up` is +inf in GAMS, and
                # `_lower_semi_variables` refuses it rather than big-M it.
                var = m.integer(name, shape=shape, lb=1, ub=9.999e19)
                self._semi_vars.append((name, var))
            elif vtype in ("sos1", "sos2"):
                # Read as `free` this silently dropped the SOS restriction --
                # the same widened-model class as semicont (#1613). GAMS
                # derives the set membership from the variable's index
                # structure; that is not implemented, so refuse loudly.
                raise GamsParseError(
                    f"{vtype.upper()} variable '{name}' is not supported by the GAMS "
                    "reader; reading it as a free variable would drop the SOS "
                    "restriction. Model it with Model.sos1/sos2 instead."
                )
            else:  # free
                var = m.continuous(name, shape=shape)
            self.dvar_map[name] = var

    def _lower_semi_variables(self, m):
        """Impose GAMS ``semicont``/``semiint`` semantics exactly (#1613 C-03c).

        A semicontinuous ``x`` with bounds ``[lo, up]`` means ``x = 0`` **or**
        ``lo <= x <= up``. Where ``0`` already lies in ``[lo, up]`` that union is
        just the box, so the element needs nothing. Otherwise it is lowered with
        an on/off binary ``z``: ``lo*z <= x <= up*z`` on the hull box
        ``[min(0, lo), max(0, up)]`` -- ``z = 0`` pins ``x = 0`` and ``z = 1``
        restores ``[lo, up]``, which is the set exactly (integrality, for
        ``semiint``, stays on ``x``). That needs both bounds finite; an element
        whose disjunction would need an invented big-M is refused, not
        approximated.
        """
        for name, var in self._semi_vars:
            lb = np.array(var.lb, dtype=np.float64).reshape(-1)
            ub = np.array(var.ub, dtype=np.float64).reshape(-1)
            need = [k for k in range(lb.size) if not (lb[k] <= 0.0 <= ub[k])]
            if not need:
                continue
            # discopt's "infinite" bound is the 1e20-scale sentinel, not inf.
            bad = [k for k in need if not (abs(lb[k]) < 1e19 and abs(ub[k]) < 1e19)]
            if bad:
                raise GamsParseError(
                    f"Semicontinuous/semi-integer variable '{name}' has an element "
                    f"(flat index {bad[0]}) with bounds [{lb[bad[0]]}, {ub[bad[0]]}] "
                    "excluding 0 and an infinite bound; `x = 0 or lo <= x <= up` has no "
                    "exact bounded lowering then. Give it a finite .lo and .up."
                )
            if lb.size == 1 and var.shape in ((), (1,)):
                z = m.binary(f"{name}__semi_on")
                m.subject_to(var >= float(lb[0]) * z, name=f"{name}__semi_lo")
                m.subject_to(var <= float(ub[0]) * z, name=f"{name}__semi_up")
            else:
                z = m.binary(f"{name}__semi_on", shape=var.shape)
                # Elements whose box already contains 0 need no switch; pin
                # theirs to 0 so no unconstrained binary is left to branch on.
                z_ub = np.zeros(var.shape)
                z_ub.reshape(-1)[need] = 1.0
                z.ub = z_ub
                for k in need:
                    idx = np.unravel_index(k, var.shape)
                    m.subject_to(var[idx] >= float(lb[k]) * z[idx], name=f"{name}__semi_lo_{k}")
                    m.subject_to(var[idx] <= float(ub[k]) * z[idx], name=f"{name}__semi_up_{k}")
            new_lb = lb.copy()
            new_ub = ub.copy()
            for k in need:
                new_lb[k] = min(0.0, lb[k])
                new_ub[k] = max(0.0, ub[k])
            shape = var.shape
            var.lb = new_lb.reshape(shape) if shape else np.asarray(new_lb[0])
            var.ub = new_ub.reshape(shape) if shape else np.asarray(new_ub[0])

    def _domain_shape(self, domain: list[str]) -> tuple:
        if not domain:
            return ()
        dims = []
        for d in domain:
            # resolve to set elements
            resolved = d
            if d in self.p.aliases:
                resolved = self.p.aliases[d]
            if resolved in self.set_elements:
                dims.append(len(self.set_elements[resolved]))
            elif d in self.set_elements:
                dims.append(len(self.set_elements[d]))
            else:
                # unknown set dimension — try equation/variable domain
                # fallback: check if any set has this name (case insensitive)
                found = False
                for sn, se in self.set_elements.items():
                    if sn.lower() == d.lower():
                        dims.append(len(se))
                        found = True
                        break
                if not found:
                    raise GamsParseError(f"Unknown set '{d}' in domain")
        return tuple(dims)

    def _domain_set_names(self, domain: list[str]) -> list[str]:
        """Resolve domain names to actual set names."""
        result = []
        for d in domain:
            if d in self.p.aliases:
                result.append(self.p.aliases[d])
            else:
                result.append(d)
        return result

    def _build_equations(self, m, solve):
        """Build constraints and objective from equation definitions."""
        obj_var_name = solve.objective_var if solve else None
        obj_sense = solve.sense if solve else "minimizing"
        obj_set = False

        for eqdef in self.p.equation_defs:
            # Build the constraint for each index combination
            domain = eqdef.domain
            if domain:
                set_names = self._domain_set_names(domain)
                index_sets = []
                for sn in set_names:
                    if sn in self.set_elements:
                        index_sets.append(self.set_elements[sn])
                    else:
                        for k, v in self.set_elements.items():
                            if k.lower() == sn.lower():
                                index_sets.append(v)
                                break
                        else:
                            raise GamsParseError(f"Unknown set '{sn}'")
                # iterate over cartesian product
                import itertools

                for combo in itertools.product(*index_sets):
                    env = {}
                    for dn, val in zip(domain, combo):
                        env[dn] = val
                    # Evaluate dollar condition on equation definition
                    if eqdef.dollar_cond is not None and self._row_is_excluded(
                        eqdef.dollar_cond, env, eqdef.name
                    ):
                        continue
                    lhs_expr = self._build_expr(eqdef.lhs, env)
                    rhs_expr = self._build_expr(eqdef.rhs, env)
                    # A GAMS indexed equation ``eq(i)`` expands to one *distinct*
                    # constraint row per index tuple, each with its own dual — so
                    # name each row by its index key (``supply[p1]``, ``supply[p2]``)
                    # rather than reusing the bare equation name for every row.
                    # Distinct names keep ``result.constraint_duals`` (name-keyed)
                    # sound and avoid a spurious duplicate-name collision; this
                    # matches ``Model.constraint``'s own ``name[key]`` convention.
                    key_label = ".".join(str(v) for v in combo)
                    row_name = f"{eqdef.name}[{key_label}]" if eqdef.name else None
                    self._add_constraint(m, lhs_expr, eqdef.sense, rhs_expr, row_name)
            else:
                # Scalar equation — dollar condition on scalar is unusual but handle it
                if eqdef.dollar_cond is not None and self._row_is_excluded(
                    eqdef.dollar_cond, {}, eqdef.name
                ):
                    continue
                # The objective's defining equation, when substituting it out
                # is exact (#2002); otherwise it stays a constraint and the
                # fallback below minimizes the objective variable itself.
                subst = getattr(self, "_subst_obj_var", None)
                if subst is not None and self._is_obj_equation(eqdef, subst):
                    obj_expr = self._build_expr(self._objective_side(eqdef, subst), {})
                    if obj_sense.startswith("min"):
                        m.minimize(obj_expr)
                    else:
                        m.maximize(obj_expr)
                    obj_set = True
                else:
                    lhs_expr = self._build_expr(eqdef.lhs, {})
                    rhs_expr = self._build_expr(eqdef.rhs, {})
                    self._add_constraint(m, lhs_expr, eqdef.sense, rhs_expr, eqdef.name)

        # Fallback for the MINLPLib standard form: ``Solve m ... minimizing
        # objvar`` where ``objvar`` is a free variable that does NOT appear as a
        # bare ``objvar =e= expr`` definition but is instead embedded in a
        # defining equation (e.g. ``defobj.. expr + objvar =E= 0``). No equation
        # was recognized as the objective above, so minimize/maximize the
        # objective variable directly and leave every equation (including the
        # defining one, already added as a constraint) in place. This is the
        # exact GAMS semantics — GAMS minimizes the scalar variable ``objvar``
        # subject to all equations — so it is sound and value-preserving.
        if obj_var_name and not obj_set:
            obj_var = self.dvar_map.get(obj_var_name)
            if obj_var is not None and getattr(obj_var, "shape", None) in ((), (1,)):
                if obj_sense.startswith("min"):
                    m.minimize(obj_var)
                else:
                    m.maximize(obj_var)

        # Objectiveless solves (CNS — Constrained Nonlinear System, MCP — Mixed
        # Complementarity) and any solve whose objective variable could not be
        # resolved leave no objective set. GAMS treats CNS/MCP as pure
        # feasibility / square-system solves ("find x satisfying all equations").
        # Model that exactly as "minimize 0 subject to the constraints": a
        # constant objective makes every feasible point optimal, which is the
        # CNS semantics, and lets the model validate + solve instead of raising
        # "No objective set". Gated on an EMPTY objective variable so a genuine
        # optimization solve whose objective var failed to resolve still raises
        # loudly rather than being silently downgraded to a feasibility solve.
        if m._objective is None and not obj_var_name:
            m.minimize(0.0)

    def _is_obj_equation(self, eqdef, obj_var_name: str | None) -> bool:
        """Is *eqdef* ``z =e= expr`` or ``expr =e= z`` for objective variable ``z``?"""
        if not obj_var_name or eqdef.sense != "=e=":
            return False
        key = obj_var_name.lower()
        return any(
            isinstance(side, ExprRef) and side.name.lower() == key
            for side in (eqdef.lhs, eqdef.rhs)
        )

    @staticmethod
    def _objective_side(eqdef, obj_var_name: str):
        """The expression side (AST) of the defining equation ``z =e= expr``."""
        lhs = eqdef.lhs
        if isinstance(lhs, ExprRef) and lhs.name.lower() == obj_var_name.lower():
            return eqdef.rhs
        return lhs

    def _add_constraint(self, m, lhs, sense, rhs, name):
        if sense == "=e=":
            m.subject_to(lhs == rhs, name=name)
        elif sense == "=l=":
            m.subject_to(lhs <= rhs, name=name)
        elif sense == "=g=":
            m.subject_to(lhs >= rhs, name=name)

    def _build_expr(self, ast_node, env: dict):
        """Convert a GAMS expression AST node to a discopt Expression."""
        from discopt.modeling import core as dm

        if isinstance(ast_node, ExprNum):
            return dm.Constant(ast_node.value)

        if isinstance(ast_node, ExprAttr):
            raise _attr_error(ast_node)

        if isinstance(ast_node, ExprRef):
            name = ast_node.name
            # check if it's a loop index variable
            if name in env:
                # it's an index — resolve to the element name (used for param lookup)
                return env[name]  # returns the string element name
            # check discopt variables
            if name in self.dvar_map:
                var = self.dvar_map[name]
                if var.shape == () or var.shape == (1,):
                    return var
                return var
            # check scalars
            if name in self.scalar_values:
                return dm.Constant(self.scalar_values[name])
            # check parameters (0-dim)
            if name in self.param_values:
                pdata = self.param_values[name]
                if len(pdata) == 1:
                    return dm.Constant(list(pdata.values())[0])
            raise GamsParseError(f"Unresolved reference: '{name}'")

        if isinstance(ast_node, ExprIndex):
            name = ast_node.name
            # Resolve indices — handle lag/lead (i-1, i+1) via set offset
            indices = []
            for dim, idx_ast in enumerate(ast_node.indices):
                idx_val = self._resolve_index_expr(idx_ast, env, name, dim)
                indices.append(idx_val)
            # None means out-of-bounds lag/lead — return 0 (term vanishes)
            if any(v is None for v in indices):
                return dm.Constant(0.0)
            # If all indices resolved to strings (set element names), map to ints
            if all(isinstance(v, str) for v in indices):
                return self._resolve_indexed(name, indices)
            # If it's a variable with expression indices
            if name in self.dvar_map:
                var = self.dvar_map[name]
                int_indices = []
                for iv in indices:
                    if isinstance(iv, int):
                        int_indices.append(iv)
                    elif isinstance(iv, str):
                        int_indices.append(self._element_index(name, iv, len(int_indices)))
                    else:
                        int_indices.append(iv)
                if len(int_indices) == 1:
                    return var[int_indices[0]]
                return var[tuple(int_indices)]
            raise GamsParseError(f"Cannot resolve indexed ref: {name}")

        if isinstance(ast_node, ExprBinOp):
            # Iteratively unwind the LEFT-associative operator spine instead of
            # recursing into ``ast_node.left``. The precedence-climbing parser
            # builds long flat chains (e.g. a 1000-term autocorrelation sum) as a
            # left-deep tree ``(((a+b)+c)+d)``; a naive recursion descends once
            # per term and overflows the (C) stack on large models — manifesting
            # as a RecursionError at the default limit or a hard hang/segfault
            # once the recursion limit is raised. Walking the left spine in a
            # loop makes this O(N) iterative while preserving exact left-to-right
            # evaluation order (so ``-``/``/`` and float rounding are unchanged).
            chain = []  # (op, right_ast), collected top-down
            node: object = ast_node
            while isinstance(node, ExprBinOp):
                chain.append((node.op, node.right))
                node = node.left
            acc = self._ensure_expr(self._build_expr(node, env))
            for op, right_ast in reversed(chain):
                right = self._ensure_expr(self._build_expr(right_ast, env))
                acc = self._apply_binop(op, acc, right)
            return acc

        if isinstance(ast_node, ExprUnaryMinus):
            operand = self._build_expr(ast_node.operand, env)
            operand = self._ensure_expr(operand)
            return -operand

        if isinstance(ast_node, ExprSMinMax):
            # #1325: ``smin(i, expr)`` / ``smax(i, expr)`` over an index set has
            # no sound algebraic form in the solver's expression IR, and the
            # body still references the index ``i`` -- the failure surfaced as
            # "Unresolved reference: 'i'", naming the index rather than the
            # unsupported construct. Refused here, BEFORE the body is built, so
            # the message says what is actually wrong. Equation bodies only: a
            # CONSTANT one folds through ``_eval_const_expr_with_env`` and is
            # a perfectly good number (#1333).
            _fn = ast_node.op.lower()
            _folded = self._eval_const_expr(ast_node)
            if _folded is not None:
                return _folded
            raise GamsParseError(
                f"{_fn}(...) over an index set is not supported in an equation "
                "body: it is a minimum/maximum over set elements, which has no "
                "sound algebraic form in the solver's expression IR. Model it "
                "explicitly -- introduce a variable z with one inequality per "
                f"element ({'z =L= x(i)' if _fn == 'smin' else 'z =G= x(i)'} "
                "for all i) -- or use the n-ary min/max over a fixed argument "
                "list."
            )

        if isinstance(ast_node, ExprFunc):
            args = [self._build_expr(a, env) for a in ast_node.args]
            args = [self._ensure_expr(a) for a in args]
            return self._map_func(ast_node.func, args)

        if isinstance(ast_node, ExprSum):
            return self._build_sum(ast_node, env)

        if isinstance(ast_node, ExprProd):
            return self._build_prod(ast_node, env)

        if isinstance(ast_node, ExprCard):
            elems = self.set_elements.get(ast_node.set_name, [])
            return dm.Constant(float(len(elems)))

        if isinstance(ast_node, ExprOrd):
            # ord(i) returns the 1-based ordinal position of element i in its set
            sname = ast_node.set_name
            if sname in env:
                elem_val = env[sname]
                # find which set this belongs to and get position
                for set_name, elems in self.set_elements.items():
                    if elem_val in elems:
                        return dm.Constant(float(elems.index(elem_val) + 1))
            return dm.Constant(1.0)

        raise GamsParseError(f"Unknown AST node: {type(ast_node)}")

    @staticmethod
    def _apply_binop(op, left, right):
        """Apply a binary operator to two already-built Expression operands."""
        if op == "+":
            return left + right
        if op == "-":
            return left - right
        if op == "*":
            return left * right
        if op == "/":
            return left / right
        if op == "**":
            return left**right
        raise GamsParseError(f"Unknown operator: {op}")

    def _ensure_expr(self, val):
        """Convert non-Expression values (strings, ints, floats) to Constant."""
        from discopt.modeling.core import Constant, Expression

        if isinstance(val, Expression):
            return val
        if isinstance(val, (int, float)):
            return Constant(float(val))
        if isinstance(val, str):
            # possibly a scalar or param
            if val in self.scalar_values:
                return Constant(self.scalar_values[val])
            return Constant(0.0)
        return Constant(float(val))

    def _resolve_indexed(self, name: str, str_indices: list[str]):
        """Resolve name(elem1, elem2) to either a param value or variable element."""
        from discopt.modeling.core import Constant

        # check params/tables
        if name in self.param_values:
            pdata = self.param_values[name]
            # 1-D parameter data is stored under the bare element key by
            # ``_parse_param_data`` (e.g. ``"p1"``), while multi-dim data uses a
            # tuple key. Earlier this looked up 1-D refs as a 1-tuple ``("p1",)``,
            # which never matched the bare-string storage and silently fell back
            # to the 0.0 default — quietly dropping every 1-D parameter value.
            # Tolerate both key forms so the lookup matches regardless of how the
            # entry was stored.
            if len(str_indices) == 1:
                key: object = str_indices[0]
                if key not in pdata:
                    key = (str_indices[0],)
            else:
                key = tuple(str_indices)
            val = pdata.get(key, 0.0)
            return Constant(float(val))
        # check variables
        if name in self.dvar_map:
            var = self.dvar_map[name]
            int_indices = []
            for dim, elem in enumerate(str_indices):
                int_indices.append(self._element_index(name, elem, dim))
            if len(int_indices) == 1:
                return var[int_indices[0]]
            return var[tuple(int_indices)]
        raise GamsParseError(f"Cannot resolve '{name}' with indices {str_indices}")

    def _resolve_index_expr(self, idx_ast, env: dict, name: str, dim: int):
        """Resolve an index expression, handling lag/lead (i-1, i+1).

        Returns a string (set element name), int (position), or Expression.
        """
        # Quoted element label: 'e' -> the element itself
        if isinstance(idx_ast, ExprLabel):
            return idx_ast.value

        # Simple reference: i -> look up in env
        if isinstance(idx_ast, ExprRef):
            if idx_ast.name in env:
                return env[idx_ast.name]
            return self._build_expr(idx_ast, env)

        # Lag/lead: i-1, i+1, i-2, etc.
        if isinstance(idx_ast, ExprBinOp) and idx_ast.op in ("+", "-"):
            if isinstance(idx_ast.left, ExprRef) and isinstance(idx_ast.right, ExprNum):
                index_name = idx_ast.left.name
                offset = int(idx_ast.right.value)
                if idx_ast.op == "-":
                    offset = -offset
                if index_name in env:
                    cur_elem = env[index_name]
                    # Find the set and compute offset element
                    new_elem = self._offset_set_element(name, cur_elem, dim, offset)
                    if new_elem is not None:
                        return new_elem
                    # Out of bounds — return None to signal skip
                    return None

        # Fall back to general expression evaluation
        return self._build_expr(idx_ast, env)

    def _offset_set_element(
        self, var_or_param_name: str, cur_elem: str, dim: int, offset: int
    ) -> str | None:
        """Get the element at cur_elem + offset in the set for a given dimension.

        Returns None if the offset goes out of bounds.
        """
        # Find the set for this dimension
        domain = None
        if var_or_param_name in self.p.variables:
            domain = self.p.variables[var_or_param_name].domain
        elif var_or_param_name in self.p.parameters:
            domain = self.p.parameters[var_or_param_name].domain
        elif var_or_param_name in self.p.tables:
            domain = self.p.tables[var_or_param_name].domain
        elems = None
        if domain and dim < len(domain):
            set_name = domain[dim]
            if set_name in self.p.aliases:
                set_name = self.p.aliases[set_name]
            elems = self.set_elements.get(set_name)
        if elems is None:
            # Search all sets for cur_elem
            for sn, se in self.set_elements.items():
                if cur_elem in se:
                    elems = se
                    break
        if elems is None:
            return None
        if cur_elem not in elems:
            return None
        new_pos = elems.index(cur_elem) + offset
        if 0 <= new_pos < len(elems):
            return elems[new_pos]
        return None  # out of bounds

    def _element_index(self, var_or_param_name: str, element: str, dim: int) -> int:
        """Find the integer position of a set element for a given dimension."""
        # figure out which set this dimension belongs to
        # check variable domain first
        domain = None
        if var_or_param_name in self.p.variables:
            domain = self.p.variables[var_or_param_name].domain
        elif var_or_param_name in self.p.parameters:
            domain = self.p.parameters[var_or_param_name].domain
        elif var_or_param_name in self.p.tables:
            domain = self.p.tables[var_or_param_name].domain
        if domain and dim < len(domain):
            set_name = domain[dim]
            if set_name in self.p.aliases:
                set_name = self.p.aliases[set_name]
            elems = self.set_elements.get(set_name, [])
            if element in elems:
                return elems.index(element)
        # fallback: search all sets
        for sn, elems in self.set_elements.items():
            if element in elems:
                return elems.index(element)
        raise GamsParseError(f"Element '{element}' not found in any set")

    def _build_sum(self, node: ExprSum, env: dict):
        """Build a sum over indexed set elements."""
        import itertools

        from discopt.modeling.core import Constant

        index_names = node.index_names
        index_sets = []
        for iname in index_names:
            resolved = iname
            if iname in self.p.aliases:
                resolved = self.p.aliases[iname]
            if resolved in self.set_elements:
                index_sets.append(self.set_elements[resolved])
            elif iname in self.set_elements:
                index_sets.append(self.set_elements[iname])
            else:
                # might be an alias or same-name set
                for sn, se in self.set_elements.items():
                    if sn.lower() == iname.lower():
                        index_sets.append(se)
                        break
                else:
                    raise GamsParseError(f"Unknown set '{iname}' in sum")

        terms = []
        for combo in itertools.product(*index_sets):
            new_env = dict(env)
            for iname, val in zip(index_names, combo):
                new_env[iname] = val
            # Evaluate dollar condition — skip this combination if false
            if node.dollar_cond is not None:
                cond_val = self._eval_const_expr(node.dollar_cond)
                if cond_val is None:
                    # Try evaluating with env substitution
                    cond_val = self._eval_dollar_cond(node.dollar_cond, new_env)
                if cond_val is not None and cond_val == 0.0:
                    continue
            term = self._build_expr(node.body, new_env)
            term = self._ensure_expr(term)
            terms.append(term)

        if not terms:
            return Constant(0.0)
        result = terms[0]
        for t in terms[1:]:
            result = result + t
        return result

    def _build_prod(self, node: ExprProd, env: dict):
        """Build a product over indexed set elements."""
        import itertools

        from discopt.modeling.core import Constant

        index_names = node.index_names
        index_sets = []
        for iname in index_names:
            resolved = iname
            if iname in self.p.aliases:
                resolved = self.p.aliases[iname]
            if resolved in self.set_elements:
                index_sets.append(self.set_elements[resolved])
            elif iname in self.set_elements:
                index_sets.append(self.set_elements[iname])
            else:
                raise GamsParseError(f"Unknown set '{iname}' in prod")

        terms = []
        for combo in itertools.product(*index_sets):
            new_env = dict(env)
            for iname, val in zip(index_names, combo):
                new_env[iname] = val
            if node.dollar_cond is not None:
                cond_val = self._eval_const_expr(node.dollar_cond)
                if cond_val is None:
                    cond_val = self._eval_dollar_cond(node.dollar_cond, new_env)
                if cond_val is not None and cond_val == 0.0:
                    continue
            term = self._build_expr(node.body, new_env)
            term = self._ensure_expr(term)
            terms.append(term)

        if not terms:
            return Constant(1.0)
        result = terms[0]
        for t in terms[1:]:
            result = result * t
        return result

    def _map_func(self, func_name: str, args: list):
        """Map a GAMS function name to a discopt expression."""
        from discopt.modeling import core as dm

        fn = func_name.lower()
        if fn == "exp":
            return dm.exp(args[0])
        if fn == "log":
            return dm.log(args[0])
        if fn == "log2":
            return dm.log2(args[0])
        if fn == "log10":
            return dm.log10(args[0])
        if fn == "sqrt":
            return dm.sqrt(args[0])
        if fn == "sqr":
            return args[0] ** 2
        if fn == "abs":
            return dm.abs_(args[0])
        if fn == "sin":
            return dm.sin(args[0])
        if fn == "cos":
            return dm.cos(args[0])
        if fn == "tan":
            return dm.tan(args[0])
        if fn == "arcsin":
            return dm.FunctionCall("asin", args[0])
        if fn == "arccos":
            return dm.FunctionCall("acos", args[0])
        if fn == "arctan":
            return dm.FunctionCall("atan", args[0])
        if fn == "sinh":
            return dm.FunctionCall("sinh", args[0])
        if fn == "cosh":
            return dm.FunctionCall("cosh", args[0])
        if fn == "tanh":
            return dm.tanh(args[0])
        if fn == "sigmoid":
            return dm.sigmoid(args[0])
        if fn == "power":
            return args[0] ** args[1]
        if fn == "rpower":
            # GAMS rPower(x, y) = x**y for x >= 0 -- the spelling ``to_gams``
            # writes for a fractional or symbolic exponent (#1503).
            return args[0] ** args[1]
        if fn == "sign":
            return dm.sign(args[0])
        if fn == "signpower":
            # GAMS signpower(x, p) = sign(x) * |x|^p, exactly equal to the
            # smooth form x * |x|^(p-1) for all p >= 0 (both are 0 at x=0).
            # Using x*|x|^(p-1) avoids a spurious sign() discontinuity that
            # would otherwise wreck the relaxation.  Fold a constant exponent
            # so the relaxation/FBBT see a clean form (for p=2 this is x*|x|).
            base = args[0]
            pexp = args[1]
            pval: float | None = None
            if isinstance(pexp, dm.Constant):
                pval = float(pexp.value)
            elif isinstance(pexp, (int, float)):
                pval = float(pexp)
            if pval is not None:
                if pval == 2.0:
                    return base * dm.abs_(base)
                if pval == 1.0:
                    return base
                return base * dm.abs_(base) ** (pval - 1.0)
            return base * dm.abs_(base) ** (pexp - 1)
        if fn in ("min", "max"):
            _check_min_max_arity(fn, len(args))
        if fn == "min":
            # GAMS min/max take two or more arguments (#1312: this hard-coded
            # 2-arg form silently dropped args[2:], producing a WRONG certified
            # optimum -- not a loose bound -- for any 3+-ary call in an
            # equation body. dm.minimum/dm.maximum have been n-ary since #1250;
            # the constant-folding arm of this same module already used
            # min(fargs)/max(fargs) correctly, so this made the two arms
            # silently disagree on the endogenous case).
            return dm.minimum(*args)
        if fn == "max":
            return dm.maximum(*args)
        if fn == "errorf":
            # GAMS errorf is the standard normal CDF, not erf (#1288).
            return 0.5 * (1.0 + dm.erf(args[0] / math.sqrt(2.0)))
        # Every remaining name in `_GAMS_FUNCS` -- ceil, floor, round, mod,
        # uniform, normal -- has NO sound mapping into the IR. Building
        # `FunctionCall(fn, *args)` for them used to let `from_gams` return a
        # model carrying a node nothing downstream understands: the import
        # succeeded, and the failure surfaced much later as an opaque
        # "Unknown function: 'ceil'" from the DAG compiler -- after the
        # incumbent-verification snapshot had already failed and *disabled the
        # false-primal guard for that solve*. Refuse at the boundary instead, the
        # same policy the `.nl` parser applies to the matching opcodes (C-5) and
        # `serialize.loads` applies to an unknown function name on read.
        #
        # Only an ENDOGENOUS use is refused. `ceil(2.3)` inside an equation body
        # is a number, not a step function of a variable, and GAMS itself allows
        # it, so fold it first -- `_eval_const_expr_with_env` handles the
        # data/assignment sites but does not run on equation bodies, which reach
        # `_map_func` with their literal arguments already wrapped as Constants.
        # (Measured: without this fold, `c1.. x + ceil(2.3) =L= 2;` refused.)
        folded = [_fold_constant(a) for a in args]
        if args and all(v is not None for v in folded):
            cargs: list[float] = [float(v) for v in folded if v is not None]
            if fn == "ceil":
                return dm.Constant(float(math.ceil(cargs[0])))
            if fn == "floor":
                return dm.Constant(float(math.floor(cargs[0])))
            if fn == "round":
                nd = int(cargs[1]) if len(cargs) > 1 else 0
                return dm.Constant(_gams_round(cargs[0], nd))
            # GAMS mod(a, b) = a - b*trunc(a/b), i.e. fmod semantics. A zero
            # divisor is a GAMS execution error, so refuse rather than fold.
            if fn == "mod" and len(cargs) > 1 and cargs[1] != 0.0:
                return dm.Constant(float(math.fmod(cargs[0], cargs[1])))

        # ceil/floor/round carry the shared discontinuous-intrinsic message
        # (which explains the integer reformulation); mod/uniform/normal are
        # refused with their own reasons. uniform/normal are NOT folded even for
        # literal arguments: they are nondeterministic, and the data-statement
        # path deliberately leaves them unevaluable for the same reason.
        if fn in dm._UNREPRESENTABLE_INTRINSICS:
            raise GamsParseError(
                dm._unrepresentable_intrinsic_message(
                    fn, where=f"GAMS function {fn}(...) over a variable"
                )
            )
        if fn == "mod":
            raise GamsParseError(
                "GAMS mod(a, b) could not be reduced to a constant here (a "
                "non-literal argument, or a zero divisor): mod is discontinuous in "
                "its arguments and discopt's expression IR has no node for it. "
                "Refusing rather than building a node that fails later during the "
                "solve. Reformulate with an explicit integer quotient "
                "(a = q*b + r, q integer, 0 <= r < b) and use r."
            )
        if fn in ("uniform", "normal"):
            raise GamsParseError(
                f"GAMS function {fn}(...) over a variable is not supported: it draws "
                "a random number, so it does not denote a deterministic function of "
                "the model's variables and has no meaning in an expression discopt "
                "must optimise over. Refusing rather than building a node that fails "
                "later during the solve. (A literal-argument call in a data "
                "statement is a separate path and is already refused there.)"
            )
        raise GamsParseError(
            f"GAMS function {fn!r} has no mapping into discopt's expression IR. "
            "Refusing rather than building a node that fails later during the "
            "solve."
        )

    def _store_initial_value(self, b, var, val: float):
        """Store .l initial value for a variable."""
        import itertools

        name = b.var_name
        if name not in self._initial_values:
            self._initial_values[name] = {}
        if b.domain:
            set_names = self._domain_set_names(b.domain)
            index_sets = []
            for sn in set_names:
                if sn in self.set_elements:
                    index_sets.append(self.set_elements[sn])
                else:
                    matched = False
                    for k, v in self.set_elements.items():
                        if k.lower() == sn.lower():
                            index_sets.append(v)
                            matched = True
                            break
                    if not matched:
                        # Concrete element label (e.g. ``x.l('a') = 1``):
                        # treat as a literal single element, mirroring
                        # _apply_bounds — previously this dimension was
                        # dropped and idx[0] raised IndexError (#745).
                        index_sets.append([sn])
            for combo in itertools.product(*index_sets):
                if b.dollar_cond is not None:
                    env = dict(zip(b.domain, combo))
                    cond_val = self._eval_dollar_cond(b.dollar_cond, env)
                    if cond_val is not None and cond_val == 0.0:
                        continue
                idx = []
                for dim, elem in enumerate(combo):
                    idx.append(self._element_index(name, elem, dim))
                flat_idx = tuple(idx) if len(idx) > 1 else idx[0]
                self._initial_values[name][flat_idx] = val
        else:
            # Scalar initial value
            self._initial_values[name] = val

    def _apply_bounds(self, m):
        """Apply .lo, .up, .fx bound assignments and .l initial values."""
        for b in self.p.bounds:
            if b.var_name not in self.dvar_map:
                continue
            var = self.dvar_map[b.var_name]
            # .l is initial value, not a bound
            if b.suffix == "l":
                val = self._eval_const_expr(b.expr)
                if val is not None:
                    self._store_initial_value(b, var, val)
                continue
            # .m (marginal/dual), .prior, .scale are informational — skip
            if b.suffix in ("m", "prior", "scale"):
                continue
            if b.domain:
                # indexed bound: apply to specific elements
                import itertools

                set_names = self._domain_set_names(b.domain)
                index_sets = []
                for sn in set_names:
                    if sn in self.set_elements:
                        index_sets.append(self.set_elements[sn])
                    else:
                        matched = False
                        for k, v in self.set_elements.items():
                            if k.lower() == sn.lower():
                                index_sets.append(v)
                                matched = True
                                break
                        if not matched:
                            # Concrete element label (e.g. `x.lo('1') = ...`):
                            # not a set name, so treat it as a literal single
                            # element for this dimension. This is how the
                            # per-element bounds `to_gams` emits for
                            # heterogeneous array blocks round-trip (X-2, #413).
                            index_sets.append([sn])
                for combo in itertools.product(*index_sets):
                    env = {}
                    for dn, elem in zip(b.domain, combo):
                        env[dn] = elem
                    # Evaluate dollar condition on bound assignment
                    if b.dollar_cond is not None:
                        cond_val = self._eval_dollar_cond(b.dollar_cond, env)
                        if cond_val is not None and cond_val == 0.0:
                            continue
                    # Evaluate the right-hand side PER ELEMENT, with the domain
                    # index bound: `x.lo(i) = lo(i)` depends on `i`. Evaluating it
                    # once with no index made it unevaluable, and the bound was
                    # then silently dropped (#1613: a semicont `x.lo(i)` lost).
                    val = self._eval_const_expr_with_env(b.expr, env)
                    if val is None:
                        raise GamsParseError(
                            f"Cannot evaluate bound {b.var_name}.{b.suffix}"
                            f"({', '.join(map(str, combo))}) to a constant; refusing to "
                            "drop it silently."
                        )
                    idx = []
                    for dim, elem in enumerate(combo):
                        idx.append(self._element_index(b.var_name, elem, dim))
                    flat_idx = tuple(idx) if len(idx) > 1 else idx[0]
                    # Edit a private writable copy and rebind, never
                    # `var.lb[i] = ...`: an installed box is read-only, since
                    # `saved_bounds(copy=False)` aliases it (#1321).
                    if b.suffix == "lo":
                        new_lb = np.array(var.lb, dtype=np.float64)
                        new_lb[flat_idx] = val
                        var.lb = new_lb
                    elif b.suffix == "up":
                        new_ub = np.array(var.ub, dtype=np.float64)
                        new_ub[flat_idx] = val
                        var.ub = new_ub
                    elif b.suffix == "fx":
                        new_lb = np.array(var.lb, dtype=np.float64)
                        new_ub = np.array(var.ub, dtype=np.float64)
                        new_lb[flat_idx] = val
                        new_ub[flat_idx] = val
                        var.lb = new_lb
                        var.ub = new_ub
            else:
                # scalar bound
                val = self._eval_const_expr(b.expr)
                if val is None:
                    raise GamsParseError(
                        f"Cannot evaluate bound {b.var_name}.{b.suffix} to a constant; "
                        "refusing to drop it silently."
                    )
                if b.suffix == "lo":
                    var.lb = np.full(var.shape, val) if var.shape else np.asarray(val)
                elif b.suffix == "up":
                    var.ub = np.full(var.shape, val) if var.shape else np.asarray(val)
                elif b.suffix == "fx":
                    var.lb = np.full(var.shape, val) if var.shape else np.asarray(val)
                    var.ub = np.full(var.shape, val) if var.shape else np.asarray(val)


# ── Public API ─────────────────────────────────────────────────
def parse_gams(source: str) -> "Model":
    """Parse GAMS source text and return a discopt Model.

    Parameters
    ----------
    source : str
        GAMS (.gms) source code as a string.

    Returns
    -------
    discopt.modeling.core.Model
        A discopt Model ready to solve.

    Raises
    ------
    GamsParseError
        If the GAMS source cannot be parsed.
    """
    tokens = _tokenize(source)
    parser = _Parser(tokens)
    parser.parse()
    builder = _ModelBuilder(parser)
    return builder.build()


def parse_gams_file(path: str) -> "Model":
    """Parse a GAMS .gms file and return a discopt Model.

    Parameters
    ----------
    path : str
        Path to the .gms file.

    Returns
    -------
    discopt.modeling.core.Model

    Raises
    ------
    FileNotFoundError
        If the file does not exist.
    GamsParseError
        If the GAMS source cannot be parsed.
    """
    import os

    if not os.path.isfile(path):
        raise FileNotFoundError(f"GAMS file not found: {path}")
    with open(path) as f:
        source = f.read()
    return parse_gams(source)
