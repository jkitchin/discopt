"""Special convex-pattern recognizers beyond the DCP composition walker.

The DCP walker in :mod:`rules` is sound but incomplete: it leaves
non-constant products and quotients at ``UNKNOWN`` because the
generic rules cannot prove convexity of cone primitives whose
structure is only visible at a supra-node level. This module
supplies targeted recognizers for a small, disciplined set of
shapes where a dedicated proof exists:

* **Homogeneous PSD quadratic ``x^T Q x``** (:func:`is_homogeneous_psd_quadratic`)
  — used as a building block for norm and quadratic-over-linear.
* **Quadratic-over-affine with positive affine denominator**
  (:func:`classify_division_pattern`) — convex when the numerator is
  a homogeneous PSD quadratic.
* **Perspective of exp: ``y * exp(x / y)`` with ``y > 0``**
  (:func:`classify_product_pattern`).
* **Exp times reciprocal powers: ``exp(affine) * prod_i g_i(x)**a_i``**
  with each ``g_i`` affine, strictly positive, and ``a_i <= 0``
  (:func:`classify_product_pattern`).
* **Weighted geometric mean ``prod_i x_i^{a_i}``** with ``x_i >= 0``,
  ``0 <= a_i <= 1``, and ``sum_i a_i == 1`` (:func:`classify_product_pattern`).
* **Norm ``sqrt(x^T Q x)`` with Q PSD**
  (:func:`classify_sqrt_pattern`).
* **Quadratic-over-affine epigraph constraint**
  (:func:`classify_fractional_epigraph_constraint`) — the MINLPTests
  ``nlp_cvx_108_*`` family rearranges to ``y >= q(x) / (d x + e)`` with
  ``q`` a PSD quadratic and the linear denominator strictly signed on
  the box.
* **Global quadratic fallback ``f(x) = x^T Q x + c^T x + d``**
  (:func:`quadratic_curvature`) — eigendecomposition of the symmetrised
  Q determines CONVEX / CONCAVE / AFFINE.

Each recognizer has a precise mathematical precondition (PSD of an
extracted matrix, a proven strict sign on a subexpression, a
specific syntactic shape). When the precondition is not met the
recognizer returns ``None`` — the caller preserves its existing
``UNKNOWN`` verdict.

The helpers are ported from the AMP-branch detector on
``bernalde/discopt`` so this branch covers the same MINLPTests
convex families without regressing soundness.
"""

from __future__ import annotations

import logging
from typing import Optional

import numpy as np
import scipy.sparse as _sp

from discopt.modeling.core import (
    BinaryOp,
    Constant,
    Constraint,
    Expression,
    FunctionCall,
    IndexExpression,
    MatMulExpression,
    Model,
    Parameter,
    SumExpression,
    SumOverExpression,
    UnaryOp,
    Variable,
)

from .eigenvalue import psd_proved
from .lattice import Curvature

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────
# Local utilities (ported with minor adaptation from bernalde/discopt
# branch ``fix/amp-false-infeasible-minlptests``)
# ──────────────────────────────────────────────────────────────────────


# Per-model cache of the declared-box arrays + scalar count (issue: qap-class
# convexity classification). ``_box_bounds`` / ``_total_scalar_variables`` are pure
# functions of the model's DECLARED variable bounds, yet the syntactic convexity
# recognizers call them once per product term (``_affine_strictly_positive`` ->
# ``_affine_lower_bound``) — 66k times on qap's 21,424-term objective, each an
# O(n_vars) rebuild (10s of pure recomputation). Declared bounds are static within a
# single classification pass, so we memoize the result on the model and invalidate it
# exactly where the solver resets ``_convexity_classification_cache`` (see
# :func:`clear_declared_box_cache`, called from ``solver.solve_model``), so a
# post-presolve re-classification with tightened bounds recomputes. Bound-neutral: the
# returned arrays/count are identical, only recomputation is removed.
_DECLARED_BOX_CACHE_ATTR = "_patterns_declared_box_cache"


def clear_declared_box_cache(model: Model) -> None:
    """Invalidate the per-model declared-box cache (call when declared bounds change).

    Idempotent and safe on a model that was never cached. The solver calls this at
    every point it resets its convexity-classification cache, so a re-classification
    after presolve/reformulation tightens the declared bounds sees fresh values.
    """
    # #1520: no except -- the old blanket handler was an UNSOUND fallback. A failed
    # invalidation leaves the box cache stale, and the recognizers then classify
    # against bounds the model no longer has: after a caller *widens* a bound the
    # stale, narrower box can prove a positivity/convexity the real box does not
    # support, i.e. a false convex claim. A model whose attribute cannot be deleted
    # must therefore fail the classification loudly, not continue on the stale box.
    if hasattr(model, _DECLARED_BOX_CACHE_ATTR):
        delattr(model, _DECLARED_BOX_CACHE_ATTR)


def _total_scalar_variables(model: Model) -> int:
    cached = getattr(model, _DECLARED_BOX_CACHE_ATTR, None)
    if cached is not None:
        return int(cached[0])
    return sum(v.size for v in model._variables)


def _scalar_var_offset(model: Model, target: Variable) -> Optional[int]:
    offset = 0
    for v in model._variables:
        if v is target or v.name == target.name:
            return offset if v.size == 1 else None
        offset += v.size
    return None


def _var_offset(model: Model, target: Variable) -> Optional[int]:
    offset = 0
    for v in model._variables:
        if v is target or v.name == target.name:
            return offset
        offset += v.size
    return None


def _same_expr(lhs: Expression, rhs: Expression) -> bool:
    """Identity-or-structural equality for the small patterns we match."""
    if lhs is rhs:
        return True
    if isinstance(lhs, Variable) and isinstance(rhs, Variable):
        return lhs.name == rhs.name
    if isinstance(lhs, IndexExpression) and isinstance(rhs, IndexExpression):
        return _same_expr(lhs.base, rhs.base) and lhs.index == rhs.index
    return False


def _contains_var(expr: Expression, target: Variable) -> bool:
    if isinstance(expr, Variable):
        return expr is target or expr.name == target.name
    if isinstance(expr, IndexExpression):
        return isinstance(expr.base, Variable) and (
            expr.base is target or expr.base.name == target.name
        )
    if isinstance(expr, BinaryOp):
        return _contains_var(expr.left, target) or _contains_var(expr.right, target)
    if isinstance(expr, UnaryOp):
        return _contains_var(expr.operand, target)
    if isinstance(expr, FunctionCall):
        return any(_contains_var(arg, target) for arg in expr.args)
    if isinstance(expr, SumExpression):
        return _contains_var(expr.operand, target)
    if isinstance(expr, SumOverExpression):
        return any(_contains_var(term, target) for term in expr.terms)
    return False


def _constant_expr(value: float) -> Constant:
    return Constant(np.array(float(value), dtype=np.float64))


def _add_expr(lhs: Optional[Expression], rhs: Expression) -> Expression:
    if lhs is None:
        return rhs
    return BinaryOp("+", lhs, rhs)


def _scale_expr(expr: Expression, scale: float) -> Expression:
    if abs(scale - 1.0) <= 1e-12:
        return expr
    if abs(scale + 1.0) <= 1e-12:
        return UnaryOp("neg", expr)
    return BinaryOp("*", _constant_expr(scale), expr)


def _flatten_sum_terms(expr: Expression, scale: float, out: list[tuple[float, Expression]]) -> None:
    if isinstance(expr, BinaryOp) and expr.op == "+":
        _flatten_sum_terms(expr.left, scale, out)
        _flatten_sum_terms(expr.right, scale, out)
        return
    # An n-ary ``dm.sum([...])`` is the same sum as the binary chain (#1537: the
    # recentring rewrite folds every affine subtree into one, and the recognisers
    # must not lose a structure because of how a sum was spelled).
    if isinstance(expr, SumOverExpression):
        for term in expr.terms:
            _flatten_sum_terms(term, scale, out)
        return
    if isinstance(expr, BinaryOp) and expr.op == "-":
        _flatten_sum_terms(expr.left, scale, out)
        _flatten_sum_terms(expr.right, -scale, out)
        return
    if isinstance(expr, UnaryOp) and expr.op == "neg":
        _flatten_sum_terms(expr.operand, -scale, out)
        return
    out.append((scale, expr))


def _flatten_product(expr: Expression, out: list[Expression]) -> None:
    if isinstance(expr, BinaryOp) and expr.op == "*":
        _flatten_product(expr.left, out)
        _flatten_product(expr.right, out)
        return
    out.append(expr)


def _extract_power_factor(expr: Expression) -> Optional[tuple[Expression, float]]:
    """Return ``(base, exponent)`` if ``expr`` is ``base ** const`` or ``base``."""
    if isinstance(expr, BinaryOp) and expr.op == "**":
        if isinstance(expr.right, (Constant, Parameter)):
            val = np.asarray(expr.right.value)
            if val.ndim == 0:
                return expr.left, float(val)
        return None
    return expr, 1.0


def _extract_linear_factor(expr: Expression, target: Variable) -> Optional[Expression]:
    """Extract the coefficient expression of ``target`` if ``expr`` is linear in it.

    Returns ``None`` when ``expr`` has a nonlinear (or zero) dependence on
    ``target``. ``Constant(1.0)`` is returned for the variable itself.
    """
    if isinstance(expr, Variable) and (expr is target or expr.name == target.name):
        return _constant_expr(1.0)
    if isinstance(expr, IndexExpression):
        if isinstance(expr.base, Variable) and (
            expr.base is target or expr.base.name == target.name
        ):
            return _constant_expr(1.0)
        return None
    if isinstance(expr, UnaryOp) and expr.op == "neg":
        inner = _extract_linear_factor(expr.operand, target)
        return None if inner is None else UnaryOp("neg", inner)
    if isinstance(expr, BinaryOp) and expr.op == "*":
        left_has = _contains_var(expr.left, target)
        right_has = _contains_var(expr.right, target)
        if left_has and right_has:
            return None
        if left_has:
            inner = _extract_linear_factor(expr.left, target)
            return None if inner is None else BinaryOp("*", inner, expr.right)
        if right_has:
            inner = _extract_linear_factor(expr.right, target)
            return None if inner is None else BinaryOp("*", expr.left, inner)
    return None


def _affine_range_1d(alpha: float, beta: float, lb: float, ub: float) -> tuple[float, float]:
    """Range of ``alpha * x + beta`` for ``x in [lb, ub]``."""
    if alpha >= 0.0:
        lo = alpha * lb + beta if np.isfinite(lb) else (-np.inf if alpha > 0.0 else beta)
        hi = alpha * ub + beta if np.isfinite(ub) else (np.inf if alpha > 0.0 else beta)
    else:
        lo = alpha * ub + beta if np.isfinite(ub) else (-np.inf)
        hi = alpha * lb + beta if np.isfinite(lb) else (np.inf)
    return float(lo), float(hi)


def _box_bounds(model: Model) -> tuple[np.ndarray, np.ndarray]:
    """Per-scalar-slot lower/upper bound vectors over all model variables.

    Memoized per model (see :data:`_DECLARED_BOX_CACHE_ATTR`): pure function of the
    DECLARED bounds, called once per objective term by the syntactic convexity
    recognizers. The cache stores ``(n_scalar, lo, hi)`` so ``_total_scalar_variables``
    shares it, and is invalidated by :func:`clear_declared_box_cache`.
    """
    cached = getattr(model, _DECLARED_BOX_CACHE_ATTR, None)
    if cached is not None:
        return cached[1], cached[2]
    los: list[np.ndarray] = []
    his: list[np.ndarray] = []
    for v in model._variables:
        lb = np.asarray(v.lb, dtype=np.float64).ravel()
        ub = np.asarray(v.ub, dtype=np.float64).ravel()
        if lb.size == 1 and v.size != 1:
            lb = np.full(v.size, float(lb.item()), dtype=np.float64)
        if ub.size == 1 and v.size != 1:
            ub = np.full(v.size, float(ub.item()), dtype=np.float64)
        los.append(lb)
        his.append(ub)
    if not los:
        lo_arr, hi_arr = np.zeros(0), np.zeros(0)
    else:
        lo_arr, hi_arr = np.concatenate(los), np.concatenate(his)
    # #1520: narrowed. ``setattr`` refuses an object that cannot carry the
    # attribute (``__slots__``, a read-only proxy) with ``AttributeError``; then the
    # box is simply rebuilt on the next call -- same arrays, only slower. Anything
    # else is a defect and propagates.
    try:
        setattr(model, _DECLARED_BOX_CACHE_ATTR, (int(lo_arr.size), lo_arr, hi_arr))
    except AttributeError as exc:
        logger.debug("declared box not memoized: %s: %s", type(exc).__name__, exc)
    return lo_arr, hi_arr


def _affine_lower_bound(expr: Expression, model: Model) -> Optional[float]:
    """Rigorous lower bound of an affine ``expr`` over the declared box.

    Returns ``None`` when ``expr`` is not affine-extractable or the bound is
    not finite (an unbounded contributing variable). Unlike
    :func:`_has_positive_lower_bound` this evaluates the affine form against the
    box, so ``0.001 + 0.999 * x18`` with ``x18 in [0, 1]`` correctly yields
    ``0.001`` even though the ``x18`` term alone is only non-negative.
    """
    from discopt._relax.problem_classifier import _extract_linear_coefficients, _NotLinearError

    n = _total_scalar_variables(model)
    # #1520: narrowed. ``_NotLinearError`` is the extractor's documented decline
    # ("not affine"); any other exception is a defect and propagates.
    try:
        vec, const = _extract_linear_coefficients(expr, model, n)
    except _NotLinearError:
        return None
    vec = np.asarray(vec, dtype=np.float64).ravel()
    lo_box, hi_box = _box_bounds(model)
    if vec.size != lo_box.size:
        return None
    # min of c·x = Σ (c>0 ? c·lb : c·ub); guard infinities that actually matter.
    #
    # Pick the minimizing endpoint FIRST, then multiply only where the
    # coefficient is nonzero (#1065). Multiplying before selecting evaluates
    # both ``vec * lo_box`` and ``vec * hi_box`` in full — so a variable that
    # does not appear in this affine form at all (``c == 0``) but is declared
    # unbounded produces ``0 * inf = NaN``, which fails the finiteness guard and
    # throws away a perfectly good bound (plus a RuntimeWarning into user
    # output). The docstring's contract is an unbounded *contributing* variable;
    # a zero coefficient does not contribute. The big-M/GDP families (syn/rsyn,
    # squfl — see #1061) declare ``lb=0, ub=inf`` on most continuous variables,
    # so nearly every affine form there hit this.
    endpoint = np.where(vec >= 0.0, lo_box, hi_box)
    contrib = np.multiply(vec, endpoint, where=vec != 0.0, out=np.zeros_like(vec))
    if not np.all(np.isfinite(contrib)):
        return None
    return float(const) + float(np.sum(contrib))


def _affine_strictly_positive(expr: Expression, model: Model) -> bool:
    """True when an affine ``expr`` has a proven strictly-positive lower bound."""
    lb = _affine_lower_bound(expr, model)
    return lb is not None and lb > 1e-12


def _expr_struct_eq(a: Expression, b: Expression) -> bool:
    """Structural equality for the small affine shapes the recognizers match.

    ``from_nl`` reconstruction rebuilds shared subexpressions as distinct nodes,
    so a denominator appearing in several terms is not object-identical; this
    compares by structure (constants by value, variables by name).
    """
    if a is b:
        return True
    if isinstance(a, Constant) and isinstance(b, Constant):
        va = np.asarray(a.value)
        vb = np.asarray(b.value)
        # Exact: a recogniser that matches ``L`` against ``L`` must be matching the
        # same function. ``np.allclose`` (atol 1e-8) equated 1e-9 with 2e-9 and
        # 4e-13 with -4e-13, so ``((x/L1)**2)*L2`` read as a perspective and the
        # verdict cache reused a CONVEX verdict across different constants (PR #1594
        # review). ``from_nl`` rebuilds shared constants bit-identically, so exact
        # equality loses no genuine match. (0.0 == -0.0 is the same function.)
        return va.shape == vb.shape and bool(np.array_equal(va, vb))
    if isinstance(a, Variable) and isinstance(b, Variable):
        return a.name == b.name
    if isinstance(a, IndexExpression) and isinstance(b, IndexExpression):
        return _expr_struct_eq(a.base, b.base) and _index_eq(a.index, b.index)
    if isinstance(a, Parameter) and isinstance(b, Parameter):
        return a is b or a.name == b.name
    if isinstance(a, BinaryOp) and isinstance(b, BinaryOp):
        return (
            a.op == b.op and _expr_struct_eq(a.left, b.left) and _expr_struct_eq(a.right, b.right)
        )
    if isinstance(a, UnaryOp) and isinstance(b, UnaryOp):
        return a.op == b.op and _expr_struct_eq(a.operand, b.operand)
    if isinstance(a, SumOverExpression) and isinstance(b, SumOverExpression):
        # Term-wise and in order: equal sums spelled in a different order compare
        # unequal, which can only make a recogniser decline, never mis-fire.
        return len(a.terms) == len(b.terms) and all(
            _expr_struct_eq(x, y) for x, y in zip(a.terms, b.terms)
        )
    return False


def _index_eq(ia: object, ib: object) -> bool:
    """Exact equality of two subscripts, index arrays included.

    ``a.index == b.index`` raised ``ValueError`` ("truth value of an array is
    ambiguous") on a gather, ``x[np.array([0, 2])]`` -- the form of a builder
    quadratic objective since #1802 -- and crashed convexity classification. An
    array matches only an array of the same dtype kind, shape and values: a
    boolean mask and an integer index with equal ``tolist()`` select different
    entries.
    """
    if isinstance(ia, tuple) or isinstance(ib, tuple):
        if not (isinstance(ia, tuple) and isinstance(ib, tuple)) or len(ia) != len(ib):
            return False
        return all(_index_eq(x, y) for x, y in zip(ia, ib))
    if isinstance(ia, np.ndarray) or isinstance(ib, np.ndarray):
        if not (isinstance(ia, np.ndarray) and isinstance(ib, np.ndarray)):
            return False
        return (
            ia.dtype.kind == ib.dtype.kind and ia.shape == ib.shape and bool(np.array_equal(ia, ib))
        )
    return bool(ia == ib)


def _split_const_mul(expr: Expression) -> tuple[float, Optional[Expression]]:
    """Factor scalar constants out of a product: ``expr == const * core``.

    ``core`` is ``None`` when every factor is a scalar constant.
    """
    factors: list[Expression] = []
    _flatten_product(expr, factors)
    const = 1.0
    core_factors: list[Expression] = []
    for f in factors:
        if isinstance(f, (Constant, Parameter)):
            v = np.asarray(f.value)
            if v.ndim == 0:
                const *= float(v)
                continue
        core_factors.append(f)
    if not core_factors:
        return const, None
    core = core_factors[0]
    for f in core_factors[1:]:
        core = BinaryOp("*", core, f)
    return const, core


# ──────────────────────────────────────────────────────────────────────
# Sign-on-domain checks
# ──────────────────────────────────────────────────────────────────────


def _has_positive_lower_bound(expr: Expression, model: Model) -> bool:
    """True when ``expr`` is provably strictly positive on the declared box.

    First the syntactic proof (:func:`_has_positive_lower_bound_terms`: every
    term strictly positive); failing that, a sound outward-rounded interval
    enclosure of ``expr`` over the box whose lower end is ``> 0`` (#1616 D-23:
    ``(1 - eps)*z + eps`` with ``z in [0, 1]`` is ``>= eps`` although its ``z`` term
    is not strictly positive). Conservative: returns False on anything it cannot
    prove.
    """
    if _has_positive_lower_bound_terms(expr, model):
        return True
    from .interval_eval import evaluate_interval

    try:
        enc = evaluate_interval(expr, model)
    except (IndexError, TypeError, ValueError):
        # A malformed node (an index outside its base, as `_is_nonneg_domain`
        # also guards) has no enclosure to prove anything from: not proven.
        return False
    lo = np.asarray(enc.lo, dtype=np.float64)
    return bool(lo.size > 0 and np.all(np.isfinite(lo)) and np.all(lo > 0.0))


def _has_positive_lower_bound_terms(expr: Expression, model: Model) -> bool:
    """True when every term of ``expr`` is syntactically strictly positive.

    Handles variables, indexed variables, positive constants, and affine
    combinations where every term is strictly positive.
    """
    if isinstance(expr, Constant):
        val = np.asarray(expr.value)
        return bool(val.ndim == 0 and float(val) > 0.0)
    if isinstance(expr, Variable):
        lb = float(np.asarray(expr.lb).min())
        return lb > 0.0
    if isinstance(expr, IndexExpression):
        if isinstance(expr.base, Variable):
            try:
                lb = float(np.asarray(np.asarray(expr.base.lb)[expr.index]).min())
            except (IndexError, TypeError, ValueError):
                return False
            return lb > 0.0
    if isinstance(expr, BinaryOp) and expr.op == "+":
        return _has_positive_lower_bound_terms(
            expr.left, model
        ) and _has_positive_lower_bound_terms(expr.right, model)
    if isinstance(expr, SumOverExpression):
        return bool(expr.terms) and all(
            _has_positive_lower_bound_terms(t, model) for t in expr.terms
        )
    if isinstance(expr, BinaryOp) and expr.op == "*":
        if isinstance(expr.left, (Constant, Parameter)):
            v = np.asarray(expr.left.value)
            if v.ndim == 0 and float(v) > 0.0:
                return _has_positive_lower_bound_terms(expr.right, model)
        if isinstance(expr.right, (Constant, Parameter)):
            v = np.asarray(expr.right.value)
            if v.ndim == 0 and float(v) > 0.0:
                return _has_positive_lower_bound_terms(expr.left, model)
    return False


def _is_nonneg_domain(expr: Expression, model: Model) -> bool:
    """True when ``expr`` is provably >= 0 on the declared box."""
    if isinstance(expr, Constant):
        val = np.asarray(expr.value)
        return bool(val.ndim == 0 and float(val) >= 0.0)
    if isinstance(expr, Variable):
        lb = float(np.asarray(expr.lb).min())
        return lb >= 0.0
    if isinstance(expr, IndexExpression):
        if isinstance(expr.base, Variable):
            try:
                lb = float(np.asarray(np.asarray(expr.base.lb)[expr.index]).min())
            except (IndexError, TypeError, ValueError):
                return False
            return lb >= 0.0
    if isinstance(expr, BinaryOp) and expr.op == "+":
        return _is_nonneg_domain(expr.left, model) and _is_nonneg_domain(expr.right, model)
    if isinstance(expr, SumOverExpression):
        return all(_is_nonneg_domain(t, model) for t in expr.terms)
    if isinstance(expr, BinaryOp) and expr.op == "*":
        if isinstance(expr.left, (Constant, Parameter)):
            v = np.asarray(expr.left.value)
            if v.ndim == 0 and float(v) >= 0.0:
                return _is_nonneg_domain(expr.right, model)
        if isinstance(expr.right, (Constant, Parameter)):
            v = np.asarray(expr.right.value)
            if v.ndim == 0 and float(v) >= 0.0:
                return _is_nonneg_domain(expr.left, model)
    return False


# ──────────────────────────────────────────────────────────────────────
# Quadratic-form analysis
# ──────────────────────────────────────────────────────────────────────


def _quadratic_data(expr: Expression, model: Model):
    """Extract ``(Q_sym, c, const)`` from ``f = x^T Q x + c^T x + const`` or return None.

    Uses :func:`problem_classifier._extract_quadratic_coefficients` and
    symmetrises ``Q``. Returns ``None`` if the expression is not degree-2.

    Also returns ``None`` when the extractor hands back a *sparse* ``Q`` (#863).
    Every consumer of this function is unavoidably dense — ``np.diag(Q)``, boolean
    row/column masks, ``np.linalg.eigvalsh`` — and each already treats ``None`` as
    "not extractable as a quadratic form", which is the conservative answer (no
    curvature claim, so the caller keeps its weaker but valid classification). The
    sparse arm only triggers above ``_QP_DENSE_Q_MAX_BYTES`` (n > ~5,657), where
    this analysis was already impractical: it makes three ``(n, n)`` copies in the
    ``0.5 * (Q + Q.T)`` line alone. Refusing there is strictly better than the old
    behaviour, which allocated ``(n, n)`` unconditionally — 91 GB on
    watercontamination0202's 106,711 variables.
    """
    from discopt._relax.problem_classifier import (
        _EXTRACTION_DECLINES,
        _extract_quadratic_coefficients,
    )

    # #1520: narrowed to the extractor's documented declines: ``_NotQuadraticError``
    # ("degree > 2") and ``_NotLinearError``, which its constant folding raises on a
    # non-scalar array coefficient (``_eval_const``; test_944 exercises it).
    try:
        Q, c, const = _extract_quadratic_coefficients(expr, model, _total_scalar_variables(model))
    except _EXTRACTION_DECLINES:
        return None
    if _sp.issparse(Q):
        return None
    Q = 0.5 * (Q + Q.T)
    return Q, np.asarray(c, dtype=np.float64), float(const)


def _support_restricted(Q: np.ndarray) -> np.ndarray:
    """Restrict a symmetric ``Q`` to the nonzero support of its rows/columns.

    ``_quadratic_data`` hands back ``Q`` as a full ``n_total x n_total`` dense
    matrix, so a quadratic touching a handful of variables still costs an
    ``O(n_total**3)`` ``eigvalsh`` (#814). The omitted rows/columns are all-zero
    and contribute exactly-zero eigenvalues, which can never flip a
    ``min >= -tol`` or ``max <= tol`` sign test — so every eigenvalue-SIGN
    classification is identical on the submatrix, while the cost drops to the
    support dimension.

    This is only valid for sign tests against a tolerance that admits zero. Do
    not use it where the *number* or *magnitude* of zero eigenvalues matters
    (rank, determinant, condition number).

    Returns a ``0x0`` array when ``Q`` is entirely zero; callers decide what an
    empty spectrum means rather than having this function guess.
    """
    # Exact nonzeros (#1660): a ``1e-12`` cut dropped ``-1e-13 * x**2`` from the
    # support, so the sign test never saw the negative curvature it carries.
    support = np.nonzero(np.any(Q != 0.0, axis=0))[0]
    if support.size < Q.shape[0]:
        return Q[np.ix_(support, support)]
    return Q


def _quadratic_sign_form(expr: Expression, model: Model):
    """``(Q_support, c, const)`` for an eigenvalue SIGN test, or ``None``.

    Returns exactly what ``_support_restricted(_quadratic_data(expr, model)[0])``
    returns — the same submatrix, bit for bit — **without ever materialising the
    ``(n_total, n_total)`` Hessian** (#1456).

    #814 and #1458 cut the *eigendecomposition* down to the support, which left
    the allocation as the whole cost.  Measured on ``glider400`` (5215 variables,
    401 calls from one ``has_factorable_work`` scan): ``_quadratic_data`` spends
    26.8 s, of which 26.2 s is the single line ``0.5 * (Q + Q.T)`` — three dense
    218 MB temporaries per call, for quadratics that touch a handful of
    variables.  Building the support submatrix straight from the sparse term
    dict costs **0.002 s** for the same 401 calls, a 16,709x reduction, with all
    401 PSD/NSD sign decisions and every ``c``/``const`` identical.

    (Recorded per CLAUDE.md §4: the first attempt — reorder to restrict support
    *before* symmetrising, keeping the dense extraction — was measured at 3.5x
    against a pre-stated 5x kill criterion and abandoned.  Caching was measured
    too: all 401 expressions are distinct objects, so there is nothing to reuse.
    The allocation had to go, not be reordered or memoised.)

    BIT-IDENTICAL, deliberately, so this is a bound-NEUTRAL change (§5) and can
    be verified by "node count and objective exactly unchanged" rather than by a
    differential panel:

    * ``_extract_quadratic_terms`` is the same walk ``_extract_quadratic_coefficients``
      performs — the latter is a thin wrapper that materialises its result — so
      the cell values, including #1397's exact ``math.fsum``, are the same doubles.
    * The support is taken on the SYMMETRISED values against the same ``1e-12``,
      which for a symmetric matrix is the same index set as
      ``_support_restricted``'s column test, and is emitted in ascending global
      index order exactly as ``np.ix_`` does.
    * The wide-model refusal is preserved.  ``_quadratic_data`` returns ``None``
      once ``(n, n)`` float64 exceeds ``_QP_DENSE_Q_MAX_BYTES`` because its
      consumers were dense (#863).  This consumer no longer is, so the refusal
      could now be lifted — that would recognise structure on wide models that is
      currently declined, which is *bound-changing* and belongs in its own PR
      behind the §5 differential panel.  It is kept here so that this change
      alters nothing but the clock.
    """
    from discopt._relax.problem_classifier import (
        _EXTRACTION_DECLINES,
        _QP_DENSE_Q_MAX_BYTES,
        _extract_quadratic_terms,
    )

    n = _total_scalar_variables(model)
    if (n * n * 8) > _QP_DENSE_Q_MAX_BYTES:
        return None
    # #1520: narrowed to the extractor's documented declines (see ``_quadratic_data``).
    try:
        terms, c, const = _extract_quadratic_terms(expr, model, n)
    except _EXTRACTION_DECLINES:
        return None

    # Symmetrise on the nonzeros only: ``0.5 * (Q + Q.T)`` restricted to the
    # cells either triangle actually touches.  A cell absent from both is 0.0 in
    # the dense arm too, so it can be neither in the support nor in the submatrix.
    sym: dict[tuple[int, int], float] = {}
    for i, j in terms:
        if (i, j) in sym:
            continue
        v = 0.5 * (terms.get((i, j), 0.0) + terms.get((j, i), 0.0))
        sym[(i, j)] = v
        sym[(j, i)] = v

    # Exact nonzeros, matching ``_support_restricted`` (#1660).
    support = sorted({i for (i, _j), v in sym.items() if v != 0.0})
    if not support:
        # ``_support_restricted`` returns 0x0 for an all-zero Q; callers decide
        # what an empty spectrum means.
        return np.zeros((0, 0), dtype=np.float64), np.asarray(c, dtype=np.float64), float(const)
    pos = {g: k for k, g in enumerate(support)}
    sub = np.zeros((len(support), len(support)), dtype=np.float64)
    for (i, j), v in sym.items():
        ki, kj = pos.get(i), pos.get(j)
        if ki is not None and kj is not None:
            sub[ki, kj] = v
    return sub, np.asarray(c, dtype=np.float64), float(const)


def _linear_vector_matrix(expr: Expression, model: Model) -> Optional[np.ndarray]:
    """Return A for vector affine form ``A @ x`` with no constant term."""
    n_total = _total_scalar_variables(model)
    if isinstance(expr, MatMulExpression):
        if isinstance(expr.left, Constant) and isinstance(expr.right, Variable):
            mat = np.asarray(expr.left.value, dtype=np.float64)
            var = expr.right
            offset = _var_offset(model, var)
            if offset is None:
                return None
            if mat.ndim == 1:
                mat = mat.reshape(1, -1)
            if mat.ndim != 2 or mat.shape[1] != var.size:
                return None
            out = np.zeros((mat.shape[0], n_total), dtype=np.float64)
            out[:, offset : offset + var.size] = mat.reshape(mat.shape[0], var.size)
            return out
        if isinstance(expr.left, Variable) and isinstance(expr.right, Constant):
            mat = np.asarray(expr.right.value, dtype=np.float64)
            var = expr.left
            offset = _var_offset(model, var)
            if offset is None:
                return None
            if mat.ndim == 1:
                mat = mat.reshape(-1, 1)
            if mat.ndim != 2 or mat.shape[0] != var.size:
                return None
            out = np.zeros((mat.shape[1], n_total), dtype=np.float64)
            out[:, offset : offset + var.size] = mat.T.reshape(mat.shape[1], var.size)
            return out
    if isinstance(expr, Variable):
        offset = _var_offset(model, expr)
        if offset is None:
            return None
        out = np.zeros((expr.size, n_total), dtype=np.float64)
        out[:, offset : offset + expr.size] = np.eye(expr.size, dtype=np.float64)
        return out
    return None


def _sum_of_squares_linear_matrix(expr: Expression, model: Model) -> Optional[np.ndarray]:
    """Return A for ``sum((A @ x) * (A @ x))``-style squared norms."""
    if not isinstance(expr, SumExpression):
        return None
    operand = expr.operand
    if not isinstance(operand, BinaryOp) or operand.op != "*":
        return None
    left = _linear_vector_matrix(operand.left, model)
    right = _linear_vector_matrix(operand.right, model)
    if left is None or right is None:
        return None
    # Exact: ``(A x) * (A' x)`` with ``A' != A`` is not ``||A x||^2`` and can be
    # indefinite however close ``A'`` is (``allclose``'s rtol=1e-5 accepted it).
    if left.shape != right.shape or not np.array_equal(left, right):
        return None
    return left


def _affine_square_sum_matrix(
    expr: Expression, model: Model
) -> Optional[tuple[np.ndarray, np.ndarray]]:
    """Return ``(A, b)`` when ``expr == sum_i (a_i . x + b_i)**2 == ||A x + b||^2``.

    Each summand of the top-level ``+`` tree must be a perfect square of a
    *scalar affine* form: either ``(affine)**2`` or ``affine * affine`` with
    both factors structurally identical. Rows of ``A`` are the affine
    coefficient vectors and ``b`` the affine constants. Returns ``None`` if the
    expression does not have this shape.

    Because ``sqrt`` of this is the Euclidean norm ``||A x + b||_2`` of an
    affine map, it is convex for *any* ``A`` and ``b`` — no PSD/eigenvalue
    check is needed (the sum-of-squares structure makes it PSD by
    construction, and a nonzero constant ``b`` is still convex). This is the
    affine-difference generalization of :func:`_sum_of_squares_linear_matrix`,
    which only matched homogeneous ``sum((A@x)*(A@x))`` MatMul forms.
    """
    from discopt._relax.problem_classifier import _extract_linear_coefficients, _NotLinearError

    n_total = _total_scalar_variables(model)

    terms: list[Expression] = []

    def _flatten_sum(node: Expression) -> None:
        if isinstance(node, BinaryOp) and node.op == "+":
            _flatten_sum(node.left)
            _flatten_sum(node.right)
        elif isinstance(node, SumExpression) and _summed_vector_square_base(node) is None:
            _flatten_sum(node.operand)
        else:
            terms.append(node)

    _flatten_sum(expr)
    if not terms:
        return None

    rows: list[np.ndarray] = []
    consts: list[float] = []
    for term in terms:
        # Peel a nonnegative scalar coefficient: ``c * s**2`` with ``c >= 0`` is the
        # square ``(sqrt(c) * s)**2``, so a *weighted* sum of affine squares is still
        # ``||A x + b||^2`` (absorb ``sqrt(c)`` into the affine row). A negative
        # coefficient would break the sum-of-squares/PSD structure, so it abstains.
        scale, core = _peel_nonneg_scale(term)
        if scale is None:
            return None
        # A bare nonnegative constant term ``c`` is the square ``(sqrt(c))**2`` of a
        # zero affine form — a valid constant row, so ``sqrt(sum affine^2 + c)`` is
        # still ``||A x + b||`` (e.g. smoothed/regularized distances).
        if isinstance(core, Constant) and core.value.ndim == 0:
            cval = scale * float(core.value)
            if cval < 0.0:
                return None
            rows.append(np.zeros(n_total, dtype=np.float64))
            consts.append(float(np.sqrt(cval)))
            continue
        # ``dm.sum(v**2)`` for a vector affine ``v`` is one square per element of
        # ``v`` (#1933; the same reading the sum-of-squares lift gives it, #1679).
        vec_base = _summed_vector_square_base(core)
        if vec_base is not None:
            vec_rows = _vector_affine_rows(vec_base, model, n_total)
            if vec_rows is None:
                return None
            A_v, b_v = vec_rows
            root_v = float(np.sqrt(scale))
            rows.extend(root_v * np.asarray(A_v.toarray(), dtype=np.float64))
            consts.extend((root_v * np.asarray(b_v, dtype=np.float64).ravel()).tolist())
            continue
        base: Optional[Expression] = None
        if (
            isinstance(core, BinaryOp)
            and core.op == "**"
            and isinstance(core.right, Constant)
            and core.right.value.ndim == 0
            and abs(float(core.right.value) - 2.0) < 1e-12
        ):
            base = core.left
        elif isinstance(core, BinaryOp) and core.op == "*" and _same_expr(core.left, core.right):
            base = core.left
        if base is None:
            return None
        # #1520: narrowed to the extractor's documented decline ("not affine").
        try:
            coeffs, const = _extract_linear_coefficients(base, model, n_total)
        except _NotLinearError:
            return None
        root = float(np.sqrt(scale))
        rows.append(root * coeffs)
        consts.append(root * const)

    return np.asarray(rows, dtype=np.float64), np.asarray(consts, dtype=np.float64)


def _summed_vector_square_base(node: Expression) -> Optional[Expression]:
    """``v`` when ``node`` is ``dm.sum(v**2)`` or ``dm.sum(v * v)`` (full reduction)."""
    if not isinstance(node, SumExpression) or node.axis is not None:
        return None
    op = node.operand
    if (
        isinstance(op, BinaryOp)
        and op.op == "**"
        and isinstance(op.right, Constant)
        and op.right.value.ndim == 0
        and float(op.right.value) == 2.0
    ):
        return op.left
    if isinstance(op, BinaryOp) and op.op == "*" and (op.left is op.right):
        return op.left
    return None


def _vector_affine_rows(expr: Expression, model: Model, n_total: int):
    """``(A, b)`` with ``expr == A @ x_flat + b`` element-wise (flattened), or ``None``.

    #1679: the vector spelling of least squares, ``dm.sum((K @ x - b)**2)``, is a
    sum of squares of the affine rows of ``K @ x - b``; the scalar extractor
    refuses a vector-valued node, so the sum-of-squares lift never saw it. Handled
    exactly (each coefficient is the float the expression itself would multiply by,
    no tolerance): variables (whole, or indexed by a slice / index array), constants,
    ``M @ v`` / ``v @ M`` with a constant matrix ``M`` and a 1-D affine ``v``, ``+``
    and ``-`` (with scalar broadcasting), ``neg``, and ``*`` / ``/`` by a constant
    scalar or an equal-shape constant array (no other broadcasting: ``x + ones((3, 1))``
    is 3x3 and is refused). Anything else returns ``None`` -- an
    abstention, never a guess. ``A`` is CSR of shape ``(m, n_total)``.
    """

    def same_or_scalar(s1: tuple, s2: tuple) -> Optional[tuple]:
        # Result shape when ``s1`` and ``s2`` combine element-wise with *no* broadcasting
        # except a size-1 operand against the other's exact shape; ``None`` otherwise.
        # Anything wider (``(3,) + (3, 1) -> (3, 3)``) would change the element count
        # behind a matching size, so it is refused rather than flattened wrongly.
        try:
            out = tuple(np.broadcast_shapes(s1, s2))
        except ValueError:
            return None
        if s1 == s2:
            return out
        if int(np.prod(s2)) == 1 and out == s1:
            return out
        if int(np.prod(s1)) == 1 and out == s2:
            return out
        return None

    def rec(e: Expression):
        if isinstance(e, Constant):
            val = np.asarray(e.value, dtype=np.float64)
            v = val.ravel()
            return _sp.csr_matrix((v.size, n_total)), v, tuple(val.shape)
        if isinstance(e, Variable):
            off = _var_offset(model, e)
            if off is None:
                return None
            cols = off + np.arange(e.size)
            A = _sp.csr_matrix(
                (np.ones(e.size), (np.arange(e.size), cols)), shape=(e.size, n_total)
            )
            return A, np.zeros(e.size), tuple(e.shape)
        if isinstance(e, IndexExpression) and isinstance(e.base, Variable):
            off = _var_offset(model, e.base)
            if off is None:
                return None
            try:
                picked = np.asarray(np.arange(e.base.size).reshape(e.base.shape)[e.index])
            except (IndexError, TypeError, ValueError):
                return None
            sel = picked.ravel()
            k = sel.size
            A = _sp.csr_matrix((np.ones(k), (np.arange(k), off + sel)), shape=(k, n_total))
            return A, np.zeros(k), tuple(picked.shape)
        if isinstance(e, UnaryOp) and e.op == "neg":
            r = rec(e.operand)
            return None if r is None else (-r[0], -r[1], r[2])
        if isinstance(e, MatMulExpression):
            if isinstance(e.left, Constant):
                M = np.asarray(e.left.value, dtype=np.float64)
                r = rec(e.right)
                if r is None or M.ndim not in (1, 2):
                    return None
                M2 = M.reshape(1, -1) if M.ndim == 1 else M
            elif isinstance(e.right, Constant):
                M = np.asarray(e.right.value, dtype=np.float64)
                r = rec(e.left)
                if r is None or M.ndim not in (1, 2):
                    return None
                M2 = M.reshape(1, -1) if M.ndim == 1 else M.T
            else:
                return None
            # Only matrix-vector / vector-vector products of a 1-D affine operand.
            if len(r[2]) != 1 or M2.shape[1] != r[2][0] or not np.all(np.isfinite(M2)):
                return None
            mshape: tuple = () if M.ndim == 1 else (M2.shape[0],)
            return _sp.csr_matrix(_sp.csr_matrix(M2) @ r[0]), M2 @ r[1], mshape
        if isinstance(e, BinaryOp) and e.op in ("+", "-"):
            lr, rr = rec(e.left), rec(e.right)
            if lr is None or rr is None:
                return None
            (A1, b1, s1), (A2, b2, s2) = lr, rr
            shape = same_or_scalar(s1, s2)
            if shape is None:
                return None
            m1, m2 = A1.shape[0], A2.shape[0]
            if m1 != m2:
                if m1 == 1:
                    A1, b1 = _sp.vstack([A1] * m2).tocsr(), np.repeat(b1, m2)
                elif m2 == 1:
                    A2, b2 = _sp.vstack([A2] * m1).tocsr(), np.repeat(b2, m1)
                else:
                    return None
            s = 1.0 if e.op == "+" else -1.0
            return (A1 + s * A2).tocsr(), b1 + s * b2, shape
        if isinstance(e, BinaryOp) and e.op in ("*", "/"):
            if isinstance(e.right, Constant):
                cval, other = np.asarray(e.right.value, dtype=np.float64), e.left
            elif isinstance(e.left, Constant) and e.op == "*":
                cval, other = np.asarray(e.left.value, dtype=np.float64), e.right
            else:
                return None
            r = rec(other)
            if r is None or not np.all(np.isfinite(cval)):
                return None
            A, b, sh = r
            shape = same_or_scalar(sh, tuple(cval.shape))
            if shape is None or shape != sh:
                return None
            cst = cval.ravel()
            if cst.size == 1:
                f = float(cst[0])
                if e.op == "/":
                    if f == 0.0:
                        return None
                    return (A / f).tocsr(), b / f, sh
                return (A * f).tocsr(), b * f, sh
            if e.op == "/":
                if np.any(cst == 0.0):
                    return None
                return _sp.csr_matrix(_sp.diags(1.0 / cst) @ A), b / cst, sh
            return _sp.csr_matrix(_sp.diags(cst) @ A), b * cst, sh
        return None

    out = rec(expr)
    return None if out is None else (out[0], out[1])


def weighted_affine_square_decomposition(
    expr: Expression, model: Model, sign: float = 1.0
) -> Optional[tuple[np.ndarray, _sp.csr_matrix, np.ndarray, np.ndarray, float]]:
    """Decompose ``sign * expr`` as ``sum_k w_k (a_k . x + b_k)**2 + l . x + c0``, ``w_k > 0``.

    Returns ``(w, A, b, l, c0)`` -- rows of ``A`` are the ``a_k`` over every scalar
    variable of the model, sparse -- or ``None`` when the expression does not have that
    shape *structurally*. The top level is a signed sum (``+``, ``-``, negation,
    ``dm.sum``); each summand, after peeling a product of scalar constants, is
    either a square of a scalar affine form (``s**2`` or ``s * s`` with the same
    ``s``) carrying a strictly positive weight, or affine. A square with a
    non-positive weight abstains: that is curvature this proof does not cover.

    The point is that convexity here is a fact about the *expression*, not about a
    floating-point Hessian: ``Q = 2 A' diag(w) A`` assembled in floats can be
    indefinite in exact arithmetic for a rank-deficient ``A`` (#1616 A-18), and an
    exact PSD test then correctly refuses it. Lifting ``d_k = a_k . x + b_k`` turns
    the objective into ``sum_k w_k d_k**2 + l . x + c0``, whose Hessian is
    diagonal with entries ``2 w_k > 0`` -- PSD exactly, with no rounding to argue.
    """
    from discopt._relax.problem_classifier import (
        _extract_linear_coefficients_sparse,
        _NotLinearError,
    )

    n_total = _total_scalar_variables(model)
    terms: list[tuple[float, Expression]] = []
    _flatten_sum_terms(expr, float(sign), terms)

    weights: list[float] = []
    r_idx: list[int] = []
    c_idx: list[int] = []
    vals: list[float] = []
    consts: list[float] = []
    lin = np.zeros(n_total, dtype=np.float64)
    c0 = 0.0
    for scale, term in terms:
        node = term
        while isinstance(node, BinaryOp) and node.op == "*":
            if isinstance(node.left, Constant) and node.left.value.ndim == 0:
                scale *= float(node.left.value)
                node = node.right
            elif isinstance(node.right, Constant) and node.right.value.ndim == 0:
                scale *= float(node.right.value)
                node = node.left
            else:
                break
        if not np.isfinite(scale):
            return None
        vec_base = _summed_vector_square_base(node)
        if vec_base is not None:
            # #1679: ``dm.sum(v**2)`` for a vector affine ``v`` -- one weighted square
            # per element of ``v``.
            if scale == 0.0:
                continue
            if scale < 0.0:
                return None
            rows = _vector_affine_rows(vec_base, model, n_total)
            if rows is None:
                return None
            A_v, b_v = rows
            coo = A_v.tocoo()
            base_row = len(weights)
            r_idx.extend((coo.row + base_row).tolist())
            c_idx.extend(coo.col.tolist())
            vals.extend(coo.data.tolist())
            weights.extend([scale] * A_v.shape[0])
            consts.extend(np.asarray(b_v, dtype=np.float64).tolist())
            continue
        base: Optional[Expression] = None
        if (
            isinstance(node, BinaryOp)
            and node.op == "**"
            and isinstance(node.right, Constant)
            and node.right.value.ndim == 0
            and float(node.right.value) == 2.0
        ):
            base = node.left
        elif isinstance(node, BinaryOp) and node.op == "*" and _same_expr(node.left, node.right):
            base = node.left
        try:
            if base is not None:
                if scale == 0.0:
                    continue
                if scale < 0.0:
                    return None
                row, const = _extract_linear_coefficients_sparse(base, model, n_total)
                for j, v in row.items():
                    r_idx.append(len(weights))
                    c_idx.append(j)
                    vals.append(float(v))
                weights.append(scale)
                consts.append(float(const))
            else:
                row, const = _extract_linear_coefficients_sparse(node, model, n_total)
                for j, v in row.items():
                    lin[j] += scale * float(v)
                c0 += scale * float(const)
        except _NotLinearError:
            return None
    if not weights:
        return None
    return (
        np.asarray(weights, dtype=np.float64),
        _sp.csr_matrix((vals, (r_idx, c_idx)), shape=(len(weights), n_total)),
        np.asarray(consts, dtype=np.float64),
        lin,
        float(c0),
    )


def _peel_nonneg_scale(term: Expression) -> tuple[Optional[float], Expression]:
    """Peel a product of nonnegative constant factors off ``term``.

    Returns ``(scale, core)`` where ``term == scale * core`` and ``scale >= 0``,
    or ``(None, term)`` if a constant factor is negative (which would invalidate
    the sum-of-squares structure the caller relies on). Constants may appear on
    either side and may be nested (``c1 * (c2 * s**2))``.
    """
    scale = 1.0
    node = term
    while isinstance(node, BinaryOp) and node.op == "*":
        if isinstance(node.left, Constant) and node.left.value.ndim == 0:
            c = float(node.left.value)
            if c < 0.0:
                return None, term
            scale *= c
            node = node.right
        elif isinstance(node.right, Constant) and node.right.value.ndim == 0:
            c = float(node.right.value)
            if c < 0.0:
                return None, term
            scale *= c
            node = node.left
        else:
            break
    return scale, node


def is_affine_norm_square(expr: Expression, model: Model) -> bool:
    """True when ``expr == ||A x + b||_2^2`` for some affine map ``A x + b``.

    Recognises a sum of squares of scalar affine forms (see
    :func:`_affine_square_sum_matrix`). ``sqrt`` of such an expression is a
    convex Euclidean norm regardless of the constant term, which covers
    ``sqrt((x0-x2)**2 + (x1-x3)**2)``-style neighbourhood/distance objectives
    (MINLPLib ``tspn*``) that the homogeneous quadratic recognizer misses.
    """
    return _affine_square_sum_matrix(expr, model) is not None


def is_homogeneous_psd_quadratic(expr: Expression, model: Model) -> bool:
    """True when ``expr`` is ``x^T Q x`` (no linear/constant term) with Q PSD."""
    if _sum_of_squares_linear_matrix(expr, model) is not None:
        # ``sum((A@x)*(A@x))`` with the two factors equal is ``||A x||**2``: PSD and
        # homogeneous by construction, for every ``A``. The eigenvalue test this
        # replaced decided an identity by floating point (#1660).
        return True
    # #1456: this is a min-eigenvalue SIGN test, so it is exact on the support
    # (see ``_support_restricted``). Without this, one ``sqrt`` node in
    # glider400's 5215-variable model costs a 5215x5215 eigendecomposition;
    # measured, 20 such calls spent 119 s -- 97.6% of a solve given a 20 s
    # time_limit. The sibling ``quadratic_curvature`` got this treatment in
    # #814 and this function was missed.
    #
    # ``_quadratic_sign_form`` returns that same submatrix bit for bit without
    # allocating the whole-model Hessian first, which after the eigendecomposition
    # was cut down had become the entire remaining cost: 26.2 s of glider400's
    # 26.8 s, in the symmetrisation line alone.
    data = _quadratic_sign_form(expr, model)
    if data is None:
        return False
    Qs, c, const = data
    # Exactly homogeneous (#1660): ``sqrt(x^T Q x + c^T x)`` is not a norm for
    # any nonzero ``c``, however small -- a box makes a tiny term matter.
    if np.any(c != 0.0) or const != 0.0:
        return False
    if Qs.size == 0:
        return True  # Q is entirely zero: the zero form is PSD
    return psd_proved(Qs)


def quadratic_curvature(expr: Expression, model: Model) -> Optional[Curvature]:
    """Return the curvature of a scalar quadratic, if one can be extracted.

    ``None`` when the expression is not extractable as a quadratic form
    (e.g., it contains a non-polynomial atom). Used as a whole-expression
    fallback when the DCP walker leaves a degree-2 polynomial at UNKNOWN
    because its structure only becomes visible after symbolic expansion.
    """
    # #814: restrict the eigenproblem to the nonzero SUPPORT of Q, which is exact
    # for the CONVEX (min >= 0) / CONCAVE (max <= 0) sign tests below. Without it
    # one gas-pipe flow term in gastrans582's 2186-var model triggers an
    # O(n_total**3) eigvalsh and grinds the root relaxation build for 75s+ before
    # B&B even starts. Shared with ``is_homogeneous_psd_quadratic`` via
    # ``_quadratic_sign_form`` so the two cannot drift apart again (#1456: they
    # had, and the miss cost glider400 97.6% of its time limit).
    #
    # #1456: the submatrix now comes back without the whole-model Hessian being
    # built at all — bit-identical, so every classification below is unchanged.
    data = _quadratic_sign_form(expr, model)
    if data is None:
        return None
    Q, _c, _const = data
    # #1660: every verdict here is box-free, so it must hold on every box. The
    # absolute ``1e-10`` tests this replaces called ``-1e-11 * x**2`` AFFINE and
    # ``-1e-11 * x**2 + y**2`` CONVEX; on ``x in [-1e4, 1e4]`` that negative
    # curvature is worth -1e-3 and the convex-QP route certified a false bound.
    # AFFINE now means Q is exactly zero (the support is exact, so that is an
    # empty support), and CONVEX/CONCAVE need a proof (``psd_proved``).
    if Q.size == 0:
        return Curvature.AFFINE
    if psd_proved(Q):
        return Curvature.CONVEX
    if psd_proved(-Q):
        return Curvature.CONCAVE
    return Curvature.UNKNOWN


# ──────────────────────────────────────────────────────────────────────
# Product / division / sqrt pattern recognizers
# ──────────────────────────────────────────────────────────────────────


def classify_product_pattern(
    expr: BinaryOp,
    model: Model,
    classify_expr,  # noqa: ANN001 — forward reference avoids circular import
    cache: dict,
) -> Optional[Curvature]:
    """Return CONVEX / CONCAVE for recognised product patterns, else None.

    Recognised:

    * ``y * exp(x / y)`` with ``y > 0`` and ``x`` affine — perspective of
      ``exp``: CONVEX.
    * ``exp(affine) * prod_i g_i(x)**a_i`` where every ``g_i`` is affine and
      strictly positive and every ``a_i <= 0``: CONVEX because it is
      ``exp(affine + Σ a_i log(g_i(x)))`` with a convex exponent.
    * **Signomial monomial** ``c * prod_i base_i ** a_i`` with every base
      affine, classified by exponent sign pattern on the positive orthant
      (Boyd & Vandenberghe §3.1.5):

        - all ``a_i >= 0`` and ``sum a_i <= 1`` with nonneg bases — a
          generalized weighted geometric mean: CONCAVE.
        - all ``a_i <= 0`` with strictly-positive bases: CONVEX.
        - exactly one ``a_k >= 1``, every other ``a_i <= 0``, ``sum a_i >= 1``,
          strictly-positive bases: CONVEX.

      A negative leading constant ``c`` flips CONVEX <-> CONCAVE.
    """
    # Perspective of exp: y * exp(x / y), y > 0.
    for scale_expr, exp_expr in ((expr.left, expr.right), (expr.right, expr.left)):
        if (
            classify_expr(scale_expr, model, cache) == Curvature.AFFINE
            and _has_positive_lower_bound(scale_expr, model)
            and isinstance(exp_expr, FunctionCall)
            and exp_expr.func_name == "exp"
            and len(exp_expr.args) == 1
        ):
            inner = exp_expr.args[0]
            if isinstance(inner, BinaryOp) and inner.op == "/":
                if (
                    _same_expr(scale_expr, inner.right)
                    and classify_expr(inner.left, model, cache) == Curvature.AFFINE
                    and classify_expr(inner.right, model, cache) == Curvature.AFFINE
                ):
                    return Curvature.CONVEX

    # Peel the leading scalar constant. The remaining product is inspected by
    # the exp-times-reciprocal-power and signomial recognizers below. A negative
    # constant flips the curvature.
    const, core = _split_const_mul(expr)
    if core is None or abs(const) <= 1e-12:
        return None
    factors: list[Expression] = []
    _flatten_product(core, factors)
    if len(factors) < 2:
        return None

    exp_factor_count = 0
    power_factors: list[tuple[Expression, float]] = []
    exp_power_candidate = True
    for factor in factors:
        if (
            isinstance(factor, FunctionCall)
            and factor.func_name == "exp"
            and len(factor.args) == 1
            and classify_expr(factor.args[0], model, cache) == Curvature.AFFINE
        ):
            exp_factor_count += 1
            continue
        extracted = _extract_power_factor(factor)
        if extracted is None:
            exp_power_candidate = False
            break
        base, exponent = extracted
        if classify_expr(base, model, cache) != Curvature.AFFINE:
            exp_power_candidate = False
            break
        power_factors.append((base, exponent))

    tol = 1e-10
    if (
        exp_power_candidate
        and exp_factor_count >= 1
        and all(exp <= tol for _base, exp in power_factors)
        and all(_affine_strictly_positive(base, model) for base, _exp in power_factors)
    ):
        return Curvature.CONCAVE if const < 0 else Curvature.CONVEX

    parsed: list[tuple[Expression, float]] = []
    for factor in factors:
        extracted = _extract_power_factor(factor)
        if extracted is None:
            return None
        base, exponent = extracted
        if classify_expr(base, model, cache) != Curvature.AFFINE:
            return None
        parsed.append((base, exponent))

    exps = [exp for _, exp in parsed]
    bases = [base for base, _ in parsed]
    total = sum(exps)

    base_curv: Optional[Curvature] = None
    if (
        all(exp >= -tol for exp in exps)
        and total <= 1.0 + tol
        and all(_is_nonneg_domain(base, model) for base in bases)
    ):
        # Generalized weighted geometric mean — concave on the nonneg orthant.
        base_curv = Curvature.CONCAVE
    elif all(_affine_strictly_positive(base, model) for base in bases):
        if all(exp <= tol for exp in exps):
            # All exponents non-positive — convex on the positive orthant.
            base_curv = Curvature.CONVEX
        else:
            big = [exp for exp in exps if exp >= 1.0 - tol]
            rest_nonpos = all(exp <= tol for exp in exps if exp < 1.0 - tol)
            if len(big) == 1 and rest_nonpos and total >= 1.0 - tol:
                # One exponent >= 1, the rest <= 0, total >= 1 — convex.
                base_curv = Curvature.CONVEX

    if base_curv is None:
        return None
    if const < 0:
        return Curvature.CONCAVE if base_curv == Curvature.CONVEX else Curvature.CONVEX
    return base_curv


def classify_division_pattern(
    expr: BinaryOp,
    model: Model,
    classify_expr,  # noqa: ANN001
    cache: dict,
) -> Optional[Curvature]:
    """Return CONVEX for ``x^T Q x / affine(y)`` with ``affine > 0`` and Q PSD."""
    if classify_expr(expr.right, model, cache) != Curvature.AFFINE:
        return None
    if not _has_positive_lower_bound(expr.right, model):
        return None
    if is_homogeneous_psd_quadratic(expr.left, model):
        return Curvature.CONVEX
    return None


def classify_sqrt_pattern(
    arg: Expression,
    model: Model,
    classify_expr=None,  # noqa: ANN001 — forward reference avoids circular import
    cache: Optional[dict] = None,
) -> Optional[Curvature]:
    """Return curvature for recognised ``sqrt(arg)`` shapes, else None.

    * ``sqrt(x^T Q x)`` with Q PSD — Euclidean-style norm: CONVEX (even though
      the inner quadratic is itself convex, ``concave ∘ convex`` would fail DCP
      composition, so the norm is recognised directly).
    * ``sqrt(prod_i base_i ** p_i)`` with every ``base_i`` affine and nonneg on
      the box, ``p_i >= 0`` and ``sum_i p_i <= 2`` — a weighted geometric mean
      ``prod_i base_i ** (p_i / 2)`` whose halved exponents are nonneg and sum
      to ``<= 1``: CONCAVE. Covers ``sqrt(x_i * x_j)`` geometric-mean concavity
      (MINLPLib ``tls*``). Requires ``classify_expr`` / ``cache`` to verify the
      bases are affine; skipped when they are not supplied.
    """
    # Euclidean norm of an affine map: sqrt(sum_i (a_i.x + b_i)^2) = ||A x + b||,
    # convex for any affine map. Tried first: it is a structural walk, while the
    # homogeneous PSD recognizer below runs an eigendecomposition on the support
    # (3.3 s on a 5000-term cone, #1933). Either one proving CONVEX suffices, so
    # the order changes only the cost.
    if is_affine_norm_square(arg, model):
        return Curvature.CONVEX

    if is_homogeneous_psd_quadratic(arg, model):
        return Curvature.CONVEX

    # Geometric-mean concavity: sqrt of a product of nonneg affine powers.
    # sqrt(prod base_i^{p_i}) = prod base_i^{p_i/2}; with weights w_i = p_i/2
    # >= 0 and sum w_i <= 1 over affine nonneg bases, the product of powers is
    # concave on the nonneg orthant (Boyd & Vandenberghe §3.1.5).
    if classify_expr is not None:
        factors: list[Expression] = []
        _flatten_product(arg, factors)
        if len(factors) >= 1:
            total = 0.0
            ok = True
            for factor in factors:
                extracted = _extract_power_factor(factor)
                if extracted is None:
                    ok = False
                    break
                base, exponent = extracted
                if exponent < -1e-10:
                    ok = False
                    break
                if classify_expr(base, model, cache) != Curvature.AFFINE:
                    ok = False
                    break
                if not _is_nonneg_domain(base, model):
                    ok = False
                    break
                total += exponent
            if ok and total > 1e-10 and total <= 2.0 + 1e-10:
                return Curvature.CONCAVE
    return None


def classify_perspective_product(
    expr: BinaryOp,
    model: Model,
    classify_expr,  # noqa: ANN001 — forward reference avoids circular import
    cache: dict,
) -> Optional[Curvature]:
    """Return CONVEX for a perspective product ``P * L`` with ``L`` affine > 0.

    Recognises the perspective reformulation ``g(x)^2 / L`` written in the
    expanded arrangement ``((g / L) ** 2) * L`` together with its affine
    companions ``(h / L) * L`` and ``const * L``. With ``L`` affine and
    strictly positive on the box, each squared term ``(g / L) ** 2`` (``g``
    affine) is a quadratic-over-affine; multiplying the whole sum by ``L``
    distributes and collapses ``(g / L)^2 * L = g^2 / L`` (convex
    quad-over-linear), ``(h / L) * L = h`` (affine), and ``const * L`` (affine).
    A nonneg-weighted sum of convex + affine terms is convex.

    Covers the MINLPLib ``clay*hfsg`` perspective layout, which the
    quadratic-over-affine recogniser misses (the ``* L`` keeps the node a
    product) and whose box interval Hessian blows up as ``L`` approaches its
    lower bound, defeating the Gershgorin certificate.

    Requires at least one genuine squared (quad-over-affine) term — a product
    whose terms all collapse to affine is left to the generic walker.
    """
    if not isinstance(expr, BinaryOp) or expr.op != "*":
        return None

    for p_expr, l_expr in ((expr.left, expr.right), (expr.right, expr.left)):
        if classify_expr(l_expr, model, cache) != Curvature.AFFINE:
            continue
        if not _affine_strictly_positive(l_expr, model):
            continue

        terms: list[tuple[float, Expression]] = []
        _flatten_sum_terms(p_expr, 1.0, terms)
        if not terms:
            continue

        all_ok = True
        saw_square = False
        for scale_i, term in terms:
            const, core = _split_const_mul(term)
            if core is None:
                # const * L → affine, any sign acceptable.
                continue
            # Affine companion: (h / L) * L = h, with h affine, denominator ≡ L.
            if (
                isinstance(core, BinaryOp)
                and core.op == "/"
                and _expr_struct_eq(core.right, l_expr)
                and classify_expr(core.left, model, cache) == Curvature.AFFINE
            ):
                continue
            # Square term: (g / L) ** 2, g affine, denominator ≡ L; the squared
            # quad-over-affine is convex only with a nonneg effective weight.
            if (
                isinstance(core, BinaryOp)
                and core.op == "**"
                and isinstance(core.right, (Constant, Parameter))
            ):
                pwr = np.asarray(core.right.value)
                inner = core.left
                if (
                    pwr.ndim == 0
                    and abs(float(pwr) - 2.0) <= 1e-10
                    and isinstance(inner, BinaryOp)
                    and inner.op == "/"
                    and _expr_struct_eq(inner.right, l_expr)
                    and classify_expr(inner.left, model, cache) == Curvature.AFFINE
                ):
                    if scale_i * const >= -1e-10:
                        saw_square = True
                        continue
            all_ok = False
            break

        if all_ok and saw_square:
            return Curvature.CONVEX
    return None


# ──────────────────────────────────────────────────────────────────────
# Constraint-level: quadratic-over-affine epigraph recognition
# ──────────────────────────────────────────────────────────────────────


def classify_fractional_epigraph_constraint(
    constraint: Constraint,
    model: Model,
) -> Optional[bool]:
    """Detect scalar epigraphs of univariate quadratic-over-affine forms.

    Recognises a ``<=`` constraint whose body linearises as

        ``coeff(x) * y + remainder(x) <= 0``

    with:

    * ``y`` a scalar model variable appearing only linearly,
    * ``coeff(x)`` an affine form in a single other scalar variable ``x``
      with a proven non-zero sign on the declared box,
    * ``remainder(x)`` a scalar quadratic in ``x`` only (no dependence on
      ``y`` or any other variable).

    Such a constraint rearranges to ``y >= q(x) / L(x)`` (or ``<=``,
    depending on sign of ``L``), a univariate quadratic-over-affine; it
    is convex iff the Schur-complement discriminant
    ``a e^2 - b d e + c d^2`` has the right sign, where
    ``q(x) = a x^2 + b x + c`` and ``L(x) = d x + e``.

    Covers the MINLPTests ``nlp_cvx_108_*`` family, which the DCP
    walker cannot classify directly (the body is syntactically
    bilinear + quadratic, but algebraically an epigraph of a convex
    quadratic-over-linear).
    """
    from discopt._relax.problem_classifier import _extract_linear_coefficients, _NotLinearError

    if constraint.sense != "<=":
        return None

    scalar_targets = [v for v in model._variables if v.size == 1]
    if len(scalar_targets) != 2:
        return None

    n = _total_scalar_variables(model)
    for target in scalar_targets:
        terms: list[tuple[float, Expression]] = []
        _flatten_sum_terms(constraint.body, 1.0, terms)

        coeff_expr: Optional[Expression] = None
        remainder_expr: Optional[Expression] = None
        valid = True
        for term_scale, term in terms:
            factor = _extract_linear_factor(term, target)
            if factor is None:
                if _contains_var(term, target):
                    valid = False
                    break
                remainder_expr = _add_expr(remainder_expr, _scale_expr(term, term_scale))
                continue
            coeff_expr = _add_expr(coeff_expr, _scale_expr(factor, term_scale))

        if not valid or coeff_expr is None or remainder_expr is None:
            continue

        # #1520: narrowed to the extractor's documented decline ("not affine"): this
        # constraint keeps its UNKNOWN verdict. Any other exception propagates.
        try:
            coeff_vec, coeff_const = _extract_linear_coefficients(coeff_expr, model, n)
        except _NotLinearError as exc:
            logger.debug(
                "fractional-epigraph coefficient extraction failed: %s: %s",
                type(exc).__name__,
                exc,
            )
            continue

        nonzero_coeff = np.flatnonzero(np.abs(coeff_vec) > 1e-10)
        target_idx = _scalar_var_offset(model, target)
        if target_idx is None:
            continue
        if target_idx in nonzero_coeff:
            continue
        if len(nonzero_coeff) != 1:
            continue
        other_idx = int(nonzero_coeff[0])

        data = _quadratic_data(remainder_expr, model)
        if data is None:
            continue
        Q, c, const = data
        remainder_support: set[int] = {int(i) for i in np.flatnonzero(np.abs(np.diag(Q)) > 1e-10)}
        remainder_support |= {int(i) for i in np.flatnonzero(np.abs(c) > 1e-10)}
        if remainder_support - {other_idx}:
            continue
        row_mask = np.arange(Q.shape[0]) != other_idx
        if np.any(np.abs(Q[row_mask, :]) > 1e-10):
            continue
        if np.any(np.abs(Q[:, row_mask]) > 1e-10):
            continue

        other_var = None
        running = 0
        for var in model._variables:
            if running == other_idx and var.size == 1:
                other_var = var
                break
            running += var.size
        if other_var is None:
            continue

        a = 0.5 * float(Q[other_idx, other_idx])
        b = float(c[other_idx])
        c0 = float(const)
        d = float(coeff_vec[other_idx])
        e = float(coeff_const)
        if abs(a) <= 1e-10:
            continue
        lb = float(np.asarray(other_var.lb).min())
        ub = float(np.asarray(other_var.ub).max())
        coeff_lo, coeff_hi = _affine_range_1d(d, e, lb, ub)

        # Schur-complement discriminant for the quadratic-over-affine
        # q(x) / L(x): the epigraph { (x, y) : q(x)/L(x) <= y } with L>0
        # is convex iff a e^2 - b d e + c d^2 >= 0 (equivalently, the
        # 2x2 matrix [[a, (b d - a e)/... ]] has the right PSD profile).
        curvature_numerator = a * e * e - b * d * e + c0 * d * d
        if coeff_hi < -1e-10:
            # coeff(x) * y + r(x) <= 0 with coeff < 0 ⇒ y >= r(x) / (-coeff).
            return curvature_numerator >= -1e-10
        if coeff_lo > 1e-10:
            # coeff(x) * y + r(x) <= 0 with coeff > 0 ⇒ y <= -r(x) / coeff, a
            # hypograph { y <= -q(x)/L(x) }; it is convex iff -q/L is concave,
            # i.e. q/L is convex over the positive denominator L>0. That is the
            # SAME discriminant as the coeff_hi<0 branch: a e^2 - b d e + c d^2
            # >= 0. (The earlier `<= 1e-10` inverted this, classifying the
            # nonconvex hypograph of a convex ratio as convex — see #757.)
            return curvature_numerator >= -1e-10

    return None


__all__ = [
    "classify_division_pattern",
    "classify_fractional_epigraph_constraint",
    "classify_perspective_product",
    "classify_product_pattern",
    "classify_sqrt_pattern",
    "is_homogeneous_psd_quadratic",
    "quadratic_curvature",
]
