"""Linear-constraint context for constraint-aware sign reasoning.

The syntactic SUSPECT-style walker in :mod:`rules` determines the sign
of each subexpression from its algebraic structure and the declared
variable bounds alone. For atoms with restricted domains (``log``,
``sqrt``, ``1/x``, fractional ``x**p``), a sign of the argument that
is merely ``NONNEG`` or ``UNKNOWN`` is not enough to apply the DCP
concavity / convexity rule. But the argument's sign often *is*
provable once linear inequalities and equalities of the model are
taken into account — for example ``log(1 + x1 - x2)`` with the
constraint ``x2 <= x1`` implies the argument is ``>= 1 > 0``.

This module provides a ``LinearContext`` that holds the model's
linear relaxation (variable bounds + linear inequality and equality
constraints) and can answer range queries on affine expressions via
two pure-Rust POUNCE LP solves. The range is a sound enclosure over the
intersection of the box with the linear relaxation, so the resulting
sign label is mathematically valid as a premise of a DCP rule.

Range enclosures for affine expressions are exact; for nonlinear
arguments we fall back to the declared variable box.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import scipy.sparse as sp

from discopt._flat_index import resolve_scalar_slot
from discopt._relax.convexity.lattice import Sign, is_strict, sign_from_bounds
from discopt._relax.scalarize import sum_is_full_reduction
from discopt.modeling.core import (
    BinaryOp,
    Constant,
    Constraint,
    Expression,
    IndexExpression,
    Model,
    Parameter,
    SumExpression,
    SumOverExpression,
    UnaryOp,
    Variable,
)

# Relative margin widening the POUNCE-IPM affine-range enclosure so it stays a
# sound outer bound despite the interior-point optimum's small tolerance (#356).
_LP_ENCLOSURE_MARGIN = 1e-7

# Per-solve wall-clock cap for the POUNCE affine-range LP. POUNCE's interior-point
# method is pathologically slow on the ill-conditioned LPs some convexity probes
# produce (hda's signomial-equilibrium rows), and convexity analysis issues many
# such probes, so an unbounded solve can hang the whole (CI-visible) analysis.
# Bounding it is sound: a non-optimal result falls back to the box-only enclosure
# below, which is a valid (looser) outer bound — convexity then abstains rather
# than mis-proves, exactly the conservative direction. Well-conditioned probes
# solve far inside this budget (~milliseconds), so proven-convex detection is
# unaffected; only the pathological ill-conditioned probes hit the cap and abstain.
_LP_POUNCE_TIME_LIMIT = 0.5


# ──────────────────────────────────────────────────────────────────────
# Affine coefficient extraction
# ──────────────────────────────────────────────────────────────────────


def _compute_var_offset(var: Variable, model: Model) -> int:
    # Delegates to ``Model._flat_var_offset``: a memoized exclusive prefix-sum table,
    # O(1) per lookup, rebuilt only when the (append-only) variable list grows. This
    # re-summed ``model._variables[: var._index]`` from scratch -- O(n_vars) per
    # variable REFERENCE -- which is the quadratic #654 removed on the paths it
    # covered. Pure speedup: ``_variables`` only grows and a Variable's ``_index`` /
    # ``size`` are immutable, so the value is unchanged (#863).
    return model._flat_var_offset(var)


def extract_affine(
    expr: Expression, model: Model, n_vars: int
) -> Optional[tuple[np.ndarray, float]]:
    """Return ``(coeffs, const)`` for an affine scalar expression.

    Walks the DAG collecting linear coefficients. Returns ``None``
    when the expression contains any nonlinear operator or shape that
    doesn't reduce to a scalar affine form.
    """
    terms = _affine_terms(expr, model, n_vars)
    if terms is None:
        return None
    coeffs_dict, const = terms
    coeffs = np.zeros(n_vars, dtype=np.float64)
    for idx, v in coeffs_dict.items():
        coeffs[idx] = v
    return coeffs, const


def _affine_terms(
    expr: Expression, model: Model, n_vars: int
) -> Optional[tuple[dict[int, float], float]]:
    """:func:`extract_affine`'s ``(column -> coefficient, const)``, before it is
    made dense: what :func:`build_linear_context` stacks into sparse rows."""

    def walk(node: Expression, scale: float) -> Optional[tuple[dict[int, float], float]]:
        if isinstance(node, Constant):
            val = np.asarray(node.value)
            if val.ndim == 0:
                return {}, scale * float(val)
            return None

        if isinstance(node, Parameter):
            val = np.asarray(node.value)
            if val.ndim == 0:
                return {}, scale * float(val)
            return None

        if isinstance(node, Variable):
            if node.size != 1:
                return None
            return {_compute_var_offset(node, model): scale}, 0.0

        if isinstance(node, IndexExpression) and isinstance(node.base, Variable):
            # Normalises negative indices, refuses partial/out-of-range (#1952).
            slot = resolve_scalar_slot(node, model)
            if slot is None:
                return None
            return {slot: scale}, 0.0

        if isinstance(node, UnaryOp):
            if node.op == "neg":
                return walk(node.operand, -scale)
            return None

        if isinstance(node, BinaryOp):
            if node.op in ("+", "-"):
                left = walk(node.left, scale)
                right = walk(node.right, scale if node.op == "+" else -scale)
                if left is None or right is None:
                    return None
                merged = dict(left[0])
                for k, v in right[0].items():
                    merged[k] = merged.get(k, 0.0) + v
                return merged, left[1] + right[1]

            if node.op == "*":
                if _is_scalar_const(node.left):
                    return walk(node.right, scale * _scalar_value(node.left))
                if _is_scalar_const(node.right):
                    return walk(node.left, scale * _scalar_value(node.right))
                return None

            if node.op == "/":
                if _is_scalar_const(node.right):
                    divisor = _scalar_value(node.right)
                    if abs(divisor) <= 1e-30:
                        return None
                    return walk(node.left, scale / divisor)
                return None

            return None

        if isinstance(node, SumExpression):
            # A full reduction contributes one row whose terms are the operand's
            # elements at a uniform scale. An axis reduction is array-valued --
            # several rows -- so this single coefficient row would be their sum
            # (#1160). Abstain rather than describe a row the model does not have.
            if not sum_is_full_reduction(node):
                return None
            return walk(node.operand, scale)

        if isinstance(node, SumOverExpression):
            acc: dict[int, float] = {}
            total = 0.0
            for t in node.terms:
                part = walk(t, scale)
                if part is None:
                    return None
                for k, v in part[0].items():
                    acc[k] = acc.get(k, 0.0) + v
                total += part[1]
            return acc, total

        return None

    result = walk(expr, 1.0)
    if result is None:
        return None
    coeffs_dict, const = result
    return {idx: v for idx, v in coeffs_dict.items() if 0 <= idx < n_vars}, const


def _is_scalar_const(expr: Expression) -> bool:
    if isinstance(expr, (Constant, Parameter)):
        val = np.asarray(expr.value)
        return bool(val.ndim == 0)
    return False


def _scalar_value(expr: Expression) -> float:
    return float(np.asarray(expr.value))  # type: ignore[attr-defined]


# ──────────────────────────────────────────────────────────────────────
# Linear context
# ──────────────────────────────────────────────────────────────────────


@dataclass
class LinearContext:
    """Linear relaxation of a model for affine range queries.

    ``A_ub x <= b_ub``, ``A_eq x = b_eq``, ``lb <= x <= ub``. The
    coefficient matrices are CSR and may have no rows (no linear
    constraints); variable bounds are always present. ``n_vars`` is the
    flattened decision-variable dimension. They were dense until a
    15k-row GDP lowering (GDPlib biofuel) spent 21.7 s in one ``np.vstack``
    of full-width rows, all of it before the solve's deadline applied.
    """

    n_vars: int
    lb: np.ndarray
    ub: np.ndarray
    A_ub: sp.csr_matrix
    b_ub: np.ndarray
    A_eq: sp.csr_matrix
    b_eq: np.ndarray

    def affine_range(self, coeffs: np.ndarray, const: float) -> tuple[float, float]:
        """Sound enclosure of ``coeffs · x + const`` over the relaxation.

        Uses the declared variable bounds as a free box-only enclosure;
        invokes the pure-Rust POUNCE LP only when linear constraints are
        present, since the box-only bound is already optimal otherwise.
        """
        # Box-only enclosure is optimal when there are no linear rows.
        lo_box, hi_box = _box_range(coeffs, self.lb, self.ub)
        lo_box += const
        hi_box += const
        # Rows, not ``.size``: on a sparse matrix that is the nonzero count.
        if self.A_ub.shape[0] == 0 and self.A_eq.shape[0] == 0:
            return lo_box, hi_box

        from discopt.solvers import SolveStatus
        from discopt.solvers.lp_pounce import solve_lp

        # ``bounds`` as (lo, hi) tuples; POUNCE maps ±inf via its own sentinel.
        bounds = [(float(lo), float(hi)) for lo, hi in zip(self.lb, self.ub)]

        A_ub = self.A_ub if self.A_ub.shape[0] else None
        b_ub = self.b_ub if self.b_ub.size else None
        A_eq = self.A_eq if self.A_eq.shape[0] else None
        b_eq = self.b_eq if self.b_eq.size else None

        try:
            lo_res = solve_lp(
                coeffs,
                A_ub=A_ub,
                b_ub=b_ub,
                A_eq=A_eq,
                b_eq=b_eq,
                bounds=bounds,
                time_limit=_LP_POUNCE_TIME_LIMIT,
            )
            hi_res = solve_lp(
                -coeffs,
                A_ub=A_ub,
                b_ub=b_ub,
                A_eq=A_eq,
                b_eq=b_eq,
                bounds=bounds,
                time_limit=_LP_POUNCE_TIME_LIMIT,
            )
        except (ValueError, RuntimeError, ImportError):
            return lo_box, hi_box

        # POUNCE is an interior-point method, so the reported optimum carries a
        # small tolerance; widen each side by a magnitude-scaled margin so the
        # range stays a *sound* enclosure (lo ≤ true min, hi ≥ true max) rather
        # than risk an over-tight one that would misclassify convexity (#356).
        lo = lo_box
        if lo_res.status == SolveStatus.OPTIMAL and lo_res.objective is not None:
            f = float(lo_res.objective)
            lo = f - _LP_ENCLOSURE_MARGIN * (1.0 + abs(f)) + const
        hi = hi_box
        if hi_res.status == SolveStatus.OPTIMAL and hi_res.objective is not None:
            f = -float(hi_res.objective)
            hi = f + _LP_ENCLOSURE_MARGIN * (1.0 + abs(f)) + const
        # Intersect with the box-only enclosure; LP errors / margins only widen.
        return max(lo, lo_box), min(hi, hi_box)

    def affine_sign(self, coeffs: np.ndarray, const: float) -> Sign:
        """Sign of ``coeffs · x + const`` over the relaxation.

        Callers that need only the sign — every caller today, since a
        DCP domain rule asks "is this argument strictly positive?", not
        "how large is it?" — should use this instead of
        :meth:`affine_range`. When the free box-only enclosure already
        yields a *strict* sign, the LP pair is skipped.

        This is exact, not an approximation. :meth:`affine_range`
        intersects its LP result with the same box enclosure, so the
        refined interval is a subset of the box interval; a subset of a
        strictly-positive interval is strictly positive, and ``POS`` /
        ``NEG`` / ``ZERO`` are the strongest labels the lattice has.
        The LP therefore cannot produce a different answer — it can
        only cost time.

        #1053: it costs a lot. On MINLPLib `hda` (722 vars) the
        classifier made 12 ``affine_range`` calls at ~1.05 s each,
        21% of a 60 s solve. All 12 were already box-conclusive
        (``POS``), and all 12 LP-refined signs matched the box sign
        exactly.
        """
        lo_box, hi_box = _box_range(coeffs, self.lb, self.ub)
        box_sign = sign_from_bounds(lo_box + const, hi_box + const)
        if is_strict(box_sign):
            return box_sign
        return sign_from_bounds(*self.affine_range(coeffs, const))


def _box_range(coeffs: np.ndarray, lb: np.ndarray, ub: np.ndarray) -> tuple[float, float]:
    """Box-only enclosure of ``coeffs · x`` without the linear rows."""
    pos = coeffs > 0
    neg = coeffs < 0
    lo = float(np.sum(coeffs[pos] * lb[pos]) + np.sum(coeffs[neg] * ub[neg]))
    hi = float(np.sum(coeffs[pos] * ub[pos]) + np.sum(coeffs[neg] * lb[neg]))
    return lo, hi


def build_linear_context(model: Model) -> Optional[LinearContext]:
    """Assemble a :class:`LinearContext` from a model's linear rows.

    Returns ``None`` when the model has no variables. Nonlinear
    constraints are silently dropped; only constraints that reduce to
    ``coeffs · x + const  sense  0`` contribute rows.
    """
    if not model._variables:
        return None

    n_vars = sum(v.size for v in model._variables)
    lb = np.empty(n_vars, dtype=np.float64)
    ub = np.empty(n_vars, dtype=np.float64)
    offset = 0
    for v in model._variables:
        vlb = np.asarray(v.lb, dtype=np.float64).reshape(-1)
        vub = np.asarray(v.ub, dtype=np.float64).reshape(-1)
        lb[offset : offset + v.size] = vlb
        ub[offset : offset + v.size] = vub
        offset += v.size

    ub_rows: list[tuple[dict[int, float], float]] = []
    eq_rows: list[tuple[dict[int, float], float]] = []

    for c in model._constraints:
        if not isinstance(c, Constraint):
            continue
        aff = _affine_terms(c.body, model, n_vars)
        if aff is None:
            continue
        terms, const = aff
        # body sense rhs  →  (coeffs · x + const)  sense  rhs
        adjusted_rhs = float(c.rhs) - const
        if c.sense == "<=":
            ub_rows.append((terms, adjusted_rhs))
        elif c.sense == ">=":
            ub_rows.append(({j: -a for j, a in terms.items()}, -adjusted_rhs))
        elif c.sense == "==":
            eq_rows.append((terms, adjusted_rhs))

    return LinearContext(
        n_vars=n_vars,
        lb=lb,
        ub=ub,
        A_ub=_csr(ub_rows, n_vars),
        b_ub=np.array([r[1] for r in ub_rows], dtype=np.float64),
        A_eq=_csr(eq_rows, n_vars),
        b_eq=np.array([r[1] for r in eq_rows], dtype=np.float64),
    )


def _csr(rows: list[tuple[dict[int, float], float]], n_vars: int) -> sp.csr_matrix:
    """The rows' coefficient dicts as one ``len(rows) x n_vars`` CSR matrix."""
    indptr = np.zeros(len(rows) + 1, dtype=np.int64)
    indptr[1:] = np.cumsum([len(t) for t, _ in rows], dtype=np.int64)
    nnz = int(indptr[-1])
    indices = np.fromiter((j for t, _ in rows for j in t), dtype=np.int64, count=nnz)
    data = np.fromiter((a for t, _ in rows for a in t.values()), dtype=np.float64, count=nnz)
    return sp.csr_matrix((data, indices, indptr), shape=(len(rows), n_vars))


__all__ = ["LinearContext", "build_linear_context", "extract_affine"]
