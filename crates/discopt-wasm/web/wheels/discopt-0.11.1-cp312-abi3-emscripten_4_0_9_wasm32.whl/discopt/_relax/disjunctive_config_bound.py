"""Disjunctive configuration bound for gated-configuration MINLPs (#732 Stage 2).

For models whose objective couples through integer-multilinear products (the #707
reform class), the tree's global dual is dominated by shallow nodes where the
configuration selectors are fractional and every cost coupling relaxes to ~0
(the L3 wall of ``docs/dev/ex1252-certification-plan.md``). But the configuration
space itself is tiny: the reform records which integer factors gate the products
(``model._ipx_config_indicators`` — range-{0,1} selectors — and
``model._ipx_config_counts`` — small-range counts, e.g. pump multiplicities).

This pass computes a valid global lower bound by **partitioning on the
configuration variables** instead of relaxing across them:

1. Enumerate the ``2^k`` indicator patterns (every feasible point has integral
   indicators; the patterns partition the box).
2. Per configuration box: interval **FBBT** (fresh Rust repr per box — proves the
   degenerate patterns crossed/empty in milliseconds, which the ill-conditioned
   LP cannot Farkas-certify), then budgeted **OBBT** with the incumbent cutoff,
   then the node **LP** bound.
3. **Unit-peel** the weakest surviving leaf on a configuration count variable
   (``{lo}`` vs ``[lo+1, ub]`` — a partition of the integer domain, the same
   implied-integrality trust the #707 reform itself relies on), best-first,
   under a leaf/wall budget.

Anytime-valid by construction: every child inherits its parent's bound until its
own is certified, so ``min over leaves`` is a valid lower bound at any budget
cutoff; leaves pruned infeasible contribute nothing and leaves pruned by the
incumbent cutoff contribute their certified bound. Soundness: FBBT/OBBT/LP are
each sound per box, the indicator patterns partition the box exactly, and the
unit-peel partitions the integer domain of a reform-expanded (declared or
implied integer) variable.

Entry experiments (recorded in the plan doc): per-config bounds 71644–115466 on
the single-line ex1252 patterns (one pruned outright by the incumbent cutoff),
12/16 pump-dichotomy children of a multi-line pattern pruned, and the FBBT step
closing the ``numerical`` leaves that poisoned the min.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from itertools import product as _iproduct
from typing import Optional

import numpy as np

from discopt.modeling.core import Model

logger = logging.getLogger(__name__)

# A leaf whose certified LP bound sits within this of the incumbent is pruned by
# the cutoff (mirrors the solver's absolute gap tolerance).
_CUTOFF_EPS = 1e-6
# FBBT iteration cap per box (the per-box repr build + sweep measures ~4 ms).
_FBBT_MAX_ITER = 20
_FBBT_TOL = 1e-9


@dataclass
class DisjunctiveConfigResult:
    """Outcome of the disjunctive configuration pass.

    ``bound`` is a valid global lower bound for the model over the input box, or
    ``None`` when the pass declined / could not certify anything above ``-inf``.
    ``infeasible`` is True only when EVERY configuration pattern was pruned
    infeasible — a rigorous proof the input box contains no feasible point.

    ``stopped_on`` records *what ended the pass*, following the same convention as
    ``WorkBudget.stopped_on`` (#912):

    * ``"budget"``    — the ``max_leaf_solves`` leaf budget was spent. The bound is
      a reproducible function of the input and the budget.
    * ``"deadline"``  — the wall-clock ``deadline`` fired first. The bound is then
      a function of **how fast the machine is**, and comparing it against a fixed
      quality bar measures the runner, not the relaxation.
    * ``"exhausted"`` — the search ran out of work (no splittable leaf left)
      before either limit. Also reproducible.

    Without this field the two reproducible outcomes and the irreproducible one
    are indistinguishable in the result, which is exactly how a slow runner came
    to look like a bound regression on ``ex1252`` (#960 post-merge).
    """

    bound: Optional[float] = None
    infeasible: bool = False
    n_processed: int = 0
    n_pruned_infeasible: int = 0
    n_pruned_cutoff: int = 0
    n_leaves: int = 0
    wall: float = 0.0
    stopped_on: str = "exhausted"


@dataclass
class _Leaf:
    lb: np.ndarray
    ub: np.ndarray
    bound: float  # inherited from the parent until certified — always valid
    certified: bool = False
    attempts: int = 0
    depth: int = 0
    spatial_depth: int = 0  # number of continuous bisections on this path
    terminal: bool = False  # no splittable variable remains / budget-terminal
    key: tuple = field(default_factory=tuple)


def _box_fbbt(model: Model, lb: np.ndarray, ub: np.ndarray):
    """Interval FBBT restricted to ``[lb, ub]`` via a fresh Rust repr.

    Returns ``(tight_lb, tight_ub, crossed)``. Abstains -- the input box with
    ``crossed=False``, sound because FBBT is a tightener -- when the model has no
    Rust repr (``model_to_repr``'s documented ``ValueError``) or the repr's block
    layout does not match the flat box. Any other exception is a defect and
    propagates (#1514).
    """
    from discopt._relax.problem_classifier import MODEL_TO_REPR_DECLINES
    from discopt._rust import model_to_repr

    try:
        rep = model_to_repr(model, getattr(model, "_builder", None))
    except MODEL_TO_REPR_DECLINES as exc:  # #1520: the full documented set
        logger.debug("disjunctive pass: per-box FBBT abstained, no Rust repr: %s", exc)
        return lb, ub, False
    off = 0
    for bi, v in enumerate(model._variables):
        rep.tighten_var_bounds(bi, list(lb[off : off + v.size]), list(ub[off : off + v.size]))
        off += v.size
    fl, fu = rep.fbbt(max_iter=_FBBT_MAX_ITER, tol=_FBBT_TOL)
    tl = np.concatenate([np.atleast_1d(np.asarray(b, dtype=np.float64)) for b in fl])
    tu = np.concatenate([np.atleast_1d(np.asarray(b, dtype=np.float64)) for b in fu])
    if tl.shape != lb.shape:
        return lb, ub, False
    # Intersect defensively (FBBT starts from the written box, so this is a
    # no-op unless the binding returned something unexpected).
    tl = np.maximum(tl, lb)
    tu = np.minimum(tu, ub)
    crossed = bool(np.any(tl > tu + 1e-9))
    return tl, tu, crossed


def _split_var(
    leaf: _Leaf,
    count_flats: list[int],
    cont_flats: list[int],
    root_width: np.ndarray,
    max_spatial_depth: int,
) -> Optional[tuple[str, int]]:
    """Next split for the leaf: a count unit-peel, else a continuous bisection.

    Count variables first (fixing the configuration is what couples the cost
    terms); once none has integer width left, fall to spatial bisection of the
    widest-relative continuous nonlinear participant (#732 Stage 4 — the cubic
    block's x6-class variables; measured +12.5% min-child per split at the
    config box), capped at ``max_spatial_depth`` bisections per path.
    """
    for j in count_flats:
        lo = np.ceil(leaf.lb[j] - 1e-9)
        hi = np.floor(leaf.ub[j] + 1e-9)
        if hi - lo >= 1.0:
            return ("count", j)
    if leaf.spatial_depth >= max_spatial_depth:
        return None
    best_j, best_rel = None, 0.05  # ignore near-pinned variables
    for j in cont_flats:
        w = float(leaf.ub[j] - leaf.lb[j])
        rw = float(root_width[j])
        if rw > 0.0 and np.isfinite(rw):
            rel = w / rw
            if rel > best_rel:
                best_rel, best_j = rel, j
    if best_j is None:
        return None
    return ("cont", best_j)


def compute_disjunctive_config_bound(
    model: Model,
    lb: np.ndarray,
    ub: np.ndarray,
    *,
    incumbent: Optional[float] = None,
    deadline: Optional[float] = None,
    max_leaf_solves: int = 48,
    max_indicators: int = 4,
    obbt_rounds: int = 3,
    obbt_lp_time: float = 0.2,
    root_floor: float = -np.inf,
    max_spatial_depth: int = 6,
) -> DisjunctiveConfigResult:
    """Compute the disjunctive configuration bound over ``[lb, ub]``.

    ``root_floor`` is the caller's existing valid bound for the box (used as the
    inherited bound of unprocessed leaves, keeping the pass anytime-valid).
    ``incumbent`` is in the **internal minimization space** — it is compared
    against ``node.lower_bound`` (an internal LP bound) and forwarded verbatim to
    :func:`obbt_tighten_root`, whose cutoff rows are internal too (#1373).
    Declines (``bound=None``) when the model carries no configuration metadata,
    the indicator count exceeds ``max_indicators``, or nothing above ``-inf``
    could be certified within budget.
    """
    t0 = time.perf_counter()
    res = DisjunctiveConfigResult()

    indicators = sorted(getattr(model, "_ipx_config_indicators", None) or ())
    count_flats = sorted(getattr(model, "_ipx_config_counts", None) or ())
    lb = np.asarray(lb, dtype=np.float64).copy()
    ub = np.asarray(ub, dtype=np.float64).copy()
    # Only indicators still free in this box need enumeration.
    free_ind = [j for j in indicators if ub[j] - lb[j] > 0.5]
    if not indicators or len(free_ind) > max_indicators:
        return res

    from discopt._relax.mccormick_lp import MccormickLPRelaxer
    from discopt._relax.obbt import obbt_tighten_root

    # #732 Stage 4: continuous bisection candidates — nonlinear-term participants
    # that are neither configuration counts nor indicators (the cubic block's
    # x6-class variables on ex1252). Structural, never name-keyed.
    # #1514: no ``except``. Term classification is structural, with no documented
    # failure mode; a raise is a defect, not "no continuous candidates".
    from discopt._relax.term_classifier import classify_nonlinear_terms

    _terms = classify_nonlinear_terms(model)
    _part: set[int] = set()
    for _grp in (_terms.bilinear, _terms.trilinear, _terms.multilinear):
        for _t in _grp or []:
            _part.update(int(_x) for _x in _t)
    for _t in _terms.monomial or []:
        _part.add(int(_t[0]))
    cont_flats: list[int] = sorted(_part - set(count_flats) - set(indicators))
    root_width = np.where(
        np.isfinite(ub - lb), ub - lb, np.inf
    )  # spatial ranking is relative to the root width

    relaxer = MccormickLPRelaxer(model)

    leaves: list[_Leaf] = []
    for pattern in _iproduct((0.0, 1.0), repeat=len(free_ind)):
        clb, cub = lb.copy(), ub.copy()
        for j, v in zip(free_ind, pattern, strict=True):
            clb[j] = cub[j] = v
        leaves.append(_Leaf(clb, cub, root_floor, key=pattern))
    terminal_bounds: list[float] = []

    def _out_of_budget() -> bool:
        # Record WHICH limit fired, not just that one did: the leaf budget is a
        # reproducible stopping rule, the clock is not, and a caller comparing the
        # bound against a fixed bar can only interpret it if it knows which one
        # ended the pass. Same distinction as ``WorkBudget.stopped_on`` (#912).
        if res.n_processed >= max_leaf_solves:
            res.stopped_on = "budget"
            return True
        if deadline is not None and time.perf_counter() >= deadline:
            res.stopped_on = "deadline"
            return True
        return False

    def _process(leaf: _Leaf) -> Optional[_Leaf]:
        """FBBT -> OBBT(cutoff) -> LP on the leaf. Returns the surviving leaf
        (certified or not), or ``None`` when pruned (stats updated)."""
        res.n_processed += 1
        tl, tu, crossed = _box_fbbt(model, leaf.lb, leaf.ub)
        if crossed:
            res.n_pruned_infeasible += 1
            return None
        leaf.lb, leaf.ub = tl, tu
        # #1514: no ``except``. ``obbt_tighten_root`` returns the input box when it
        # cannot proceed, so a raise is a defect.
        ob = obbt_tighten_root(
            model,
            leaf.lb.copy(),
            leaf.ub.copy(),
            rounds=obbt_rounds,
            time_limit_per_lp=obbt_lp_time,
            incumbent_cutoff=incumbent,
            deadline=deadline,
        )
        if ob.infeasible:
            res.n_pruned_infeasible += 1
            return None
        leaf.lb, leaf.ub = ob.lb.copy(), ob.ub.copy()
        _tl = None
        if deadline is not None:
            _tl = max(deadline - time.perf_counter(), 1.0)
        node = relaxer.solve_at_node(leaf.lb.copy(), leaf.ub.copy(), time_limit=_tl)
        if node.status == "infeasible":
            res.n_pruned_infeasible += 1
            return None
        leaf.attempts += 1
        if node.status == "optimal" and node.lower_bound is not None:
            b = float(node.lower_bound)
            leaf.bound = max(leaf.bound, b)
            leaf.certified = True
            if incumbent is not None and b >= incumbent - _CUTOFF_EPS:
                # The leaf holds nothing better than the incumbent: its box
                # contributes at least b to the min — terminal, kept as a bound.
                res.n_pruned_cutoff += 1
                terminal_bounds.append(b)
                return None
        return leaf

    # Pass 1: process every indicator pattern once.
    survivors: list[_Leaf] = []
    for leaf in leaves:
        if _out_of_budget():
            survivors.append(leaf)  # unprocessed: keeps its inherited bound
            continue
        kept = _process(leaf)
        if kept is not None:
            survivors.append(kept)

    if not survivors and not terminal_bounds:
        # Every configuration pattern pruned infeasible: the box is empty.
        res.infeasible = res.n_pruned_cutoff == 0
        res.bound = incumbent if res.n_pruned_cutoff else None
        res.n_leaves = 0
        res.wall = time.perf_counter() - t0
        return res

    # Pass 2: best-first unit-peeling — always work the weakest leaf, because the
    # result is min over leaves and only lifting the min helps.
    while not _out_of_budget():
        survivors.sort(key=lambda le: (le.terminal, le.certified, le.bound))
        leaf = survivors[0]
        if leaf.terminal:
            break  # weakest leaf can no longer improve
        if leaf.certified or leaf.attempts > 0:
            split = _split_var(leaf, count_flats, cont_flats, root_width, max_spatial_depth)
            if split is None:
                leaf.terminal = True
                continue
            kind, j = split
            sd = leaf.spatial_depth + (1 if kind == "cont" else 0)
            left = _Leaf(
                leaf.lb.copy(), leaf.ub.copy(), leaf.bound, depth=leaf.depth + 1, spatial_depth=sd
            )
            right = _Leaf(
                leaf.lb.copy(), leaf.ub.copy(), leaf.bound, depth=leaf.depth + 1, spatial_depth=sd
            )
            if kind == "count":
                lo = float(np.ceil(leaf.lb[j] - 1e-9))
                left.ub[j] = lo
                left.lb[j] = min(left.lb[j], lo)
                right.lb[j] = lo + 1.0
            else:  # continuous bisection at the midpoint (#732 Stage 4)
                mid = 0.5 * (float(leaf.lb[j]) + float(leaf.ub[j]))
                left.ub[j] = mid
                right.lb[j] = mid
            survivors.remove(leaf)
            for child in (left, right):
                if _out_of_budget():
                    survivors.append(child)  # inherited bound keeps validity
                    continue
                kept = _process(child)
                if kept is not None:
                    survivors.append(kept)
            if not survivors and not terminal_bounds:
                res.infeasible = res.n_pruned_cutoff == 0
                res.bound = incumbent if res.n_pruned_cutoff else None
                res.n_leaves = 0
                res.wall = time.perf_counter() - t0
                return res
        else:
            kept = _process(leaf)
            if kept is None:
                survivors.remove(leaf)
                if not survivors and not terminal_bounds:
                    res.infeasible = res.n_pruned_cutoff == 0
                    res.bound = incumbent if res.n_pruned_cutoff else None
                    res.n_leaves = 0
                    res.wall = time.perf_counter() - t0
                    return res

    all_bounds = [le.bound for le in survivors] + terminal_bounds
    res.n_leaves = len(survivors)
    res.wall = time.perf_counter() - t0
    if not all_bounds:
        return res
    best = float(min(all_bounds))
    res.bound = best if np.isfinite(best) else None
    return res
