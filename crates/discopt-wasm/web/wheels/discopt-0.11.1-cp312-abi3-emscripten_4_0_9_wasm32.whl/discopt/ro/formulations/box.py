"""Box-uncertainty robust reformulation.

Mathematical Background
-----------------------
For a constraint body expression ``g(x, p) <= 0`` with box uncertainty
``{p : |p_j - p_bar_j| <= delta_j}``, the robust counterpart requires::

    max_{p in U} g(x, p) <= 0

When g is affine in p and the coefficient of p is a known constant, the
worst-case value depends on the sign of the coefficient (sign-tracking).

When g contains *bilinear* terms (decision variable * uncertain parameter),
as arises from affine decision rules, the coefficient of p involves decision
variables whose sign is not known a priori.  In this case the correct
reformulation uses absolute-value linearization::

    max_{|xi|<=delta} coeff(x) * xi = delta * |coeff(x)|

The absolute value is linearized via auxiliary variables::

    |coeff| <= t,  with  coeff <= t  and  -coeff <= t,  t >= 0.
"""

from __future__ import annotations

import numpy as np

from discopt.ro.formulations._common import (
    _contains_any_parameter,
    _contains_uncertain_param,
    aggregate_affine_counterpart,
    cancel_like_terms,
    is_affine_in_params,
    max_uncertain_multiplicity,
    record_conservative,
    sign_tracking_substitute,
    substitute_param,
    worst_case_attained,
)
from discopt.ro.uncertainty import BoxUncertaintySet


class BoxRobustFormulation:
    """Apply box-uncertainty robust reformulation to a model.

    Parameters
    ----------
    model : discopt.Model
        The model to robustify (modified in-place).
    uncertainty_sets : list[BoxUncertaintySet]
        Uncertainty sets, one per uncertain parameter.
    prefix : str
        Name prefix for any auxiliary variables / constraints added.
    """

    def __init__(
        self, model, uncertainty_sets: list[BoxUncertaintySet], prefix: str = "ro"
    ) -> None:
        self._model = model
        self._uncertainty_sets = uncertainty_sets
        self._prefix = prefix

    def build(self) -> None:
        """Robustify the model in-place."""
        m = self._model
        param_names = {u.parameter.name for u in self._uncertainty_sets}

        # Check whether any expression has bilinear terms (variable * parameter).
        has_bilinear = self._detect_bilinear(m, param_names)

        if has_bilinear:
            self._build_with_linearization(m, param_names)
        else:
            self._build_sign_tracking(m, param_names)

    # ------------------------------------------------------------------
    # Fast path: no bilinear terms, use sign-tracking substitution
    # ------------------------------------------------------------------

    def _build_sign_tracking(self, m, param_names):
        """Robustify via sign-tracking (original approach, no bilinear terms)."""
        from discopt.modeling.core import Constraint, Objective, ObjectiveSense

        unc_map = {u.parameter.name: u for u in self._uncertainty_sets}

        def robustify(expr, maximize: bool, where: str):
            # An affine row whose parameter occurrences cancel (``sum(M @ p)``,
            # ``3*p0 - p0``) gets the exact aggregate counterpart; sign tracking
            # would charge every occurrence separately (#1831 review).
            exact = aggregate_affine_counterpart(expr, unc_map, param_names, maximize)
            if exact is not None:
                return exact
            return self._sign_track_nonaffine(expr, unc_map, maximize, where)

        new_constraints = []
        for ci, con in enumerate(m._constraints):
            if not isinstance(con, Constraint):
                new_constraints.append(con)
                continue
            new_expr = robustify(con.body, maximize=True, where=con.name or f"_constraints[{ci}]")
            new_constraints.append(
                Constraint(body=new_expr, sense=con.sense, rhs=con.rhs, name=con.name)
            )
        m._constraints = new_constraints

        obj = m._objective
        if obj is None:
            return
        maximize_obj_wc = obj.sense == ObjectiveSense.MINIMIZE
        new_expr = robustify(obj.expression, maximize=maximize_obj_wc, where="<objective>")
        m._objective = Objective(expression=new_expr, sense=obj.sense)

    def _sign_track_nonaffine(self, expr, unc_map, maximize: bool, where: str):
        """Worst case of a row that is not affine in the uncertain parameters.

        Like terms are cancelled first (#1848): ``x + exp(p) - exp(p)`` is ``x``,
        and charging each ``exp(p)`` its own worst case made a feasible robust
        model infeasible. If the cancelled row is affine it takes the exact
        aggregate. Otherwise sign tracking substitutes each occurrence at its own
        worst bound, which is the exact worst case only when no uncertain
        component occurs twice; else the row is recorded as conservative and
        ``Model.solve`` withholds the result's certificate.
        """
        names = set(unc_map)
        cancelled = cancel_like_terms(expr)
        if cancelled is not expr:
            if not _contains_uncertain_param(cancelled, names):
                return cancelled
            exact = aggregate_affine_counterpart(cancelled, unc_map, names, maximize)
            if exact is not None:
                return exact
        if max_uncertain_multiplicity(cancelled, names) > 1 and not worst_case_attained(
            cancelled, unc_map, maximize
        ):
            record_conservative(self._model, where)
        return sign_tracking_substitute(
            cancelled,
            {n: u.lower for n, u in unc_map.items()},
            {n: u.upper for n, u in unc_map.items()},
            names,
            maximize=maximize,
            sign=+1,
        )

    # ------------------------------------------------------------------
    # Bilinear path: coefficient extraction + absolute-value linearization
    # ------------------------------------------------------------------

    def _build_with_linearization(self, m, param_names):
        """Robustify with absolute-value linearization for bilinear terms.

        For each uncertain parameter p with box half-width delta, and each
        expression that is affine in p:

            expr = f(x) + coeff(x) * (p - p_bar)

        the worst case over |p - p_bar| <= delta is:

            f(x) + delta * |coeff(x)|

        We linearize |coeff| by introducing t >= 0 with coeff <= t, -coeff <= t.
        """
        from discopt.modeling.core import (
            BinaryOp,
            Constant,
            Constraint,
            Objective,
            ObjectiveSense,
        )

        unc_map = {u.parameter.name: u for u in self._uncertainty_sets}
        aux_idx = 0

        def _robustify_expr(expr, maximize: bool, where: str):
            """Replace uncertain parameters in expr with worst-case penalty.

            Returns (new_expr, list_of_new_constraints).

            For each uncertain parameter p_k, extracts the linear coefficient
            of p_k in the expression (evaluated with all OTHER parameters at
            nominal).  If the coefficient is constant, uses sign-tracking.
            If it involves decision variables, uses absolute-value linearization.
            """
            nonlocal aux_idx
            new_constraints = []

            # #1836: the decomposition below -- nominal value plus, per
            # parameter, a finite-difference coefficient times the deviation --
            # is exact only for an expression jointly affine in the uncertain
            # parameters. For ``x + p**3`` the "coefficient" ``(p_bar+1)**3 -
            # p_bar**3`` is not a slope of anything, and for ``x + p1*p2`` the
            # per-parameter penalties are each taken with the other parameter at
            # nominal; both certified non-robust points. Such an expression is
            # robustified whole by sign tracking, which handles a nonlinear node
            # only by proof and refuses otherwise.
            if not is_affine_in_params(expr, set(unc_map)):
                cancelled = cancel_like_terms(expr)  # #1848
                if cancelled is expr or not is_affine_in_params(cancelled, set(unc_map)):
                    return self._sign_track_nonaffine(expr, unc_map, maximize, where), []
                expr = cancelled

            # Step 1: substitute ALL params with nominal to get the base expression
            all_nominal = expr
            for pname, unc in unc_map.items():
                all_nominal = substitute_param(all_nominal, pname, Constant(unc.parameter.value))

            # Step 2: for each param, extract coefficient and add penalty
            result = all_nominal
            for pname, unc in unc_map.items():
                nominal = unc.parameter.value
                delta = unc.delta

                # #1437: a parameter that does not OCCUR in this expression
                # contributes no uncertainty to it, so there is nothing to
                # robustify. Without this the finite difference below is taken
                # between two copies of the same expression -- identically zero,
                # but still syntactically variable-bearing, so
                # ``_contains_variable`` said True and the bilinear branch ran:
                # it added an aux variable, two degenerate rows
                # (``(e - e) - t <= 0``, i.e. ``t >= 0`` and nothing else) and a
                # penalty term to an expression that needed none. Measured, this
                # is what put a ``Constant((2,)) * ro_abs1`` into the objective of
                # a model whose uncertain parameter appeared only in a CONSTRAINT.
                if not _contains_uncertain_param(expr, {pname}):
                    continue

                # Compute coefficient of p_k by substituting all params to nominal
                # except p_k, then evaluating at p_k = p_bar and p_k = p_bar + 1.
                expr_at_nom = expr
                for other_name, other_unc in unc_map.items():
                    if other_name != pname:
                        expr_at_nom = substitute_param(
                            expr_at_nom, other_name, Constant(other_unc.parameter.value)
                        )

                base = substitute_param(expr_at_nom, pname, Constant(nominal))
                unit = substitute_param(
                    expr_at_nom, pname, Constant(nominal + np.ones_like(nominal))
                )
                coeff_expr = BinaryOp("-", unit, base)

                # The finite differences below are the coefficients of ``xi`` only
                # for a row affine in p; for ``x + exp(p)`` they are secants and
                # the |coeff| linearization treated a nonlinear row as linear
                # (#1841). Such a row is worst-cased by sign tracking instead,
                # which is sound through monotone nodes and refuses otherwise.
                if not _contains_variable(coeff_expr) or not is_affine_in_params(
                    expr_at_nom, {pname}
                ):
                    # Non-bilinear: use sign-tracking for this param only.
                    # Apply to result which already has all params at nominal.
                    # Re-derive the non-bilinear worst-case contribution.
                    wc_lower = {pname: unc.lower}
                    wc_upper = {pname: unc.upper}
                    # Worst case of constant_coeff * p over [p_bar-delta, p_bar+delta].
                    # Contribution = coeff * (p_wc - p_bar) where p_wc depends on sign.
                    wc_expr = aggregate_affine_counterpart(
                        expr_at_nom, {pname: unc}, {pname}, maximize
                    )
                    if wc_expr is None:
                        wc_expr = sign_tracking_substitute(
                            expr_at_nom,
                            wc_lower,
                            wc_upper,
                            {pname},
                            maximize=maximize,
                            sign=+1,
                        )
                    # Penalty = (worst-case expression) - (nominal expression)
                    wc_penalty = BinaryOp("-", wc_expr, base)
                    result = BinaryOp("+", result, wc_penalty)
                else:
                    # Bilinear: absolute-value linearization, ONE AUX PER
                    # COMPONENT (#1437).
                    #
                    # The box counterpart of ``sum_j coeff_j(x) * xi_j`` over
                    # ``|xi_j| <= delta_j`` is ``sum_j delta_j * |coeff_j(x)|``.
                    # That is a per-component statement: component j's worst case
                    # is reached at ``xi_j = +-delta_j`` independently of the
                    # others. Before this, ONE scalar ``t`` was created for the
                    # whole parameter and multiplied by the whole ``delta``
                    # vector, which
                    #   (a) lumped every component into a single aggregate
                    #       coefficient (the finite difference perturbs EVERY
                    #       component by 1 at once, giving ``sum_j coeff_j``), and
                    #   (b) produced a shape-``(k,)`` term -- ``Constant(delta) *
                    #       t`` with scalar ``t`` -- inside a scalar row or
                    #       objective, which the LP route rejects with
                    #       ``jax.grad ... Output had shape: (2,)`` and POUNCE
                    #       with ``cannot reshape array of shape (2,) into (1,)``.
                    # A scalar parameter has k = 1, so that case is unchanged.
                    nominal_arr = np.atleast_1d(np.asarray(nominal, dtype=float))
                    delta_arr = np.atleast_1d(np.asarray(delta, dtype=float))
                    if delta_arr.size == 1 and nominal_arr.size > 1:
                        delta_arr = np.full(nominal_arr.shape, float(delta_arr.flat[0]))
                    is_scalar_param = np.ndim(nominal) == 0

                    for j in range(nominal_arr.size):
                        if float(delta_arr.flat[j]) == 0.0:
                            # A component with no uncertainty contributes no
                            # penalty; emitting one would add an aux variable and
                            # two rows that can only ever be slack.
                            continue
                        # coeff_j = g(p_bar + e_j) - g(p_bar): the finite
                        # difference in component j ALONE, which is the
                        # coefficient multiplying xi_j.
                        if is_scalar_param:
                            bumped = Constant(np.asarray(nominal, dtype=float) + 1.0)
                        else:
                            step = np.zeros_like(nominal_arr)
                            step.flat[j] = 1.0
                            bumped = Constant((nominal_arr + step).reshape(np.shape(nominal)))
                        unit_j = substitute_param(expr_at_nom, pname, bumped)
                        coeff_j = BinaryOp("-", unit_j, base)

                        # A certain Parameter in the coefficient can change (or be
                        # made uncertain by a later pass), so no bound read from its
                        # current value is valid; leave t unbounded then.
                        t_ub = (
                            None
                            if _contains_any_parameter(coeff_j)
                            else _coeff_magnitude_bound(coeff_j)
                        )
                        t_name = f"{self._prefix}_abs{aux_idx}"
                        if t_ub is None:
                            t_var = m.continuous(t_name, lb=0)
                        else:
                            t_var = m.continuous(t_name, lb=0, ub=t_ub)
                        aux_idx += 1
                        if t_ub is None:
                            # #1834: no finite enclosure of |coeff_j|, so t is
                            # unbounded above by construction; the large-bounds
                            # warning's remedy does not apply to it (#1755).
                            if not hasattr(m, "_free_by_construction"):
                                m._free_by_construction = set()
                            m._free_by_construction.add(t_var.name)

                        # |coeff_j| <= t_j:  coeff_j - t_j <= 0  and  -coeff_j - t_j <= 0
                        new_constraints.append(
                            Constraint(
                                body=BinaryOp("-", coeff_j, t_var),
                                sense="<=",
                                rhs=0.0,
                                name=f"{self._prefix}_abs_pos{aux_idx - 1}",
                            )
                        )
                        new_constraints.append(
                            Constraint(
                                body=BinaryOp(
                                    "-",
                                    BinaryOp("*", Constant(np.array(-1.0)), coeff_j),
                                    t_var,
                                ),
                                sense="<=",
                                rhs=0.0,
                                name=f"{self._prefix}_abs_neg{aux_idx - 1}",
                            )
                        )

                        # Penalty: delta_j * t_j -- a SCALAR coefficient times a
                        # scalar aux, so the result keeps the host expression's
                        # shape.
                        penalty = BinaryOp("*", Constant(np.array(float(delta_arr.flat[j]))), t_var)
                        if maximize:
                            result = BinaryOp("+", result, penalty)
                        else:
                            result = BinaryOp("-", result, penalty)

            return result, new_constraints

        # -- Robustify constraints ----------------------------------------
        new_constraints = []
        for ci, con in enumerate(m._constraints):
            if not isinstance(con, Constraint):
                new_constraints.append(con)
                continue
            new_body, aux_cons = _robustify_expr(
                con.body, maximize=True, where=con.name or f"_constraints[{ci}]"
            )
            new_constraints.append(
                Constraint(body=new_body, sense=con.sense, rhs=con.rhs, name=con.name)
            )
            new_constraints.extend(aux_cons)
        m._constraints = new_constraints

        # -- Robustify objective ------------------------------------------
        obj = m._objective
        if obj is None:
            return
        maximize_obj_wc = obj.sense == ObjectiveSense.MINIMIZE
        new_expr, aux_cons = _robustify_expr(
            obj.expression, maximize=maximize_obj_wc, where="<objective>"
        )
        m._objective = Objective(expression=new_expr, sense=obj.sense)
        m._constraints.extend(aux_cons)

    # ------------------------------------------------------------------
    # Detection
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_bilinear(m, param_names):
        """Return True if any constraint or objective has bilinear var*param terms."""
        from discopt.modeling.core import Constraint

        exprs = []
        for con in m._constraints:
            if isinstance(con, Constraint):
                exprs.append(con.body)
        if m._objective is not None:
            exprs.append(m._objective.expression)

        for expr in exprs:
            if _has_bilinear_param_var(expr, param_names):
                return True
        return False


def _coeff_magnitude_bound(coeff) -> "float | None":
    """A valid upper bound on ``|coeff(x)|`` over the variable box, or ``None``.

    Taken from a sound interval enclosure of the coefficient expression, so the
    ``ro_abs`` auxiliary ``t >= |coeff|`` never cuts off its own counterpart.
    The former cap ``max|variable bound| + 1`` ignored the coefficient's scale:
    ``5 * y * p`` with ``y`` in [-10, 10] has ``|coeff|`` up to 50 against a cap
    of 11, and made a feasible robust model infeasible (#1834 -- the box twin of
    the polyhedral dual cap removed in #1611 X-30b). ``None`` (unbounded) when
    the enclosure is not finite; ``t`` enters only linearly, so that is no
    obstacle to the solve.
    """
    from discopt._relax.convexity.interval_eval import evaluate_interval

    enc = evaluate_interval(coeff, None)
    mag = np.maximum(np.abs(np.asarray(enc.lo, dtype=np.float64)), np.abs(enc.hi))
    bound = float(np.max(mag)) if np.size(mag) else 0.0
    # A coefficient over a variable at the modeling layer's "unbounded" default
    # (9.999e19) is no finite bound either.
    if not np.isfinite(bound) or bound >= 1e19:
        return None
    # Outward slack on top of the (already outward-rounded) enclosure, so an
    # interior-point solve at the bound is not active against the true |coeff|.
    return bound * (1.0 + 1e-6) + 1e-6


def _contains_variable(expr) -> bool:
    """Check whether expr contains any Variable node."""
    from discopt.modeling.core import (
        BinaryOp,
        FunctionCall,
        IndexExpression,
        MatMulExpression,
        SumExpression,
        SumOverExpression,
        UnaryOp,
        Variable,
    )

    if isinstance(expr, Variable):
        return True
    if isinstance(expr, (BinaryOp, MatMulExpression)):
        return _contains_variable(expr.left) or _contains_variable(expr.right)
    if isinstance(expr, UnaryOp):
        return _contains_variable(expr.operand)
    if isinstance(expr, FunctionCall):
        return any(_contains_variable(a) for a in expr.args)
    if isinstance(expr, IndexExpression):
        return _contains_variable(expr.base)
    if isinstance(expr, SumExpression):
        return _contains_variable(expr.operand)
    if isinstance(expr, SumOverExpression):
        return any(_contains_variable(t) for t in expr.terms)
    return False


def _var_provably_nonneg(expr) -> bool:
    """True only if *expr* is a Variable expression provably >= 0 (lb >= 0).

    Conservative: returns False for anything but a bare ``Variable`` with a
    non-negative lower bound (index expressions, sums, products, etc. resolve to
    False and are routed through the sign-safe |coeff| linearization). Used to
    keep the sign-tracking fast path only where it is sound (RO-1).
    """
    from discopt.modeling.core import Variable

    if isinstance(expr, Variable):
        lb = getattr(expr, "lb", None)
        return lb is not None and bool(np.all(np.asarray(lb) >= 0))
    return False


def _has_bilinear_param_var(expr, param_names: set[str]) -> bool:
    """Check whether expr has a true bilinear product: Variable * f(Parameter).

    A "true bilinear" term is one where a decision-variable expression
    multiplies an expression containing an uncertain parameter, AND that
    expression is not just the parameter itself (which sign-tracking
    handles correctly).  The canonical case is ``Y * (p - p_bar)`` from
    an affine decision rule.

    Note: ``Parameter * Variable`` (e.g. ``c * x``) is NOT bilinear in this
    sense because the parameter IS the coefficient and sign-tracking can
    determine its worst-case value directly.
    """
    from discopt.modeling.core import (
        BinaryOp,
        Constant,
        FunctionCall,
        IndexExpression,
        MatMulExpression,
        Parameter,
        SumExpression,
        SumOverExpression,
        UnaryOp,
    )

    if isinstance(expr, BinaryOp):
        if expr.op in ("*", "/") and (
            _mixed_constant_over_coupled(expr.right, expr.left, param_names)
            or (expr.op == "*" and _mixed_constant_over_coupled(expr.left, expr.right, param_names))
        ):
            return True
        if expr.op == "*":
            if not isinstance(expr.left, Constant) and not isinstance(expr.right, Constant):
                # Check for the specific pattern: one side is a Variable (or
                # expression with variables but no params), the other side
                # is an expression containing BOTH variables AND parameters.
                # This catches Y * (p - p_bar) but not Parameter * Variable.
                l_param = _contains_uncertain_param(expr.left, param_names)
                r_param = _contains_uncertain_param(expr.right, param_names)
                l_var = _contains_variable(expr.left)
                r_var = _contains_variable(expr.right)
                # True bilinear: both sides have at least one of {var, param}
                # AND they're mixed (not just param*var at the leaf level).
                if l_var and r_param and r_var:
                    return True  # left has var, right has both var and param
                if r_var and l_param and l_var:
                    return True  # right has var, left has both var and param
                # Variable-only * param-containing expression, e.g. Y*(p - p_bar).
                if l_var and not l_param and r_param and not isinstance(expr.right, Parameter):
                    return True
                if r_var and not r_param and l_param and not isinstance(expr.left, Parameter):
                    return True
                # RO-1: bare Parameter * Variable (`p * x`). Sign-tracking treats
                # the parameter AS the coefficient and picks its worst-case value
                # by sign — correct ONLY when the variable factor is provably
                # nonnegative. For a sign-indefinite variable the worst-case
                # parameter sign depends on the (unknown) sign of the variable, so
                # sign-tracking under-protects (returns a non-counterpart). Route
                # such terms through the |coeff| linearization path, which is
                # correct for any sign; keep sign-tracking only for x >= 0.
                if l_var and not l_param and isinstance(expr.right, Parameter):
                    if not _var_provably_nonneg(expr.left):
                        return True
                if r_var and not r_param and isinstance(expr.left, Parameter):
                    if not _var_provably_nonneg(expr.right):
                        return True
        return _has_bilinear_param_var(expr.left, param_names) or _has_bilinear_param_var(
            expr.right, param_names
        )
    if isinstance(expr, (MatMulExpression,)):
        if _mixed_constant_over_coupled(
            expr.left, expr.right, param_names
        ) or _mixed_constant_over_coupled(expr.right, expr.left, param_names):
            return True
        # #1726: RO-1 for ``p @ x`` / ``x @ p``. It is the same coefficient-times-
        # variable product as ``p * x`` and carries the same hazard: sign-tracking
        # replaces ``p`` by ONE corner of its box, which protects the row only when
        # ``x >= 0``. Without this test ``a @ x >= 10`` with a sign-indefinite ``x``
        # got a non-counterpart (worst case 0 against a required 10) while the
        # equivalent ``sum(a * x)`` was routed correctly.
        if isinstance(expr.left, Parameter) and expr.left.name in param_names:
            if _contains_variable(expr.right) and not _var_provably_nonneg(expr.right):
                return True
        if isinstance(expr.right, Parameter) and expr.right.name in param_names:
            if _contains_variable(expr.left) and not _var_provably_nonneg(expr.left):
                return True
        return _has_bilinear_param_var(expr.left, param_names) or _has_bilinear_param_var(
            expr.right, param_names
        )
    if isinstance(expr, UnaryOp):
        return _has_bilinear_param_var(expr.operand, param_names)
    if isinstance(expr, FunctionCall):
        return any(_has_bilinear_param_var(a, param_names) for a in expr.args)
    if isinstance(expr, IndexExpression):
        return _has_bilinear_param_var(expr.base, param_names)
    if isinstance(expr, SumExpression):
        return _has_bilinear_param_var(expr.operand, param_names)
    if isinstance(expr, SumOverExpression):
        return any(_has_bilinear_param_var(t, param_names) for t in expr.terms)
    return False


def _mixed_constant_over_coupled(factor, other, param_names: set[str]) -> bool:
    """A mixed-sign constant multiplying a term that holds a variable AND ``p``.

    Sign tracking splits a mixed-sign constant into ``c+ + c-`` and worst-cases
    each part on its own (#1831). That is exact when each parameter element
    enters once, but in ``sum([3, -1] * (p * y))`` with a scalar ``p`` the two
    parts pick *different* values of the same ``p`` -- sound, but the row
    becomes ``3 p_max y0 - p_min y1`` instead of ``max_p p (3 y0 - y1)``. The
    coefficient of ``p`` there, ``3 y0 - y1``, depends on the decision, and the
    |coeff| linearization is exact for it: measured on that row (``p`` in
    [-1, 1], rhs 1, maximize ``y1 - y0``, ``y`` in [0, 2]^2) the split gives
    objective 1, the linearization the true robust optimum 5/3.
    """
    from discopt.ro.formulations._common import _needs_multiplier_sign, eval_constant_expr

    if not _needs_multiplier_sign(factor, other, param_names):
        return False
    if not (_contains_variable(other) and _contains_uncertain_param(other, param_names)):
        return False
    value = np.asarray(eval_constant_expr(factor), dtype=np.float64)
    return bool(np.any(value > 0) and np.any(value < 0))
