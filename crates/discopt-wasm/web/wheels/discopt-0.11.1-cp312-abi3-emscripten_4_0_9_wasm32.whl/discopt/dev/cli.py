"""discopt-dev CLI — developer-only commands for the discopt source tree.

Usage:
    discopt-dev lit-scan [topic ...]
    discopt-dev adversary [-n COUNT] [topic ...]
    discopt-dev search-arxiv "query" [--max-results 20] [--start-date 2026-01-01]
    discopt-dev search-openalex "query" [--from-date ...] [--to-date ...] [--per-page 20]
    discopt-dev write-report <output-path>

These commands invoke project-scope Claude Code slash commands
(``.claude/commands/discoptbot.md``, ``.claude/commands/adversary.md``) and
read/write paths inside the discopt repository, so they must be run from the
source tree. They are not part of the user-facing ``discopt`` CLI.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path


def search_arxiv(query: str, max_results: int = 20) -> list[dict]:
    """Query arXiv API and return parsed results."""
    params = urllib.parse.urlencode(
        {
            "search_query": query,
            "start": 0,
            "max_results": max_results,
            "sortBy": "submittedDate",
            "sortOrder": "descending",
        }
    )
    url = f"http://export.arxiv.org/api/query?{params}"

    req = urllib.request.Request(url, headers={"User-Agent": "discopt-discoptbot/1.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        xml_data = resp.read().decode("utf-8")

    ns = {
        "atom": "http://www.w3.org/2005/Atom",
        "arxiv": "http://arxiv.org/schemas/atom",
    }
    root = ET.fromstring(xml_data)

    results = []
    for entry in root.findall("atom:entry", ns):
        title_el = entry.find("atom:title", ns)
        summary_el = entry.find("atom:summary", ns)
        published_el = entry.find("atom:published", ns)
        updated_el = entry.find("atom:updated", ns)

        title_text = title_el.text if title_el is not None else None
        summary_text = summary_el.text if summary_el is not None else None
        pub_text = published_el.text if published_el is not None else None
        upd_text = updated_el.text if updated_el is not None else None

        title = title_text.strip().replace("\n", " ") if title_text else ""
        abstract = summary_text.strip().replace("\n", " ") if summary_text else ""
        published = pub_text.strip() if pub_text else ""
        updated = upd_text.strip() if upd_text else ""

        authors = []
        for author_el in entry.findall("atom:author", ns):
            name_el = author_el.find("atom:name", ns)
            name_text = name_el.text if name_el is not None else None
            if name_text:
                authors.append(name_text.strip())

        arxiv_id = ""
        pdf_link = ""
        for link_el in entry.findall("atom:link", ns):
            href = link_el.get("href", "")
            if link_el.get("title") == "pdf":
                pdf_link = href
            elif "/abs/" in href:
                arxiv_id = href.split("/abs/")[-1]

        category_el = entry.find("arxiv:primary_category", ns)
        category = category_el.get("term", "") if category_el is not None else ""

        doi_el = entry.find("arxiv:doi", ns)
        doi_text = doi_el.text if doi_el is not None else None
        doi = doi_text.strip() if doi_text else ""

        results.append(
            {
                "title": title,
                "authors": authors,
                "arxiv_id": arxiv_id,
                "published": published[:10],
                "updated": updated[:10],
                "abstract": abstract[:500],
                "category": category,
                "doi": doi,
                "pdf_link": pdf_link,
                "link": f"https://arxiv.org/abs/{arxiv_id}" if arxiv_id else "",
            }
        )

    return results


def search_openalex(
    query: str,
    from_date: str | None = None,
    to_date: str | None = None,
    per_page: int = 20,
    api_key: str | None = None,
) -> list[dict]:
    """Query OpenAlex API and return parsed results."""
    filters = [f"default.search:{query}"]
    if from_date:
        filters.append(f"from_created_date:{from_date}")
    if to_date:
        filters.append(f"to_created_date:{to_date}")

    params: dict = {
        "filter": ",".join(filters),
        "sort": "publication_date:desc",
        "per_page": per_page,
    }
    if api_key:
        params["api_key"] = api_key

    url = f"https://api.openalex.org/works?{urllib.parse.urlencode(params)}"

    req = urllib.request.Request(
        url,
        headers={"User-Agent": "discopt/1.0", "Accept": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode("utf-8"))

    results = []
    for work in data.get("results", []):
        title = work.get("title", "") or ""
        doi = work.get("doi", "") or ""
        pub_date = work.get("publication_date", "") or ""
        oa_id = work.get("id", "") or ""

        authors = []
        for authorship in work.get("authorships", []):
            author = authorship.get("author", {})
            name = author.get("display_name", "")
            if name:
                authors.append(name)

        abstract = ""
        inv_index = work.get("abstract_inverted_index")
        if inv_index:
            word_positions = []
            for word, positions in inv_index.items():
                for pos in positions:
                    word_positions.append((pos, word))
            word_positions.sort()
            abstract = " ".join(w for _, w in word_positions)[:500]

        source = ""
        primary_loc = work.get("primary_location") or {}
        source_obj = primary_loc.get("source") or {}
        source = source_obj.get("display_name", "") or ""

        link = ""
        best_oa = work.get("best_oa_location") or {}
        link = best_oa.get("pdf_url", "") or best_oa.get("landing_page_url", "") or ""
        if not link and doi:
            link = doi if doi.startswith("http") else f"https://doi.org/{doi}"

        results.append(
            {
                "title": title,
                "authors": authors[:5],
                "doi": doi.replace("https://doi.org/", "")
                if doi.startswith("https://doi.org/")
                else doi,
                "published": pub_date,
                "abstract": abstract,
                "source": source,
                "openalex_id": oa_id,
                "link": link,
            }
        )

    return results


def _cmd_search_arxiv(args):
    try:
        results = search_arxiv(args.query, args.max_results)
    except Exception as e:
        print(json.dumps({"error": str(e), "results": []}))
        sys.exit(1)

    if args.start_date:
        results = [r for r in results if r["published"] >= args.start_date]

    print(json.dumps({"query": args.query, "count": len(results), "results": results}, indent=2))


def _cmd_search_openalex(args):
    try:
        results = search_openalex(
            args.query,
            from_date=args.from_date,
            to_date=args.to_date,
            per_page=args.per_page,
            api_key=args.api_key,
        )
    except Exception as e:
        print(json.dumps({"error": str(e), "results": []}))
        sys.exit(1)

    print(
        json.dumps(
            {"query": args.query, "count": len(results), "results": results},
            indent=2,
        )
    )


def _cmd_write_report(args):
    path = args.output_path
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    content = sys.stdin.read()
    with open(path, "w") as f:
        f.write(content)
    print(f"Wrote {len(content)} bytes to {path}")


def _find_project_command(slash_command: str) -> Path | None:
    """Return the .md path for a project-scope Claude Code slash command, or None.

    Walks up from cwd looking for ``.claude/commands/<name>.md``. Dev slash
    commands (``/discoptbot``, ``/adversary``) are intentionally only registered
    in the source tree, never in user scope or shipped to ``discopt install-skills``.
    """
    filename = f"{slash_command}.md"
    cur = Path.cwd().resolve()
    while True:
        candidate = cur / ".claude" / "commands" / filename
        if candidate.is_file():
            return candidate
        if cur.parent == cur:
            return None
        cur = cur.parent


def _run_claude_command(slash_command: str, args_str: str = ""):
    """Invoke a project-scope Claude Code slash command via the ``claude`` CLI.

    Errors out cleanly if either the ``claude`` CLI is missing or cwd is outside
    a discopt checkout (i.e., ``.claude/commands/<name>.md`` cannot be found by
    walking up from cwd).
    """
    import shutil
    import subprocess

    claude_bin = shutil.which("claude")
    if claude_bin is None:
        print(
            "Error: 'claude' CLI not found on PATH.\nInstall Claude Code: https://claude.ai/code",
            file=sys.stderr,
        )
        sys.exit(1)

    if _find_project_command(slash_command) is None:
        print(
            f"Error: slash command '/{slash_command}' not found. "
            f"discopt-dev commands must be run from a discopt source checkout "
            f"(walking up from cwd, no .claude/commands/{slash_command}.md was found).",
            file=sys.stderr,
        )
        sys.exit(1)

    prompt = f"/{slash_command}"
    if args_str:
        prompt = f"{prompt} {args_str}"

    subprocess.run([claude_bin, "-p", prompt], check=False)


def _cmd_lit_scan(args):
    """Run the discoptbot literature scanner."""
    topic = " ".join(args.topic) if args.topic else ""
    _run_claude_command("discoptbot", topic)


def _cmd_adversary(args):
    """Run the adversary solver correctness agent."""
    parts = []
    if args.count != 1:
        parts.append(str(args.count))
    if args.topic:
        parts.extend(args.topic)
    _run_claude_command("adversary", " ".join(parts))


def main():
    parser = argparse.ArgumentParser(
        prog="discopt-dev",
        description="Developer-only commands for the discopt source tree.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_arxiv = subparsers.add_parser("search-arxiv", help="Search arXiv API")
    p_arxiv.add_argument("query", help="arXiv search query")
    p_arxiv.add_argument("--max-results", type=int, default=20)
    p_arxiv.add_argument("--start-date", help="Filter results after this date (YYYY-MM-DD)")
    p_arxiv.set_defaults(func=_cmd_search_arxiv)

    p_oa = subparsers.add_parser("search-openalex", help="Search OpenAlex API")
    p_oa.add_argument("query", help="Search query")
    p_oa.add_argument("--from-date", help="Start date (YYYY-MM-DD)")
    p_oa.add_argument("--to-date", help="End date (YYYY-MM-DD)")
    p_oa.add_argument("--per-page", type=int, default=20)
    p_oa.add_argument(
        "--api-key",
        default=os.environ.get("OPENALEX_API_KEY"),
        help="OpenAlex API key (or set OPENALEX_API_KEY env var)",
    )
    p_oa.set_defaults(func=_cmd_search_openalex)

    p_wr = subparsers.add_parser("write-report", help="Write stdin to a file")
    p_wr.add_argument("output_path", help="Output file path")
    p_wr.set_defaults(func=_cmd_write_report)

    p_lit = subparsers.add_parser(
        "lit-scan",
        help="Search recent literature for papers relevant to discopt",
    )
    p_lit.add_argument(
        "topic",
        nargs="*",
        help="Optional topic focus (e.g., 'McCormick relaxations')",
    )
    p_lit.set_defaults(func=_cmd_lit_scan)

    p_adv = subparsers.add_parser(
        "adversary",
        help="Test discopt against benchmark problems with known solutions",
    )
    p_adv.add_argument(
        "-n",
        "--count",
        type=int,
        default=1,
        help="Number of problems to test (default: 1)",
    )
    p_adv.add_argument(
        "topic",
        nargs="*",
        help="Optional problem class focus (e.g., 'MINLP', 'convex NLP')",
    )
    p_adv.set_defaults(func=_cmd_adversary)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
