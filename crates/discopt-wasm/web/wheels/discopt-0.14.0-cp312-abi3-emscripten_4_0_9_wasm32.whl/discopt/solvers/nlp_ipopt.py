"""
NLP solver wrapper using cyipopt (Python binding for Ipopt).

Phase 1 scaffolding: uses cyipopt for continuous relaxation solves.
Will be replaced by direct Rust Ipopt bindings later.

Maps NLPEvaluator callbacks to cyipopt.Problem interface:
  - objective, gradient, constraints, jacobian, hessian
  - Variable and constraint bounds
  - Ipopt status codes to SolveStatus enum
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any, Optional

import numpy as np

from discopt.modeling.core import Model
from discopt.solver_tuning import subsolve_wall_options
from discopt.solvers import NLPResult, SolveStatus

logger = logging.getLogger(__name__)

if TYPE_CHECKING:  # pragma: no cover - typing only
    # #75: module-scope import pulled jax onto every solve via nlp_pounce ->
    # nlp_backend. Annotation-only at runtime.
    from discopt._relax.nlp_evaluator import NLPEvaluator

# Ipopt status code mapping
# See: https://coin-or.github.io/Ipopt/IpReturnCodes_8inc.html
#
# NOTE: Status 2 ("Infeasible_Problem_Detected") is mapped to ERROR rather
# than INFEASIBLE because IPOPT can only detect *local* infeasibility.
# For non-convex NLPs the problem may still be feasible from a different
# starting point.  Mapping to ERROR prevents the solver from confidently
# reporting "infeasible" when the problem is merely hard to solve.
#: Ipopt's ``Infeasible_Problem_Detected``: the restoration phase converged to a
#: **local** minimizer of the constraint violation with the violation still
#: positive.
#:
#: It is deliberately NOT mapped to :attr:`SolveStatus.INFEASIBLE` in
#: :data:`_IPOPT_STATUS_MAP` below. On a **convex** subproblem the verdict is a
#: genuine infeasibility proof — the violation measure is convex, so a local
#: minimizer of it is global — but on a nonconvex one it says only that the
#: algorithm is stuck at an infeasible point, which is not a proof of anything.
#: The map serves every caller, including the pure-NLP path in
#: :func:`discopt.solver.solve_model`, which would then publish
#: ``status="infeasible"`` for a model it never proved infeasible (CLAUDE.md §1).
#:
#: Callers that hold a convexity certificate may read the verdict soundly, via
#: :attr:`discopt.solvers.NLPResult.raw_status`. #1141 measured the cost of the
#: conservative reading on the convex MINLP class: 60 of 401 OA fixed-NLP
#: subproblems on ``portfol_classical050_1`` came back code 2, every one of them a
#: genuinely infeasible integer assignment that the master then had to be talked
#: out of by weaker means.
IPOPT_LOCALLY_INFEASIBLE = 2

_IPOPT_STATUS_MAP: dict[int, SolveStatus] = {
    0: SolveStatus.OPTIMAL,  # Solve_Succeeded
    1: SolveStatus.OPTIMAL,  # Solved_To_Acceptable_Level
    # Infeasible_Problem_Detected — LOCAL only; see IPOPT_LOCALLY_INFEASIBLE above.
    2: SolveStatus.ERROR,
    # Ipopt code 3 = Search_Direction_Becomes_Too_Small: the IPM stalled on a tiny
    # step, typically AT/near a local solution it cannot certify to tolerance — NOT
    # unboundedness (that is code 4, Diverging_Iterates). Mapping it to UNBOUNDED made
    # a converged-but-uncertified node look like an unbounded relaxation, which a local
    # NLP can never prove; on jit1's B&B nodes this produced a false UNBOUNDED cascade
    # (pounce#257/#258) that forced a cyipopt-retry workaround. Treat it as a
    # non-converged limit — the B&B handles it soundly (non-pruning, uncertified),
    # never as a false unbounded verdict.
    3: SolveStatus.ITERATION_LIMIT,  # Search_Direction_Becomes_Too_Small (stalled, not unbounded)
    4: SolveStatus.ERROR,  # Diverging_Iterates
    5: SolveStatus.ERROR,  # User_Requested_Stop
    6: SolveStatus.ERROR,  # Feasible_Point_Found (not optimal)
    -1: SolveStatus.ITERATION_LIMIT,  # Maximum_Iterations_Exceeded
    -2: SolveStatus.ERROR,  # Restoration_Failed
    -3: SolveStatus.ERROR,  # Error_In_Step_Computation
    -4: SolveStatus.TIME_LIMIT,  # Maximum_CpuTime_Exceeded
    -5: SolveStatus.TIME_LIMIT,  # Maximum_WallTime_Exceeded
}

#: Ipopt ``ApplicationReturnStatus`` names, for the human-readable reason a
#: ``status="error"`` result carries in :attr:`SolveResult.error` (#1493). Several
#: codes collapse onto ``SolveStatus.ERROR`` above, so the mapped status alone
#: cannot tell a caller which failure it was.
IPOPT_RETURN_CODE_NAMES: dict[int, str] = {
    0: "Solve_Succeeded",
    1: "Solved_To_Acceptable_Level",
    2: "Infeasible_Problem_Detected",
    3: "Search_Direction_Becomes_Too_Small",
    4: "Diverging_Iterates",
    5: "User_Requested_Stop",
    6: "Feasible_Point_Found",
    -1: "Maximum_Iterations_Exceeded",
    -2: "Restoration_Failed",
    -3: "Error_In_Step_Computation",
    -4: "Maximum_CpuTime_Exceeded",
    -5: "Maximum_WallTime_Exceeded",
    -10: "Not_Enough_Degrees_Of_Freedom",
    -11: "Invalid_Problem_Definition",
    -12: "Invalid_Option",
    -13: "Invalid_Number_Detected",
    -100: "Unrecoverable_Exception",
    -101: "NonIpopt_Exception_Thrown",
    -102: "Insufficient_Memory",
    -199: "Internal_Error",
}


def describe_ipopt_return_code(code: Optional[int]) -> str:
    """``"code 2 (Infeasible_Problem_Detected)"``, or ``"no return code"``."""
    if code is None:
        return "no return code"
    return f"code {int(code)} ({IPOPT_RETURN_CODE_NAMES.get(int(code), 'unrecognized')})"


def _charge_evaluator(method):
    """Charge a derivative callback's time to the evaluator's own layer.

    This adapter is the *only* path from the NLP subsolver (POUNCE or cyipopt,
    both native) back into the Python evaluator, so it is the correct seam for
    attribution. Without it, the callbacks run inside ``charge("pounce")`` and
    POUNCE's bucket absorbs the derivative cost — the same kind of cross-layer
    inflation the layer profile exists to expose.

    The bucket is read from the evaluator (``timing_bucket``) rather than fixed
    here. It used to be hardcoded ``"jax"`` on the premise that "today's
    evaluator is JAX-backed"; #75's tape evaluator made that false, and because
    ``charge`` records *self* time the error was two-sided — a JAX-free tape
    solve reported fabricated ``jax_time`` **and** an equally understated
    ``pounce_time``, i.e. both halves of the rust/python partition were wrong on
    the very measurement that judges the JAX removal. Measured before this
    change on a bilinear MINLP: ``jax_time = 0.00217 s`` with
    ``"jax" not in sys.modules``.
    """
    import functools

    from discopt import _timing

    @functools.wraps(method)
    def wrapper(self, *args, **kwargs):
        if self._bucket is None:
            return method(self, *args, **kwargs)
        with _timing.charge(self._bucket):
            return method(self, *args, **kwargs)

    return wrapper


#: Ipopt's and POUNCE's ``Index`` is a 32-bit signed int, and the KKT triplet
#: count is carried in it. Past this the solver does not raise: POUNCE's FERAL
#: backend panicked with ``assertion left == right`` (2553513213 vs the same
#: count wrapped through i32), which reaches Python as a ``BaseException``.
_INT32_MAX = 2**31 - 1


class NLPIndexOverflowError(ValueError):
    """The NLP's KKT triplet count does not fit the solver's 32-bit index."""


def _check_kkt_index_capacity(n: int, m: int, jac_nnz: int, hess_nnz: int, dense: bool) -> None:
    """Refuse, before any solver sees it, an NLP whose KKT matrix overflows ``i32``.

    The bound is an upper bound on the full-space augmented system's triplet
    count: the Lagrangian Hessian plus a diagonal (``n``), the Jacobian, and at
    most three diagonals over the rows (slack, inequality identity,
    regularization). Measured on GDPlib ``stranded_gas`` (n=57828, m=15241):
    POUNCE's actual count exceeded ``jac + hess`` by 88959 <= ``n + 3m`` = 103551.
    """
    kkt = int(hess_nnz) + int(jac_nnz) + int(n) + 3 * int(m)
    if kkt <= _INT32_MAX:
        return
    how = (
        "the evaluator offers no sparse structure, so the dense fallback "
        f"(m*n = {int(m) * int(n)} Jacobian and n(n+1)/2 = {int(n) * (int(n) + 1) // 2} "
        "Hessian entries) was used"
        if dense
        else f"sparse Jacobian nnz {int(jac_nnz)}, Hessian nnz {int(hess_nnz)}"
    )
    raise NLPIndexOverflowError(
        f"NLP with n={n}, m={m} has up to {kkt} KKT nonzeros, more than the 32-bit "
        f"index limit {_INT32_MAX} of the NLP solver; {how}."
    )


class _IpoptCallbacks:
    """Adapter mapping NLPEvaluator methods to cyipopt.Problem callbacks."""

    def __init__(self, evaluator) -> None:
        self._ev = evaluator
        self._n = evaluator.n_variables
        self._m = evaluator.n_constraints
        self._use_sparse = (
            hasattr(evaluator, "has_sparse_structure") and evaluator.has_sparse_structure()
        )
        if self._use_sparse:
            jac_nnz = len(evaluator.jacobian_structure()[0])
            hess_nnz = len(evaluator.hessian_structure()[0])
        else:
            # Counted, not built: the dense structure is what would overflow.
            jac_nnz = self._m * self._n
            hess_nnz = self._n * (self._n + 1) // 2
        _check_kkt_index_capacity(self._n, self._m, jac_nnz, hess_nnz, dense=not self._use_sparse)
        # Resolve once per solve, not once per callback. An evaluator that does
        # not declare its layer gets charged to *nothing* rather than to a
        # guessed bucket: an unknown backend's time then stays with the enclosing
        # region, which is merely coarse, whereas guessing invents a number about
        # a library that may never have been loaded. The in-tree evaluators both
        # declare one (the proxies in ``solver.py`` forward it), so the warning
        # below fires only for a duck-typed evaluator from outside the package.
        self._bucket = getattr(evaluator, "timing_bucket", None)
        if self._bucket is None:
            logger.warning(
                "Evaluator %s declares no `timing_bucket`; its derivative-callback "
                "time will be left with the enclosing solver region and the layer "
                "profile will over-report that layer [timing-bucket-unknown].",
                type(evaluator).__name__,
            )

    @_charge_evaluator
    def objective(self, x: np.ndarray) -> float:
        return self._ev.evaluate_objective(x)

    @_charge_evaluator
    def gradient(self, x: np.ndarray) -> np.ndarray:
        return self._ev.evaluate_gradient(x)

    @_charge_evaluator
    def constraints(self, x: np.ndarray) -> np.ndarray:
        return self._ev.evaluate_constraints(x)

    @_charge_evaluator
    def jacobian(self, x: np.ndarray) -> np.ndarray:
        if self._use_sparse:
            return self._ev.evaluate_jacobian_values(x)
        # cyipopt wants the Jacobian flattened in the order given by jacobianstructure
        jac = self._ev.evaluate_jacobian(x)
        return jac.flatten()

    @_charge_evaluator
    def jacobianstructure(self) -> tuple[np.ndarray, np.ndarray]:
        if self._use_sparse:
            return self._ev.jacobian_structure()
        # Dense structure: all (row, col) pairs
        rows, cols = np.meshgrid(np.arange(self._m), np.arange(self._n), indexing="ij")
        return (rows.flatten(), cols.flatten())

    @_charge_evaluator
    def hessian(self, x: np.ndarray, lagrange: np.ndarray, obj_factor: float) -> np.ndarray:
        if self._use_sparse:
            return self._ev.evaluate_hessian_values(x, obj_factor, lagrange)
        # Hessian of the Lagrangian = obj_factor * H_obj + sum(lagrange[i] * H_c[i])
        if hasattr(self._ev, "evaluate_lagrangian_hessian"):
            h = self._ev.evaluate_lagrangian_hessian(x, obj_factor, lagrange)
        else:
            h = obj_factor * self._ev.evaluate_hessian(x)

        # Extract lower triangle in row-major order matching hessianstructure
        rows, cols = self.hessianstructure()
        return h[rows, cols]

    @_charge_evaluator
    def hessianstructure(self) -> tuple[np.ndarray, np.ndarray]:
        if self._use_sparse:
            return self._ev.hessian_structure()
        # Lower triangle (including diagonal)
        rows, cols = np.tril_indices(self._n)
        return (rows, cols)


_BOUNDS_CACHE_ATTR = "_discopt_constraint_bounds_cache"


def _constraint_bounds_fingerprint(constraints, sizes) -> tuple:
    """An O(1) identity of the constraint list the bounds were derived from.

    ``constraints`` and ``sizes`` are owned by the evaluator, which also owns
    the cache entry, so neither object can be garbage-collected (and neither
    ``id`` recycled) while the entry is reachable. Rebuilding either list --
    the only way a compiled evaluator's senses can change -- changes the
    identity and misses the cache.
    """
    return (id(constraints), len(constraints), id(sizes), int(np.sum(sizes)))


def _cached_constraint_bounds(source, constraints, sizes):
    entry = getattr(source, _BOUNDS_CACHE_ATTR, None)
    if entry is None:
        return None
    fingerprint, cl, cu = entry
    if fingerprint != _constraint_bounds_fingerprint(constraints, sizes):
        return None
    return cl, cu


def _store_constraint_bounds(source, constraints, sizes, cl, cu) -> None:
    # Evaluators defined with ``__slots__`` simply go uncached rather than
    # raising; the bounds are recomputed exactly as they were before.
    if not hasattr(source, "__dict__"):
        return
    entry = (_constraint_bounds_fingerprint(constraints, sizes), cl, cu)
    setattr(source, _BOUNDS_CACHE_ATTR, entry)


def _infer_constraint_bounds(source) -> tuple[np.ndarray, np.ndarray]:
    """Infer constraint bounds (cl, cu) from model constraint senses.

    Accepts either a :class:`Model` or an :class:`NLPEvaluator`.

    The NLPEvaluator compiles constraints as ``body - rhs``, so we need:
      - For ``<=`` constraints: ``body - rhs <= 0``, so ``cl=-inf, cu=0``.
      - For ``==`` constraints: ``body - rhs == 0``, so ``cl=0, cu=0``.
      - For ``>=`` constraints: ``body - rhs >= 0``, so ``cl=0, cu=inf``.

    Each source Constraint's bounds are repeated to match the evaluator's
    ``_constraint_flat_sizes`` (needed for vector-valued bodies such as
    DAEBuilder's vectorized collocation residual). A Model is resolved to its
    canonical cached evaluator first: counting one row per ``Constraint`` object
    returned too few bounds for an array-valued row and none for the #840
    builder rows, so a feasibility check against ``evaluate_constraints`` raised
    a broadcast error and rejected every point (#1297).
    """
    if isinstance(source, Model):
        from discopt._tape_nlp_evaluator import make_evaluator

        # The evaluator branch returns fresh copies, so a later ``subject_to``
        # still sees new rows: the evaluator cache is keyed on the model's
        # structure.
        return _infer_constraint_bounds(make_evaluator(source))

    constraints = source._source_constraints
    sizes = source._constraint_flat_sizes
    # An NLPEvaluator compiles its constraint list once in ``__init__`` and
    # never mutates it, but the bounds were rebuilt on every call: the OA
    # feasibility phase calls this 45k times per solve through
    # ``_constraint_violation_data``, and each call allocates ``2 * n_cons``
    # ``np.full`` arrays plus two concatenates. Measured on
    # ``portfol_classical050_1`` (103 constraints): 111.4 us/call, ~5.1 s of
    # a 32.8 s solve.
    cached = _cached_constraint_bounds(source, constraints, sizes)
    if cached is not None:
        return cached[0].copy(), cached[1].copy()

    cl_parts: list[np.ndarray] = []
    cu_parts: list[np.ndarray] = []
    for c, sz in zip(constraints, sizes):
        sz_int = int(sz)
        if c.sense == "<=":
            lo, hi = -1e20, 0.0
        elif c.sense == "==":
            lo, hi = 0.0, 0.0
        elif c.sense == ">=":
            lo, hi = 0.0, 1e20
        else:
            raise ValueError(f"Unknown constraint sense: {c.sense}")
        cl_parts.append(np.full(sz_int, lo, dtype=np.float64))
        cu_parts.append(np.full(sz_int, hi, dtype=np.float64))

    if not cl_parts:
        cl = np.empty(0, dtype=np.float64)
        cu = np.empty(0, dtype=np.float64)
    else:
        cl = np.concatenate(cl_parts)
        cu = np.concatenate(cu_parts)

    _store_constraint_bounds(source, constraints, sizes, cl, cu)
    # Callers receive their own arrays, exactly as before this was cached, so a
    # caller that writes into the result cannot corrupt the cache.
    return cl.copy(), cu.copy()


def _ipopt_version() -> tuple[int, ...]:
    """The linked Ipopt library's version, or ``()`` when cyipopt does not say.

    cyipopt exposes it as ``IPOPT_VERSION`` (a tuple of ints). Older bindings
    may not, in which case callers must treat the version as unknown rather
    than assume a floor.
    """
    from discopt._openmp_guard import check_openmp_compatible

    check_openmp_compatible("cyipopt", feature="nlp_solver='ipopt'")
    try:
        import cyipopt
    except ImportError:  # pragma: no cover - guarded by callers
        return ()
    version = getattr(cyipopt, "IPOPT_VERSION", None)
    if not isinstance(version, tuple):
        return ()
    try:
        return tuple(int(part) for part in version)
    except (TypeError, ValueError):  # pragma: no cover - defensive
        return ()


def _translate_options(opts: dict) -> dict:
    """Rewrite options the linked Ipopt is too old to know into equivalents.

    ``max_wall_time`` is Ipopt >= 3.14 only. On an older library cyipopt raises
    ``TypeError`` *after* Ipopt has already printed "Tried to set Option:
    max_wall_time. It is not a valid option." on stdout -- so the caller's time
    limit was dropped, and the only trace of it was a line of noise in the
    output. Ipopt 3.11/3.12/3.13 spell the same cap ``max_cpu_time``, so
    translate rather than drop: a requested limit stays a limit. An explicit
    ``max_cpu_time`` from the caller always wins.

    The version is checked *before* the call because the message is emitted by
    the C library; catching the exception afterwards cannot unprint it.
    """
    version = _ipopt_version()
    if not version or version >= (3, 14):
        return opts
    if "max_wall_time" not in opts:
        return opts
    translated = dict(opts)
    wall = translated.pop("max_wall_time")
    translated.setdefault("max_cpu_time", wall)
    logger.debug(
        "Ipopt %s predates max_wall_time; applying it as max_cpu_time=%s",
        ".".join(str(v) for v in version),
        wall,
    )
    return translated


def solve_nlp(
    evaluator: NLPEvaluator,
    x0: np.ndarray,
    constraint_bounds: Optional[list[tuple[float, float]]] = None,
    options: Optional[dict] = None,
) -> NLPResult:
    """
    Solve an NLP using cyipopt with JAX-compiled callbacks.

    Args:
        evaluator: NLPEvaluator providing objective/gradient/Hessian/constraint/Jacobian.
        x0: Initial point (n,).
        constraint_bounds: List of (cl, cu) per constraint. None to infer from model.
        options: Ipopt options dict (e.g., {'max_iter': 1000, 'tol': 1e-8}).

    Returns:
        NLPResult with solution
    """
    from discopt._openmp_guard import check_openmp_compatible

    check_openmp_compatible("cyipopt", feature="nlp_solver='ipopt'")
    try:
        import cyipopt
    except ImportError:
        raise ImportError(
            "cyipopt is required for solve_nlp. Install it with:\n"
            "  pip install cyipopt\n"
            "Note: cyipopt requires the Ipopt C library to be installed."
        )

    opts = dict(options) if options else {}
    # #2120: role-2 per-solve wall cap -> role-1 remainder under ``deterministic``.
    subsolve_wall_options(opts)
    opts.setdefault("print_level", 0)

    n = evaluator.n_variables
    m = evaluator.n_constraints
    lb, ub = evaluator.variable_bounds

    # Constraint bounds
    if constraint_bounds is not None:
        cl = np.array([b[0] for b in constraint_bounds], dtype=np.float64)
        cu = np.array([b[1] for b in constraint_bounds], dtype=np.float64)
    elif m > 0:
        cl, cu = _infer_constraint_bounds(evaluator)
    else:
        cl = np.empty(0, dtype=np.float64)
        cu = np.empty(0, dtype=np.float64)

    callbacks: Any = _IpoptCallbacks(evaluator)
    # #2143: the hard stop a primal heuristic armed (see ``nlp_pounce.solve_nlp``).
    from discopt.solvers._nlp_hard_stop import (
        USER_REQUESTED_STOP,
        HardStopCallbacks,
        armed_deadline,
        expired_result,
    )

    hard_stop = armed_deadline()
    if hard_stop is not None:
        if time.perf_counter() >= hard_stop:
            return expired_result(x0)
        callbacks = HardStopCallbacks(callbacks, hard_stop)

    problem = cyipopt.Problem(
        n=n,
        m=m,
        problem_obj=callbacks,
        lb=lb,
        ub=ub,
        cl=cl,
        cu=cu,
    )

    # cyipopt requires native Python types (rejects numpy scalars).
    for key, value in _translate_options(opts).items():
        try:
            if isinstance(value, (np.floating, float)):
                problem.add_option(key, float(value))
            elif isinstance(value, (np.integer, int)):
                problem.add_option(key, int(value))
            else:
                problem.add_option(key, value)
        except TypeError:
            # The option name is not one this Ipopt build knows. Dropping it
            # silently is how a caller-requested limit stops being applied with
            # nothing to show for it, so say so at WARNING, not DEBUG.
            logger.warning(
                "Ipopt %s rejected option %r; it was NOT applied to this solve.",
                ".".join(str(v) for v in _ipopt_version()) or "(unknown version)",
                key,
            )

    t0 = time.perf_counter()
    x, info = problem.solve(x0.astype(np.float64))
    wall_time = time.perf_counter() - t0

    status_code = info["status"]
    status = _IPOPT_STATUS_MAP.get(status_code, SolveStatus.ERROR)
    if status_code == USER_REQUESTED_STOP and getattr(callbacks, "fired", False):
        status = SolveStatus.TIME_LIMIT

    multipliers = info.get("mult_g", None)
    if multipliers is not None and len(multipliers) == 0:
        multipliers = None
    mult_x_L = info.get("mult_x_L", None)
    if mult_x_L is not None and len(mult_x_L) == 0:
        mult_x_L = None
    mult_x_U = info.get("mult_x_U", None)
    if mult_x_U is not None and len(mult_x_U) == 0:
        mult_x_U = None

    return NLPResult(
        status=status,
        x=np.asarray(x),
        objective=float(info["obj_val"]),
        multipliers=np.asarray(multipliers) if multipliers is not None else None,
        bound_multipliers_lower=np.asarray(mult_x_L) if mult_x_L is not None else None,
        bound_multipliers_upper=np.asarray(mult_x_U) if mult_x_U is not None else None,
        iterations=0,  # Ipopt doesn't expose iteration count via this API
        wall_time=wall_time,
        raw_status=int(status_code),
    )


def solve_nlp_from_model(
    model: Model,
    x0: Optional[np.ndarray] = None,
    options: Optional[dict] = None,
) -> NLPResult:
    """Convenience: create NLPEvaluator from model and solve.

    Args:
        model: A Model with objective and constraints set.
        x0: Initial point (n,). If None, uses midpoint of bounds clipped to [-100, 100].
        options: Ipopt options dict.

    Returns:
        NLPResult with solution.
    """
    from discopt._tape_nlp_evaluator import make_evaluator

    evaluator = make_evaluator(model)

    if x0 is None:
        lb, ub = evaluator.variable_bounds
        lb_clipped = np.clip(lb, -100.0, 100.0)
        ub_clipped = np.clip(ub, -100.0, 100.0)
        x0 = 0.5 * (lb_clipped + ub_clipped)

    return solve_nlp(evaluator, x0, options=options)
