"""HiGHS engine for pure LP / MILP solves (issue #1229).

Binding contract: ``docs/dev/lp-milp-highs-routing-plan.md`` §3. The principle is
that HiGHS's *labels* are never trusted for a certificate:

* every returned point passes a readback guard (no value at the ``1e20`` open-bound
  sentinel -- the #1229 failure class) and a feasibility check on the standard-form
  data before anything is computed from it;
* the objective is recomputed from the point, never read from HiGHS;
* an LP ``optimal`` is certified only by a Neumaier--Shcherbina safe bound computed
  in Rust (double-double ``Aᵀy``) from HiGHS's dual, closing the gap to the point;
  where roundoff leaves that bound at ``-inf``, over a rigorously widened FBBT box and
  then from an exact rational correction of the dual (labeled with its provenance);
* an LP ``infeasible`` needs a Farkas ray discopt verifies (declared or FBBT box) or a
  rigorous phase-1 bound above zero; an LP ``unbounded`` a primal ray and a feasible
  point discopt verifies;
* a MILP dual bound is HiGHS's ``mip_dual_bound`` (floating point, the same class as
  the Rust driver's), cross-checked against the NS-safe root LP bound.

Anything that fails a check is ``status="error"`` with the reason. There is no
fallback to another engine (§4): a fallback would hide exactly the failure class
this route exists to surface.

This module works on the standard form ``min cᵀx + d  s.t.  A x = b, l <= x <= u``
that :func:`discopt._relax.problem_classifier.extract_lp_data` produces; mapping
back to a ``SolveResult`` lives in ``discopt.solver``. ``highspy`` is imported
lazily so a default MINLP solve never loads it.
"""

from __future__ import annotations

import contextlib
import contextvars
import dataclasses
import logging
import os
import threading
import time
from collections.abc import Iterator, Mapping
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Optional

import numpy as np
import scipy.sparse as sp

logger = logging.getLogger(__name__)

#: discopt's open-bound sentinel (CLAUDE.md: test the bound, never a product).
INF = 1e20
#: A point or dual at or above this magnitude is read back as a failure unless the
#: value sits exactly on a declared finite bound (the default continuous box is
#: ``±9.999e19``, and ``min -x`` over it is optimal at that corner -- #850/#937).
READBACK_LIMIT = 1e15
#: HiGHS's default ``mip_feasibility_tolerance``, the tolerance its MIP domain
#: propagation works to; the route passes the same value (``feasibility_tolerance``).
HIGHS_MIP_FEAS_TOL = 1e-6
#: Per-row feasibility test ``|viol_i| <= FEAS_TOL + FEAS_RTOL * sum_j |A_ij||x_j|``:
#: the ``_matrix_solution_feasible`` convention.
FEAS_TOL = 1e-6
FEAS_RTOL = 1e-9
#: conftest integrality tolerance.
INT_TOL = 1e-5
#: HiGHS drops matrix entries with ``|a| <= small_matrix_value``; this is the smallest
#: value the option accepts (1e-13 is rejected, highspy 1.12).
SMALL_MATRIX_VALUE = 1e-12
#: An LP is ``optimal`` iff ``objective - ns_bound <= CERT_ABS + CERT_REL*|objective|``.
CERT_ABS = 1e-6
CERT_REL = 1e-9
#: Relative margin a ray descent must clear. A Farkas contradiction is checked against an
#: explicit bound on its own floating-point error instead -- see :func:`farkas_verified`.
RAY_REL = 1e-9
#: A ray entry this small (after scaling the ray to unit max-norm) is cleaned to
#: zero *before* verification, so the vector that is verified is the vector used.
RAY_CLEAN = 1e-14
#: HiGHS stores ``mip_max_nodes`` as a 32-bit int (probe: ``10**12`` -> kError).
_MAX_NODES_CAP = 2**31 - 1
#: HiGHS ``presolve_rule_off`` bit for ``kPresolveRuleParallelRowsAndCols`` (rule 13 of
#: ``PresolveRuleType`` in ``lp_data/HConst.h``; HiGHS logs it as "Rule 13 (bit 8192):
#: Parallel rows and columns"). The MILP route switches that rule off (#1634).
#:
#: Its parallel-column dominance test (``HPresolve::detectParallelRowsAndCols``) decides
#: "these two columns cost the same" by ``|c_col * colScale - c_dup| <=
#: dual_feasibility_tolerance``, an ABSOLUTE 1e-7 on a cost measured per unit of the
#: duplicate column, where ``colScale = a_dup / a_col`` is the ratio of the two columns'
#: coefficients. On the tie branch it then fixes the integer column at whichever bound the
#: other column can compensate for -- the direction the tie makes free and the true cost
#: does not. The route's own slack ``a x + s = b`` (cost 0, coefficient 1) is parallel to
#: every column once presolve leaves a single row, so a coefficient ratio of 4.9e5 turns
#: a real 0.0064-per-unit cost into 1.3e-8 per unit of ``s``: a "tie". Measured on the
#: #1634 seed-181 witness: at presolve step 5 HiGHS fixed ``x2 = 3`` (cost 0.0064 each),
#: certified 0.02082 with the true optimum 0.00801 strictly feasible (slack >= 72), and
#: every guard here passed. With this bit off all three #1634 witnesses certify the true
#: optimum and the generator panel recorded in the PR has no false certificate.
#:
#: Not a tolerance tweak: a smaller ``dual_feasibility_tolerance`` only moves the ratio at
#: which the same absolute test misfires. The reduction is unsound on badly scaled columns
#: and the route has no way to re-derive a bound HiGHS's presolve took away, so it is off.
_PRESOLVE_RULE_PARALLEL_ROWS_AND_COLS = 1 << 13
#: HiGHS ``presolve_rule_off`` bit for ``kPresolveRuleSparsify`` (rule 14). The MILP route
#: switches it off (#1667) because it is the trigger of a presolve cycle that never returns.
#:
#: On the #1667 unit-commitment hand-off (2904 rows, 4344 columns of this route's slack
#: form), ``h.run()`` stays in ``HPresolve::fastPresolveLoop`` -> ``rowPresolve`` forever.
#: A stack sample confirmed this. That loop polls neither ``time_limit`` nor the interrupt
#: callbacks, so ``Model.solve(time_limit=20)`` was still running after 120 s and the route
#: had no way to stop it. Bisected over ``presolve_rule_off``: turning off rule 9
#: (doubleton equation), 12 (aggregator) or 14 (sparsify) alone breaks the cycle
#: (``Optimal`` 450623.7692 in 5-6 s), and rules 7, 8, 10, 11, 15, 16 alone do not.
#: Sparsify is the one taken: it only re-expresses rows to cut fill, while 9 and 12
#: eliminate columns. On 23 HiGHS check instances in this route's standard form, sparsify
#: on and off gave the same status and objective on every instance (panel in the #1667 PR).
#: The upstream bug is tracked in #1671. It is a regression window, not a floor: measured
#: 2026-11-18 (#2221) with the canary's ``presolve()`` probe on the hand-off, highspy
#: 1.12.0, 1.13.0, 1.13.1, 1.14.0, 1.15.0 and 1.15.1 cycle, and 1.11.0 and 1.16.0 return.
#: The fix is ERGO-Code/HiGHS PR 2962 (bisected on ``latest``), first released in 1.16.0,
#: where sparsify on and off both reach ``Optimal`` 450623.7692 (2.2 s / 1.5 s). The bit is
#: kept as a documented opt-out because ``highspy>=1.11`` still admits the cycling
#: releases; it can go once the floor is >= 1.16 and the #1667 panel is re-measured.
#: ``test_1671_highs_presolve_cycle_canary.py`` enforces both halves.
_PRESOLVE_RULE_SPARSIFY = 1 << 14
#: Every ``presolve_rule_off`` bit the MILP route sets.
MILP_PRESOLVE_RULE_OFF = _PRESOLVE_RULE_PARALLEL_ROWS_AND_COLS | _PRESOLVE_RULE_SPARSIFY
#: The only terminal statuses a limit can produce.
_LIMIT_STATUSES = ("kTimeLimit", "kIterationLimit", "kSolutionLimit", "kInterrupt")


from discopt._optional_highs import MissingHighsError as HighsUnavailable  # noqa: E402, F401
from discopt._optional_highs import run_checked, wrap_callback  # noqa: E402


def require_highspy():
    """``highspy`` for the LP/MILP HiGHS route, or :class:`HighsUnavailable`
    (``discopt._optional_highs.MissingHighsError``)."""
    from discopt._optional_highs import require_highspy as _require

    return _require("the LP/MILP HiGHS route")


@dataclass(frozen=True)
class StdForm:
    """``min cᵀx + obj_const  s.t.  A x = b, xl <= x <= xu`` with ``x_j`` integer for
    ``j in int_idx``. ``A`` is CSC with sorted indices and no stored zeros."""

    c: np.ndarray
    A: sp.csc_matrix
    b: np.ndarray
    xl: np.ndarray
    xu: np.ndarray
    obj_const: float = 0.0
    int_idx: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.int64))

    @classmethod
    def from_arrays(cls, c, A, b, xl, xu, obj_const=0.0, int_idx=None) -> "StdForm":
        c = np.ascontiguousarray(np.asarray(c, dtype=np.float64).ravel())
        n = c.shape[0]
        A = A if sp.issparse(A) else sp.csc_matrix(np.asarray(A, dtype=np.float64).reshape(-1, n))
        A = sp.csc_matrix(A, dtype=np.float64, copy=True)
        A.eliminate_zeros()
        A.sort_indices()
        b = np.ascontiguousarray(np.asarray(b, dtype=np.float64).ravel())
        xl = np.ascontiguousarray(np.asarray(xl, dtype=np.float64).ravel())
        xu = np.ascontiguousarray(np.asarray(xu, dtype=np.float64).ravel())
        ii = np.zeros(0, dtype=np.int64) if int_idx is None else np.asarray(int_idx, np.int64)
        if A.shape != (b.shape[0], n) or xl.shape != (n,) or xu.shape != (n,):
            raise ValueError(
                f"inconsistent standard form: c {c.shape}, A {A.shape}, b {b.shape}, "
                f"xl {xl.shape}, xu {xu.shape}"
            )
        for name, arr in (("c", c), ("A", A.data), ("b", b), ("xl", xl), ("xu", xu)):
            if np.isnan(arr).any():
                raise ValueError(f"standard form {name} contains NaN")
        if ii.size and (ii.min() < 0 or ii.max() >= n):
            raise ValueError("int_idx out of range")
        return cls(c, A, b, xl, xu, float(obj_const), np.unique(ii))

    @property
    def n(self) -> int:
        return int(self.c.shape[0])

    @property
    def m(self) -> int:
        return int(self.A.shape[0])

    def relaxed(self) -> "StdForm":
        return dataclasses.replace(self, int_idx=np.zeros(0, dtype=np.int64))


@dataclass
class HighsOutcome:
    """A verified outcome in the internal (minimize) sense.

    ``status`` is one of ``optimal``, ``feasible``, ``infeasible``, ``unbounded``,
    ``time_limit``, ``node_limit``, ``error``. ``objective`` and ``bound`` include
    ``obj_const``. ``stats`` is numeric (it feeds ``SolveResult.solver_stats``);
    ``labels`` carries provenance strings.
    """

    status: str
    x: Optional[np.ndarray] = None
    objective: Optional[float] = None
    bound: Optional[float] = None
    gap_certified: bool = False
    row_dual: Optional[np.ndarray] = None
    col_dual: Optional[np.ndarray] = None
    ray: Optional[np.ndarray] = None
    message: str = ""
    highs_status: str = ""
    node_count: int = 0
    iterations: int = 0
    root_bound: Optional[float] = None
    root_time: Optional[float] = None
    wall_time: float = 0.0
    stats: dict[str, float] = field(default_factory=dict)
    labels: dict[str, str] = field(default_factory=dict)
    #: #2151: which candidate refuted THIS solve's own bound in the #1509 check
    #: (``root-lp``, ``own-integers``, ``own-integers-bounded`` (#2183: the same LP when
    #: only its NS bound settled the check), ``rounded-root``), or ``""``. A field rather
    #: than a label, so a merge of another solve's labels cannot set it.
    refuted_by: str = ""


# ─────────────────────────────────────────────────────────────
# Solver-independent verification kernels
# ─────────────────────────────────────────────────────────────


def _logical_columns(sf: StdForm) -> np.ndarray:
    """Mask of *logical* columns: continuous, zero cost, in exactly one row. Such a
    column's value is determined by its row and affects nothing else."""
    is_int = np.zeros(sf.n, dtype=bool)
    is_int[sf.int_idx] = True
    return np.asarray((np.diff(sf.A.indptr) == 1) & (sf.c == 0.0) & ~is_int, dtype=bool)


def readback_problem(x: np.ndarray, sf: StdForm, **duals: Optional[np.ndarray]) -> Optional[str]:
    """Why a HiGHS readback cannot be used, or ``None``.

    Runs before any residual so the verifier never multiplies a sentinel-sized value:
    #1229's false "feasible" needed products ~1e20 to survive a 1e-6 tolerance. A
    large ``x_j`` is legitimate only when it equals a declared *finite* bound, or
    when ``j`` is a logical: a row over huge structural values needs a huge logical
    (``z0 + z1 >= 1`` at ``z = 9.999e19``), and the logical's read-back value is
    never trusted -- :func:`_exact_rows_problem` re-derives it exactly.
    """
    x = np.asarray(x, dtype=np.float64)
    if x.shape != (sf.n,):
        return f"primal readback has shape {x.shape}, expected ({sf.n},)"
    bad = np.flatnonzero(~np.isfinite(x))
    if bad.size:
        return f"primal readback x[{bad[0]}] = {x[bad[0]]!r} is not finite"
    big = np.abs(x) >= READBACK_LIMIT
    on_bound = ((x == sf.xl) & (sf.xl > -INF)) | ((x == sf.xu) & (sf.xu < INF))
    bad = np.flatnonzero(big & ~on_bound & ~_logical_columns(sf))
    if bad.size:
        j = int(bad[0])
        return (
            f"readback at sentinel magnitude: x[{j}] = {x[j]:.6g} "
            f"(bounds [{sf.xl[j]:.6g}, {sf.xu[j]:.6g}])"
        )
    for name, d in duals.items():
        if d is None:
            continue
        d = np.asarray(d, dtype=np.float64)
        bad = np.flatnonzero(~np.isfinite(d) | (np.abs(d) >= READBACK_LIMIT))
        if bad.size:
            return f"readback at sentinel magnitude: {name}[{bad[0]}] = {d[bad[0]]!r}"
    return None


def feasibility_problem(x: np.ndarray, sf: StdForm, check_integrality: bool) -> Optional[str]:
    """Why ``x`` is not a feasible point of ``sf``, or ``None``. Call only after
    :func:`readback_problem` passed.

    A row is tested as ``|viol_i| <= FEAS_TOL + FEAS_RTOL * sum_j |A_ij||x_j|`` (the
    ``_matrix_solution_feasible`` convention), except a row touching a value at or
    above ``READBACK_LIMIT`` -- by the readback guard, a declared huge finite bound
    such as the default ``±9.999e19`` box. There ``-9.999e19 + 9.999e19`` cancels to
    exactly 0 and ``1e-9 * 2e20`` forgives any violation under ``2e11``; together they
    certified the infeasible ``x + y >= 2, x + y <= 1`` over free columns as optimal.
    Such a row is checked by :func:`_exact_rows_problem` instead, with the huge values
    left out of its tolerance scale.
    """
    x = np.asarray(x, dtype=np.float64)
    if check_integrality and sf.int_idx.size:
        # #1380: integrality FIRST, then test the rows at the point being
        # CLAIMED -- the integral one. Checking the rows at the fractional point
        # and integrality separately lets a column inside INT_TOL buy ``M *
        # INT_TOL`` of row slack: on ``x <= 1e7 z`` a binary read back at 1e-6
        # carries x all the way to 10 while passing both tests, and the route
        # then reports an objective below the model's true optimum.
        seg = x[sf.int_idx]
        frac = np.abs(seg - np.round(seg))
        k = int(np.argmax(frac))
        if frac[k] > INT_TOL:
            return f"integer column {int(sf.int_idx[k])} = {seg[k]:.9g} is fractional"
        from discopt.validation.feasibility import snap_integer_columns

        x = snap_integer_columns(x, sf.int_idx)
    ax = np.abs(x)
    huge = ax >= READBACK_LIMIT
    if sf.m:
        abs_a = abs(sf.A)
        viol = np.abs(sf.A @ x - sf.b)
        thr = FEAS_TOL + FEAS_RTOL * (abs_a @ np.where(huge, 0.0, ax))
        exact = (abs_a @ huge.astype(np.float64)) > 0.0
        bad = np.flatnonzero((viol > thr) & ~exact)
        if bad.size:
            i = int(bad[np.argmax(viol[bad] - thr[bad])])
            return f"row {i} violated by {viol[i]:.3g} (tolerance {thr[i]:.3g})"
        if exact.any():
            why = _exact_rows_problem(np.flatnonzero(exact), x, sf, thr)
            if why:
                return why
    thr = FEAS_TOL + FEAS_RTOL * ax
    # Only a declared side is a bound: the 1e20 sentinel is "no bound", and a
    # legitimate logical above it (2e20 for ``z0 + z1`` at the default box) is not
    # a violation of anything.
    lo = np.flatnonzero((sf.xl > -INF) & (x < sf.xl - thr))
    if lo.size:
        j = int(lo[0])
        return f"x[{j}] = {x[j]:.6g} below its lower bound {sf.xl[j]:.6g}"
    hi = np.flatnonzero((sf.xu < INF) & (x > sf.xu + thr))
    if hi.size:
        j = int(hi[0])
        return f"x[{j}] = {x[j]:.6g} above its upper bound {sf.xu[j]:.6g}"
    return None


def _exact_rows_problem(
    rows: np.ndarray, x: np.ndarray, sf: StdForm, thr: np.ndarray
) -> str | None:
    """Check ``rows`` of ``A x = b`` in exact rational arithmetic (doubles are exact
    rationals, so this has no rounding at all).

    In each row one *logical* -- a continuous, zero-cost column appearing in no other
    row -- is not taken at its read-back value, which may be unable to represent
    what the row needs (``9.999e19 + 1``). The value the row requires of it is
    computed exactly and checked against its bounds; since nothing else depends on
    that column, the point is feasible iff that value is. The largest-magnitude
    logical is chosen, as it is the one whose rounding can matter.
    """
    from fractions import Fraction

    csr = sf.A.tocsr()
    logical = _logical_columns(sf)
    for i in rows:
        i = int(i)
        s, e = int(csr.indptr[i]), int(csr.indptr[i + 1])
        cols, vals = csr.indices[s:e], csr.data[s:e]
        cand = [k for k in range(e - s) if logical[cols[k]]]
        k_free = max(cand, key=lambda k: abs(x[cols[k]])) if cand else -1
        r = Fraction(float(sf.b[i]))
        for k in range(e - s):
            if k != k_free:
                r -= Fraction(float(vals[k])) * Fraction(float(x[cols[k]]))
        if k_free < 0:
            if abs(r) > Fraction(float(thr[i])):
                return (
                    f"row {i} violated by {float(abs(r)):.3g} in exact arithmetic "
                    f"(tolerance {thr[i]:.3g})"
                )
            continue
        j = int(cols[k_free])
        need = r / Fraction(float(vals[k_free]))
        lo, hi = float(sf.xl[j]), float(sf.xu[j])
        if lo > -INF and need < Fraction(lo) - Fraction(FEAS_TOL + FEAS_RTOL * abs(lo)):
            return f"row {i} needs logical x[{j}] = {float(need):.6g} below its bound {lo:.6g}"
        if hi < INF and need > Fraction(hi) + Fraction(FEAS_TOL + FEAS_RTOL * abs(hi)):
            return f"row {i} needs logical x[{j}] = {float(need):.6g} above its bound {hi:.6g}"
    return None


def ns_bound(y: np.ndarray, sf: StdForm) -> Optional[float]:
    """Neumaier--Shcherbina safe lower bound on ``min cᵀx`` (plus ``obj_const``) from
    any dual ``y``, computed in Rust. ``None`` means ``-inf``."""
    from discopt._rust import ns_safe_bound_csc_py

    g = ns_safe_bound_csc_py(
        np.ascontiguousarray(y, dtype=np.float64),
        sf.c,
        sf.m,
        sf.n,
        np.ascontiguousarray(sf.A.indptr, dtype=np.int64),
        np.ascontiguousarray(sf.A.indices, dtype=np.int64),
        np.ascontiguousarray(sf.A.data, dtype=np.float64),
        sf.b,
        sf.xl,
        sf.xu,
    )
    return None if g is None else float(g) + sf.obj_const


def scaled_dual_for_open_columns(y: np.ndarray, sf: StdForm) -> Optional[np.ndarray]:
    """A repair of ``y`` whose reduced costs are safely signed on every open
    column, or ``None`` when sign projection plus scaling cannot reach one (#1729).

    Two sign-safe moves: a wrong-signed row multiplier is projected to zero (see
    below), then the result is scaled by the largest ``t in (0, 1]`` that clears
    every open column.

    The NS bound is ``-inf`` as soon as a column open above has a reduced cost
    ``r_j = c_j - (Aᵀy)_j`` that is negative -- by one rounding error is enough, and
    HiGHS's ``kOptimal`` dual routinely carries such errors. On a covering LP with
    no explicit upper bounds every structural column is open above, FBBT cannot
    close them (every row is ``>=`` with nonnegative coefficients), and the
    certificate was lost although the same LP with a redundant ``ub=10`` certified.

    Scaling the dual moves every reduced cost along ``r(t) = c - t Aᵀy``, linearly
    in ``t``, and keeps the sign of every component of ``y`` -- so the implied sign
    of every row multiplier (carried by its logical column's reduced cost
    ``-t (Aᵀy)_j``) is preserved. Each open column then confines ``t`` to a
    half-line; the intersection with ``(0, 1]`` is taken at its top, which costs
    ``(1 - t) bᵀy`` of bound -- one rounding error's worth on the issue's LPs.

    Only a candidate: :func:`ns_bound` computes the bound from ``t * y`` rigorously,
    as it does from any ``y``, so this cannot produce an invalid bound -- at worst a
    weak or ``-inf`` one. The margin keeps ``r_j(t)`` clear of the reduced-cost
    error the safe bound charges, so the candidate is not refused for being exact.
    """
    A = sf.A
    y = np.array(y, dtype=np.float64, copy=True)
    # A row multiplier a rounding error the wrong side of zero shows up on the
    # row's logical column (``c_j = 0``, one nonzero ``a``: ``r_j = -a y_i``), and
    # scaling cannot fix a sign. Project it: ``y_i = 0`` puts ``r_j`` exactly at
    # zero, and moves every other reduced cost by ``|y_i A_ik|`` -- the same
    # rounding-error size, absorbed by the scaling below.
    nnz_col = np.diff(A.indptr)
    for j in np.flatnonzero((nnz_col == 1) & (sf.c == 0.0)):
        hi_open, lo_open = sf.xu[j] >= INF, sf.xl[j] <= -INF
        if hi_open == lo_open:
            continue  # bounded both sides (no condition) or free (needs y_i == 0 anyway)
        k = A.indptr[j]
        i, a = int(A.indices[k]), float(A.data[k])
        r_j = -a * y[i]
        if (hi_open and r_j < 0.0) or (lo_open and r_j > 0.0):
            y[i] = 0.0
    g = np.asarray(A.T @ y, dtype=np.float64)
    absg = np.asarray(abs(A).T @ np.abs(y), dtype=np.float64)
    nnz = np.diff(A.indptr).astype(np.float64)
    eps = np.finfo(np.float64).eps
    margin = 8.0 * (nnz + 2.0) * eps * (absg + np.abs(sf.c))
    open_hi = sf.xu >= INF
    open_lo = sf.xl <= -INF
    if not (open_hi.any() or open_lo.any()):
        return None
    t_lo, t_hi = 0.0, 1.0
    for j in np.flatnonzero(open_hi | open_lo):
        c_j, g_j, m_j = float(sf.c[j]), float(g[j]), float(margin[j])
        if open_hi[j] and open_lo[j]:
            # A free column needs r_j == 0 exactly; scaling cannot arrange that
            # unless both terms already vanish.
            if c_j == 0.0 and g_j == 0.0:
                continue
            return None
        if open_hi[j]:  # need c_j - t g_j >= m_j
            if g_j > 0.0:
                t_hi = min(t_hi, (c_j - m_j) / g_j)
            elif g_j < 0.0:
                t_lo = max(t_lo, (c_j - m_j) / g_j)
            elif c_j < m_j:
                return None
        else:  # open below: need c_j - t g_j <= -m_j
            if g_j > 0.0:
                t_lo = max(t_lo, (c_j + m_j) / g_j)
            elif g_j < 0.0:
                t_hi = min(t_hi, (c_j + m_j) / g_j)
            elif c_j > -m_j:
                return None
    if not (t_hi > 0.0 and t_lo <= t_hi):
        return None
    return min(t_hi, 1.0) * y


def _box_prod(t: np.ndarray, x: np.ndarray) -> np.ndarray:
    """``t * x`` with the convention ``0 * inf = 0``: a coefficient that is exactly zero
    cannot ride an open bound side, and numpy would make that product ``nan``."""
    out = np.zeros_like(t)
    nz = t != 0.0
    out[nz] = t[nz] * x[nz]
    return out


def _farkas_exact(y: np.ndarray, sf: StdForm) -> bool:
    """Decide the Farkas contradiction in exact rational arithmetic.

    Every entry of ``A``, ``b``, the box and ``y`` is a float64 and therefore an exact
    rational, so ``r = Aᵀy``, the box supremum of ``rᵀx`` and ``yᵀb`` are all computed
    here with no rounding at all: the verdict is the mathematical truth for the declared
    standard form, with no tolerance and no error bound to get wrong.

    This exists because the float error bound in :func:`farkas_verified` is a *bound*, not
    the error. On the huge box a column whose true ``r_j`` is exactly ``0`` still carries a
    positive bound, and ``(nnz_j + 2)·eps·Σ|A_ij y_i|`` against a ``9.999e19`` side is
    ~1.8e5 -- enough to swamp any real margin and refuse every genuine huge-box ray, which
    is how the free-column infeasible LPs lose their certificates. Widening the margin to
    rescue them would put roundoff back inside the certificate; deciding exactly keeps both
    the guard and the proofs.

    A column with ``r_j = 0`` contributes nothing whatever its box side, which is the
    ``0 * inf = 0`` convention of :func:`_box_prod` made exact. A nonzero ``r_j`` pointing
    along an open side makes the supremum ``+inf``, which proves nothing.
    """
    indptr, indices, data = sf.A.indptr, sf.A.indices, sf.A.data
    zero = Fraction(0)
    for s in (1, -1):
        ys = [Fraction(float(v)) * s for v in y]
        yb = sum((Fraction(float(sf.b[i])) * ys[i] for i in range(sf.m)), zero)
        sup = zero
        bounded = True
        for j in range(sf.n):
            rj = sum(
                (
                    Fraction(float(data[k])) * ys[indices[k]]
                    for k in range(indptr[j], indptr[j + 1])
                ),
                zero,
            )
            if rj > 0:
                if sf.xu[j] >= INF:
                    bounded = False
                    break
                sup += rj * Fraction(float(sf.xu[j]))
            elif rj < 0:
                if sf.xl[j] <= -INF:
                    bounded = False
                    break
                sup += rj * Fraction(float(sf.xl[j]))
        if bounded and yb > sup:
            return True
    return False


def farkas_verified(y: np.ndarray, sf: StdForm) -> bool:
    """True iff ``y`` (in either orientation) proves ``A x = b, xl <= x <= xu`` empty.

    For every box point ``yᵀA x <= sup_box (Aᵀy)ᵀx``; if that supremum is finite and
    strictly below ``yᵀb``, no box point satisfies the rows.

    ``r = Aᵀy`` is a floating-point column dot, so it is only known to lie in
    ``[r - e, r + e]`` with ``e = (nnz_j + 2)·eps·Σ_i |A_ij y_i|``. The supremum is taken
    over that interval as well as over the box, and ``yᵀb`` is lowered by its own
    summation error, so the contradiction has to survive the arithmetic that produced it.
    The module corrects for the same absorption in :func:`fbbt_box` and ``_on_open_side``.

    Comparing against a *relative* margin of the rounded total instead was unsound:
    roundoff in a column dot enters the supremum at full magnitude while raising the
    margin by only ``RAY_REL`` times itself. Bounding that error by ``|side|`` is not
    enough either -- a truly nonzero ``r_j`` that rounds to exactly ``0`` contributes no
    term *and* no error -- so the whole box is used. A coefficient that may be nonzero on
    an open side makes the supremum infinite and the ray is refused.

    Clearing this bound proves the contradiction, but failing it proves nothing: the bound
    is conservative, and on the huge box it refuses genuine rays whose ``r_j`` is exactly
    ``0`` (see :func:`_farkas_exact`). So a float refusal falls through to the exact
    rational decision rather than being taken as the answer.
    """
    y = np.asarray(y, dtype=np.float64)
    if y.shape != (sf.m,) or not np.all(np.isfinite(y)) or not np.any(y):
        return False
    y = y / np.max(np.abs(y))
    absA = abs(sf.A).tocsc()
    nnz_col = np.diff(absA.indptr)
    lo_x = np.where(sf.xl <= -INF, -np.inf, sf.xl)
    hi_x = np.where(sf.xu >= INF, np.inf, sf.xu)
    for s in (1.0, -1.0):
        ys = s * y
        r = np.asarray(sf.A.T @ ys, dtype=np.float64)
        r_err = (nnz_col + 2) * _EPS * np.asarray(absA.T @ np.abs(ys), dtype=np.float64)
        lo_t, hi_t = r - r_err, r + r_err
        sup_j = np.maximum(
            np.maximum(_box_prod(lo_t, lo_x), _box_prod(lo_t, hi_x)),
            np.maximum(_box_prod(hi_t, lo_x), _box_prod(hi_t, hi_x)),
        )
        if not np.all(np.isfinite(sup_j)):
            continue
        sup = float(np.sum(sup_j))
        sup_err = (sup_j.size + 2) * _EPS * float(np.sum(np.abs(sup_j)))
        yb = float(sf.b @ ys)
        yb_err = (sf.m + 2) * _EPS * float(np.sum(np.abs(sf.b * ys)))
        if np.isfinite(sup) and (yb - yb_err) - (sup + sup_err) > 0.0:
            return True
    return _farkas_exact(y, sf)


def primal_ray_verified(d: np.ndarray, sf: StdForm, *, deadline: Optional[float] = None) -> bool:
    """True iff ``d`` proves a descent direction of the recession cone exists:
    ``A d' = 0``, ``cᵀd' < 0``, and ``d'`` only moves along open bound sides, for an
    exact rational ``d'`` on the support of ``d`` (:func:`_exact_ray`).

    The floating-point screen below is only a filter. Its relative residual test
    ``|A d| <= RAY_REL |A||d|`` cannot see a row whose one coupling to the ray is
    tiny: ``x1 + x2 = 0``, ``x1 + x2 + 1e-12 x3 = 0`` and ``max x3`` accepted
    ``d = (1, -1, 1)`` with residual 1e-12 on the second row and certified
    ``unbounded`` on an LP whose optimum is 0 (#1286). Any nonzero exact residual,
    however small, grows without bound along the ray, so acceptance is decided
    exactly."""
    d = np.asarray(d, dtype=np.float64)
    if d.shape != (sf.n,) or not np.all(np.isfinite(d)) or not np.any(d):
        return False
    d = d / np.max(np.abs(d))
    d = np.where(np.abs(d) <= RAY_CLEAN, 0.0, d)
    if np.any((d > 0.0) & (sf.xu < INF)) or np.any((d < 0.0) & (sf.xl > -INF)):
        return False
    if sf.m:
        res = np.abs(sf.A @ d)
        if np.any(res > RAY_REL * (abs(sf.A) @ np.abs(d)) + RAY_CLEAN):
            return False
    cd = float(sf.c @ d)
    if not cd < -RAY_REL * max(1.0, float(np.abs(sf.c) @ np.abs(d))):
        return False
    return _exact_ray(d, sf, deadline)


def _exact_ray(d: np.ndarray, sf: StdForm, deadline: Optional[float]) -> bool:
    """Whether an exact recession ray with ``cᵀd' < 0`` lives on the support of ``d``.

    Restricted to the support ``S``, ``A_S d'_S = 0`` is solved over the rationals by
    Gauss-Jordan elimination. Each row pivots on its column of largest ``|d_j|``, the
    remaining (free) columns keep their values from ``d``, and the pivot columns are
    solved for. A good float ray changes by its residual only, so its sign pattern
    survives. ``d'`` is accepted only if every nonzero moves along an open side and
    ``cᵀd' < 0`` holds exactly; columns outside ``S`` stay at 0, so rows outside the
    support are satisfied. Refuses (``False``) past ``EXACT_MAX_COLUMNS`` support
    columns, ``EXACT_MAX_WORK`` bit operations or ``deadline``: an undecided ray is
    never a certificate.
    """
    from fractions import Fraction

    support = np.flatnonzero(d)
    if support.size == 0 or support.size > EXACT_MAX_COLUMNS:
        return False
    sub = sf.A[:, support].tocsr()
    sub.eliminate_zeros()
    mag = np.abs(d[support])

    def size(q: Fraction) -> int:
        return int(q.numerator.bit_length() + q.denominator.bit_length())

    pivots: list[tuple[dict, int]] = []
    work = 0
    for i in range(sub.shape[0]):
        lo, hi = sub.indptr[i], sub.indptr[i + 1]
        if lo == hi:
            continue
        if deadline is not None and time.perf_counter() > deadline:
            return False
        row = {int(sub.indices[p]): Fraction(float(sub.data[p])) for p in range(lo, hi)}
        for pv, pc in pivots:
            f = row.get(pc)
            if not f:
                continue
            for k, v in pv.items():
                work += size(f) + size(v)
                nv = row.get(k, Fraction(0)) - f * v
                if nv:
                    row[k] = nv
                else:
                    row.pop(k, None)
            if work > EXACT_MAX_WORK:
                return False
        if not row:
            continue
        pc = max(row, key=lambda k: (mag[k], -k))
        inv = 1 / row[pc]
        row = {k: v * inv for k, v in row.items()}
        for pv, _ in pivots:
            f = pv.get(pc)
            if not f:
                continue
            for k, v in row.items():
                work += size(f) + size(v)
                nv = pv.get(k, Fraction(0)) - f * v
                if nv:
                    pv[k] = nv
                else:
                    pv.pop(k, None)
            if work > EXACT_MAX_WORK:
                return False
        pivots.append((row, pc))
    pivot_cols = {pc for _, pc in pivots}
    dx = [Fraction(float(v)) for v in d[support]]
    for pv, pc in pivots:
        dx[pc] = -sum(
            (v * dx[k] for k, v in pv.items() if k != pc and k not in pivot_cols),
            Fraction(0),
        )
    cd = Fraction(0)
    for k, j in enumerate(support):
        v = dx[k]
        if (v > 0 and sf.xu[j] < INF) or (v < 0 and sf.xl[j] > -INF):
            return False
        if v:
            cd += Fraction(float(sf.c[j])) * v
    return cd < 0


# ─────────────────────────────────────────────────────────────
# Certificate recovery: FBBT box, exact dual correction, phase 1
# ─────────────────────────────────────────────────────────────

#: FBBT sweeps for the certificate box; every sweep keeps a superset of the feasible set.
FBBT_ROUNDS = 20
#: Most columns the exact dual correction zeroes, and most correction rounds. Past
#: either the rational elimination is too slow for a fallback; the bound is then left
#: uncertified (never guessed). Each round is bounded by the column cap and
#: :data:`EXACT_MAX_WORK`, and all rounds together by :data:`EXACT_MAX_TOTAL_WORK`,
#: so the round cap only has to let a correction that CONVERGES finish. #1655's
#: robust-counterpart LP (budget set, Gamma = 1) needed 9-16 rounds -- zeroing one
#: wrong-signed dual column disturbs the next -- and converged to a bound equal to
#: the objective in 0.01 s, where the old cap of 8 left the NS bound 19% below the
#: optimum and the LP uncertified.
EXACT_MAX_COLUMNS = 256
EXACT_MAX_ROUNDS = 64
#: Work cap for one rational elimination, in bit operations (entries updated times the
#: bit length of the operands). Rational elimination can grow its denominators, and a
#: fallback must not hang a solve; a count, not a clock, so whether a bound is certified
#: does not depend on machine speed (#912). Calibrated on dense 60-bit rational systems
#: at 1.0-2.2e8 units/s (n=60: 5.9e8 units, 6.0 s), so the cap is ~1-2 s of elimination.
EXACT_MAX_WORK = 200_000_000
#: #1655: work cap summed over every elimination of one correction (~2-4 s), so the
#: raised round cap cannot multiply the per-elimination worst case.
EXACT_MAX_TOTAL_WORK = 2 * EXACT_MAX_WORK
_EPS = float(np.finfo(np.float64).eps)


def certify_lp_dual(
    y: np.ndarray,
    sf: StdForm,
    obj: float,
    deadline: Optional[float] = None,
    *,
    exact: bool = True,
) -> tuple[Optional[float], str, str]:
    """The NS safe-bound ladder that decides whether an LP point at ``obj`` is
    certified optimal: ``(bound, provenance, why)``.

    ``y`` is a row dual in the HiGHS (minimize) convention for ``sf``; any ``y``
    gives a valid bound, so a wrong one only weakens it. The rungs run in order
    until one closes ``obj - bound <= CERT_ABS + CERT_REL * |obj|``: the declared
    box, the FBBT box, a sign-safe rescaling of ``y`` (#1729), and the exact dual
    correction. ``bound`` is the largest found (``None`` means ``-inf``);
    ``provenance`` names the rung that produced it (``""`` for the first);
    ``why`` is the exact correction's reason for giving up, if it ran and did.

    Shared by the HiGHS LP route and the native LP engines (#1953), so both
    certify a point against the same evidence.

    ``exact=False`` stops before the exact correction, the one rung whose cost is not
    negligible (#2067: a caller certifying every B&B node rations it per solve).
    """
    thr = CERT_ABS + CERT_REL * abs(obj)
    # Every candidate below is a valid lower bound, so the largest one is too.
    ns = ns_bound(y, sf)
    provenance = ""
    why = ""
    if ns is None or obj - ns > thr:
        box = fbbt_box(sf)
        g = ns_bound(y, box)
        if g is not None and (ns is None or g > ns):
            ns, provenance = g, "ns-fbbt-box"
        if ns is None or obj - ns > thr:
            # #1729: a reduced cost a rounding error the wrong side of zero
            # on an open column; a sign-preserving scale of ``y`` fixes it.
            for _sf_try in (sf, box):
                y_s = scaled_dual_for_open_columns(y, _sf_try)
                if y_s is None:
                    continue
                g = ns_bound(y_s, _sf_try)
                if g is not None and (ns is None or g > ns):
                    ns, provenance = g, "ns-scaled-dual"
        if exact and (ns is None or obj - ns > thr):
            g, reason = exact_ns_bound(y, box, deadline=deadline)
            if g is not None and (ns is None or g > ns):
                ns, provenance = g, "ns-exact-dual-correction"
            elif reason:
                why = reason
    return ns, provenance, why


def fbbt_box(sf: StdForm, k: Optional[int] = None, open_limit: float = INF) -> StdForm:
    """``sf`` with the open bound sides of its first ``k`` columns (default: all) replaced
    by finite sides implied by ``A[:, :k] x = b`` and the declared box.

    A side is *open* when its magnitude is at least ``open_limit``. The default is the
    ``1e20`` sentinel, which every certificate caller uses. #1678 passes
    ``READBACK_LIMIT``, so a declared huge finite side such as the default
    ``±9.999e19`` box also counts as open. Such a side is then left out of the
    activity sums, which only loosens them. It is replaced only by a strictly tighter
    derived side.

    With ``k = n`` the box contains ``{A x = b, xl <= x <= xu}``, so an NS bound or a
    Farkas proof over it holds for the declared problem. With ``k < n`` it contains the
    first ``k`` coordinates of every point of ``A[:, :k] x = b`` in the box: the phase-1
    use, where the trailing columns are the row violations.

    A derived side ``(b_i - rest)/a_ij`` is widened outward by a bound on its whole
    floating-point error, ``(nnz_i + 8)·eps·(Σ|terms| + |b_i|)/|a_ij| + 8·eps·|side|``, so
    it holds in exact arithmetic on the data. This matters where a term is huge: ``rest``
    is a row total minus the column's own term, and at ``|term| ~ 1e20`` that cancellation
    alone is off by ~1e4, which a relative widening does not cover.
    """
    kk = sf.n if k is None else int(k)
    A = sf.A[:, :kk].tocoo()
    rows, cols, vals = A.row, A.col, A.data
    if vals.size == 0:
        return sf
    m = sf.m
    lim = float(open_limit)
    lb = np.where(sf.xl[:kk] <= -lim, -np.inf, sf.xl[:kk])
    ub = np.where(sf.xu[:kk] >= lim, np.inf, sf.xu[:kk])
    pos = vals > 0.0
    b_r = sf.b[rows]
    slack_r = (np.bincount(rows, minlength=m)[rows] + 8.0) * _EPS
    absb_r = np.abs(b_r)
    absa = np.abs(vals)

    def rest(use: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        inf = ~np.isfinite(use)
        t = vals * np.where(inf, 0.0, use)
        n_inf = np.bincount(rows, weights=inf.astype(np.float64), minlength=m)
        total = np.bincount(rows, weights=t, minlength=m)
        mag = np.bincount(rows, weights=np.abs(t), minlength=m)
        others_finite = (n_inf[rows] - inf) == 0
        return total[rows] - t, others_finite, mag[rows]

    for _ in range(FBBT_ROUNDS):
        # A term at its minimum uses lb for a positive coefficient, ub for a negative one.
        rmin, fin_min, mag_min = rest(np.where(pos, lb[cols], ub[cols]))
        rmax, fin_max, mag_max = rest(np.where(pos, ub[cols], lb[cols]))
        with np.errstate(over="ignore", divide="ignore", invalid="ignore"):
            from_max = (b_r - rmax) / vals
            from_min = (b_r - rmin) / vals
            err_max = slack_r * (mag_max + absb_r) / absa + 8.0 * _EPS * np.abs(from_max)
            err_min = slack_r * (mag_min + absb_r) / absa + 8.0 * _EPS * np.abs(from_min)
            lo_c = np.where(pos, from_max - err_max, from_min - err_min)
            hi_c = np.where(pos, from_min + err_min, from_max + err_max)
        lo_ok = np.where(pos, fin_max, fin_min) & np.isfinite(lo_c)
        hi_ok = np.where(pos, fin_min, fin_max) & np.isfinite(hi_c)
        cand_lo = np.full(kk, -np.inf)
        np.maximum.at(cand_lo, cols[lo_ok], lo_c[lo_ok])
        cand_hi = np.full(kk, np.inf)
        np.minimum.at(cand_hi, cols[hi_ok], hi_c[hi_ok])
        new_lb = np.maximum(lb, cand_lo)
        new_ub = np.minimum(ub, cand_hi)
        with np.errstate(invalid="ignore"):
            moved = np.isfinite(new_lb) & ~np.isfinite(lb)
            moved |= np.isfinite(new_ub) & ~np.isfinite(ub)
            moved |= new_lb > lb + 1e-9 * (1.0 + np.abs(lb))
            moved |= new_ub < ub - 1e-9 * (1.0 + np.abs(ub))
        lb, ub = new_lb, new_ub
        if not moved.any():
            break
    xl, xu = sf.xl.copy(), sf.xu.copy()
    # A sentinel side takes any finite derived side (the certificate callers' rule); a
    # declared huge finite side only a tighter one.
    xl0, xu0 = sf.xl[:kk], sf.xu[:kk]
    with np.errstate(invalid="ignore"):
        take_l = (xl0 <= -lim) & np.isfinite(lb) & ((xl0 <= -INF) | (lb > xl0))
        take_u = (xu0 >= lim) & np.isfinite(ub) & ((xu0 >= INF) | (ub < xu0))
    xl[:kk] = np.where(take_l, lb, xl0)
    xu[:kk] = np.where(take_u, ub, xu0)
    return dataclasses.replace(sf, xl=xl, xu=xu)


def _exact_reduced_costs(Y: list, sf: StdForm, cols) -> dict:
    from fractions import Fraction

    A = sf.A
    out = {}
    for j in cols:
        j = int(j)
        s = Fraction(float(sf.c[j]))
        for p in range(A.indptr[j], A.indptr[j + 1]):
            yi = Y[A.indices[p]]
            if yi:
                s -= Fraction(float(A.data[p])) * yi
        out[j] = s
    return out


def _on_open_side(r, sf: StdForm, j: int) -> bool:
    """A reduced cost that selects an open or sentinel-scale side.

    On an open side the box term is ``-inf``. On a finite side at ``READBACK_LIMIT`` or
    beyond (the default ``±9.999e19`` box) it is finite but useless: a roundoff reduced
    cost of 1.4e-17 times that side cost 1.9e3 of bound on nlp_cvx_001_010, leaving an
    objective of -2.04 uncertified. Both are corrected to an exact zero.
    """
    return bool((r > 0 and sf.xl[j] <= -READBACK_LIMIT) or (r < 0 and sf.xu[j] >= READBACK_LIMIT))


def _exact_solve(
    M: list, rhs: list, deadline: Optional[float], spent: Optional[list] = None
) -> Optional[list]:
    """``M z = rhs`` over the rationals by Gaussian elimination; ``None`` if singular, past
    ``EXACT_MAX_WORK`` bit operations, or past the caller's ``deadline``. ``spent``, a
    one-element list, accumulates the work across calls and refuses past
    ``EXACT_MAX_TOTAL_WORK`` (#1655).

    Sparse (highs-parity P2.5): rows are ``{column: Fraction}`` maps, each elimination
    step updates only the pivot row's remaining nonzeros, and the pivot in each column is
    the remaining row with the fewest nonzeros (a Markowitz-style choice that limits
    fill). ``M`` here is a block of LP columns with a handful of nonzeros each, and the
    dense form swept every column of every row it updated: on ``perold`` (a 196-column
    correction from the Rust dual) it spent the whole 4e8 ``EXACT_MAX_TOTAL_WORK`` and
    left the LP uncertified, where this form needs 1.9e7. The answer does not depend on
    the elimination order: a nonsingular ``M`` has exactly one rational solution, and
    elimination finds no pivot in some column exactly when ``M`` is singular. So every
    system the dense form solved gets the identical ``z`` (measured: HiGHS's ``perold``
    bounds bit-identical), and only the work counted -- entries actually updated, times
    the operands' bit lengths -- is smaller.
    """
    from fractions import Fraction

    def size(q: Fraction) -> int:
        return int(q.numerator.bit_length() + q.denominator.bit_length())

    n = len(rhs)
    rows: list[dict[int, Fraction]] = []
    colrows: dict[int, set[int]] = {}
    for i in range(n):
        d = {k: v for k, v in enumerate(M[i]) if v != 0}
        for k in d:
            colrows.setdefault(k, set()).add(i)
        if rhs[i] != 0:
            d[n] = rhs[i]  # the right-hand side rides along as column ``n``
        rows.append(d)
    remaining = set(range(n))
    order: list[tuple[int, int]] = []
    work = 0
    for col in range(n):
        if deadline is not None and time.perf_counter() > deadline:
            return None
        cand = [r for r in colrows.get(col, ()) if r in remaining]
        if not cand:
            return None
        piv = min(cand, key=lambda r: (len(rows[r]), r))
        remaining.discard(piv)
        prow = rows[piv]
        p = prow[col]
        tail = {k: v for k, v in prow.items() if k > col}
        row_size = max([size(v) for v in tail.values()] + [size(p)])
        for r in cand:
            if r == piv:
                continue
            rr = rows[r]
            f = rr.pop(col) / p
            colrows[col].discard(r)
            step = len(tail) * (size(f) + row_size)
            work += step
            if work > EXACT_MAX_WORK:
                return None
            if spent is not None:
                spent[0] += step
                if spent[0] > EXACT_MAX_TOTAL_WORK:
                    return None
            for k, v in tail.items():
                nv = rr.get(k, Fraction(0)) - f * v
                if nv == 0:
                    if k in rr:
                        del rr[k]
                        if k < n:
                            colrows[k].discard(r)
                else:
                    if k < n and k not in rr:
                        colrows.setdefault(k, set()).add(r)
                    rr[k] = nv
        order.append((piv, col))
    z = [Fraction(0)] * n
    for piv, col in reversed(order):
        d = rows[piv]
        acc = d.get(n, Fraction(0))
        for k, v in d.items():
            if col < k < n:
                acc -= v * z[k]
        z[col] = acc / d[col]
    return z


def exact_ns_bound(
    y: np.ndarray, sf: StdForm, *, deadline: Optional[float] = None
) -> tuple[Optional[float], str]:
    """A rigorous lower bound on ``min cᵀx + obj_const`` over ``{A x = b, xl <= x <= xu}``
    from a rational correction of ``y``. Returns ``(bound, "")`` or ``(None, reason)``.

    Weak duality holds for every ``y``: the minimum is at least
    ``bᵀy + Σ_j min_{xl_j <= x_j <= xu_j} (c - Aᵀy)_j x_j``. A float ``y`` cannot use it
    when an open-sided column has reduced cost exactly zero in every optimal dual (a
    zero-cost recession direction, measured on 25fv47/e226/scrs8/stair): roundoff puts
    the reduced cost on the open side and the term is ``-inf``. The correction picks, in
    floating point, independent wrong-signed columns ``S`` and pivot rows ``R``, then
    solves ``A_{R,S}ᵀ dy_R = rc_S`` over the rationals so ``rc_S`` becomes exactly zero
    (project-and-shift, Steffy & Wolter), and repeats on the columns that step disturbed.
    The bound is summed exactly and rounded down. The floating-point choices decide only
    whether a bound is found, never whether it is valid.
    """
    from fractions import Fraction

    import scipy.linalg as sla

    y = np.asarray(y, dtype=np.float64)
    if y.shape != (sf.m,) or not np.all(np.isfinite(y)):
        return None, "dual is not a finite vector over the rows"
    Y = [Fraction(float(v)) for v in y]
    open_cols = np.flatnonzero((sf.xl <= -READBACK_LIMIT) | (sf.xu >= READBACK_LIMIT))
    held: list[int] = []
    spent = [0]
    for rnd in range(EXACT_MAX_ROUNDS + 1):
        if deadline is not None and time.perf_counter() > deadline:
            return None, "time limit reached during the exact dual correction"
        rc = _exact_reduced_costs(Y, sf, open_cols)
        wrong = [j for j, r in rc.items() if _on_open_side(r, sf, j)]
        if not wrong:
            break
        if rnd == EXACT_MAX_ROUNDS:
            return None, f"{len(wrong)} reduced costs still select an open side"
        S = sorted(set(held) | set(wrong))
        if len(S) > EXACT_MAX_COLUMNS:
            return None, f"{len(S)} columns need an exact zero reduced cost"
        sub = sf.A[:, S]
        touched = np.unique(sub.indices)
        if touched.size == 0:
            return None, "an open column with a nonzero cost has no rows"
        B = sub[touched].toarray()
        _, R, piv = sla.qr(B, mode="economic", pivoting=True)
        d = np.abs(np.diag(R))
        rank = int(np.count_nonzero(d > 1e-10 * d[0])) if d.size and d[0] > 0.0 else 0
        if rank == 0:
            return None, "the wrong-signed columns have no usable rows"
        indep = [S[i] for i in piv[:rank]]
        P, _, _ = sla.lu(B[:, piv[:rank]])
        prow = touched[np.argmax(P, axis=0)[:rank]]
        block = sf.A[:, indep].tocsr()[prow].toarray()  # rank x rank, block[i, k] = A[prow_i, S_k]
        rcS = _exact_reduced_costs(Y, sf, indep)
        M = [[Fraction(float(block[i, kc])) for i in range(rank)] for kc in range(rank)]
        dy = _exact_solve(M, [rcS[j] for j in indep], deadline, spent)
        if dy is None:
            return None, "pivot block singular in exact arithmetic, or work/time limit reached"
        for i, v in zip(prow, dy):
            Y[int(i)] += v
        held = S

    total = Fraction(float(sf.obj_const))
    for i, v in enumerate(Y):
        if v:
            total += Fraction(float(sf.b[i])) * v
    for j, r in _exact_reduced_costs(Y, sf, range(sf.n)).items():
        if r > 0:
            if sf.xl[j] <= -INF:
                return None, f"column {j} reduced cost selects its open lower side"
            total += r * Fraction(float(sf.xl[j]))
        elif r < 0:
            if sf.xu[j] >= INF:
                return None, f"column {j} reduced cost selects its open upper side"
            total += r * Fraction(float(sf.xu[j]))
    try:
        g = float(total)
    except OverflowError:
        return None, "exact bound is outside the double range"
    if Fraction(g) > total:
        g = float(np.nextafter(g, -np.inf))
    return g, ""


def phase1_infeasibility_proof(
    sf: StdForm, *, time_limit: Optional[float], engine: Optional[str] = None
) -> tuple[bool, str]:
    """Prove ``{A x = b, xl <= x <= xu}`` empty without a Farkas ray.

    The phase-1 LP ``min 1ᵀ(p + q)  s.t.  A x + p - q = b`` over ``x`` in the FBBT box of
    ``A x = b`` and ``p, q >= 0`` has value 0 if the declared LP has a point (that point,
    with ``p = q = 0``, lies in the box). A rigorous lower bound on it above a relative
    margin therefore proves the LP empty. The bound comes from HiGHS's phase-1 dual
    through ``ns_bound``, then ``exact_ns_bound``. Returns ``(True, provenance)`` or
    ``(False, reason)``. ``engine`` picks who solves the phase-1 LP (P1.1,
    :mod:`~discopt.solvers.lp_std_engine`); the proof is the same either way.
    """
    eng = _lp_engine(engine)
    t0 = time.perf_counter()
    m, n = sf.m, sf.n
    if m == 0:
        return False, "no rows"
    eye = sp.identity(m, format="csc")
    work = StdForm.from_arrays(
        np.r_[np.zeros(n), np.ones(2 * m)], sp.hstack([sf.A, eye, -eye], format="csc"), sf.b,
        np.r_[sf.xl, np.zeros(2 * m)], np.r_[sf.xu, np.full(2 * m, INF)],
    )  # fmt: skip
    if time_limit is not None and time_limit <= 0.0:
        return False, "no time left for the phase-1 LP"
    raw = eng.solve(work, time_limit=time_limit, presolve=None, tight_tolerances=True)
    if raw.pass_error:
        return False, f"phase-1 LP: {raw.pass_error}"
    if raw.status != "optimal":
        return False, f"phase-1 LP {raw.name}"
    y = raw.y
    if not np.all(np.isfinite(y)):
        return False, "phase-1 dual is not finite"
    box = fbbt_box(work, n)
    margin = RAY_REL * (1.0 + float(np.abs(sf.b).sum()))
    g = ns_bound(y, box)
    if g is not None and g > margin:
        return True, "phase1-ns-fbbt-box"
    # The caller's own time_limit only; the work is capped by count (EXACT_MAX_WORK).
    deadline = None if time_limit is None else t0 + float(time_limit)
    g2, why = exact_ns_bound(y, box, deadline=deadline)
    if g2 is not None and g2 > margin:
        return True, "phase1-exact-dual-correction"
    best = max((v for v in (g, g2) if v is not None), default=None)
    return False, f"phase-1 bound {best} does not exceed {margin:.3g}{'; ' + why if why else ''}"


def recession_ray(
    sf: StdForm, *, time_limit: Optional[float], engine: Optional[str] = None
) -> Optional[np.ndarray]:
    """A candidate descent ray of ``{A x = b, xl <= x <= xu}``, or ``None``.

    Solves ``min cᵀd  s.t.  A d = 0`` with ``d_j`` in ``[-1, 0]`` on an open lower side,
    ``[0, 1]`` on an open upper side (both for a free column) and fixed at 0 otherwise.
    That LP is bounded and ``d = 0`` is feasible, so its value is at most 0. A negative
    value gives a ray. The caller still checks it with ``primal_ray_verified``, so this
    decides only whether a ray is found, never whether one is accepted.
    """
    eng = _lp_engine(engine)
    if time_limit is not None and time_limit <= 0.0:
        return None
    lo = np.where(sf.xl <= -INF, -1.0, 0.0)
    hi = np.where(sf.xu >= INF, 1.0, 0.0)
    if not np.any(lo) and not np.any(hi):
        return None
    work = StdForm.from_arrays(sf.c, sf.A, np.zeros(sf.m), lo, hi)
    raw = eng.solve(work, time_limit=time_limit, presolve=None, tight_tolerances=False)
    if raw.pass_error or raw.status != "optimal":
        return None
    d = raw.x
    return d if float(sf.c @ d) < 0.0 else None


def _lp_engine(engine: Optional[str]):
    """The raw-LP engine for ``solve_lp_std`` and its helpers (highs-parity P1.1).

    ``None`` reads ``DISCOPT_LP_STD_ENGINE`` (``rust`` unless set). **Default ``rust``
    since 2026-11-07** (highs-parity P6.4, owner: eliminate HiGHS): the R1-LP parity
    gate this waited on passed (P2.6, decision D1). ``=highs`` is the opt-out; any other
    value raises.
    """
    from discopt.solvers.lp_std_engine import get_engine

    if engine is None:
        env = os.environ.get("DISCOPT_LP_STD_ENGINE")
        if env is not None:
            engine = env.strip().lower()
        elif _USER_OPTIONS.get():
            # ``Model.solve(highs_options=...)`` is an explicit request for HiGHS behaviour;
            # running the in-house engine would leave those options silently inert.
            engine = "highs"
        elif _IN_HIGHS_MILP_ROUTE.get():
            # The HiGHS MILP route's own LP checks (the NS-safe root cross-check, the
            # #1509 fixed-integer LP, the #1733 refutations) were calibrated against
            # HiGHS's LP, and the route already requires highspy. With the in-house
            # LP engine they disagreed with HiGHS's MILP and declined certificates the
            # HiGHS LP grants (#2156 tiny-weight ReLU nets: ``feasible`` instead of
            # ``optimal``; #1447's threshold point assigned instead of refused). The
            # P6.4 default applies to the LP seam outside this route.
            engine = "highs"
        else:
            engine = "rust"
    return get_engine(engine)


# ─────────────────────────────────────────────────────────────
# HiGHS plumbing
# ─────────────────────────────────────────────────────────────


def _version_number(h) -> float:
    parts = [int(p) for p in str(h.version()).split(".")[:3]]
    parts += [0] * (3 - len(parts))
    return float(parts[0] * 10000 + parts[1] * 100 + parts[2])


def _set_options(h, highspy, opts: list[tuple[str, Any]]) -> None:
    for key, val in opts:
        st = h.setOptionValue(key, val)
        if st != highspy.HighsStatus.kOk:
            raise RuntimeError(f"HiGHS rejected option {key}={val!r} (status {st})")


def _huge_box(sf: StdForm) -> tuple[np.ndarray, np.ndarray]:
    """Per-side masks of the finite declared bounds at sentinel-adjacent magnitude (the
    default ±9.999e19 box).

    The sides are returned separately because a column can carry one sentinel-magnitude
    side and one ordinary declared side. Folding them into a single column mask and
    re-deriving the side from the sign discards the declared side too: ``lb=-5`` with a
    default ``ub`` opened to ``[-inf, inf]``, and the MILP route answered ``error`` where
    the declared box has an optimum. ``lb=0`` escaped only because ``0 < 0`` is false.
    """
    lo = (np.abs(sf.xl) >= READBACK_LIMIT) & (sf.xl > -INF)
    hi = (np.abs(sf.xu) >= READBACK_LIMIT) & (sf.xu < INF)
    return np.asarray(lo, dtype=bool), np.asarray(hi, dtype=bool)


#: #1295: an entry on a column with an open (or sentinel-magnitude) side that is smaller
#: than this fraction of its row's largest entry puts the model outside the class whose
#: HiGHS MIP certificate this route accepts. The value is HiGHS's default column-scale
#: cap, ``2**-kDefaultAllowedMatrixPow2Scale`` (``HConst.h``), beyond which scaling cannot
#: equilibrate the entry. Measured on 280 generated badly scaled MILPs: all 97 false
#: certificates sit at ratio <= 5.3e-7 (below the cap); the 26 real MILPs in
#: ``ref/HiGHS/check`` plus i1183 all sit at >= 3.4e-5 (above it).
UNSCALABLE_OPEN_RATIO = 2.0**-20


def open_column_coefficient_ratio(sf: StdForm) -> float:
    """Smallest ``|a_ij| / max_k |a_ik|`` over entries on a column with an open side.

    A column is open when either side is infinite or at least ``READBACK_LIMIT``, the
    bounds this route hands HiGHS as infinite. ``1.0`` when no entry qualifies.
    """
    A = sp.csr_matrix(sf.A)  # noqa: N806
    A.eliminate_zeros()
    if A.nnz == 0:
        return 1.0
    absA = abs(A).tocoo()  # noqa: N806
    open_col = (np.abs(sf.xl) >= READBACK_LIMIT) | (np.abs(sf.xu) >= READBACK_LIMIT)
    on_open = open_col[absA.col]
    if not on_open.any():
        return 1.0
    row_max = np.zeros(A.shape[0])
    np.maximum.at(row_max, absA.row, absA.data)
    return float((absA.data[on_open] / row_max[absA.row[on_open]]).min())


#: Safety factor on the round-off bound for a reduced cost, covering error accumulated
#: inside HiGHS's own factorization and refinement rather than just the final dot product.
#: The measured separation makes the exact value immaterial: on 120 well-scaled LPs the
#: worst relative violation is 7.87e-17, and on the #1410 counterexample it is 1.0, so
#: every threshold between 1e-14 and 1e-6 gives byte-identical behaviour. This is a
#: round-off bound, not a tuned tolerance.
_DUAL_CERT_SAFETY = 64.0


def box_dual_violation(
    sf: StdForm, x: np.ndarray, row_dual: np.ndarray, *, problem_scale_floor: bool = False
) -> float:
    """How far HiGHS's returned primal/dual pair is from being a dual-feasible certificate.

    For ``min cᵀx s.t. Ax = b, xl <= x <= xu`` the reduced costs ``d = c - Aᵀy`` must, at
    an optimal basis, satisfy ``d_j >= 0`` where ``x_j`` sits at ``xl_j``, ``d_j <= 0``
    where it sits at ``xu_j``, and ``d_j == 0`` where it is interior. Returned relative to
    each reduced cost's own scale ``|c_j| + (|A|ᵀ|y|)_j``, because ``d_j`` is a *difference*
    and the round-off it can carry is set by the magnitudes cancelling in it, not by
    ``|d_j|`` (the #1392/#1397 yardstick rule: scaling a cancellation residual by the
    result is useless — the scale lives in the inputs).

    A violation far above round-off means the pair HiGHS returned does not certify the LP
    it was handed, which is a statement about HiGHS's arithmetic on *this* matrix and
    therefore about every LP it solves in the tree.

    #1410: measured 7.87e-17 worst over 120 well-scaled LPs, versus 1.0 on the instance
    where the MILP route certified a false optimum (miss 0.0171 on a true optimum of
    -0.01513). Used as a guard signal it caught 8/8 wrong HiGHS simplex optima over 4200
    generated badly scaled LPs at a cost of 11/4192 (0.26%) correct results decertified;
    the pre-existing :data:`UNSCALABLE_OPEN_RATIO` proxy caught the same 8/8 but
    decertified 3197/4192 (76.3%).

    ``problem_scale_floor`` (#2300) floors each column's scale at the LP's own magnitude
    ``S = ‖c‖∞ + ‖A‖∞·‖y‖∞`` instead of at ``tiny``. Without it, a basic single-entry
    ``c_j = 0`` slack whose row dual is round-off (``y_i = 7e-15``) has numerator and
    denominator both ``|a·y_i|`` and reads exactly 1.0 however small ``y_i`` is -- which
    the in-house LP engine's duals hit routinely (HiGHS returns exact zeros there).
    Measured on the #2300 set cover (highspy 1.16.0): Rust pair 1.0 -> 1.05e-15, HiGHS
    pair 5.6e-17 -> 3.2e-17, against a round-off bound of 1.42e-13. The floor also
    UNDERSTATES real violations, so the floored value is reported
    (``milp/root_dual_violation_scaled``) and must never be gated on, nor read as "the
    root pair is fine". The MILP route's gate uses the per-column scale, and its value
    stays ``milp/root_dual_violation``.

    #2309 measured the choice (``scripts/panel_2309_root_dual_gate.py``: 4420 badly
    scaled / well-scaled / knapsack / set-cover MILPs x 5 arms, highspy 1.11.0, 1.15.1
    and 1.16.0 with the root LP on HiGHS and on the in-house engine; truth by exact
    enumeration and rational vertex enumeration). 84 root pairs were wrong against the
    exact LP optimum, every one ABOVE it (the #1410 shape). The per-column gate, with the
    NS-gap fall-through, refused 84/84 and refused one correct pair whose dual could not
    certify it (NS gap 1.0e-5 against a 1.0e-6 yardstick). Gating on the floored value
    let 6 of the 84 through (floored 1.4e-14 / 2.9e-14 against a 4.3e-14 tolerance on
    two LPs wrong by 7.3e-5 / 6.9e-4; ``test_2309_root_dual_gate_choice``). Skipping
    interior single-entry ``c_j = 0`` columns matched the per-column gate on the panel
    but is unsound by construction (same test). Always running the NS gap certified
    exactly what the per-column gate certifies on every arm, at an NS run per solve.
    """
    y = np.asarray(row_dual, dtype=np.float64).ravel()
    xv = np.asarray(x, dtype=np.float64).ravel()
    d = sf.c - np.asarray(sf.A.T @ y).ravel()
    absA = abs(sp.csc_matrix(sf.A))  # noqa: N806
    floor = float(np.finfo(float).tiny)
    if problem_scale_floor:
        a_max = float(absA.max()) if absA.nnz else 0.0
        c_max = float(np.abs(sf.c).max()) if sf.c.size else 0.0
        y_max = float(np.abs(y).max()) if y.size else 0.0
        floor = max(floor, c_max + a_max * y_max)
    scale = np.maximum(np.abs(sf.c) + np.asarray(absA.T @ np.abs(y)).ravel(), floor)
    # An infinite (or sentinel-magnitude) side is not a bound a column can sit at, and
    # forming the test band against it yields ``inf - inf`` -> NaN, which would make every
    # comparison below false and silently empty the check. Slack columns all carry
    # ``xu = INF``, so this is the common case, not an edge one.
    fin_lo = sf.xl > -INF
    fin_hi = sf.xu < INF
    lo = np.where(fin_lo, sf.xl, 0.0)
    hi = np.where(fin_hi, sf.xu, 0.0)
    at_lo = fin_lo & (xv <= lo + 1e-9 * (1.0 + np.abs(lo)))
    at_hi = fin_hi & (xv >= hi - 1e-9 * (1.0 + np.abs(hi)))
    # A fixed column (xl == xu) is at both bounds at once and prices either way, so it
    # constrains nothing; an interior column must price to zero.
    lo_only = at_lo & ~at_hi
    hi_only = at_hi & ~at_lo
    v = np.zeros_like(d)
    v[lo_only] = np.maximum(0.0, -d[lo_only])
    v[hi_only] = np.maximum(0.0, d[hi_only])
    interior = ~at_lo & ~at_hi
    v[interior] = np.abs(d[interior])
    return float((v / scale).max()) if v.size else 0.0


def root_pair_ns_gap(sf: StdForm, x: np.ndarray, row_dual: np.ndarray) -> Optional[float]:
    """Rigorous duality gap of HiGHS's own root primal/dual pair, in objective units.

    ``cᵀx + obj_const - NS(ŷ)`` where ``NS`` is the Neumaier--Shcherbina safe bound over
    the DECLARED box (no FBBT box, no exact dual correction: the question is whether
    HiGHS's arithmetic certifies the LP, not whether a certificate can be built some
    other way) and ``ŷ`` is HiGHS's row dual with one sign repair: on a column with a
    single entry ``a_ij`` whose reduced cost points at an infinite side (``d_j < 0`` with
    ``xu_j = inf``, or ``d_j > 0`` with ``xl_j = -inf``) -- a slack whose row dual came
    back with the wrong sign at round-off level -- ``ŷ_i`` is set to ``c_j / a_ij``, which
    makes that reduced cost exactly zero. ``NS`` is a valid lower bound for ANY dual, so
    the repair cannot make the bound wrong; it only moves the round-off from a column NS
    cannot charge (infinite box) onto columns it can, where it is charged in full.

    The gap is ``>= 0`` up to NS's outward rounding whenever ``x`` is feasible, and it
    bounds how far ``x`` can be from the LP optimum. ``None`` means the NS bound is
    ``-inf`` (a violated reduced cost on an open side the repair cannot reach).

    #1612: this is the scale-aware form of the #1410 check. A per-column relative
    violation divides by ``|c_j| + (|A|ᵀ|y|)_j``, which collapses to round-off itself on a
    slack whose row dual is round-off zero (``c_j = 0``, ``y_i = 1e-14``) and reports a
    "violation" of 1.0 on a perfectly solved set-cover LP. Measured: the gap here is
    ``6.5e-11`` on that LP and ``2.1e-12`` on the knapsack whose 6.8e-14 violation also
    tripped the check, against ``0.0221`` on the #1410 matrix, whose LP HiGHS mis-solved.
    """
    xv = np.asarray(x, dtype=np.float64).ravel()
    y = np.array(row_dual, dtype=np.float64).ravel()
    A = sp.csc_matrix(sf.A)  # noqa: N806
    A.eliminate_zeros()
    nnz = np.diff(A.indptr)
    for j in np.flatnonzero(nnz == 1):
        k = A.indptr[j]
        i, a = int(A.indices[k]), float(A.data[k])
        d = float(sf.c[j]) - a * y[i]
        if (sf.xu[j] >= INF and d < 0.0) or (sf.xl[j] <= -INF and d > 0.0):
            y[i] = float(sf.c[j]) / a
    ns = ns_bound(y, sf)
    if ns is None:
        return None
    return float(sf.c @ xv) + sf.obj_const - ns


def dual_violation_tolerance(sf: StdForm) -> float:
    """Round-off bound on :func:`box_dual_violation` for ``sf``.

    ``d_j`` sums ``nnz_j + 1`` terms, so its error is bounded by ``(nnz_j + 1) * u`` times
    its own scale; the widest column sets the bound for the whole vector.
    """
    A = sp.csc_matrix(sf.A)  # noqa: N806
    max_col_nnz = int(np.diff(A.indptr).max()) if A.shape[1] else 0
    return _DUAL_CERT_SAFETY * (max_col_nnz + 1) * float(np.finfo(float).eps)


def _relax_huge_box(sf: StdForm, huge_lo: np.ndarray, huge_hi: np.ndarray) -> StdForm:
    """``sf`` with the huge finite bounds opened to infinity, one side at a time: a
    relaxation of ``sf`` that keeps every ordinary declared bound."""
    return dataclasses.replace(
        sf,
        xl=np.where(huge_lo, -INF, sf.xl),
        xu=np.where(huge_hi, INF, sf.xu),
    )


def _absorb_tiny_entries(sf: StdForm) -> tuple[StdForm, np.ndarray, np.ndarray, int]:
    """Remove every ``|a_ij| <= SMALL_MATRIX_VALUE`` entry HiGHS would drop, soundly (#1617).

    HiGHS drops such an entry on ``passModel`` and answers ``kWarning``; the model it
    then solves is a *perturbation* of ``sf``, so neither its infeasible label nor its
    tree bound would be valid for ``sf``. Instead each dropped term ``a_ij x_j`` is
    replaced by its interval over the declared column box ``[xl_j, xu_j]``: row ``i``
    becomes the ranged row ``b_i - hi_i <= sum_{kept} a_ik x_k <= b_i - lo_i``. Every
    feasible point of ``sf`` satisfies the ranged rows, so the passed model is a
    *relaxation* of ``sf``: an infeasible label and a dual bound for it hold for ``sf``,
    and every incumbent is still verified against ``sf`` itself by the caller. A term on
    a column whose side is open (the ``1e20`` sentinel -- tested on the bound, never on
    the product, CLAUDE.md) opens that side of the row.

    Returns ``(sf without those entries, row_lower, row_upper, n_dropped)``.
    """
    A = sf.A.tocsc()
    data = A.data
    tiny = np.abs(data) <= SMALL_MATRIX_VALUE
    n_drop = int(tiny.sum())
    b = np.asarray(sf.b, dtype=np.float64)
    if n_drop == 0:
        return sf, b.copy(), b.copy(), 0
    col_of = np.repeat(np.arange(A.shape[1]), np.diff(A.indptr))
    cols = col_of[tiny]
    rows = A.indices[tiny]
    a = data[tiny]
    xl = np.asarray(sf.xl, dtype=np.float64)[cols]
    xu = np.asarray(sf.xu, dtype=np.float64)[cols]
    lo_open = np.where(a > 0, xl <= -INF, xu >= INF)
    hi_open = np.where(a > 0, xu >= INF, xl <= -INF)
    with np.errstate(invalid="ignore", over="ignore"):
        t_lo = np.where(a > 0, a * xl, a * xu)
        t_hi = np.where(a > 0, a * xu, a * xl)
    t_lo = np.where(lo_open | (a == 0.0), 0.0, t_lo)
    t_hi = np.where(hi_open | (a == 0.0), 0.0, t_hi)
    m = sf.m
    lo_sum = np.bincount(rows, weights=t_lo, minlength=m)
    hi_sum = np.bincount(rows, weights=t_hi, minlength=m)
    lo_inf = np.bincount(rows, weights=(lo_open & (a != 0.0)).astype(np.float64), minlength=m)
    hi_inf = np.bincount(rows, weights=(hi_open & (a != 0.0)).astype(np.float64), minlength=m)
    # Outward: the sums' own rounding error is bounded by n*eps*sum|terms|, and the
    # subtraction from ``b`` adds one more ulp; widen by both, then one ulp more.
    k = np.bincount(rows, minlength=m).astype(np.float64)
    mag = np.bincount(rows, weights=np.abs(t_lo) + np.abs(t_hi), minlength=m)
    err = (k + 4.0) * np.finfo(np.float64).eps * (mag + np.abs(b))
    row_lower = np.nextafter(b - hi_sum - err, -np.inf)
    row_upper = np.nextafter(b - lo_sum + err, np.inf)
    touched = np.bincount(rows, minlength=m) > 0
    row_lower = np.where(touched, row_lower, b)
    row_upper = np.where(touched, row_upper, b)
    row_lower = np.where(hi_inf > 0, -np.inf, row_lower)
    row_upper = np.where(lo_inf > 0, np.inf, row_upper)
    keep = ~tiny
    A2 = sp.csc_matrix((data[keep], (A.indices[keep], col_of[keep])), shape=A.shape)
    return dataclasses.replace(sf, A=A2), row_lower, row_upper, n_drop


def _row_form_enabled() -> bool:
    """``DISCOPT_MILP_ROW_FORM`` (#1733, default ON; ``=0`` hands HiGHS the explicit
    slack columns again).

    Graduated on introduction by the panel recorded in
    ``docs/dev/issue-1733-row-form-panel-2026-10-17.md``; the opt-out keeps the
    slack-column route reachable for A/B measurement.
    """
    return os.environ.get("DISCOPT_MILP_ROW_FORM", "1") != "0"


#: #1733: oldest HiGHS (``_version_number``) the row form is used with. HiGHS 1.10.0 and
#: 1.11.0 return ``kInfeasible`` (presolve on and off) on the row form of the #1229
#: instance, which is feasible -- the slack form solves it. The minimal trigger is eight
#: folded rows, among them a parallel pair and rows over a fixed integer column. 1.12.0,
#: 1.13.0, 1.14.0 and 1.15.1 solve the same row form to its optimum. Older versions keep
#: the slack form.
ROW_FORM_MIN_HIGHS = 11200.0


@dataclass(frozen=True)
class _RowForm:
    """The logical columns :func:`_eliminate_logicals` folded into row bounds."""

    keep: np.ndarray  # mask over ``sf``'s columns that HiGHS still sees
    cols: np.ndarray  # eliminated logical columns
    rows: np.ndarray  # the single row each one sits in
    coef: np.ndarray  # its entry in that row


def _eliminate_logicals(
    sf: StdForm, row_lo: np.ndarray, row_hi: np.ndarray, n_struct: Optional[int]
) -> tuple[StdForm, np.ndarray, np.ndarray, Optional[_RowForm]]:
    """Fold the route's logical (slack) columns into ranged rows for HiGHS (#1733).

    HiGHS's MIP solver was measured unreliable on the explicit slack form this route
    builds: on #1733's epsilon-constraint facility-location family (an ``em <= e* +
    1e-6`` row over binaries), 25 of 100 instances came back wrong with presolve on
    and 8 of 100 with it off -- false ``kInfeasible`` labels and ``kOptimal`` at a
    point above the optimum, which a user warm start then turned into a certified
    false bound. The same models passed with the slack as row bounds were solved
    correctly in all 600 runs (three right-hand-side shifts, both presolve settings).

    The elimination is exact, not a relaxation: a logical ``s_j`` (continuous, zero
    cost, one row, :func:`_logical_columns`) with ``a s_j + r_i(x) in [lo_i, hi_i]``
    and ``s_j in [l_j, u_j]`` exists iff ``r_i(x) in [lo_i - max(a l, a u), hi_i -
    min(a l, a u)]``. Those ends are rounded outward whenever the subtracted term is
    nonzero, so the passed model stays a relaxation of ``sf`` in floating point too.
    A side of ``s_j`` at the ``INF`` sentinel opens the matching row end. Columns
    before ``n_struct`` are the model's own and are never eliminated, and a row with
    more than one candidate keeps them all. :func:`_lift_logicals` rebuilds the
    eliminated values from the rows, and every point is still verified against ``sf``.
    """
    lg = _logical_columns(sf)
    if n_struct is not None:
        lg[: int(n_struct)] = False
    cols = np.flatnonzero(lg)
    if cols.size == 0:
        return sf, row_lo, row_hi, None
    A = sf.A
    rows = A.indices[A.indptr[cols]]
    # Only a row's SOLE candidate is folded: with two, neither value is determined by
    # the row alone, and picking one is arbitrary -- picking a model column over the
    # slack left the slack free and put the model column at the 1e20 sentinel.
    sole = np.bincount(rows, minlength=sf.m)[rows] == 1
    cols, rows = cols[sole], rows[sole]
    if cols.size == 0:
        return sf, row_lo, row_hi, None
    coef = A.data[A.indptr[cols]]
    xl, xu = sf.xl[cols], sf.xu[cols]
    # Openness is read off the BOUND, never the product: the sentinel is the finite
    # 1e20, and ``0.5 * 1e20`` would pass as a finite (binding) row end (CLAUDE.md).
    l_open, u_open = xl <= -INF, xu >= INF
    pos = coef > 0
    with np.errstate(invalid="ignore", over="ignore"):
        t_lo = np.where(pos, coef * xl, coef * xu)
        t_hi = np.where(pos, coef * xu, coef * xl)
    lo_open = np.where(pos, l_open, u_open)  # t_lo is -inf
    hi_open = np.where(pos, u_open, l_open)  # t_hi is +inf
    lo = np.array(row_lo, dtype=np.float64, copy=True)
    hi = np.array(row_hi, dtype=np.float64, copy=True)
    with np.errstate(invalid="ignore"):
        new_lo = lo[rows] - np.where(hi_open, 0.0, t_hi)
        new_hi = hi[rows] - np.where(lo_open, 0.0, t_lo)
    new_lo = np.where(t_hi == 0.0, new_lo, np.nextafter(new_lo, -np.inf))
    new_hi = np.where(t_lo == 0.0, new_hi, np.nextafter(new_hi, np.inf))
    lo[rows] = np.where(hi_open, -np.inf, new_lo)
    hi[rows] = np.where(lo_open, np.inf, new_hi)
    keep = np.ones(sf.n, dtype=bool)
    keep[cols] = False
    new_idx = np.cumsum(keep) - 1
    reduced = dataclasses.replace(
        sf,
        c=sf.c[keep],
        A=sp.csc_matrix(sf.A[:, keep]),
        xl=sf.xl[keep],
        xu=sf.xu[keep],
        int_idx=new_idx[sf.int_idx],
    )
    return reduced, lo, hi, _RowForm(keep, cols, rows, coef)


def _lift_logicals(x_kept: np.ndarray, sf: StdForm, rf: _RowForm) -> np.ndarray:
    """The full point of ``sf`` from a :func:`_eliminate_logicals` solution: each
    eliminated logical takes the value its row determines, clipped to its box, so
    any residual HiGHS left lands on the row, where :func:`feasibility_problem`
    judges it on the row's own scale."""
    x = np.zeros(sf.n, dtype=np.float64)
    x[rf.keep] = np.asarray(x_kept, dtype=np.float64)
    r = sf.A @ x
    s = (sf.b[rf.rows] - r[rf.rows]) / rf.coef
    x[rf.cols] = np.clip(s, sf.xl[rf.cols], sf.xu[rf.cols])
    return x


def _pass_model(
    h,
    highspy,
    sf: StdForm,
    integer: bool,
    offset: float = 0.0,
    row_bounds: Optional[tuple[np.ndarray, np.ndarray]] = None,
) -> tuple[Any, str]:
    """Hand ``sf`` to HiGHS; returns ``(passModel status, reason)``, ``reason`` empty on kOk.

    kWarning means HiGHS changed the model on the way in -- it drops every matrix entry
    with ``|a| <= small_matrix_value`` -- so the caller decides whether its certificates
    survive that. kError means HiGHS holds no model. Neither is raised: both are
    properties of the input, not defects, and the route reports them as ``error``.

    ``offset`` is HiGHS's objective constant. Every HiGHS objective value and bound
    then includes it (``objective_function_value`` and ``mip_dual_bound`` both do,
    measured), so a caller that passes ``sf.obj_const`` must not add it again. The
    MILP route passes it because ``mip_rel_gap`` is measured on HiGHS's objective:
    with a constant-free one, a change of variables ``x = y - 1e6`` makes ``c . y``
    ~1e6 at every feasible point and HiGHS stops on a gap that is 3.6e-5 of that
    but 35 units of the objective discopt publishes (#1536). The LP callers keep
    the default -- they read no HiGHS objective value.
    """
    from discopt.solvers.milp_highs import _to_highs_inf

    if sf.A.nnz >= 2**31 or sf.n >= 2**31:
        raise ValueError(f"model too large for HiGHS 32-bit indices (nnz={sf.A.nnz})")
    lp = highspy.HighsLp()
    lp.num_col_ = sf.n
    lp.num_row_ = sf.m
    lp.col_cost_ = sf.c
    lp.col_lower_ = _to_highs_inf(sf.xl, highspy)
    lp.col_upper_ = _to_highs_inf(sf.xu, highspy)
    if row_bounds is None:
        lp.row_lower_ = sf.b
        lp.row_upper_ = sf.b
    else:
        # ``_absorb_tiny_entries``'s ranged rows; ``±inf`` is HiGHS's own infinity.
        lp.row_lower_ = np.where(np.isinf(row_bounds[0]), -highspy.kHighsInf, row_bounds[0])
        lp.row_upper_ = np.where(np.isinf(row_bounds[1]), highspy.kHighsInf, row_bounds[1])
    lp.offset_ = float(offset)
    lp.sense_ = highspy.ObjSense.kMinimize
    lp.a_matrix_.format_ = highspy.MatrixFormat.kColwise
    lp.a_matrix_.num_col_ = sf.n
    lp.a_matrix_.num_row_ = sf.m
    lp.a_matrix_.start_ = sf.A.indptr.astype(np.int32)
    lp.a_matrix_.index_ = sf.A.indices.astype(np.int32)
    lp.a_matrix_.value_ = sf.A.data
    if integer and sf.int_idx.size:
        kinds = [highspy.HighsVarType.kContinuous] * sf.n
        for j in sf.int_idx:
            kinds[int(j)] = highspy.HighsVarType.kInteger
        lp.integrality_ = kinds
    st = h.passModel(lp)
    if st == highspy.HighsStatus.kWarning:
        # HiGHS's default 1e-9 dropped a coefficient (``1e-9 x >= 1e-9`` lost its only
        # entry); re-pass at the smallest value it accepts. Only then: the option also
        # moves HiGHS's internal numerics, and set on every model it turned netlib
        # klein1 from a proved infeasible into kUnknown.
        _set_options(h, highspy, [("small_matrix_value", SMALL_MATRIX_VALUE)])
        st = h.passModel(lp)
    if st == highspy.HighsStatus.kOk:
        return st, ""
    a = np.abs(sf.A.data)
    reason = (
        f"HiGHS passModel {str(st).rsplit('.', 1)[-1]}: {int((a <= SMALL_MATRIX_VALUE).sum())} "
        f"|a_ij| <= {SMALL_MATRIX_VALUE:g} dropped, {int((a >= 1e15).sum())} |a_ij| >= 1e15, "
        f"{int((np.abs(sf.b) >= INF).sum())} row right-hand sides at the 1e20 infinity sentinel"
    )
    return st, reason


def _status_name(h) -> str:
    return str(h.getModelStatus()).rsplit(".", 1)[-1]


def _ray(getter) -> Optional[np.ndarray]:
    out = getter()
    if not (isinstance(out, tuple) and len(out) == 3):
        raise RuntimeError(f"unexpected highspy ray API result {type(out)!r}")
    _st, has, vals = out
    return np.asarray(vals, dtype=np.float64) if has else None


#: HiGHS options ``Model.solve(highs_options=...)`` may set (#1620). An allowlist,
#: not a denylist: HiGHS has hundreds of options, and one this route does not know
#: about (``solver="pdlp"``, ``solve_relaxation``, ``user_objective_scale``,
#: ``write_*_to_file``, a new release's additions) must be refused here rather than
#: trusted to be caught by a downstream certificate check. Every entry changes only
#: logging or the *search* -- never a tolerance, a limit, a gap, the problem HiGHS
#: solves, or the process-wide thread scheduler (see :func:`_new_highs`) -- so the
#: route's certificate means the same thing whatever value is passed. Extending it
#: is a review decision: add the option with that argument.
ALLOWED_USER_OPTIONS: frozenset[str] = frozenset(
    {
        # logging
        "output_flag",
        "log_to_console",
        "log_file",
        "log_dev_level",
        "mip_report_level",
        # search strategy
        "presolve",
        "mip_detect_symmetry",
        "mip_allow_restart",
        "mip_heuristic_effort",
        "mip_heuristic_run_rins",
        "mip_heuristic_run_rens",
        "mip_heuristic_run_root_reduced_cost",
        "mip_heuristic_run_zi_round",
        "mip_heuristic_run_shifting",
        "mip_lp_age_limit",
        "mip_pool_age_limit",
        "mip_pool_soft_limit",
        "mip_pscost_minreliable",
        "simplex_scale_strategy",
        "simplex_dual_edge_weight_strategy",
        "simplex_primal_edge_weight_strategy",
        "simplex_price_strategy",
    }
)

#: Why the options a user is most likely to reach for are refused; anything else
#: outside :data:`ALLOWED_USER_OPTIONS` gets the generic message.
RESERVED_USER_OPTIONS: dict[str, str] = {
    "mip_rel_gap": "use Model.solve(gap_tolerance=...)",
    "mip_abs_gap": "use Model.solve(abs_gap_tolerance=...)",
    "mip_max_nodes": "use Model.solve(max_nodes=...)",
    "time_limit": "use Model.solve(time_limit=...)",
    "presolve_rule_off": "the route pins it (#1634: an unsound presolve rule is disabled)",
    "run_crossover": "the route's dual certificates need a crossover basis",
    "small_matrix_value": "the route sets it to pass its standard form exactly",
    "threads": "HiGHS's scheduler is process-wide; a nonzero value breaks later solves",
    "random_seed": "the route pins it for reproducible certificates",
}

_USER_OPTIONS: contextvars.ContextVar[tuple[tuple[str, Any], ...]] = contextvars.ContextVar(
    "discopt_highs_user_options", default=()
)

#: Set while :func:`solve_milp_std` (the HiGHS MILP route) runs; see :func:`_lp_engine`.
_IN_HIGHS_MILP_ROUTE: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "discopt_in_highs_milp_route", default=False
)


def validate_user_options(options: Mapping[str, Any]) -> tuple[tuple[str, Any], ...]:
    """Check ``Model.solve(highs_options=...)`` and return it as ``(key, value)`` pairs.

    Raises ``TypeError`` for a non-mapping or a non-string key and ``ValueError``
    for any option not in :data:`ALLOWED_USER_OPTIONS` (with the reason from
    :data:`RESERVED_USER_OPTIONS` when there is a specific one). A bad *value* for
    an allowed option raises later, from :func:`_set_options`, when the route
    builds its HiGHS instance.
    """
    if not isinstance(options, Mapping):
        raise TypeError(
            "highs_options must be a dict of HiGHS option name -> value, got "
            f"{type(options).__name__}"
        )
    pairs = []
    for key, val in options.items():
        if not isinstance(key, str):
            raise TypeError(f"highs_options keys must be HiGHS option names, got {key!r}")
        if key not in ALLOWED_USER_OPTIONS:
            why = RESERVED_USER_OPTIONS.get(
                key,
                "only logging and search-strategy options are passed through "
                f"(allowed: {', '.join(sorted(ALLOWED_USER_OPTIONS))})",
            )
            raise ValueError(f"highs_options[{key!r}] cannot be set: {why} (#1620)")
        pairs.append((key, val))
    return tuple(pairs)


@contextlib.contextmanager
def user_options(pairs: tuple[tuple[str, Any], ...]) -> Iterator[None]:
    """Apply validated user HiGHS options to every HiGHS instance built in the scope.

    They are set after the route's base options (so ``output_flag=True`` turns the
    HiGHS log on) and before each solve's own options, so a route option -- e.g. the
    #1634 cross-check's ``presolve="off"`` -- always wins over a user one.
    """
    token = _USER_OPTIONS.set(tuple(pairs))
    try:
        yield
    finally:
        _USER_OPTIONS.reset(token)


def _new_highs(highspy, opts: list[tuple[str, Any]]):
    h = highspy.Highs()
    # ``threads`` stays at HiGHS's default (0). HiGHS keeps one process-wide scheduler,
    # sized by the first run in the process, and refuses any later run whose nonzero
    # ``threads`` differs from that size (``run()`` -> kError). The OA/GDP paths and user
    # code run highspy with default options, so pinning a value here made every later
    # LP/MILP solve in the same process return ``error``.
    _set_options(h, highspy, [("output_flag", False), ("random_seed", 0)])
    # #1620: ``Model.solve(highs_options=...)``, checked by validate_user_options.
    _set_options(h, highspy, list(_USER_OPTIONS.get()))
    _set_options(h, highspy, opts)
    return h


# ─────────────────────────────────────────────────────────────
# LP
# ─────────────────────────────────────────────────────────────


def solve_lp_std(
    sf: StdForm, *, time_limit: Optional[float] = None, engine: Optional[str] = None
) -> HighsOutcome:
    """Solve the continuous relaxation of ``sf`` under the §3.1 contract.

    ``engine`` (``rust``, the default, or ``highs``; ``None`` reads
    ``DISCOPT_LP_STD_ENGINE``, ``rust`` unless set) picks who produces the raw answer (P1.1,
    :mod:`~discopt.solvers.lp_std_engine`). Every certificate below is the same for both:
    it reads ``sf`` and the returned vectors only.
    """
    eng = _lp_engine(engine)
    t0 = time.perf_counter()
    sf = sf.relaxed() if sf.int_idx.size else sf
    stats: dict[str, float] = (
        {"route/lp_milp_backend": 1.0} if eng.name == "highs" else {"lp/std_engine_rust": 1.0}
    )

    def remaining() -> Optional[float]:
        return None if time_limit is None else float(time_limit) - (time.perf_counter() - t0)

    def done(out: HighsOutcome) -> HighsOutcome:
        out.wall_time = time.perf_counter() - t0
        out.stats = {**stats, **out.stats}
        return out

    # Declared finite bounds at sentinel-adjacent magnitude (the default ±9.999e19
    # box). HiGHS computes in floating point at that scale and can call an infeasible
    # LP optimal; the exact check refuses the point, and one re-solve with those
    # bounds relaxed to infinity then looks for a Farkas ray. A ray of the relaxed
    # problem also proves the declared problem empty, and it is verified against the
    # declared bounds regardless. Nothing else from that re-solve is used.
    huge_lo, huge_hi = _huge_box(sf)
    # An engine with no presolve gives the same answer twice: start where the
    # presolve-free re-solve would.
    presolve_off = not eng.has_presolve
    relaxed = False
    last_reason = ""
    while True:
        rem = remaining()
        if rem is not None and rem <= 0.0:
            return done(HighsOutcome("time_limit", message="LP time budget exhausted"))
        sf_pass = _relax_huge_box(sf, huge_lo, huge_hi) if relaxed else sf
        raw = eng.solve(
            sf_pass,
            time_limit=rem,
            presolve=False if (presolve_off or relaxed) else None,
            tight_tolerances=True,
        )
        if raw.version is not None:
            stats["highs/version"] = raw.version
        if raw.pass_error:
            return done(HighsOutcome("error", message=raw.pass_error))
        if raw.pass_warning:
            # kWarning: HiGHS solves a perturbed LP. Every certificate below -- the
            # point's feasibility, the NS bound, the Farkas and primal rays -- is
            # re-verified against ``sf`` itself, so a perturbed answer is refused, not
            # trusted.
            stats["lp/highs_pass_warning"] = 1.0
        name = raw.name
        stats["lp/iters"] = stats.get("lp/iters", 0.0) + raw.iters
        if raw.run_error:
            if not presolve_off and not relaxed:
                # #2187: a HiGHS error is not a verdict on the LP. Measured on the
                # fixed-integer LP of a 2-32-32-1 ``relu_bigm`` net with Anderson cuts
                # (matrix entries down to 2e-8, "excessively small column bounds"):
                # the presolved LP solves, postsolve hands dual simplex a start with
                # objective -3.3e15, and HiGHS aborts ("excessive dual values").
                # Without presolve the same LP solves to -38.1894282 in a few
                # iterations. So the one presolve-free re-solve below also covers an
                # error; whatever it returns passes the same checks as any other.
                presolve_off = True
                last_reason = f"HiGHS run() error ({name})"
                stats["lp/presolve_off_error_resolve"] = 1.0
                continue
            return done(
                HighsOutcome("error", message=f"HiGHS run() error ({name})", highs_status=name)
            )

        if relaxed:
            if raw.status == "infeasible":
                y = raw.dual_ray()
                if y is not None and farkas_verified(y, sf):
                    return done(
                        HighsOutcome("infeasible", ray=y, gap_certified=True, highs_status=name)
                    )
            return done(HighsOutcome("error", highs_status=name, message=last_reason))

        if raw.status == "optimal":
            x, y, rc = raw.x, raw.y, raw.rc
            why = readback_problem(x, sf, row_dual=y, col_dual=rc) or feasibility_problem(
                x, sf, check_integrality=False
            )
            if why and (huge_lo.any() or huge_hi.any()):
                relaxed = True
                last_reason = f"HiGHS LP optimal: {why}"
                stats["lp/huge_box_relaxed_resolve"] = 1.0
                continue
            if why:
                return done(
                    HighsOutcome("error", message=f"HiGHS LP optimal: {why}", highs_status=name)
                )
            obj = float(sf.c @ x) + sf.obj_const
            thr = CERT_ABS + CERT_REL * abs(obj)
            out = HighsOutcome(
                "feasible", x=x, objective=obj, row_dual=y, col_dual=rc, highs_status=name
            )
            # The caller's own time_limit only; the work is capped by count.
            deadline = None if time_limit is None else t0 + float(time_limit)
            ns, provenance, why = certify_lp_dual(y, sf, obj, deadline=deadline)
            if why:
                out.message = f"exact dual correction: {why}"
            if provenance:
                out.labels["lp/bound_provenance"] = provenance
                stats["lp/bound_provenance_" + provenance.replace("-", "_")] = 1.0
            if ns is None:
                stats["lp/ns_bound_missing"] = 1.0
                out.message = (
                    "NS safe bound is -inf for the HiGHS dual over the declared box, the FBBT "
                    f"box and after exact dual correction; optimality not certified. {out.message}"
                )
                return done(out)
            gap = obj - ns
            stats["lp/ns_gap"] = float(gap)
            out.bound = min(ns, obj)
            if gap <= thr:
                out.status = "optimal"
                out.gap_certified = True
            else:
                out.message = f"NS safe bound {ns:.12g} is {gap:.3g} below the objective"
            return done(out)

        if raw.status == "infeasible":
            y = raw.dual_ray()
            if y is not None and farkas_verified(y, sf):
                return done(
                    HighsOutcome("infeasible", ray=y, gap_certified=True, highs_status=name)
                )
            if y is not None and farkas_verified(y, fbbt_box(sf)):
                out = HighsOutcome("infeasible", ray=y, gap_certified=True, highs_status=name)
                out.labels["lp/infeasible_provenance"] = "farkas-fbbt-box"
                stats["lp/infeasible_provenance_farkas_fbbt_box"] = 1.0
                return done(out)
            last_reason = "infeasible label without a verifiable Farkas ray"
        elif raw.status == "unbounded":
            d = raw.primal_ray()
            xp: np.ndarray | None = raw.x_primal
            point_ok = xp is not None and not (
                readback_problem(xp, sf) or feasibility_problem(xp, sf, check_integrality=False)
            )
            if point_ok and (d is None or not primal_ray_verified(d, sf)):
                # HiGHS can label an LP unbounded with no ray (measured: ``min x`` over a
                # free column and no rows, highspy 1.12 and 1.15). Look for one directly.
                d = recession_ray(sf, time_limit=remaining(), engine=eng.name)
                if d is not None:
                    stats["lp/recession_ray_lp"] = 1.0
            if d is not None and point_ok and primal_ray_verified(d, sf):
                return done(HighsOutcome("unbounded", x=xp, ray=d, highs_status=name))
            last_reason = "unbounded label without a verified ray and feasible point"
        elif raw.status == "undecided":
            last_reason = f"{eng.name} could not decide between infeasible and unbounded"
        elif raw.status in ("time_limit", "iteration_limit"):
            # #2053: an iteration cap is not a clock. ``highs_status`` kept the
            # truth, but ``status`` is the field callers read.
            return done(HighsOutcome(raw.status, highs_status=name, message=name))
        elif raw.status == "empty" and sf.n == 0 and sf.m == 0:
            # #1385: an LP with no columns and no rows has one feasible point --
            # the empty assignment -- so ``obj_const`` is the optimum and the
            # certificate is exact. This name was not in the dispatch above, so
            # it fell to the catch-all and returned ``error`` with the constant
            # discarded. The shape test is the certificate: we answer only for a
            # model that really is empty, never for a HiGHS status we merely
            # recognise by name.
            return done(
                HighsOutcome(
                    "optimal",
                    x=np.zeros(0, dtype=np.float64),
                    objective=float(sf.obj_const),
                    bound=float(sf.obj_const),
                    gap_certified=True,
                    highs_status=name,
                )
            )
        else:
            return done(HighsOutcome("error", highs_status=name, message=f"HiGHS LP status {name}"))

        if presolve_off:
            if raw.status in ("infeasible", "undecided") and (
                raw.status == "infeasible" or not eng.has_presolve
            ):
                proved, how = phase1_infeasibility_proof(
                    sf, time_limit=remaining(), engine=eng.name
                )
                stats["lp/phase1_proof_ran"] = 1.0
                if proved:
                    out = HighsOutcome("infeasible", gap_certified=True, highs_status=name)
                    out.labels["lp/infeasible_provenance"] = how
                    stats["lp/infeasible_provenance_" + how.replace("-", "_")] = 1.0
                    return done(out)
                last_reason = f"{last_reason}; {how}"
            return done(HighsOutcome("error", highs_status=name, message=last_reason))
        # One re-solve without presolve: rays and the infeasible/unbounded split are
        # only available on the original model, not a presolved reduction of it.
        presolve_off = True
        stats["lp/presolve_off_resolve"] = 1.0


# ─────────────────────────────────────────────────────────────
# MILP
# ─────────────────────────────────────────────────────────────


def complete_seed(sf: StdForm, x_struct: np.ndarray, n_struct: int) -> Optional[np.ndarray]:
    """Extend a structural point with the logical columns it determines, or ``None``.

    Each logical column must appear in exactly one row, and each row may carry at
    most one logical; then ``s = (b_i - a_i·x) / A_ij`` is exact. HiGHS validates the
    completed start itself, and the result is re-verified after the solve anyway, so
    this is a warm-start hint only.
    """
    x_struct = np.asarray(x_struct, dtype=np.float64).ravel()
    if x_struct.shape != (n_struct,) or not np.all(np.isfinite(x_struct)):
        return None
    full = np.zeros(sf.n)
    full[:n_struct] = x_struct
    if sf.n == n_struct:
        return full
    S = sf.A[:, n_struct:]
    if np.any(np.diff(S.indptr) != 1):
        return None
    rows = S.indices
    if np.unique(rows).size != rows.size:
        return None
    resid = sf.b - sf.A[:, :n_struct] @ x_struct
    full[n_struct:] = resid[rows] / S.data
    return full


#: Node cap on the integer-feasibility probe. Soundness-neutral: a probe that hits
#: it returns no point, and the caller then reports ``error`` exactly as before.
_UNBOUNDED_PROBE_MAX_NODES = 10_000


def _integer_feasible_point(sf: "StdForm", budget, stats: dict):
    """An integer-feasible point of ``sf``, or ``None``. Never raises.

    The witness Meyer's theorem needs to turn "the relaxation has an improving
    recession ray" into "the MILP is unbounded". HiGHS supplies one whenever it
    finds an incumbent, but on a ``kUnbounded`` exit it returns none -- it stopped
    because the objective ran away, not because the system is empty -- so the
    point has to be asked for separately.

    Asking is the same move #1337 makes for ``kInfeasible``: drop the objective,
    keep the rows, the box and the integrality, and solve for feasibility alone.
    The result is a verified incumbent of the same standard form, so it is the
    same kind of evidence an ordinary incumbent would have been.

    The probe keeps its own ``root_check``: without it a ``kInfeasible`` exit would
    come back ``gap_certified`` with no cross-check at all, which is exactly the
    unchecked label #1295/#1320 exist to refuse -- and this function would then
    hand it on as a proof of emptiness.

    Sets ``milp/unbounded_feasibility_probe_infeasible`` when the probe proves the
    integer system EMPTY, which resolves ``kUnboundedOrInfeasible`` the other way.
    A probe that merely runs out of budget or settles nothing sets nothing, and
    the caller reports ``error`` exactly as before.
    """
    if budget is not None and budget <= 0.0:
        return None
    stats["milp/unbounded_feasibility_probe"] = 1.0
    try:
        probe = solve_milp_std(
            dataclasses.replace(sf, c=np.zeros(sf.n, dtype=np.float64), obj_const=0.0),
            time_limit=budget,
            gap_tolerance=1e-4,
            max_nodes=_UNBOUNDED_PROBE_MAX_NODES,
            root_check=True,
        )
    except Exception as exc:  # noqa: BLE001 - the probe may decline; it may not fail a solve
        logger.debug("integer-feasibility probe raised %s: %s", type(exc).__name__, exc)
        return None
    if probe.status == "infeasible" and probe.gap_certified:
        stats["milp/unbounded_feasibility_probe_infeasible"] = 1.0
        return None
    if probe.status in ("optimal", "feasible") and probe.x is not None:
        pt = np.asarray(probe.x, dtype=np.float64)
        # Verified here, not taken on the probe's word: the witness is the whole
        # evidence for an ``unbounded`` certificate, so it is checked against the
        # rows, the box and the integrality of the form actually being decided.
        if _point_is_integer_feasible(sf, pt):
            return pt
        logger.debug("integer-feasibility probe returned a point that fails re-checking")
    return None


def _point_is_integer_feasible(sf: "StdForm", x: np.ndarray, tol: float = 1e-6) -> bool:
    """Whether ``x`` satisfies ``A x = b``, the box, and ``sf``'s integrality."""
    if x.shape != (sf.n,) or not np.all(np.isfinite(x)):
        return False
    resid = np.abs(sf.A @ x - sf.b)
    scale = np.abs(sf.A) @ np.abs(x)
    if np.any(resid > tol * (1.0 + np.abs(sf.b)) + 1e-9 * scale):
        return False
    if np.any(x < sf.xl - tol) or np.any(x > sf.xu + tol):
        return False
    if sf.int_idx.size:
        xi = x[sf.int_idx]
        if np.any(np.abs(xi - np.round(xi)) > INT_TOL):
            return False
    return True


def _verified_mip_point(
    sf: "StdForm", x: Optional[np.ndarray]
) -> Optional[tuple[np.ndarray, float]]:
    """``(point, objective)`` when ``x`` passes the incumbent verifier, else ``None``.

    The same two gates every HiGHS incumbent passes (:func:`readback_problem`, then
    :func:`feasibility_problem` with integrality), and the point is returned at its
    integral realisation -- the one those gates tested (#1380) -- with the objective
    recomputed from it. So a point this returns is evidence of exactly the standing a
    HiGHS incumbent has.
    """
    if x is None:
        return None
    x = np.asarray(x, dtype=np.float64).ravel()
    if readback_problem(x, sf) or feasibility_problem(x, sf, check_integrality=True):
        return None
    from discopt.validation.feasibility import snap_integer_columns

    x = snap_integer_columns(x, sf.int_idx)
    return x, float(sf.c @ x) + sf.obj_const


def _snapped_incumbent(x: np.ndarray, sf: "StdForm", rf: Optional["_RowForm"]) -> np.ndarray:
    """A verified incumbent ``x`` at its integral realisation (#1750).

    ``x`` has passed :func:`feasibility_problem` with integrality, which tested the
    rows at exactly ``snap_integer_columns(x)`` -- so that point is already verified.
    On the row form (``rf``), the logicals were lifted from the unsnapped columns;
    re-lifting them from the snapped ones makes each row hold at its own value, and
    that point replaces the plain snap only when it passes the same gates.
    """
    from discopt.validation.feasibility import snap_integer_columns

    snapped = snap_integer_columns(x, sf.int_idx)
    if rf is None or not sf.int_idx.size:
        return snapped
    relifted = _lift_logicals(snapped[rf.keep], sf, rf)
    if readback_problem(relifted, sf) or feasibility_problem(relifted, sf, check_integrality=True):
        return snapped
    return relifted


def _fixed_integer_lp(sf: "StdForm", x: np.ndarray, time_limit: Optional[float]) -> HighsOutcome:
    """The NS-safe LP of ``sf`` with every integer column fixed at ``round(x_j)``.

    #1509: a HiGHS ``kOptimal`` claims in particular that its incumbent is optimal
    for its OWN integer assignment. That claim is checkable at one LP's cost -- and
    the check does not route through HiGHS's MIP presolve/propagation, which is where
    the #1509 false optimum came from.
    """
    xl = sf.xl.copy()
    xu = sf.xu.copy()
    xi = np.round(np.asarray(x, dtype=np.float64)[sf.int_idx])
    xl[sf.int_idx] = xi
    xu[sf.int_idx] = xi
    return solve_lp_std(dataclasses.replace(sf, xl=xl, xu=xu), time_limit=time_limit)


def _fixed_integer_lp_cannot_refute(
    sf: "StdForm", fx: HighsOutcome, bound: float
) -> Optional[tuple[np.ndarray, float]]:
    """#2183: does the fixed-integer LP ``fx`` prove that no point on its integer
    assignment refutes the MILP ``bound``, without being known optimal?

    The #1509 check asks whether some verified point lies below the reported bound by
    more than the yardstick ``CERT_ABS + CERT_REL*|bound|``. It solves the LP over the
    incumbent's integers to find that assignment's best point. When the LP's NS gap does
    not close, ``solve_lp_std`` returns ``feasible``. The LP optimum is then only known
    to lie in ``[fx.bound, fx.objective]``. ``fx.bound`` is the NS-safe bound, rigorous
    whatever the dual's quality. If ``fx.bound`` already sits within the yardstick of
    ``bound``, every point on this assignment does too, and the question has its answer
    ("none refutes"). That holds whether or not the LP is optimal. This accepts nothing
    the optimal-LP arm would refuse, since its optimum ``v >= fx.bound`` passes the same
    margin test whenever ``fx.bound`` does.

    Measured on GDPlib med_term_purchasing (big-M) with highspy >= 1.13 on Linux: NS
    bound -6797.541 against the MILP bound -6798.199 (minimisation terms). The old arm
    called that "inconclusive" and declined a sound certificate.

    Returns the verified ``(point, objective)`` of ``fx`` when the verdict holds, else
    ``None``: the LP point must also pass the incumbent verifier, and the caller adds
    it as a candidate.
    """
    if fx.status != "feasible" or fx.bound is None or fx.x is None:
        return None
    if not np.isfinite(fx.bound) or not np.isfinite(bound):
        return None
    if bound - float(fx.bound) > CERT_ABS + CERT_REL * abs(bound):
        return None
    return _verified_mip_point(sf, fx.x)


#: #1920: wall-clock cap of the :func:`fix_and_propagate_point` start heuristic, and
#: the share of the solve's time limit it may take when that is smaller. Work is also
#: capped by count (:data:`FIXPROP_ROW_VISITS_PER_NNZ`), so a cap only ever costs a
#: start, never a certificate.
FIXPROP_MAX_SECONDS = 2.0
FIXPROP_BUDGET_FRACTION = 0.05
FIXPROP_ROW_VISITS_PER_NNZ = 50


def _fixprop_seed_enabled() -> bool:
    """``DISCOPT_MILP_FIXPROP_SEED`` (#1920, default ON; ``=0`` starts HiGHS cold when
    the caller gave no warm start).

    Graduated on introduction by the panel recorded in
    ``docs/dev/issue-1920-fixprop-seed-panel.md``; the opt-out keeps the cold start
    reachable for A/B measurement.
    """
    return os.environ.get("DISCOPT_MILP_FIXPROP_SEED", "1") != "0"


def fix_and_propagate_point(
    sf: StdForm, n_struct: int, deadline: Optional[float]
) -> Optional[np.ndarray]:
    """#1920: a candidate start for HiGHS by fix-and-propagate, or ``None``.

    ``deadline`` is a ``time.monotonic`` value. Fix the structural columns in order
    -- each at the midpoint of its domain as propagation has left it (the finite side
    when one side is open, rounded when integer) -- and after each fix propagate the
    rows to a fixpoint with activity-bound (FBBT) reasoning on ``A x = b``. A row whose
    activity cannot meet ``b`` is a dead end and the heuristic gives up; it never
    backtracks. This is the classic fix-and-propagate primal heuristic (as in SCIP),
    and it exists for the class HiGHS's own heuristics miss: measured on a 2-64-64-1
    ``relu_bigm`` network, plain HiGHS (and HiGHS through OMLT's formulation) had no
    incumbent after 52 s; fixing the two inputs lets propagation decide every
    pre-activation, binary and output, and this returned a point in 0.3-0.5 s on all
    six nets tried.

    The result is only a candidate: the caller re-optimises its integers by
    :func:`_fixed_integer_lp` and keeps a point only if it passes the incumbent
    verifier. Propagation here decides nothing a certificate rests on. Open bound sides
    are the ``1e20`` sentinel and are tested on the bound, never on a product with it
    (CLAUDE.md).
    """
    A = sf.A.tocsr()
    At = sf.A.tocsc()
    m = A.shape[0]
    lo = np.asarray(sf.xl, dtype=np.float64).copy()
    hi = np.asarray(sf.xu, dtype=np.float64).copy()
    is_int = np.zeros(sf.n, dtype=bool)
    is_int[sf.int_idx] = True
    budget = [FIXPROP_ROW_VISITS_PER_NNZ * max(1, A.nnz)]

    def open_lo(v: np.ndarray) -> np.ndarray:
        return v <= -INF

    def open_hi(v: np.ndarray) -> np.ndarray:
        return v >= INF

    def propagate(rows: np.ndarray) -> Optional[bool]:
        """``True`` at a fixpoint, ``None`` on a dead end, ``False`` out of budget."""
        queue = list(dict.fromkeys(int(i) for i in rows))
        queued = np.zeros(m, dtype=bool)
        queued[queue] = True
        head = 0
        while head < len(queue):
            i = queue[head]
            head += 1
            queued[i] = False
            budget[0] -= 1
            if budget[0] < 0 or (deadline is not None and time.monotonic() > deadline):
                return False
            s, e = A.indptr[i], A.indptr[i + 1]
            cols, a = A.indices[s:e], A.data[s:e]
            lj, hj = lo[cols], hi[cols]
            pos = a > 0
            # The smallest / largest value of each term a_j x_j over the box; an open
            # side contributes an infinite term, counted rather than summed.
            min_open = np.where(pos, open_lo(lj), open_hi(hj))
            max_open = np.where(pos, open_hi(hj), open_lo(lj))
            tmin = np.where(min_open, 0.0, a * np.where(pos, lj, hj))
            tmax = np.where(max_open, 0.0, a * np.where(pos, hj, lj))
            n_min_open, n_max_open = int(min_open.sum()), int(max_open.sum())
            smin, smax = float(tmin.sum()), float(tmax.sum())
            # The rest of the row without term j; finite only if no OTHER term is open.
            rmin_ok = (n_min_open - min_open) == 0
            rmax_ok = (n_max_open - max_open) == 0
            rmin = smin - tmin
            rmax = smax - tmax
            b = float(sf.b[i])
            with np.errstate(divide="ignore", invalid="ignore"):
                # a_j x_j = b - rest  =>  x_j in [(b - rmax)/a_j, (b - rmin)/a_j] for a_j > 0
                lo_src_ok = np.where(pos, rmax_ok, rmin_ok)
                hi_src_ok = np.where(pos, rmin_ok, rmax_ok)
                new_lo = np.where(lo_src_ok, (b - np.where(pos, rmax, rmin)) / a, -INF)
                new_hi = np.where(hi_src_ok, (b - np.where(pos, rmin, rmax)) / a, INF)
            ints = is_int[cols]
            new_lo = np.where(ints & (new_lo > -INF), np.ceil(new_lo - 1e-6), new_lo)
            new_hi = np.where(ints & (new_hi < INF), np.floor(new_hi + 1e-6), new_hi)
            scale = 1.0 + np.minimum(np.abs(lj), INF) + np.minimum(np.abs(hj), INF)
            up = new_lo > lj + 1e-9 * scale
            down = new_hi < hj - 1e-9 * scale
            if not (up.any() or down.any()):
                continue
            lo[cols[up]] = new_lo[up]
            hi[cols[down]] = new_hi[down]
            touched = cols[up | down]
            gap = lo[touched] - hi[touched]
            if np.any(gap > 1e-7 * (1.0 + np.abs(lo[touched]))):
                return None
            snap = gap > 0  # crossed by round-off only: collapse to the midpoint
            if snap.any():
                mid = 0.5 * (lo[touched[snap]] + hi[touched[snap]])
                lo[touched[snap]] = mid
                hi[touched[snap]] = mid
            for j in touched:
                for r in At.indices[At.indptr[j] : At.indptr[j + 1]]:
                    if not queued[r]:
                        queued[r] = True
                        queue.append(int(r))
        return True

    if propagate(np.arange(m)) is not True:
        return None
    for j in range(int(n_struct)):
        lj, hj = lo[j], hi[j]
        if hj - lj <= 0.0:
            continue
        if lj > -INF and hj < INF:
            v = 0.5 * (lj + hj)
        elif lj > -INF:
            v = lj
        elif hj < INF:
            v = hj
        else:
            v = 0.0
        if is_int[j]:
            v = float(min(max(round(v), lj), hj))
        lo[j] = hi[j] = v
        if propagate(At.indices[At.indptr[j] : At.indptr[j + 1]]) is not True:
            return None
    x = 0.5 * (lo + hi)
    return x if np.all(np.isfinite(x)) else None


def _fixprop_start(
    sf: StdForm, n_struct: int, time_limit: Optional[float], stats: dict[str, float]
) -> Optional[tuple[np.ndarray, float]]:
    """#1920: a VERIFIED start from :func:`fix_and_propagate_point`, or ``None``.

    The candidate's integers are re-optimised by :func:`_fixed_integer_lp` and the
    point is kept only if it passes :func:`_verified_mip_point` -- the standing of any
    HiGHS incumbent. Budget: :data:`FIXPROP_MAX_SECONDS`, or
    :data:`FIXPROP_BUDGET_FRACTION` of ``time_limit`` when smaller.
    """
    # ``monotonic``, as in :func:`solve_milp_std`: this clock only budgets the start
    # and must not shift the route's own ``perf_counter`` deadline reads.
    t0 = time.monotonic()
    cap = FIXPROP_MAX_SECONDS
    if time_limit is not None:
        cap = min(FIXPROP_MAX_SECONDS, FIXPROP_BUDGET_FRACTION * max(0.0, float(time_limit)))
    stats["milp/fixprop_ran"] = 1.0
    x = fix_and_propagate_point(sf, n_struct, t0 + cap)
    pt = None
    if x is not None:
        rem = cap - (time.monotonic() - t0)
        if rem > 0.0:
            fx = _fixed_integer_lp(sf, x, rem)
            pt = _verified_mip_point(sf, fx.x) if fx.status == "optimal" else None
    stats["milp/fixprop_time"] = time.monotonic() - t0
    if pt is not None:
        stats["milp/fixprop_found"] = 1.0
        stats["milp/fixprop_objective"] = float(pt[1])
    return pt


def _rederived_point(
    sf: "StdForm",
    x: Optional[np.ndarray],
    time_limit: Optional[float],
    stats: dict,
    rederived: Optional[list] = None,
    stat_prefix: str = "milp/cross_point",
) -> Optional[tuple[np.ndarray, float]]:
    """A verified point carrying ``x``'s integers, re-derived by the fixed-integer LP.

    #1733: a falsifier's point is evidence against a bound only if it is a point, not
    a tolerance. :func:`feasibility_problem` admits a row violated by ``FEAS_TOL``, the
    same 1e-6 as the refutation yardstick ``CERT_ABS``. So a HiGHS incumbent that
    spends HiGHS's 1e-6 MIP row tolerance on the objective row refutes an exact bound
    by exactly that much. Measured on the #1494 piecewise models: the presolve-free
    cross-solve verified at -1e-6 against an exact optimum of 0 and withdrew a
    correct certificate. :func:`_fixed_integer_lp` re-optimises the continuous part
    over ``x``'s own integers at the LP's 1e-7 primal tolerance. Its verified point is
    the best one those integers admit, and it replaces ``x``'s. When the LP gives no
    verified point, ``x``'s own point is kept, so the falsifier never has less
    evidence than before.

    #2187: ``rederived``, when given, receives the LP point only when the LP produced
    one, so a caller that must not use a raw point (#1678 adoption) can tell the two
    outcomes apart without solving the LP again.

    #2221: the #1509 check's root-LP candidate goes through here too
    (``stat_prefix="milp/root_point"``), for the same reason.
    """
    pt = _verified_mip_point(sf, x)
    if pt is None or not sf.int_idx.size:
        return pt
    if time_limit is not None and time_limit <= 0.0:
        return pt
    fx = _fixed_integer_lp(sf, pt[0], time_limit)
    lp_pt = _verified_mip_point(sf, fx.x) if fx.status == "optimal" else None
    if lp_pt is None:
        stats[f"{stat_prefix}_rederive_failed"] = 1.0
        return pt
    stats[f"{stat_prefix}_rederived_shift"] = float(lp_pt[1] - pt[1])
    if rederived is not None:
        rederived.append(lp_pt)
    return lp_pt


def _repair_refused_incumbent(
    sf: "StdForm",
    x: np.ndarray,
    root: HighsOutcome,
    time_limit: Optional[float],
    stats: dict,
) -> Optional[tuple[np.ndarray, float]]:
    """A verified point carrying the integers of a refused HiGHS incumbent, or ``None``.

    #1654: the LP of ``sf`` with every integer column fixed at ``round(x_j)``
    (:func:`_fixed_integer_lp`), re-verified by :func:`_verified_mip_point`. Only a
    point that passes the same gates as any HiGHS incumbent is returned, so the
    repair can add a feasible point and never an infeasible one. Skipped when the
    root LP already proved the relaxation empty (that branch reports infeasible), or
    when ``x`` is not finite.
    """
    if root.status == "infeasible" or not sf.int_idx.size:
        return None
    x = np.asarray(x, dtype=np.float64).ravel()
    if x.shape != (sf.n,) or not np.all(np.isfinite(x)):
        return None
    if time_limit is not None and time_limit <= 0.0:
        stats["milp/incumbent_repair_skipped"] = 1.0
        return None
    stats["milp/incumbent_repair_ran"] = 1.0
    fx = _fixed_integer_lp(sf, x, time_limit)
    pt = _verified_mip_point(sf, fx.x) if fx.status == "optimal" else None
    if pt is not None:
        stats["milp/incumbent_repaired"] = 1.0
        stats["milp/fixed_int_objective"] = float(pt[1])
    return pt


def logical_column_scales(sf: StdForm, n_struct: Optional[int]) -> Optional[np.ndarray]:
    """Power-of-two factors that equilibrate the route's own logical columns, or ``None``.

    #1537: the standard form ends every inequality row with a unit logical
    ``a x + s = b, s >= 0``. Multiply that row by 1e6 -- the same model -- and the
    logical is 2.5e-7 of its row's largest entry, below :data:`UNSCALABLE_OPEN_RATIO`.
    That is not a false alarm: on the #1295-class panel HiGHS then pruned the true
    optimum on 3/9 such models (caught only by the #1509 refutation), and with the
    logical's coefficient raised to its row's magnitude it certified all of them
    correctly. Before this, ×1e6 rows on clean MILPs withdrew 12/12 correct
    certificates.

    So the logical is rescaled rather than excused: ``s = f s'`` with ``f`` a power of
    two is exact in floating point, changes no other row and (``c_s = 0``) not the
    objective, and puts the column's entry within a factor 2 below its row's largest. Only
    columns at index ``>= n_struct`` (the route's own, never published), with one
    nonzero, zero cost, continuous, and *below* the cap are touched, so a model this
    route certifies today is handed to HiGHS unchanged. A user's own tiny-coefficient
    column is not touched and still decertifies: that class was measured wrong
    (#1295) and is the user's scaling, not the route's.

    #1621: the same holds for a user's tiny entry that shares the logical's row. In a
    big-M row ``x - M z + s = 0`` the logical is small only because ``x`` is: ``x``'s
    own entry sits at ``1/M`` of the row too. Rescaling ``s`` there removes the one
    entry #1295 measures (an open column) and leaves the user's ``1/M`` entry -- the
    actual trap -- in a model now handed to HiGHS as trusted. Measured on the #1621
    blending MILP: certified ``infeasible`` at M = 1e9 and ``optimal`` 0 at M = 1e10
    (true optimum 473,958.43, x = 0 feasible). So a logical is rescaled only when
    every OTHER entry of its row is within the cap of the row's largest -- the row is
    well scaled apart from the route's own column, which is the #1537 premise.
    """
    if n_struct is None or n_struct >= sf.n or sf.A.nnz == 0:
        return None
    A = sp.csc_matrix(sf.A)  # noqa: N806
    absA = abs(A).tocoo()  # noqa: N806
    row_max = np.zeros(sf.m)
    np.maximum.at(row_max, absA.row, absA.data)
    scales = np.ones(sf.n)
    cand = _logical_columns(sf)
    cand[:n_struct] = False
    # Smallest nonzero entry of each row over the columns that are not rescaling
    # candidates (a logical is the only entry of its column, so this is "every other
    # entry of the row" for each candidate).
    keep = ~cand[absA.col] & (absA.data > 0.0)
    row_min_other = np.full(sf.m, np.inf)
    np.minimum.at(row_min_other, absA.row[keep], absA.data[keep])
    lo_open, hi_open = sf.xl <= -INF, sf.xu >= INF
    for j in np.flatnonzero(cand):
        i, a = int(A.indices[A.indptr[j]]), abs(float(A.data[A.indptr[j]]))
        if row_max[i] <= 0.0 or a / row_max[i] >= UNSCALABLE_OPEN_RATIO:
            continue
        if row_min_other[i] / row_max[i] < UNSCALABLE_OPEN_RATIO:
            continue  # #1621: the user's own entry is below the cap; not ours to excuse
        # floor, not round: the rescaled entry lands in (row_max / 2, row_max], so it
        # never becomes its row's new largest and lowers every other entry's ratio.
        f = float(2.0 ** np.floor(np.log2(row_max[i] / a)))
        if f * a > row_max[i]:
            f /= 2.0
        # A finite side must stay an ordinary finite side after ``/ f``; a sentinel
        # side stays the sentinel. Anything else would change what "open" means.
        new_lo, new_hi = sf.xl[j] / f, sf.xu[j] / f
        if not lo_open[j] and (abs(sf.xl[j]) >= READBACK_LIMIT or new_lo * f != sf.xl[j]):
            continue
        if not hi_open[j] and (abs(sf.xu[j]) >= READBACK_LIMIT or new_hi * f != sf.xu[j]):
            continue
        scales[j] = f
    return scales if np.any(scales != 1.0) else None


def _scale_logicals(sf: StdForm, f: np.ndarray) -> StdForm:
    """``sf`` in the variables ``x'_j = x_j / f_j`` (sentinel sides kept)."""
    A = sp.csc_matrix(sf.A) @ sp.diags(f, format="csc")  # noqa: N806
    xl = np.where(sf.xl <= -INF, sf.xl, sf.xl / f)
    xu = np.where(sf.xu >= INF, sf.xu, sf.xu / f)
    return StdForm.from_arrays(sf.c * f, A, sf.b, xl, xu, sf.obj_const, sf.int_idx)


#: #1654: safety factor on the round-off margin of the activity slack ``d`` that
#: coefficient tightening removes. ``d`` is a floating-point sum of the row's terms,
#: whose error is at most ``(k + 2) * eps * sum|terms|`` for ``k`` terms; shrinking ``d``
#: by this factor times that bound only makes the tightening weaker, never invalid
#: (any ``0 <= d' <= d`` is exact). A margin relative to the row scale itself would
#: be set by the big-M being removed: 1e-9 of 1e9 left ``M`` at 11 where 10 is exact.
_COEF_TIGHTEN_SAFETY = 8.0


def fold_fixed_columns(sf: StdForm) -> tuple[Optional[StdForm], int]:
    """``sf`` with every fixed structural column's entries moved into ``b``.

    #2304: a column with ``xl_j == xu_j = v`` takes one value, so ``a_ij x_j`` is the
    constant ``a_ij v`` and ``a x = b`` holds exactly when ``a' x = b - a_ij v`` does,
    ``a'`` being ``a`` with that entry dropped. The column keeps its index, box and
    cost (now with no entries), so a point of either form is a point of the other and
    every feasible point, LP relaxation and bound is the same.

    Why it matters: a binary pinned by a singleton row (``z == 1``, rounded into its
    box by ``_round_single_integer_rows_sparse`` since f83addeba) keeps its big-M
    coefficient, which :func:`coefficient_tightened` does not rewrite (it is not a
    free binary) and which the #1295 guard (:func:`open_column_coefficient_ratio`)
    then reads against the row's logical: ``1/M``, below :data:`UNSCALABLE_OPEN_RATIO`,
    so one such row decertified the model. An entry on a fixed column gives HiGHS no
    scaling freedom to get wrong; folding it removes it from the matrix HiGHS sees,
    so the guard still reads every entry HiGHS is handed.

    Exactness is checked, not assumed: an entry folds only when ``b_i - a_ij v`` is
    exact in floating point (checked in rationals), and a column folds only when ALL
    its entries do, so it is left with no entries rather than one, which would make
    it look like a logical (:func:`_logical_columns`). Logical columns, columns with a
    side at or beyond ``READBACK_LIMIT`` and integer columns at a non-integral value
    are never folded. Returns ``(form, n_entries_folded)``, ``form`` ``None`` when
    nothing folded.
    """
    if sf.A.nnz == 0:
        return None, 0
    logical = _logical_columns(sf)
    is_int = np.zeros(sf.n, dtype=bool)
    is_int[sf.int_idx] = True
    fixed = (
        (sf.xl == sf.xu)
        & (np.abs(sf.xl) < READBACK_LIMIT)
        & ~logical
        & (np.diff(sf.A.indptr) > 0)
        & ~(is_int & (sf.xl != np.round(sf.xl)))
    )
    if not fixed.any():
        return None, 0
    csc = sp.csc_matrix(sf.A, copy=True)
    csc.sort_indices()
    b = sf.b.astype(np.float64, copy=True)
    b_exact: dict[int, Fraction] = {}
    folded = np.zeros(sf.n, dtype=bool)
    n_folded = 0
    for j_np in np.flatnonzero(fixed):
        j = int(j_np)
        lo, hi = int(csc.indptr[j]), int(csc.indptr[j + 1])
        v = Fraction(float(sf.xl[j]))
        trial: dict[int, Fraction] = {}
        for k in range(lo, hi):
            i = int(csc.indices[k])
            cur = trial.get(i, b_exact.get(i, Fraction(float(b[i]))))
            nxt = cur - Fraction(float(csc.data[k])) * v
            if Fraction(float(nxt)) != nxt:
                break  # not representable: leave the whole column in place
            trial[i] = nxt
        else:
            b_exact.update(trial)
            folded[j] = True
            n_folded += hi - lo
    if not n_folded:
        return None, 0
    for i, val in b_exact.items():
        b[i] = float(val)
    keep = np.repeat(~folded, np.diff(csc.indptr))
    csc.data[~keep] = 0.0
    csc.eliminate_zeros()
    return (
        StdForm.from_arrays(sf.c, csc, b, sf.xl, sf.xu, sf.obj_const, sf.int_idx),
        n_folded,
    )


def coefficient_tightened(
    sf: StdForm, *, implied_bounds: bool = False
) -> tuple[Optional[StdForm], int]:
    """``sf`` with every binary's big-M coefficient shrunk to its row's activity bound.

    #1654: the classic MIP coefficient tightening (Savelsbergh 1994; Achterberg 2007
    §10.1). Take a one-sided row ``a x <= U`` -- in this standard form, ``a x + s = b``
    with a single-entry logical ``s`` whose range has one finite side -- and a binary
    ``y`` in it with coefficient ``a_k``. With ``maxact`` the row's maximal activity
    over the declared box of every OTHER column:

    * ``a_k > 0`` and ``d = U - maxact > 0``: the row is slack by ``d`` at ``y = 0``,
      so ``a_k -> a_k - d`` and ``U -> U - d``;
    * ``a_k < 0`` and ``d = U - (maxact + a_k) > 0``: the row is slack by ``d`` at
      ``y = 1``, so ``a_k -> a_k + d``.

    Each rewrite leaves the row's restriction at ``y = 0`` and at ``y = 1`` exactly as
    it was over the box, so the set of INTEGER-feasible points -- and therefore the
    MILP's optimum, every feasible point and every valid bound -- is unchanged; only
    the LP relaxation tightens. On a big-M row ``s_i + p_i <= s_j + M (1 - y)`` over
    ``s in [0, 200]`` it replaces ``M = 1e9`` by ``209``, which removes the trap that
    makes the model unsolvable in floating point: HiGHS accepts ``y`` within 1e-6 of
    integral, and ``1e-6 * 1e9`` is a thousand units of row slack. Any ``d' in [0, d]``
    is also exact, so ``d`` is reduced by a round-off margin before use.

    Only binary columns (integer, box ``[0, 1]``) are rewritten; a row with an
    unbounded or sentinel-magnitude column has no finite activity bound and is left
    alone; ranged and equality rows are left alone. Returns ``(form, n_rewritten)``,
    ``form`` ``None`` when nothing changed.

    ``implied_bounds`` (#1678, ``DISCOPT_MILP_IMPLIED_BOUNDS``) first gives every
    non-logical column with an open side (magnitude ``>= READBACK_LIMIT``, which
    includes the default ``±9.999e19`` box) the finite side implied by the rows,
    using the outward-rounded FBBT of :func:`fbbt_box`. On facility location with
    ``x`` left at the default bound, ``x_ij <= d_j`` follows from the demand equality,
    and the big-M rows become tightenable. The tightened form DECLARES that box
    ``B``. Every feasible point of ``sf`` lies in ``B``, and ``B`` lies inside the
    declared box. Over ``B`` each rewritten row has the same integer restrictions as
    before. So the tightened form has exactly ``sf``'s integer-feasible set. If the
    implied box is empty, nothing is rewritten and the route decides the instance.
    """
    if not sf.int_idx.size or sf.A.nnz == 0:
        return None, 0
    logical = _logical_columns(sf)
    xl, xu = sf.xl, sf.xu
    if implied_bounds:
        ib = fbbt_box(sf, open_limit=READBACK_LIMIT)
        xl = np.where(logical, sf.xl, ib.xl)
        xu = np.where(logical, sf.xu, ib.xu)
        if np.any(xl > xu):
            return None, 0
    is_bin = np.zeros(sf.n, dtype=bool)
    ii = sf.int_idx
    is_bin[ii[(xl[ii] == 0.0) & (xu[ii] == 1.0)]] = True
    if not is_bin.any():
        return None, 0
    csc = sp.csc_matrix(sf.A)
    # row -> its logical column (exactly one per one-sided inequality row)
    row_logical = np.full(sf.m, -1, dtype=np.int64)
    n_log = np.zeros(sf.m, dtype=np.int64)
    for j in np.flatnonzero(logical):
        i = int(csc.indices[csc.indptr[j]])
        row_logical[i] = j
        n_log[i] += 1
    finite_box = (np.abs(xl) < READBACK_LIMIT) & (np.abs(xu) < READBACK_LIMIT)
    A = sp.csr_matrix(sf.A, copy=True)  # noqa: N806
    A.sort_indices()
    b = sf.b.copy()
    n_rewritten = 0
    # The rows the loop can act on -- one logical column and a binary entry -- found in
    # one pass; the loop visits them in the same ascending order the full scan did and
    # skips exactly the rows it skipped. (The full scan cost ~2 s of Python on a 15k-row
    # model, 2026-11-13, before the engine started.)
    has_bin = np.zeros(sf.m, dtype=bool)
    entry_row = np.repeat(np.arange(sf.m), np.diff(A.indptr))
    has_bin[entry_row[is_bin[A.indices]]] = True
    for i_np in np.flatnonzero((n_log == 1) & has_bin):
        i = int(i_np)
        j_s = int(row_logical[i])
        lo, hi = A.indptr[i], A.indptr[i + 1]
        cols = A.indices[lo:hi]
        k_s = lo + int(np.flatnonzero(cols == j_s)[0])
        sig = float(A.data[k_s])
        ends = sorted((sig * sf.xl[j_s], sig * sf.xu[j_s]))
        lo_fin = abs(ends[0]) < READBACK_LIMIT
        hi_fin = abs(ends[1]) < READBACK_LIMIT
        if lo_fin == hi_fin:
            continue  # ranged (or free) row: not a one-sided inequality
        # ``a x = b - sig*s``: ``<= b - min(sig*s)`` when that end is finite, else
        # ``>= b - max(sig*s)``. Work in ``<=`` form; ``sgn`` maps back.
        sgn = 1.0 if lo_fin else -1.0
        U = sgn * (b[i] - (ends[0] if lo_fin else ends[1]))  # noqa: N806
        others = np.flatnonzero(cols != j_s) + lo
        if not np.all(finite_box[A.indices[others]]):
            continue
        # The row's activity terms change only when one of its entries is rewritten:
        # computed once, and again after each rewrite -- the same arrays, hence the same
        # sums, the per-binary recompute produced (that recompute made the row
        # quadratic in its length: ~2 s on reblock420's 15k rows with no rewrite).
        stale = True
        for k_ent in others:
            kq = int(k_ent)
            if not is_bin[int(A.indices[kq])]:
                continue
            if stale:
                g = sgn * A.data[others]
                cj = A.indices[others]
                terms = np.maximum(g * xl[cj], g * xu[cj])
                terms_sum = float(terms.sum())
                terms_abs = float(np.abs(terms).sum())
                stale = False
            gk = sgn * float(A.data[kq])
            maxact_rest = terms_sum - max(gk, 0.0)
            scale = terms_abs + abs(U) + abs(gk)
            margin = _COEF_TIGHTEN_SAFETY * (terms.size + 2) * np.finfo(float).eps * scale
            if gk > 0.0:
                d = U - maxact_rest - margin
                if not 0.0 < d < gk:
                    continue
                gk_new, U = gk - d, U - d  # noqa: N806
                b[i] -= sgn * d
            else:
                d = U - (maxact_rest + gk) - margin
                if not 0.0 < d < -gk:
                    continue
                gk_new = gk + d
            A.data[kq] = sgn * gk_new
            stale = True
            n_rewritten += 1
    if not n_rewritten:
        return None, 0
    return (
        StdForm.from_arrays(sf.c, sp.csc_matrix(A), b, xl, xu, sf.obj_const, sf.int_idx),
        n_rewritten,
    )


def _coef_tighten_enabled() -> bool:
    """``DISCOPT_MILP_COEF_TIGHTEN`` (default ON; ``=0`` restores the pre-#1654 route).

    Graduated on introduction by the §5 panel recorded in
    ``docs/dev/issue-1654-coef-tighten-panel-2026-10-05.md`` (certified 22/48 -> 48/48
    on three big-M families, 0 soundness violations); the opt-out keeps the
    pre-#1654 route reachable for A/B measurement.
    """
    return os.environ.get("DISCOPT_MILP_COEF_TIGHTEN", "1") != "0"


def _implied_bounds_enabled() -> bool:
    """``DISCOPT_MILP_IMPLIED_BOUNDS`` (#1678, default ON; ``=0`` restores the #1654
    tightening over the declared box only).

    Gives open columns their row-implied bounds before the #1654 tightening
    (:func:`coefficient_tightened`). It is bound-changing because it changes the
    tightened LP on a class the #1654 panel did not cover: big-M rows over columns left
    at the default box. It was graduated on introduction by the §5 panel recorded in
    ``docs/dev/issue-1678-implied-bounds-panel-2026-10-10.md``. On the open-box
    families, certified went from 39/100 to 63/100. The #1654 families and the HiGHS
    check set were unchanged, apart from one extra certificate (2122). There were 0
    soundness violations and 0 certification regressions.
    """
    return os.environ.get("DISCOPT_MILP_IMPLIED_BOUNDS", "1") != "0"


def _coefficient_tightening_rescue(
    sf: StdForm, out: HighsOutcome, kw: dict[str, Any], t0: float
) -> HighsOutcome:
    """#1654: re-solve a MILP the route could not certify on its coefficient-tightened
    form (:func:`coefficient_tightened`), and adopt what that solve proves.

    Runs only when the primary result is NOT certified, so a model this route
    certifies today is untouched. The tightened form has exactly ``sf``'s
    integer-feasible set, so its certified bound and infeasibility are statements
    about ``sf`` -- but that is a claim about exact arithmetic, so the tightened solve
    goes through the whole certified pipeline (#1295, #1509, #1621, #1634, #1612), its
    incumbent is re-verified on ``sf`` itself, and a verified point of the primary
    below its bound refutes it. Anything less returns the primary, improved at most by
    a better verified incumbent.
    """
    # #2304: fixed columns first, so a big-M on a binary pinned by a singleton row is
    # neither left in the matrix HiGHS sees nor read by the #1295 guard on the re-solve.
    sf_f, n_fold = fold_fixed_columns(sf)
    sf_ct, n_rw = coefficient_tightened(
        sf if sf_f is None else sf_f, implied_bounds=_implied_bounds_enabled()
    )
    if (
        sf_ct is None
        and sf_f is not None
        and open_column_coefficient_ratio(sf)
        < UNSCALABLE_OPEN_RATIO
        <= open_column_coefficient_ratio(sf_f)
    ):
        # Nothing to tighten, but the fold alone clears the #1295 guard: re-solving
        # is worth it only then (otherwise it is the primary's model again).
        sf_ct = sf_f
    if sf_ct is None:
        return out
    out.stats["milp/coef_tightened_entries"] = float(n_rw)
    if n_fold:
        out.stats["milp/fixed_entries_folded"] = float(n_fold)
    # Name the form that was actually solved: a fold with nothing tightened is not the
    # #1654 form, and the route string is read as a statement of what ran.
    if n_rw and n_fold:
        form = "coefficient-tightened, fixed-column-folded form (#1654, #2304)"
    elif n_rw:
        form = "coefficient-tightened form (#1654)"
    else:
        form = "fixed-column-folded form (#2304)"
    kw2 = dict(kw)
    if kw["time_limit"] is not None:
        kw2["time_limit"] = float(kw["time_limit"]) - (time.monotonic() - t0)
        if kw2["time_limit"] <= 0.0:
            out.stats["milp/coef_tighten_skipped"] = 1.0
            return out
    # The primary's user start is a point of ``sf`` and so of the tightened form too.
    ct = _certified_milp(sf_ct, kw2)
    # #2156: the tightened solve's infeasible label is a HiGHS label too.
    ct = _sub_tolerance_infeasible_guard(sf_ct, ct)
    if ct.gap_certified and ct.status == "optimal":
        ct = _tighten_feasibility_artefact(sf_ct, ct, kw2, time.monotonic())
    out.stats["milp/coef_tighten_ran"] = 1.0
    out.stats["milp/coef_tighten_time"] = float(ct.wall_time)
    out.labels["milp/coef_tighten_status"] = ct.status
    pt = _verified_mip_point(sf, ct.x)
    if pt is None and ct.x is not None:
        rem = (
            None if kw["time_limit"] is None else float(kw["time_limit"]) - (time.monotonic() - t0)
        )
        pt = _repair_refused_incumbent(sf, ct.x, ct, rem, out.stats)
    mine = _verified_mip_point(sf, out.x)
    best = min((p for p in (pt, mine) if p is not None), key=lambda p: p[1], default=None)

    def merged(base: HighsOutcome, primary: HighsOutcome) -> HighsOutcome:
        base.stats = {**primary.stats, **base.stats}
        base.labels = {**primary.labels, **base.labels}
        base.node_count += primary.node_count
        base.iterations += primary.iterations
        base.wall_time = time.monotonic() - t0
        return base

    why = None
    if ct.gap_certified and ct.status == "infeasible":
        if best is not None:
            why = (
                f"tightened form certified infeasible, but a verified point ({best[1]:.12g}) exists"
            )
        else:
            ct.labels["milp/bound_provenance"] = "coef-tightened"
            ct.x = None
            ct = merged(ct, out)
            ct.labels.pop("milp/certificate", None)
            return ct
    elif ct.gap_certified and ct.status == "optimal" and ct.bound is not None:
        claim = float(ct.bound)
        if best is None:
            why = "tightened form certified optimal, but its incumbent fails on the model"
        elif claim - best[1] > CERT_ABS + CERT_REL * abs(claim):
            why = f"tightened bound {claim:.12g} is above a verified point ({best[1]:.12g})"
        else:
            x, obj = best
            bound = min(claim, obj)
            ct.x, ct.objective, ct.bound = x, obj, bound
            if not _gap_closed(obj, bound, kw):
                ct.status, ct.gap_certified = "feasible", False
                ct.labels["milp/certificate"] = "declined"
            ct.labels["milp/bound_provenance"] = (
                f"{ct.labels.get('milp/bound_provenance', 'highs-fp')} on the {form}"
            )
            ct.message = ct.message or f"certified on the {form}"
            ct = merged(ct, out)
            # The primary's decline is superseded; only the tightened solve's own
            # verdict may label the result.
            if ct.gap_certified:
                ct.labels.pop("milp/certificate", None)
            return ct
    else:
        why = f"tightened solve not certified ({ct.status}: {ct.message or 'no message'})"
    out.labels["milp/coef_tighten_declined"] = why
    # No certificate either way: keep the primary, with the better verified point.
    if best is not None and (out.objective is None or best[1] < out.objective - 1e-12):
        out.x, out.objective = best
        out.stats["milp/incumbent_from_coef_tighten"] = 1.0
        if out.status in ("error", "time_limit", "node_limit", "iteration_limit"):
            out.status = "feasible"
        bounds = [b for b in (out.bound, ct.root_bound, out.root_bound) if b is not None]
        out.bound = min(max(bounds), best[1]) if bounds else None
    return out


def solve_milp_std(
    sf: StdForm,
    *,
    time_limit: Optional[float],
    gap_tolerance: float,
    abs_gap_tolerance: Optional[float] = None,
    max_nodes: int,
    initial_point: Optional[np.ndarray] = None,
    n_struct: Optional[int] = None,
    root_check: bool = True,
    feasibility_tolerance: float = HIGHS_MIP_FEAS_TOL,
) -> HighsOutcome:
    """The HiGHS MILP route; its LP checks run on HiGHS's LP (:func:`_lp_engine`).

    ``feasibility_tolerance`` is HiGHS's ``mip_feasibility_tolerance`` for the
    primary solve. The caller tightens it only to re-solve a model whose published
    point the model's own verifier refused (``Model.solve``'s HiGHS MILP route).
    """
    token = _IN_HIGHS_MILP_ROUTE.set(True)
    try:
        return _solve_milp_std_route(
            sf,
            time_limit=time_limit,
            gap_tolerance=gap_tolerance,
            abs_gap_tolerance=abs_gap_tolerance,
            max_nodes=max_nodes,
            initial_point=initial_point,
            n_struct=n_struct,
            root_check=root_check,
            feasibility_tolerance=feasibility_tolerance,
        )
    finally:
        _IN_HIGHS_MILP_ROUTE.reset(token)


def _solve_milp_std_route(
    sf: StdForm,
    *,
    time_limit: Optional[float],
    gap_tolerance: float,
    abs_gap_tolerance: Optional[float] = None,
    max_nodes: int,
    initial_point: Optional[np.ndarray] = None,
    n_struct: Optional[int] = None,
    root_check: bool = True,
    feasibility_tolerance: float = HIGHS_MIP_FEAS_TOL,
) -> HighsOutcome:
    """Solve the MILP ``sf`` under the §3.2 contract, with the route's own
    under-scaled logical columns rescaled exactly first (#1537,
    :func:`logical_column_scales`), and every certificate held against a second,
    presolve-free HiGHS solve (#1634, :func:`_cross_check_presolve`); see
    :func:`_solve_milp_std`."""
    kw: dict[str, Any] = dict(
        time_limit=time_limit,
        gap_tolerance=gap_tolerance,
        abs_gap_tolerance=abs_gap_tolerance,
        max_nodes=max_nodes,
        initial_point=initial_point,
        n_struct=n_struct,
        root_check=root_check,
    )
    if feasibility_tolerance != HIGHS_MIP_FEAS_TOL:
        # Only when tightened: the default call stays exactly the call it was.
        kw["feasibility_tolerance"] = float(feasibility_tolerance)
    # ``monotonic``, not ``perf_counter``: this clock only budgets the #1612 re-solve,
    # and must not shift the route's own ``perf_counter`` deadline reads.
    t0 = time.monotonic()
    # #1920: with no warm start, give the PRIMARY one (the cross-solve of #1634 stays
    # cold, #1733); kept as the incumbent if HiGHS ends without one of its own.
    start = None
    start_stats: dict[str, float] = {}
    if initial_point is None and sf.int_idx.size and _fixprop_seed_enabled():
        start = _fixprop_start(
            sf, sf.n if n_struct is None else int(n_struct), time_limit, start_stats
        )
        if start is not None:
            kw["initial_point"] = start[0][: sf.n if n_struct is None else int(n_struct)]
        if time_limit is not None:
            kw["time_limit"] = float(time_limit) - (time.monotonic() - t0)
    out = _certified_milp(sf, kw)
    out.stats.update(start_stats)
    if (
        start is not None
        and out.status in ("feasible", "time_limit", "node_limit", "iteration_limit")
        and (
            out.objective is None
            # HiGHS can decline a start; a better verified point still stands.
            or out.objective - start[1] > CERT_ABS + CERT_REL * abs(float(out.objective))
        )
    ):
        out.x, out.objective = start
        out.status = "feasible"
        out.stats["milp/fixprop_incumbent_published"] = 1.0
        if out.bound is not None:
            out.bound = min(out.bound, out.objective)
    if (
        out.status == "infeasible"
        and out.gap_certified
        and out.labels.get("milp/infeasible_provenance") == "highs"
    ):
        out = _cross_form_infeasible_check(sf, out, kw, t0)
    out = _sub_tolerance_infeasible_guard(sf, out)
    if out.gap_certified and out.status == "optimal":
        out = _tighten_feasibility_artefact(sf, out, kw, t0)
    if (
        not out.gap_certified
        and out.refuted_by == "own-integers"
        and _refuted_tight_resolve_enabled()
    ):
        out = _tight_resolve_refuted(sf, out, kw)
    if not out.gap_certified and out.status != "unbounded" and _coef_tighten_enabled():
        out = _coefficient_tightening_rescue(sf, out, kw, t0)
    return out


def _cross_form_infeasible_check(
    sf: StdForm, out: HighsOutcome, kw: dict[str, Any], t0: float
) -> HighsOutcome:
    """#1733: hold a HiGHS-only ``infeasible`` label against a solve of the OTHER form.

    HiGHS's ``kInfeasible`` is trusted as a floating-point label once the #1634
    presolve-free cross-solve agrees, but that cross-solve sees the same form and
    repeats a form-specific failure. Measured on two forms: HiGHS 1.10/1.11 label the
    #1229 instance infeasible on the row form (the slack form solves it to 0), and
    HiGHS 1.11 labels #1733's own model infeasible on the slack form (optimum
    363.40). So the other form -- row form if the primary used slack columns, slack
    form otherwise -- is solved once, and a VERIFIED point of it refutes the label.

    A refuted label publishes that point, never the other form's own certificate. The
    two forms disagree, so neither has earned one. The bound is the NS-safe root
    bound, and the result is certified only if that bound closes the gap by the
    route's stop rule (the #1509 refutation rule). No verified point leaves the label
    as it was: this check can withdraw a certificate, never add one.
    """
    row_used = "milp/logicals_as_row_bounds" in out.stats
    kw2 = dict(kw, row_form=not row_used, initial_point=None)
    if kw["time_limit"] is not None:
        kw2["time_limit"] = float(kw["time_limit"]) - (time.monotonic() - t0)
        if kw2["time_limit"] <= 0.0:
            out.stats["milp/cross_form_check_skipped"] = 1.0
            return out
    other = _solve_milp_scaled(sf, **kw2)
    out.stats["milp/cross_form_check_ran"] = 1.0
    pt = _verified_mip_point(sf, other.x)
    if pt is None:
        return out
    x, obj = pt
    roots = [b for b in (out.root_bound, other.root_bound) if b is not None]
    bound = min(max(roots), obj) if roots else None
    closed = bound is not None and _gap_closed(obj, bound, kw)
    why = f"the {'slack' if row_used else 'row'} form has a verified point of objective {obj:.12g}"
    logger.warning(
        "HiGHS MILP route: the infeasible label is refuted (%s); reporting that point (#1733)",
        why,
    )
    labels = {
        **out.labels,
        "milp/infeasible_label_refuted": why,
        "milp/bound_provenance": "root-ns" if bound is not None else "none",
    }
    labels.pop("milp/infeasible_provenance", None)
    if not closed:
        labels["milp/certificate"] = "declined"
    return HighsOutcome(
        "optimal" if closed else "feasible",
        x=x,
        objective=obj,
        bound=bound,
        gap_certified=closed,
        message=f"HiGHS MILP infeasible label refuted: {why} (#1733)",
        highs_status=out.highs_status,
        node_count=out.node_count + other.node_count,
        iterations=out.iterations + other.iterations,
        root_bound=bound,
        root_time=out.root_time,
        wall_time=out.wall_time + other.wall_time,
        # The other form's own row-form stat would misreport which form the primary used.
        stats={
            **{k: v for k, v in other.stats.items() if k != "milp/logicals_as_row_bounds"},
            **out.stats,
            "milp/infeasible_label_refuted": 1.0,
        },
        labels=labels,
    )


def sub_tolerance_columns(sf: StdForm, tol: float = HIGHS_MIP_FEAS_TOL) -> int:
    """Continuous columns whose finite box is open but narrower than ``tol`` (#2156).

    ``0 < xu - xl < tol``: a column HiGHS's MIP domain propagation cannot resolve
    from a fixed one. An exactly fixed column (``xl == xu``) is not counted.
    """
    width = sf.xu - sf.xl
    cont = np.ones(sf.n, dtype=bool)
    cont[sf.int_idx] = False
    finite = (sf.xl > -INF) & (sf.xu < INF)
    return int(np.count_nonzero(cont & finite & (width > 0.0) & (width < tol)))


def _sub_tolerance_infeasible_guard(sf: StdForm, out: HighsOutcome) -> HighsOutcome:
    """Withdraw a HiGHS-only ``infeasible`` on a model with sub-tolerance columns (#2156).

    HiGHS's MIP answers ``kInfeasible`` on feasible models of this class, and no
    cross-check catches it, because every one of them runs the same MIP code.
    Measured on the #2156 panel: on the unmerged ``relu_extended`` encoding of
    30 tiny-weight 2-32-32-1 networks, 8 came back ``infeasible`` with
    ``gap_certified=True``. The presolve-free solve and the other form agreed in
    each case. ``verify_point`` accepts an exact point of the seed-0 model.

    On that model HiGHS still answers ``kInfeasible`` in each of these runs:
    with every integer fixed at the feasible point's values (zero LP iterations;
    domain propagation decides it at the first node), with presolve off, at any
    ``mip_feasibility_tolerance`` from 1e-4 to 1e-9, and on every sound
    relaxation tried. Those relaxations were tiny entries absorbed up to 1e-6
    and narrow columns widened or rescaled. So no input
    transformation makes the label trustworthy. A 13-row sub-model found by
    delta debugging (every candidate kept the known point feasible) was the
    smallest such model. On it, widening the columns with ``0 < xu - xl < 1e-6``,
    or fixing them at the point, gives ``kOptimal``, and at 1e-7 neither does.
    Those columns are the trigger this guard tests.

    Only the infeasible label is withdrawn. On the same panel every false HiGHS
    ``optimal`` was already refuted by the #1509/#1634 checks. 72 of the 89
    correct certificates (big-M, merged extended, merged P = 4) sit on models with
    such columns, and with this guard all 89 are still certified. A Farkas proof
    of the root relaxation is the route's own certificate and stands. The
    withdrawn label becomes ``error``, the #1295
    treatment of an unverified ``kInfeasible``.
    """
    if not (out.status == "infeasible" and out.gap_certified):
        return out
    if out.labels.get("milp/infeasible_provenance") not in ("highs", "highs-root-feasible"):
        return out
    k = sub_tolerance_columns(sf)
    out.stats["milp/sub_tolerance_columns"] = float(k)
    if k == 0:
        return out
    why = (
        f"{k} continuous column(s) have 0 < xu - xl < {HIGHS_MIP_FEAS_TOL:g}, where "
        "HiGHS's MIP has labelled feasible models infeasible (#2156)"
    )
    logger.warning("HiGHS MILP route: infeasible label not certified: %s", why)
    labels = dict(out.labels)
    labels.pop("milp/infeasible_provenance", None)
    labels["milp/certificate"] = "declined"
    labels["milp/infeasible_label_declined"] = why
    out.status, out.gap_certified, out.bound = "error", False, None
    out.message = f"HiGHS reported infeasible, unverified: {why}"
    out.labels = labels
    out.stats["milp/infeasible_label_declined_sub_tolerance"] = 1.0
    return out


def _concurrent_cross_enabled() -> bool:
    """``DISCOPT_MILP_CONCURRENT_CROSS`` (#1920, default ON; ``=0`` runs the #1634
    presolve-free cross-solve after the primary instead of beside it).

    A documented opt-out, not a stalled graduation: it changes when the cross-solve
    runs, never what a verdict needs. It exists for a single-core budget, where two
    concurrent HiGHS solves only share one CPU, and for A/B measurement.
    """
    return os.environ.get("DISCOPT_MILP_CONCURRENT_CROSS", "1") != "0"


class _CrossStop:
    """#1920: a stop signal another thread can raise on a running HiGHS MILP solve.

    ``deadline`` (a ``time.perf_counter`` value, set later) and ``event`` are both read
    from HiGHS's MIP interrupt callback, so the cross-solve's cap can be set after it
    started -- the cap depends on the primary's wall time, known only when the primary
    returns.
    """

    def __init__(self) -> None:
        self.event = threading.Event()
        self.deadline: Optional[float] = None

    def should_stop(self) -> bool:
        return self.event.is_set() or (
            self.deadline is not None and time.perf_counter() >= self.deadline
        )

    def attach(self, h: Any, highspy: Any) -> None:
        def _interrupt(callback_type, message, data_out, data_in, user_data):  # noqa: ARG001
            data_in.user_interrupt = self.should_stop()

        h.setCallback(wrap_callback(h, _interrupt), None)
        h.startCallback(highspy.cb.HighsCallbackType.kCallbackMipInterrupt)


def _certified_milp(sf: StdForm, kw: dict[str, Any]) -> HighsOutcome:
    """One HiGHS MILP solve with every route certificate check (#1537/#1621, #1634).

    #1920: the #1634 presolve-free cross-solve runs CONCURRENTLY with the primary
    (HiGHS releases the GIL), from the same start and under the same time limit,
    instead of after it on what the primary left. Measured on three 2-40-40-1
    ``relu_bigm`` nets: the sequential cross-solve was 27-100 s of 54-157 s totals,
    against 23-41 s for HiGHS alone. Its verdict rule and its own cap
    (:data:`PRESOLVE_CROSS_BUDGET_FACTOR` times the primary's wall time) are those of
    :func:`_cross_check_presolve`; it now never starves for lack of budget left over.

    When the primary ends WITHOUT a certificate (a time, node or interrupt limit), the
    cross-solve is stopped at once and its tree bound joins the primary's
    (:func:`_merge_uncertified_cross`): the published bound is then the
    ``min(presolved, presolve-free)`` rule on every exit, so it no longer drops when a
    longer run happens to prove optimality without confirming it.
    """
    if not _concurrent_cross_enabled() or presolve_exact_class(sf):
        out = _solve_milp_scaled(sf, **kw)
        if out.gap_certified and out.status in ("optimal", "infeasible"):
            return _cross_check_presolve(sf, out, kw)
        return out
    t0 = time.perf_counter()
    stop = _CrossStop()
    kw_c = dict(kw, initial_point=None, stop=stop)  # #1733: the cross-solve starts cold
    box: dict[str, Any] = {}
    ctx = contextvars.copy_context()  # the #1620 user options are a ContextVar

    def _run_cross() -> None:
        try:
            box["out"] = ctx.run(_solve_milp_scaled, sf, presolve=False, **kw_c)
        except BaseException as err:  # re-raised in the caller's thread below
            box["err"] = err

    th = threading.Thread(target=_run_cross, name="discopt-highs-cross", daemon=True)
    th.start()
    try:
        out = _solve_milp_scaled(sf, **kw)
    except BaseException:
        stop.event.set()
        th.join()
        raise
    certified = out.gap_certified and out.status in ("optimal", "infeasible")
    if certified:
        cap = max(PRESOLVE_CROSS_MIN_BUDGET, PRESOLVE_CROSS_BUDGET_FACTOR * float(out.wall_time))
        stop.deadline = t0 + cap
        out.stats["milp/presolve_cross_check_budget"] = cap
    else:
        stop.event.set()
    th.join()
    if "err" in box:
        raise box["err"]
    cross: HighsOutcome = box["out"]
    out.stats["milp/presolve_cross_concurrent"] = 1.0
    out.stats["milp/presolve_cross_check_ran"] = 1.0
    out.stats["milp/presolve_cross_check_time"] = float(cross.wall_time)
    if not certified:
        rem = None
        if kw["time_limit"] is not None:
            rem = float(kw["time_limit"]) - (time.perf_counter() - t0)
        return _merge_uncertified_cross(sf, out, cross, rem)
    # The cross-solve's wall time is already inside the elapsed wall here, so
    # :func:`_tight_cross_bound` must not charge it a second time.
    # As in the sequential path, what is left of the cross-solve's own cap bounds
    # the #1640 tight re-run too.
    elapsed = time.perf_counter() - t0
    left = cap - elapsed
    if kw["time_limit"] is not None:
        left = min(left, float(kw["time_limit"]) - elapsed)
    kw_j = dict(kw, initial_point=None, time_limit=max(0.0, left), _cross_wall_charged=True)
    return _judge_presolve_cross(sf, out, cross, kw_j)


def _merge_uncertified_cross(
    sf: StdForm, out: HighsOutcome, cross: HighsOutcome, time_limit: Optional[float]
) -> HighsOutcome:
    """#1920: fold the stopped cross-solve into a primary that ended without a certificate.

    The cross-solve's point counts only as RE-DERIVED: the LP over its own integers
    (:func:`_fixed_integer_lp`, 1e-7 primal tolerance), verified, within
    ``time_limit``. Its raw point is never used. The verifier's relative row tolerance
    lets a point spend ``FEAS_RTOL * M`` on a big-M row, and choosing the BEST
    objective among candidates selects exactly such points. Measured on the #1654
    ``sequencing`` family at M = 1e10: the raw presolve-free point verified at 11.0
    while violating the model by 8; the LP over its integers gives the true 31.0.
    Adopting the raw point published the infeasible 11.0, and it then outranked the
    #1654 rescue's certified 31.0. With no budget left for the LP, nothing is taken
    from the cross point.

    * A re-derived cross point below the primary's tree bound by more than the equality
      yardstick refutes that bound (the #1634 falsifier); only the NS-safe root bounds
      then stand, as on a refuted certificate.
    * Otherwise the bound is ``max(root, min(primary tree, cross tree))`` -- the rule
      :func:`_weaker_bound` certifies on and :func:`_withdraw` publishes. The
      presolved tree bound alone is exactly what #1634 found can lie above the optimum
      (seed 965: 3e-6 above it with the cross-solve undecided); with both bounds in
      hand the published one no longer rests on it.
    * A re-derived cross point better than the primary's incumbent (by more than the
      yardstick) is adopted. A primary with no incumbent becomes ``feasible`` on it.

    Results that carry no bound (``error``, ``unbounded``, an uncertified
    ``infeasible``) are left as they are.
    """
    if out.status not in ("feasible", "time_limit", "node_limit", "iteration_limit"):
        return out
    pt = None
    if cross.x is not None and (time_limit is None or time_limit > 0.0):
        fx = _fixed_integer_lp(sf, cross.x, time_limit)
        pt = _verified_mip_point(sf, fx.x) if fx.status == "optimal" else None
    roots = [b for b in (out.root_bound, cross.root_bound) if b is not None]
    root = max(roots) if roots else None
    if out.bound is not None:
        tree: Optional[float] = None
        if pt is not None and out.bound - pt[1] > CERT_ABS + CERT_REL * abs(out.bound):
            out.stats["milp/presolve_bound_refuted"] = 1.0
            out.labels["milp/presolve_bound_refuted"] = (
                f"bound {out.bound:.12g} is above a verified point's objective {pt[1]:.12g}"
            )
        elif cross.bound is not None:
            tree = min(float(out.bound), float(cross.bound))
        if tree is not None and (root is None or tree > root):
            out.bound = tree
            out.labels["milp/bound_provenance"] = "min(presolved, presolve-free)"
        else:
            out.bound = root
            out.labels["milp/bound_provenance"] = "root-ns" if root is not None else "none"
        if cross.bound is not None:
            out.stats["milp/presolve_cross_bound"] = float(cross.bound)
    if pt is not None and (
        out.objective is None
        or out.objective - pt[1] > CERT_ABS + CERT_REL * abs(float(out.objective))
    ):
        out.x, out.objective = pt
        out.stats["milp/presolve_cross_incumbent_adopted"] = 1.0
        if out.status != "feasible":
            out.status = "feasible"
    if out.bound is not None and out.objective is not None:
        out.bound = min(out.bound, out.objective)
    return out


def _tighten_feasibility_artefact(
    sf: StdForm, out: HighsOutcome, kw: dict[str, Any], t0: float
) -> HighsOutcome:
    """#1612: re-solve at a tighter feasibility tolerance when HiGHS's tolerance, not its
    search, is what the certified pair's closure rests on.

    HiGHS accepts an incumbent that violates rows by up to ``mip_feasibility_tolerance``,
    so its objective ``o_H`` can be better than any truly feasible point with the same
    integers -- by ``delta = o_fx - o_H``, where ``o_fx`` is the separate fixed-integer
    LP the #1509 check already solves. HiGHS stops on that incumbent, so its bound
    carries the same ``delta``. Once ``Model.solve``'s incumbent repair moves the
    objective back to ``o_fx`` the published gap is ``delta`` wide, and with HiGHS's
    1e-6 tolerance against the default 1e-6 absolute gap it lands on the stop rule's
    edge: measured on the issue's interdiction model at ``gap_tolerance=1e-9``,
    ``delta = 9.99999997e-7`` against ``abs_gap = 1e-6``, and the #1551 evaluation-error
    check (``1.4e-14``) then withdrew the certificate and the bound.

    The trigger: ``delta > 0`` and the stop rule no longer closes once ``delta`` is
    charged against the repaired pair a second time -- the margin left is smaller than
    the tolerance artefact itself, so the closure is the artefact's doing. The whole
    certified pipeline is then run again at :data:`CROSS_TIGHT_FEAS_TOL`. Its result
    replaces the primary only if it is a certified ``optimal`` of its own (every route
    check, the #1634 presolve-free cross-solve included), no verified point of either
    solve lies below either bound, and the two bounds agree within the #1640 tolerance
    slack. Anything else -- no budget, no verdict, a disagreement -- returns the
    primary result unchanged: this never withdraws a certificate.
    """
    o_fx = out.stats.get("milp/fixed_int_objective")
    if o_fx is None or out.objective is None or out.bound is None:
        return out
    delta = float(o_fx) - float(out.objective)
    if not delta > 0.0 or _gap_closed(float(o_fx) + delta, float(out.bound), kw):
        return out
    out.stats["milp/feas_artefact_delta"] = delta
    kw2 = dict(kw, feasibility_tolerance=CROSS_TIGHT_FEAS_TOL)
    if kw["time_limit"] is not None:
        kw2["time_limit"] = float(kw["time_limit"]) - (time.monotonic() - t0)
        if kw2["time_limit"] <= 0.0:
            out.stats["milp/feas_artefact_tight_skipped"] = 1.0
            return out
    tight = _certified_milp(sf, kw2)
    out.stats["milp/feas_artefact_tight_ran"] = 1.0
    out.stats["milp/feas_artefact_tight_time"] = float(tight.wall_time)
    why = None
    if not (tight.gap_certified and tight.status == "optimal" and tight.bound is not None):
        why = f"tight re-solve status {tight.status}"
    else:
        tb, ob = float(tight.bound), float(out.bound)
        pts = [float(o_fx)] + [
            p[1] for p in (_verified_mip_point(sf, out.x), _verified_mip_point(sf, tight.x)) if p
        ]
        c_max = float(np.max(np.abs(sf.c))) if sf.c.size else 0.0
        a_max = float(np.max(np.abs(sf.A.data))) if sf.A.nnz else 0.0
        slack = CROSS_TIGHT_SHIFT_FACTOR * CROSS_FEAS_TOL * max(1.0, c_max) * max(1.0, a_max)
        if any(b - p > CERT_ABS + CERT_REL * abs(b) for b in (tb, ob) for p in pts):
            why = "a verified point lies below one of the two bounds"
        elif abs(tb - ob) > slack:
            why = f"bounds {tb:.12g} and {ob:.12g} differ by more than the slack {slack:.3g}"
    if why is not None:
        out.labels["milp/feas_artefact_tight_declined"] = why
        return out
    tight.stats = {**out.stats, **tight.stats, "milp/feas_artefact_tight_adopted": 1.0}
    tight.labels = {
        **out.labels,
        **tight.labels,
        "milp/bound_provenance": f"{tight.labels.get('milp/bound_provenance', 'highs-fp')}, "
        f"mip_feasibility_tolerance={CROSS_TIGHT_FEAS_TOL:g} (#1612)",
    }
    tight.node_count += out.node_count
    tight.iterations += out.iterations
    tight.wall_time = time.monotonic() - t0
    return tight


#: #2151: ``mip_feasibility_tolerance`` of the re-solve after a refutation over the
#: incumbent's own integers. Measured on the issue's 2-32-32-1 ``relu_bigm`` network:
#: at 1e-6, 1e-7 and 1e-8 HiGHS certifies the same bound 1.09e-6 above a feasible
#: point; at 1e-9 (and 1e-10) its bound sits 1.4e-14 (5.7e-14) BELOW that point.
REFUTED_TIGHT_FEAS_TOL = 1e-9

#: #2151: the yardstick the tight re-solve's bound is held to against every verified
#: point in hand. It is far tighter than the 1e-6 refutation yardstick, which is as
#: wide as the 1.09e-6 false bound the re-solve exists to replace. Measured
#: bound-to-point margins on the issue's network: -1.4e-14 at 1e-9, -5.7e-14 at 1e-10.
REFUTED_ADOPT_ABS = 1e-9
REFUTED_ADOPT_REL = 1e-12


def _refuted_tight_resolve_enabled() -> bool:
    """``DISCOPT_MILP_REFUTED_TIGHT_RESOLVE`` (#2151, default ON; ``=0`` publishes the
    refuted result with the NS-safe root bound, as before #2151).

    Graduated on introduction by the examples recorded in
    ``docs/dev/flag-retirement-audit.md``. There were 10 ``relu_bigm`` nets: the
    issue's, 5 neuron permutations of it and 4 random 2-32-32-1 nets. The two arms
    were interleaved, and 80 checks were made against a forward pass of each net
    and an 801x801 input grid. The re-solve fired once (on the issue's net) and
    certified it. The other 9 were identical in both arms. The opt-out keeps the
    pre-#2151 route reachable for A/B measurement.
    """
    return os.environ.get("DISCOPT_MILP_REFUTED_TIGHT_RESOLVE", "1") != "0"


def _tight_resolve_refuted(sf: StdForm, out: HighsOutcome, kw: dict[str, Any]) -> HighsOutcome:
    """#2151: one certified re-solve at :data:`REFUTED_TIGHT_FEAS_TOL`, after HiGHS's
    bound was refuted by the LP over its OWN incumbent's integers.

    Runs only when ``out.refuted_by == "own-integers"``. That field is set by the
    primary's own #1509 check and never merged from another solve. HiGHS then had the
    right integer assignment, but its continuous part was not optimal for it, and its
    tree bound sat on that suboptimal objective. Measured on the issue's network:
    HiGHS reported ``kOptimal`` with objective = ``mip_dual_bound`` = -46.6583412166
    (``mip_gap`` 0). The LP over the same integers gives -46.6583423116 with row
    residual 1.5e-16, so the bound is 1.09e-6 above a feasible point. The stop rule is
    not the cause (``mip_rel_gap = 0`` and ``mip_abs_gap = 1e-9`` return the same
    bound), and neither is ``mip_feasibility_tolerance`` at 1e-7 or 1e-8. At 1e-9,
    HiGHS certifies a bound 1.4e-14 below the point.

    The re-solve is the whole certified pipeline (:func:`_certified_milp`: its own #1509
    refutation, the #1634 presolve-free cross-solve). It is COLD (no start), so that
    the tree it certifies is independent of the refuting point. It is also capped like
    the #1634 cross-solve, at ``PRESOLVE_CROSS_BUDGET_FACTOR`` times the primary's wall
    time. It is adopted only if:
    - it is a certified ``optimal``; and
    - its bound lies below every verified point in hand (the point ``out`` publishes
      and the re-solve's own incumbent) within
      ``REFUTED_ADOPT_ABS + REFUTED_ADOPT_REL |bound|``.

    A re-solve at the primary's 1e-6 tolerance is not enough: it repeats the tree that
    was just refuted, and the 1e-6 yardstick cannot see a bound as wrong as the one
    being replaced. On adoption the better of the two verified incumbents is
    published, and the gap is re-tested on it. Otherwise ``out`` is returned unchanged,
    so this never withdraws anything. A refutation by a DIFFERENT integer assignment
    (the #1509 class itself) does not run it, because there the tree pruned a branch.
    """
    if out.x is None or out.objective is None or not sf.int_idx.size:
        return out
    cap = max(PRESOLVE_CROSS_MIN_BUDGET, PRESOLVE_CROSS_BUDGET_FACTOR * float(out.wall_time))
    if kw["time_limit"] is not None:
        cap = min(cap, float(kw["time_limit"]) - float(out.wall_time))
        if cap <= 0.0:
            out.stats["milp/refuted_tight_resolve_skipped"] = 1.0
            return out
    out.stats["milp/refuted_tight_resolve_budget"] = cap
    kw2 = dict(kw, initial_point=None, time_limit=cap, feasibility_tolerance=REFUTED_TIGHT_FEAS_TOL)
    again = _certified_milp(sf, kw2)
    out.stats["milp/refuted_tight_resolve_ran"] = 1.0
    out.stats["milp/refuted_tight_resolve_time"] = float(again.wall_time)
    best0 = (np.asarray(out.x, dtype=np.float64), float(out.objective))
    why, best = _tight_adoption_problem(sf, again, best0, kw)
    provenance = f"mip_feasibility_tolerance={REFUTED_TIGHT_FEAS_TOL:g} after a refutation (#2151)"
    if (
        why is not None
        and not again.gap_certified
        and _refuted_by_presolve(again)
        and _refuted_presolve_free_enabled()
    ):
        # #2187: the tight re-solve was refuted over its OWN integers again, so the
        # tolerance was not the cause; HiGHS's presolve is. Measured on a 2-32-32-1
        # ``relu_extended`` net: with presolve on, HiGHS's bound is 1.097e-6 above
        # the LP over its own integers at every mip_feasibility_tolerance (1e-6, 1e-9)
        # and every stop rule (mip_rel_gap 1e-4 or 0); with presolve off at 1e-9 the
        # bound is 1.7e-13 from that point. The concurrent presolve-free arm of the
        # re-solve above is stopped as soon as its primary fails, so it never gets
        # to answer. Here it runs on its own. It passes the per-solve checks (root
        # cross-check, #1509 refutation, #1621 rescaling) and the same adoption test
        # as the tight re-solve. #1634's presolve cross-check has no presolve to
        # compare against here.
        rem = cap - float(again.wall_time)
        if rem <= 0.0:
            out.stats["milp/refuted_presolve_free_skipped"] = 1.0
        else:
            free = _solve_milp_scaled(sf, presolve=False, **dict(kw2, time_limit=rem))
            out.stats["milp/refuted_presolve_free_ran"] = 1.0
            out.stats["milp/refuted_presolve_free_time"] = float(free.wall_time)
            why_free, best_free = _tight_adoption_problem(sf, free, best0, kw)
            if why_free is None:
                why, best, again = None, best_free, free
                provenance = (
                    f"presolve-free, mip_feasibility_tolerance={REFUTED_TIGHT_FEAS_TOL:g} "
                    "after a refutation (#2151, #2187)"
                )
            else:
                why = f"{why}; presolve-free re-solve: {why_free}"
    if why is not None:
        out.labels["milp/refuted_tight_resolve_declined"] = why
        return out
    # The primary's refutation is history now: its stats and labels are kept under a
    # prefix, so nothing on the adopted result reads as a refuted certificate.
    old_stats = _as_history(out.stats, ())
    old_labels = _as_history(out.labels, _DECLINE_LABELS)
    again.stats = {**old_stats, **again.stats, "milp/refuted_tight_resolve_adopted": 1.0}
    if "presolve-free" in provenance:
        again.stats["milp/refuted_presolve_free_adopted"] = 1.0
    again.labels = {
        **old_labels,
        **again.labels,
        "milp/bound_provenance": f"{again.labels.get('milp/bound_provenance', 'highs-fp')}, "
        f"{provenance}",
    }
    again.x, again.objective = best
    again.bound = min(float(again.bound), best[1])  # type: ignore[arg-type]
    again.node_count += out.node_count
    again.iterations += out.iterations
    again.wall_time += out.wall_time
    logger.info(
        "HiGHS MILP route: re-solved at mip_feasibility_tolerance=%g after the refutation; "
        "certified %.12g with bound %.12g (#2151)",
        REFUTED_TIGHT_FEAS_TOL,
        best[1],
        again.bound,
    )
    return again


def _refuted_by_presolve(again: HighsOutcome) -> bool:
    """#2187/#2221: was the tight re-solve refuted in a way that points at HiGHS's presolve?

    Two refutations do. One is a refutation over its OWN integers again (#2187): the
    tolerance was not the cause. The other is the #1634 cross-check: a presolve-free solve
    of the same model found a verified point below the presolved certificate. That is
    direct evidence against presolve. Measured on the #2187 ``s413_p1`` net with highspy
    1.16.0: the tight re-solve at 1e-9 certified -53.1465305 with presolve on. Its
    presolve-free cross-solve certified -54.5248664 (bound 3.4e-13 from its point) and
    refuted it. The re-solve then carried no ``refuted_by``, so the presolve-free stage
    never ran and the route stayed ``feasible`` with gap 0.915. On 1.15.1 the same
    re-solve is refuted over its own integers instead.
    """
    return again.refuted_by == "own-integers" or bool(
        again.stats.get("milp/presolve_certificate_refuted")
    )


def _tight_adoption_problem(
    sf: StdForm,
    again: HighsOutcome,
    best: tuple[np.ndarray, float],
    kw: dict[str, Any],
) -> tuple[Optional[str], tuple[np.ndarray, float]]:
    """#2151's adoption test for a re-solve after a refutation, factored out (#2187).

    Returns ``(why, best)``. ``why`` is ``None`` when ``again`` may replace the refuted
    result: a certified ``optimal`` whose bound lies below every verified point in hand
    (``best`` and ``again``'s own incumbent) within
    ``REFUTED_ADOPT_ABS + REFUTED_ADOPT_REL |bound|``, and that closes the route's gap
    on the better of the two points. ``best`` is that better point.
    """
    if not (again.gap_certified and again.status == "optimal" and again.bound is not None):
        return f"tight re-solve status {again.status}", best
    why = None
    b = float(again.bound)
    thr = REFUTED_ADOPT_ABS + REFUTED_ADOPT_REL * abs(b)
    own = _verified_mip_point(sf, again.x)
    for p in [best] + ([own] if own is not None else []):
        if b - p[1] > thr:
            why = f"tight bound {b:.12g} is above a verified point's objective {p[1]:.12g}"
            break
    if own is not None and own[1] < best[1]:
        best = own
    if why is None and not _gap_closed(best[1], min(b, best[1]), kw):
        why = f"tight bound {b:.12g} does not close the gap to {best[1]:.12g}"
    return why, best


def _refuted_presolve_free_enabled() -> bool:
    """``DISCOPT_MILP_REFUTED_PRESOLVE_FREE`` (#2187, default ON; ``=0`` leaves a
    refuted #2151 tight re-solve declined, as before #2187).

    Gates the presolve-free stage of :func:`_tight_resolve_refuted`, which runs only
    after the tight re-solve was itself refuted over its own integers or by its #1634
    presolve-free cross-check (:func:`_refuted_by_presolve`, #2221). The panel is
    recorded in ``docs/dev/flag-retirement-audit.md``. The opt-out keeps the
    pre-#2187 route reachable for A/B measurement.
    """
    return os.environ.get("DISCOPT_MILP_REFUTED_PRESOLVE_FREE", "1") != "0"


def _tree_below_root_repair_enabled() -> bool:
    """``DISCOPT_MILP_TREE_BELOW_ROOT_REPAIR`` (#2187, default ON; ``=0`` returns
    ``error`` when HiGHS's tree bound is below the NS-safe root bound, as before #2187).

    The panel is recorded in ``docs/dev/flag-retirement-audit.md``. The opt-out keeps
    the pre-#2187 route reachable for A/B measurement.
    """
    return os.environ.get("DISCOPT_MILP_TREE_BELOW_ROOT_REPAIR", "1") != "0"


def _repair_tree_below_root(
    sf: StdForm,
    out: HighsOutcome,
    root: float,
    labels: dict[str, str],
    stats: dict[str, float],
    gap_kw: dict[str, Any],
    time_limit: Optional[float],
) -> bool:
    """#2187: HiGHS's tree bound is below the NS-safe root bound; publish the root bound.

    Returns ``True`` when ``out`` became an ``error`` and the caller should stop.

    A lower bound below a valid lower bound is weaker, not false, so this was never a
    soundness failure. The tree bound is dropped, not trusted: HiGHS's tree may have
    solved something other than this relaxation, so nothing it derived is kept. What
    remains is a certificate that never depended on HiGHS's tree: the NS-safe root
    bound plus the verified incumbent. It certifies only if it closes the gap by the
    route's own stop rule. The later checks (#1410 root duals, #1509 refutation, #1634
    presolve cross-check) still run on it.

    Measured on a 2-32-32-1 ``relu_extended`` net: HiGHS stops at its root, at its
    defaults (``mip_feasibility_tolerance`` 1e-6, ``mip_rel_gap`` 1e-4). Its bound
    20.5560727 is its own root LP, solved within that tolerance, and it sits 5.4e-5
    (2.6e-6 relative) below the exact LP's NS bound 20.5561267. At
    ``mip_feasibility_tolerance`` 1e-9 the tree bound is above the root bound on every
    stop rule. The 1e-6 (1 + |b|) threshold of the check is tighter than a 1e-6
    feasibility tolerance can keep to on this matrix, so the route used to return
    ``error``, with no objective and no bound, for a result the root LP alone
    certifies (relative gap 5.7e-7).

    An incumbent below the root bound by more than the LP yardstick is not a point: no
    exactly feasible point beats a valid lower bound, so it bought its objective with row
    tolerance (the #1612 class). It is replaced by the verified point of the LP over its
    own integers (:func:`_fixed_integer_lp`) when that point is not itself below the
    bound, and certified only if the root bound closes the gap on it. Measured on
    highspy 1.11.0, where HiGHS's own incumbent on the net above is 20.5560762 (5.05e-5
    under the bound): the LP over its integers gives 20.5561384254, the ``relu_bigm``
    optimum. With no such point the incumbent is withdrawn, and a ``kOptimal`` becomes
    the ``error`` it was before #2187. Measured on ``test_1447``'s tree ensemble pinned
    exactly on a split threshold (``split_eps`` = 1e-6, infeasible by exactly the
    tolerance): HiGHS's 1.0 sits 4e-6 under the root bound and the LP over its integers
    is infeasible.
    """
    tree = float(out.bound)  # type: ignore[arg-type]
    stats["milp/tree_bound_below_root"] = root - tree
    labels["milp/tree_bound_below_root"] = (
        f"tree bound {tree:.12g} below the NS-safe root bound {root:.12g}; tree bound dropped"
    )
    labels["milp/bound_provenance"] = "root-ns"
    logger.info("HiGHS MILP route: %s (#2187)", labels["milp/tree_bound_below_root"])
    thr = CERT_ABS + CERT_REL * abs(root)
    was_optimal = out.status == "optimal"
    if out.objective is not None and root - float(out.objective) > thr:
        stats["milp/incumbent_below_root"] = root - float(out.objective)
        pt = None
        if out.x is not None and sf.int_idx.size and (time_limit is None or time_limit > 0.0):
            fx = _fixed_integer_lp(sf, out.x, time_limit)
            pt = _verified_mip_point(sf, fx.x) if fx.status == "optimal" else None
            if pt is not None and root - float(pt[1]) > thr:
                pt = None
        if pt is None:
            stats["milp/incumbent_below_root_withdrawn"] = 1.0
            labels["milp/certificate"] = "declined"
            out.x, out.objective, out.gap_certified = None, None, False
            out.bound = root
            if was_optimal or out.status == "feasible":
                # The route's rule for a result without a point: "feasible" only with
                # one (``"feasible" if out.x is not None else "error"``). A limit exit
                # with no incumbent stays the limit it is (review of #2189).
                status_in = out.status
                out.status = "error"
                out.message = (
                    f"HiGHS MILP {status_in}: incumbent below the NS-safe root bound "
                    f"{root:.12g} and no point over its integers reaches the bound"
                )
                return True
            return False
        stats["milp/incumbent_rederived_below_root"] = 1.0
        out.x, out.objective = np.asarray(pt[0], dtype=np.float64), float(pt[1])
    if out.objective is None:
        out.bound = root
        if was_optimal:
            # HiGHS reports a point with every kOptimal, so this is not reached today. An
            # "optimal" with no incumbent has nothing to certify (review of #2189).
            out.status, out.gap_certified = "error", False
            out.message = "HiGHS MILP kOptimal without an incumbent"
            labels["milp/certificate"] = "declined"
            return True
        return False
    out.bound = min(root, float(out.objective))
    if was_optimal:
        closed = _gap_closed(float(out.objective), float(out.bound), gap_kw)
        out.gap_certified = closed
        if not closed:
            out.status = "feasible"
            labels["milp/certificate"] = "declined"
    return False


#: Labels that mark a result as declined; on adoption they are moved to history.
_DECLINE_LABELS = ("milp/certificate", "milp/highs_certificate", "milp/bound_provenance")


def _as_history(d: dict[str, Any], also: tuple[str, ...]) -> dict[str, Any]:
    """``d`` with every ``milp/*refut*`` key, and each key in ``also``, moved under
    ``milp/before_tight_resolve/`` (#2151)."""
    return {
        (
            "milp/before_tight_resolve/" + k[5:]
            if k.startswith("milp/") and ("refut" in k or k in also)
            else k
        ): v
        for k, v in d.items()
    }


def _solve_milp_scaled(sf: StdForm, *, presolve: bool = True, **kw: Any) -> HighsOutcome:
    """:func:`_solve_milp_std` with the #1537 logical rescaling and its #1621 cross-check."""
    kw = dict(kw, presolve=presolve)
    f = logical_column_scales(sf, kw["n_struct"])
    if f is None:
        return _solve_milp_std(sf, **kw)
    t0 = time.perf_counter()
    out = _solve_milp_std(_scale_logicals(sf, f), **kw)
    # Back to ``sf``'s variables: x = f x'; a reduced cost is per unit of the column,
    # d = d' / f; a primal ray is a direction in column space. Row duals and a Farkas
    # ray live in row space, and the rows were not touched.
    if out.x is not None:
        out.x = np.asarray(out.x, dtype=np.float64) * f
    if out.col_dual is not None:
        out.col_dual = np.asarray(out.col_dual, dtype=np.float64) / f
    if out.ray is not None and out.status == "unbounded" and np.size(out.ray) == sf.n:
        out.ray = np.asarray(out.ray, dtype=np.float64) * f
    # The rescaling is exact for the MODEL, not for its tolerances: the slack's bound
    # ``s' >= -tol`` is ``s >= -f tol`` in ``sf``'s variables, so a point can be
    # feasible in the scaled form and violate a row of ``sf`` by up to ``f tol``. On
    # ``min -x + 3z, x <= M z`` (M = 1e8, #1414's class) that let x = ub, z = 0 -- a
    # 10-unit violation, 1.5e-7 in the scaled slack -- be certified at -10 against a
    # true -7. So the mapped point is re-verified on ``sf`` itself, with the same
    # checks the route applies to every HiGHS point; if it fails, the rescaled answer
    # is discarded and ``sf`` is solved as given (the pre-#1537 path, whose #1295
    # guard then decides what may be certified).
    if out.x is not None:
        why = readback_problem(out.x, sf) or feasibility_problem(out.x, sf, check_integrality=True)
        if why:
            if kw["time_limit"] is not None:
                kw["time_limit"] = max(0.0, float(kw["time_limit"]) - (time.perf_counter() - t0))
            plain = _solve_milp_std(sf, **kw)
            plain.stats["milp/logicals_rescale_refused"] = 1.0
            plain.labels["milp/logicals_rescale_refused"] = why
            return plain
    out.stats["milp/logicals_rescaled"] = float(np.count_nonzero(f != 1.0))
    if out.gap_certified and out.status in ("optimal", "infeasible"):
        return _cross_check_rescaled(sf, out, kw, t0)
    return out


def _cross_check_rescaled(
    sf: StdForm, out: HighsOutcome, kw: dict[str, Any], t0: float
) -> HighsOutcome:
    """#1621: hold a certificate earned on the rescaled form against ``sf`` itself.

    The incumbent re-verification in :func:`solve_milp_std` covers the POINT of an
    ``optimal`` result; it says nothing about the bound, and an ``infeasible`` has no
    point at all. Both certificates were measured false through the rescaling (#1621:
    ``infeasible`` at M = 1e9 and ``optimal`` 0 at M = 1e10 on a MILP whose optimum is
    473,958.43). So ``sf`` is solved as given and its VERIFIED incumbent, if any, is
    held against the rescaled claim: any verified point refutes ``infeasible``, and a
    verified point below the certified bound by more than the route's own equality
    yardstick (``CERT_ABS + CERT_REL |bound|``, as in the #1509 refutation) refutes
    ``optimal``. A refuted claim is discarded and the plain solve is published -- the
    pre-#1537 path, whose #1295 guard then decides what may be certified.

    This is a falsifier, not a proof, in the #1509 sense: a cross-solve that yields no
    verified point is no evidence either way and the rescaled certificate stands. A
    cross-check that cannot run for want of budget is a safety net that never ran, so
    the certificate is withdrawn (the #1309 rule).
    """
    kw = dict(kw)
    if kw["time_limit"] is not None:
        kw["time_limit"] = max(0.0, float(kw["time_limit"]) - (time.perf_counter() - t0))
        if kw["time_limit"] <= 0.0:
            out.stats["milp/rescale_cross_check_skipped"] = 1.0
            out.labels["milp/certificate"] = "declined"
            out.gap_certified = False
            out.message = (
                "certificate from the rescaled form withdrawn: no time budget left to "
                "cross-check it against the unscaled model (#1621)"
            )
            if out.status == "optimal":
                out.status = "feasible"
                out.bound = out.root_bound
                if out.bound is not None and out.objective is not None:
                    out.bound = min(out.bound, out.objective)
            else:
                out.status, out.bound = "error", None
            return out
    plain = _solve_milp_std(sf, **kw)
    out.stats["milp/rescale_cross_check_ran"] = 1.0
    pt = _verified_mip_point(sf, plain.x)
    refuted = None
    if pt is not None:
        if out.status == "infeasible":
            refuted = f"a verified point of objective {pt[1]:.12g} exists"
        else:
            # A certified optimum's claim is its bound (``objective`` when HiGHS gave
            # none: certified means the incumbent is optimal).
            claim = out.bound if out.bound is not None else out.objective
            if claim is not None and claim - pt[1] > CERT_ABS + CERT_REL * abs(claim):
                refuted = f"bound {claim:.12g} is above a verified point's objective {pt[1]:.12g}"
    if refuted is None:
        return out
    logger.warning(
        "HiGHS MILP route: the rescaled-form %s certificate is refuted on the unscaled "
        "model (%s); publishing the unscaled solve instead (#1621)",
        out.status,
        refuted,
    )
    plain.stats["milp/rescale_certificate_refuted"] = 1.0
    plain.labels["milp/rescale_certificate_refuted"] = f"{out.status}: {refuted}"
    return plain


def _withdraw(out: HighsOutcome, why: str, cross: Optional[HighsOutcome] = None) -> HighsOutcome:
    """#1634: strip a HiGHS MILP certificate the presolve cross-check could not confirm.

    Mirrors ``decertify_root_check`` (#1309/#1320): ``optimal`` keeps its verified
    incumbent as an uncertified ``feasible`` over the NS-safe root bound; ``infeasible``
    has no incumbent and becomes ``error``.

    #1920: when the presolve-free cross-solve RAN and left a bound of its own (it hit
    the budget without a verdict, and did not refute the primary), the published bound
    is ``max(root, min(primary tree bound, cross tree bound))``. ``min`` of the two
    configurations' bounds is the rule :func:`_weaker_bound` already certifies on (they
    fail on disjoint instances, so the ``min`` is valid whenever either is), and each
    is the same floating-point tree bound the route publishes on any budgeted exit.
    Falling back to the root bound alone made the bound non-monotone in the time limit:
    measured on a 2-32-32-1 ``relu_bigm`` net, ``time_limit=5`` returned HiGHS's tree
    bound -2.06, while ``time_limit=11`` (kOptimal at ~8 s, cross-solve cut off at
    ~3 s) returned the root bound -5.82; the issue's 600 s run returned -15.30 against
    -4.38 at 180 s. With no cross bound, or a refuted primary, the root bound stands.
    """
    out.labels["milp/certificate"] = "declined"
    out.gap_certified = False
    out.message = f"HiGHS MILP certificate withdrawn: {why} (#1634)"
    provenance = "root-ns"
    if out.status == "optimal":
        out.status = "feasible"
        tree = None
        if cross is not None and cross.bound is not None and out.bound is not None:
            tree = min(float(out.bound), float(cross.bound))
        if tree is not None and (out.root_bound is None or tree > out.root_bound):
            out.bound = tree
            provenance = "min(presolved, presolve-free)"
            out.stats["milp/withdrawn_bound_from_trees"] = 1.0
        else:
            out.bound = out.root_bound
        if out.bound is not None and out.objective is not None:
            out.bound = min(out.bound, out.objective)
    else:
        out.status, out.bound = "error", None
    out.labels["milp/bound_provenance"] = provenance if out.bound is not None else "none"
    return out


#: #1655: budget of the #1634 presolve-free cross-solve, as a multiple of the primary
#: solve's wall time (floored at :data:`PRESOLVE_CROSS_MIN_BUDGET` seconds).
PRESOLVE_CROSS_BUDGET_FACTOR = 20.0
PRESOLVE_CROSS_MIN_BUDGET = 2.0

#: #1655: magnitude cap on the integral matrix and cost entries of
#: :func:`presolve_exact_class`.
PRESOLVE_EXACT_MAX_COEF = 1000.0


def presolve_exact_class(sf: StdForm) -> bool:
    """Is ``sf`` in the class where HiGHS's absolute presolve tolerances are exact?

    #1655: the #1634 cross-check exists because HiGHS's MIP presolve decides on
    ABSOLUTE tolerances (1e-7 on costs, 1e-6 on rows) and, on a badly scaled model,
    treats a nonzero difference as a tie -- #1634's witness fixed ``x2`` on a cost
    difference of ``0.0064 / 4.9e5 = 1.3e-8``. When every matrix entry and cost is an
    integer of magnitude at most :data:`PRESOLVE_EXACT_MAX_COEF` = 1e3, and every
    right-hand side and finite bound an integer below 2**52, the quantities that
    mechanism compares are exact: a cost difference per unit of a column,
    ``c_j/a_ij - c_k/a_ik``, is a rational with denominator at most 1e6, so it is 0 or
    at least 1e-6 -- ten times the 1e-7 tie tolerance -- and a row-activity
    difference over integral bounds is 0 or at least 1. Every #1634 witness and
    generator instance has non-integral entries spanning nine decades; the class
    excludes all of them by construction. Every other route check (#1295, #1410,
    #1509, the NS root bound) still runs on such a model.
    """
    if sf.A.nnz == 0:
        return False
    vals = [np.asarray(sf.A.data, dtype=np.float64), np.asarray(sf.c, dtype=np.float64)]
    for v in vals:
        if not (np.all(np.abs(v) <= PRESOLVE_EXACT_MAX_COEF) and np.all(v == np.round(v))):
            return False
    lim = 2.0**52
    rest = [np.asarray(sf.b, dtype=np.float64)]
    fin_l = sf.xl[sf.xl > -READBACK_LIMIT]
    fin_u = sf.xu[sf.xu < READBACK_LIMIT]
    for v in (*rest, fin_l, fin_u):
        a = np.asarray(v, dtype=np.float64)
        if not (np.all(np.abs(a) < lim) and np.all(a == np.round(a))):
            return False
    return True


def _cross_check_presolve(sf: StdForm, out: HighsOutcome, kw: dict[str, Any]) -> HighsOutcome:
    """#1634: hold a HiGHS MILP certificate against a second, presolve-free solve.

    HiGHS's MIP presolve and tree decide on ABSOLUTE tolerances (1e-7 on costs, 1e-6
    on rows). On a badly scaled MILP those stop meaning what they say, and HiGHS then
    prunes a strictly feasible optimum and certifies the wrong value with every route
    guard passing: #1634's witnesses certified 0.02082 against a true 0.00801 (slack
    >= 72). One mechanism is pinned -- the parallel-column rule, now off
    (:data:`MILP_PRESOLVE_RULE_OFF`) -- but measured on the #1634 generator panel the
    class is wider than one rule: with it off, an always-on reduction still cut the
    optimum (6-column panel seed 965, at the first presolve step), and with presolve
    off entirely HiGHS's own tree did (seed 298). Neither configuration is sound on
    its own on this class; on the panel they never failed on the same instance.

    So the primary result is held against the other configuration's VERIFIED
    incumbent, the #1509/#1621 falsifier: a verified point refutes ``infeasible``, and
    a verified point below the certified bound by more than the route's equality
    yardstick (``CERT_ABS + CERT_REL |bound|``) refutes ``optimal``. A refuted
    certificate is declined loudly: the best verified point is published as
    ``feasible`` with the NS-safe root bound, never the presolve-free solve's own
    certificate -- on an instance where two HiGHS configurations disagree neither has
    earned one. An unrefuted certificate must still be CONFIRMED by the cross-solve
    (:func:`_weaker_bound`); one that cannot run for want of budget is withdrawn (#1309).
    The budget already spent is the primary solve's ``wall_time``.
    """
    if presolve_exact_class(sf):
        # #1655: the hazard this check exists for cannot arise here (see
        # :func:`presolve_exact_class`), and on such a model -- a pure-binary
        # scheduling MILP HiGHS proves in 0.07 s -- the presolve-free solve ran for
        # the whole budget and withdrew a correct certificate (260-330 s without a
        # limit). Every other route check still ran on the primary.
        out.stats["milp/presolve_cross_check_exact_class"] = 1.0
        return out
    kw = dict(kw)
    if kw["time_limit"] is not None:
        kw["time_limit"] = max(0.0, float(kw["time_limit"]) - float(out.wall_time))
        if kw["time_limit"] <= 0.0:
            out.stats["milp/presolve_cross_check_skipped"] = 1.0
            return _withdraw(
                out, "no time budget left to cross-check it against a presolve-free solve"
            )
    # #1655: a cross-solve that cannot conclude quickly is given up quickly. Its
    # no-verdict outcome is a withdrawal either way (below), so capping it only
    # changes how long the withdrawal takes, never what is certified on a verdict
    # that arrives within the cap.
    cap = max(PRESOLVE_CROSS_MIN_BUDGET, PRESOLVE_CROSS_BUDGET_FACTOR * float(out.wall_time))
    if kw["time_limit"] is None or kw["time_limit"] > cap:
        kw["time_limit"] = cap
        out.stats["milp/presolve_cross_check_budget"] = cap
    # #1733: the cross-solve is a falsifier only if it is independent of the primary's
    # claim. Handed the user's warm start, it took that point too and confirmed the
    # primary's false kOptimal at it (433.40 certified against a true 363.40); cold, it
    # reached no verdict and the certificate was withdrawn.
    kw["initial_point"] = None
    cross = _solve_milp_scaled(sf, presolve=False, **kw)
    out.stats["milp/presolve_cross_check_ran"] = 1.0
    out.stats["milp/presolve_cross_check_time"] = float(cross.wall_time)
    return _judge_presolve_cross(sf, out, cross, kw)


def _judge_presolve_cross(
    sf: StdForm, out: HighsOutcome, cross: HighsOutcome, kw: dict[str, Any]
) -> HighsOutcome:
    """The verdict half of :func:`_cross_check_presolve`: hold the certified primary
    ``out`` against the presolve-free ``cross``. ``kw["time_limit"]`` is the budget
    left before the cross-solve's wall time is charged, unless ``kw`` says it already
    was (``_cross_wall_charged``, the concurrent path of :func:`_certified_milp`)."""
    rederived: list = []
    pt = _rederived_point(sf, cross.x, kw["time_limit"], out.stats, rederived)
    refuted = None
    if pt is not None:
        if out.status == "infeasible":
            refuted = f"a verified point of objective {pt[1]:.12g} exists"
        else:
            claim = out.bound if out.bound is not None else out.objective
            if claim is not None and claim - pt[1] > CERT_ABS + CERT_REL * abs(claim):
                refuted = f"bound {claim:.12g} is above a verified point's objective {pt[1]:.12g}"
    if refuted is None or pt is None:
        # #2187: the #1678 adoption uses this re-derived point, never the raw one.
        return _weaker_bound(sf, out, cross, dict(kw, _cross_rederived=rederived[:1]))
    logger.warning(
        "HiGHS MILP route: the %s certificate is refuted by a presolve-free HiGHS solve "
        "(%s); reporting the verified point uncertified (#1634)",
        out.status,
        refuted,
    )
    x, obj = pt
    mine = _verified_mip_point(sf, out.x)
    if mine is not None and mine[1] < obj:
        x, obj = mine
    # Both root bounds are NS-safe lower bounds of ``sf``; the larger is still valid.
    roots = [b for b in (out.root_bound, cross.root_bound) if b is not None]
    bound = min(max(roots), obj) if roots else None
    stats = {**cross.stats, **out.stats, "milp/presolve_certificate_refuted": 1.0}
    # #2151: the cross-solve's own refutation provenance does not describe this result.
    labels = {
        **{k: v for k, v in cross.labels.items() if k != "milp/refuted_by"},
        **out.labels,
        "milp/certificate": "declined",
        "milp/bound_provenance": "root-ns" if bound is not None else "none",
        "milp/presolve_certificate_refuted": f"{out.status}: {refuted}",
    }
    return HighsOutcome(
        "feasible",
        x=x,
        objective=obj,
        bound=bound,
        gap_certified=False,
        message=(
            f"HiGHS MILP {out.status} certificate refuted by a presolve-free solve: "
            f"{refuted} (#1634)"
        ),
        highs_status=out.highs_status,
        node_count=out.node_count + cross.node_count,
        iterations=out.iterations + cross.iterations,
        root_bound=bound,
        root_time=out.root_time,
        wall_time=out.wall_time + cross.wall_time,
        stats=stats,
        labels=labels,
    )


def _gap_closed(obj: float, bound: float, kw: dict[str, Any]) -> bool:
    """The route's stop rule (HiGHS's ``mip_abs_gap`` OR ``mip_rel_gap``)."""
    gap = max(0.0, obj - bound)
    abs_tol = kw.get("abs_gap_tolerance")
    return gap <= (1e-6 if abs_tol is None else abs_tol) or (
        gap / max(abs(obj), abs(bound), 1e-10) <= kw["gap_tolerance"]
    )


def _adopt_better_cross_incumbent(
    sf: StdForm, out: HighsOutcome, cross: HighsOutcome, rederived: Optional[list]
) -> None:
    """#1678 II.19: publish the cross-solve's incumbent when it is verified and better.

    The presolve-free solve is a full HiGHS solve; its incumbent often beats the
    primary's (measured: multi-knapsack ``NV=30, NR=5``, ``gap_tolerance=0.01``, seed
    103 -- primary -126.0943, cross -126.5926, and the route kept the worse point).
    Discarding a point the route has itself verified costs the incumbent, and -- since
    the gap is re-tested against ``out.objective`` -- it can also cost the
    certificate: the cross bound is certified relative to the cross incumbent, so
    re-testing it against the worse primary incumbent can reopen a gap that is
    closed. Only the point moves; it passes :func:`_verified_mip_point`, the same
    gates as any HiGHS incumbent, and no bound is adopted from it. The caller has
    already ruled out a point refuting the primary's bound by more than the equality
    yardstick (:func:`_cross_check_presolve`).

    A point better by no more than that same yardstick (``CERT_ABS + CERT_REL |obj|``)
    is not adopted: the verifier admits rows violated within tolerance, so such a gain
    is tolerance, not a better point. Measured on the #1640 piecewise case: the
    cross point verified at -7.3e-7 against an exact optimum of 0 (the primary's), and
    adopting it published a super-optimal incumbent that the solve-level verifier then
    refused and re-solved.

    #2187: a gain larger than the yardstick can be tolerance too, so the point adopted is
    the cross incumbent RE-DERIVED by the LP over its own integers
    (:func:`_fixed_integer_lp`), never the raw HiGHS point -- the #1920 rule of
    :func:`_merge_uncertified_cross`. The verifier's row tolerance is relative, and a
    network row chain amplifies it. Measured on a 2-32-32-1 ``relu_extended`` net
    (a hidden-neuron permutation of #2187's ``s406_p0``): the raw cross point verified at
    -38.1894713, 4.34e-5 "better" than the primary's, while the network's exact value at
    its inputs is -38.1894279, and so is the LP over its integers. The route certified
    -38.1894713 with that as its bound. ``rederived`` is the LP point
    :func:`_judge_presolve_cross` already re-derived (``[point]``), ``[]`` when that LP
    gave none or had no budget (nothing is adopted), or ``None`` when no caller
    re-derived it (a direct call): then the LP is solved here, unbudgeted. The judge's
    point is reused so the LP is not solved twice, and nothing runs outside its budget.
    """
    if out.objective is None:
        return
    raw = _verified_mip_point(sf, cross.x)
    if raw is None:
        return
    thr = CERT_ABS + CERT_REL * abs(out.objective)
    if out.objective - raw[1] <= thr:
        return
    pt = raw
    if sf.int_idx.size:
        if rederived is None:
            fx = _fixed_integer_lp(sf, raw[0], None)
            lp_pt = _verified_mip_point(sf, fx.x) if fx.status == "optimal" else None
        else:
            lp_pt = rederived[0] if rederived else None
        if lp_pt is None:
            out.stats["milp/presolve_cross_incumbent_not_rederived"] = 1.0
            return
        out.stats["milp/presolve_cross_incumbent_rederive_shift"] = float(lp_pt[1] - raw[1])
        pt = lp_pt
        if out.objective - pt[1] <= thr:
            return
    out.stats["milp/presolve_cross_incumbent_adopted"] = 1.0
    out.stats["milp/presolve_cross_incumbent_gain"] = float(out.objective - pt[1])
    out.x, out.objective = pt


def _weaker_bound(
    sf: StdForm, out: HighsOutcome, cross: HighsOutcome, kw: dict[str, Any]
) -> HighsOutcome:
    """#1634: a certificate stands only if the presolve-free solve AGREES with it.

    Agreement means the cross-solve reached the same certified verdict (``infeasible``
    for ``infeasible``; a certified ``optimal`` for ``optimal``). A cross-solve with no
    verdict -- an error, a limit, a rejected incumbent -- is the #1309 case: the check
    that exists to catch a false certificate produced nothing, so the certificate is
    withdrawn rather than standing on the absence of evidence. Measured on the panel
    (6-column seed 965) this is not hypothetical: the presolved bound sat 3e-6 above the
    enumerated optimum, and the presolve-free solve's kOptimal incumbent failed the
    route's row re-verification, so the falsifier had no point to hold up.

    When both are certified ``optimal``, the WEAKER of the two bounds is published.

    A point can only refute a bound by more than the equality yardstick; a bound that is
    wrong by less (or one the cross-solve's incumbent, itself stopped at the route's gap
    tolerance, does not reach) survives the falsifier. Measured on the panel (6-column
    seed 965): the presolved bound sat 3e-6 above the enumerated optimum while the
    presolve-free bound was below it. The two configurations failed on disjoint
    instances, so ``min`` of the two bounds is valid whenever either one is -- the
    certificate then rests on the claim of whichever configuration is right. The gap is
    re-tested against the route's own stop rule; a gap the weaker bound reopens is
    declined, not certified -- unless the presolve-free solve re-run at a 100x tighter
    feasibility tolerance confirms the claim (#1640, :func:`_tight_cross_bound`): the
    cross bound sits below the optimum by about ``mip_feasibility_tolerance`` times a
    row coefficient, the same order as the 1e-6 absolute gap, so at 1e-6 it can reopen
    a gap on a correct certificate.

    #2187: a certificate whose bound is the NS-safe root LP
    (:func:`_repair_tree_below_root`) has no presolved tree bound in it. It is that
    bound plus the verified incumbent, and neither went through HiGHS's presolve, so
    there is nothing for the presolve-free solve to confirm or weaken. It stands as it
    is, and the cross-solve's incumbent is not adopted. On the #2187 net that incumbent
    was 5.1e-5 below the root bound, i.e. a row-tolerance artefact.
    """
    if (
        out.status == "optimal"
        and out.gap_certified
        and "milp/tree_bound_below_root" in out.stats
        and out.labels.get("milp/bound_provenance") == "root-ns"
    ):
        out.stats["milp/presolve_cross_moot_root_bound"] = 1.0
        out.labels["milp/presolve_cross_status"] = cross.status
        return out
    if not (cross.gap_certified and cross.status == out.status):
        out.stats["milp/presolve_cross_check_no_verdict"] = 1.0
        out.labels["milp/presolve_cross_status"] = cross.status
        return _withdraw(
            out,
            f"the presolve-free cross-solve did not confirm it (status {cross.status}: "
            f"{cross.message or 'no message'})",
            cross,
        )
    if out.status != "optimal" or out.bound is None or cross.bound is None:
        return out
    out.stats["milp/presolve_cross_bound"] = float(cross.bound)
    _adopt_better_cross_incumbent(sf, out, cross, kw.get("_cross_rederived"))
    if cross.bound >= out.bound:
        if out.objective is not None and out.bound > out.objective:
            out.bound = out.objective
        return out
    claim = float(out.bound)
    out.bound = min(cross.bound, out.objective) if out.objective is not None else cross.bound
    out.labels["milp/bound_provenance"] = "min(presolved, presolve-free)"
    out.stats["milp/presolve_cross_bound_lowered"] = 1.0
    if out.objective is None:
        return out
    closed = _gap_closed(out.objective, out.bound, kw)
    if not closed:
        closed = _tight_cross_bound(sf, out, cross, kw, claim)
    if not closed:
        out.gap_certified = False
        out.status = "feasible"
        out.labels["milp/certificate"] = "declined"
        out.message = (
            "HiGHS MILP: the presolve-free cross-solve's bound reopens the gap, so the "
            "result is not certified (#1634)"
        )
    return out


#: #1640: ``mip_feasibility_tolerance`` of the re-run presolve-free cross-solve. Its
#: bound is HiGHS's tree bound over node LPs solved to ``mip_feasibility_tolerance``,
#: so it sits below the true optimum by about that tolerance times the row scale --
#: the same order as the route's 1e-6 absolute gap. Measured on the #1494 piecewise
#: ``log``/max case (offset 1e4, h = 1): the cross bound is -1.5e-6 at 1e-6 and
#: -1.5e-8 at 1e-8, while ``mip_abs_gap = mip_rel_gap = 0`` leaves it unchanged.
CROSS_TIGHT_FEAS_TOL = 1e-8

#: ``mip_feasibility_tolerance`` of the first cross-solve (HiGHS's default, which
#: :func:`_solve_milp_std` keeps).
CROSS_FEAS_TOL = 1e-6

#: How far above the cross bound the tight bound may land and still count as the
#: same answer with less tolerance error: ``factor * CROSS_FEAS_TOL * max|c| * max|A|``
#: (each floored at 1). Measured on the #1640 case: shift 1.5e-6 against a slack of
#: 1e-4 x the coefficient scale.
CROSS_TIGHT_SHIFT_FACTOR = 100.0


def _tight_cross_bound(
    sf: StdForm, out: HighsOutcome, cross: HighsOutcome, kw: dict[str, Any], claim: float
) -> bool:
    """#1640: re-run the presolve-free cross-solve at a tighter feasibility tolerance
    when its bound -- and only its bound -- reopened the route's gap.

    The cross bound being weaker than the primary's by about ``mip_feasibility_tolerance``
    times a row coefficient is what that tolerance does to a tree bound, not evidence of
    a false primary certificate; but which of the two it is cannot be told from the
    numbers. So the question is asked again with the tolerance 100x tighter, and the
    tighter solve must earn the confirmation the same way the first one had to: a
    certified ``optimal`` of its own, no verified point refuting the claim (the
    #1509/#1621 falsifier), and ``min(primary bound, tight bound)`` closing the gap
    under the route's stop rule. The published bound is that minimum, so it is
    valid whenever the primary or the tight solve is right; because the cross bound
    is dropped, the tight bound must also land within a tolerance-scaled slack of it
    (:data:`CROSS_TIGHT_SHIFT_FACTOR`) -- a larger jump is two certified solves
    disagreeing, not tolerance error. Anything else --
    no budget, no verdict, a refutation, a gap that stays open -- leaves the
    certificate declined, as before. ``claim`` is the primary's own certified bound. On
    success ``out.bound`` is replaced and True is returned.
    """
    obj = out.objective
    if obj is None:
        return False
    kw = dict(kw)
    kw.pop("_cross_rederived", None)  # #2187: the #1678 adoption's, not a solve option
    charged = kw.pop("_cross_wall_charged", False)
    if kw["time_limit"] is not None:
        # ``kw`` already had the primary's wall time taken off by the caller
        # (:func:`_cross_check_presolve`); only the cross-solve's is left to charge --
        # unless it ran concurrently and the caller charged the elapsed wall (#1920).
        if not charged:
            kw["time_limit"] = float(kw["time_limit"]) - float(cross.wall_time)
        if kw["time_limit"] <= 0.0:
            out.stats["milp/presolve_cross_tight_skipped"] = 1.0
            return False
    tight = _solve_milp_scaled(
        sf, **dict(kw, presolve=False, feasibility_tolerance=CROSS_TIGHT_FEAS_TOL)
    )
    out.stats["milp/presolve_cross_tight_ran"] = 1.0
    out.stats["milp/presolve_cross_tight_time"] = float(tight.wall_time)
    if not (tight.gap_certified and tight.status == "optimal" and tight.bound is not None):
        out.labels["milp/presolve_cross_tight_status"] = tight.status
        return False
    out.stats["milp/presolve_cross_tight_bound"] = float(tight.bound)
    pt = _verified_mip_point(sf, tight.x)
    if pt is not None and claim - pt[1] > CERT_ABS + CERT_REL * abs(claim):
        out.labels["milp/presolve_cross_tight_refuted"] = (
            f"bound {claim:.12g} is above a verified point's objective {pt[1]:.12g}"
        )
        return False
    # The confirmation drops the cross bound, so the tight solve must explain it as a
    # tolerance artefact rather than overrule it: a cross bound below the tight one by
    # more than the tolerance-scaled slack is a disagreement between two certified
    # solves, and the decline stands (review of #1649).
    if cross.bound is None:  # _weaker_bound only calls with a cross bound
        return False
    shift = float(tight.bound) - float(cross.bound)
    c_max = float(np.max(np.abs(sf.c))) if sf.c.size else 0.0
    a_max = float(np.max(np.abs(sf.A.data))) if sf.A.nnz else 0.0
    slack = CROSS_TIGHT_SHIFT_FACTOR * CROSS_FEAS_TOL * max(1.0, c_max) * max(1.0, a_max)
    out.stats["milp/presolve_cross_tight_shift"] = shift
    if shift > slack:
        out.labels["milp/presolve_cross_tight_disagrees"] = (
            f"tight bound {float(tight.bound):.12g} is {shift:.3g} above the cross bound "
            f"{float(cross.bound):.12g}, more than the tolerance slack {slack:.3g}"
        )
        return False
    bound = min(claim, float(tight.bound), obj)
    if not _gap_closed(obj, bound, kw):
        return False
    out.bound = bound
    out.labels["milp/bound_provenance"] = "min(presolved, presolve-free tight)"
    out.stats["milp/presolve_cross_tight_confirmed"] = 1.0
    return True


def _solve_milp_std(
    sf: StdForm,
    *,
    time_limit: Optional[float],
    gap_tolerance: float,
    abs_gap_tolerance: Optional[float] = None,
    max_nodes: int,
    initial_point: Optional[np.ndarray] = None,
    n_struct: Optional[int] = None,
    root_check: bool = True,
    presolve: bool = True,
    feasibility_tolerance: float = 1e-6,
    row_form: Optional[bool] = None,
    stop: Optional[_CrossStop] = None,
) -> HighsOutcome:
    """Solve the MILP ``sf`` under the §3.2 contract.

    ``stop`` lets another thread end HiGHS's tree search early (#1920): only the
    concurrent presolve-free cross-solve of :func:`_certified_milp` passes one. An
    interrupted solve ends as a ``kInterrupt`` limit exit, with whatever tree bound
    and incumbent it had, through exactly the checks of any other limit exit.

    ``row_form`` forces the #1733 logical folding on or off (``None``: the
    ``DISCOPT_MILP_ROW_FORM`` default with its HiGHS-version gate); only the
    :func:`_cross_form_infeasible_check` falsifier sets it.
    ``presolve=False`` switches HiGHS's presolve off; it is the second solve of the
    #1634 cross-check (:func:`_cross_check_presolve`), not a user option.
    ``feasibility_tolerance`` is HiGHS's ``mip_feasibility_tolerance``; only the #1640
    tightened cross-solve (:func:`_weaker_bound`) changes it.

    ``abs_gap_tolerance`` is ``Model.solve``'s absolute convergence tolerance
    (#1243), mapped onto HiGHS's ``mip_abs_gap``. The mapping is faithful:
    HiGHS stops when EITHER ``mip_rel_gap`` or ``mip_abs_gap`` is met, which is
    the same disjunction ``solver.py::_gap_values_converged`` applies on the
    Python tree, so a model certified here and a model certified there mean the
    same thing by the same numbers.

    ``None`` keeps the 1e-6 this route was written with -- which is also
    ``solver.py::_DEFAULT_ABS_GAP_TOL``, so an omitted argument changes nothing.
    It has to be reachable, though: this route is the DEFAULT for pure MILP, and
    a hardcoded absolute tolerance is exactly what #1243 exists to remove. A
    CALPHAD-style certificate is an absolute test on an optimum near zero, where
    the relative arm carries no information at all.
    """
    highspy = require_highspy()
    t0 = time.perf_counter()
    stats: dict[str, float] = {"route/lp_milp_backend": 1.0, "milp/bound_provenance_highs_fp": 1.0}
    labels = {"milp/bound_provenance": "highs-fp"}

    def remaining() -> Optional[float]:
        return None if time_limit is None else float(time_limit) - (time.perf_counter() - t0)

    # #1295: HiGHS's tree bound and infeasible label are floating-point results with
    # nothing re-derived from them. On a column its scaling cannot equilibrate they were
    # measured wrong (false optimum by up to 20 units), so for that class they are not
    # reported as a certificate: only the NS-safe root bound and a Farkas proof stand.
    open_ratio = open_column_coefficient_ratio(sf)
    stats["milp/open_column_coef_ratio"] = open_ratio
    unscalable = open_ratio < UNSCALABLE_OPEN_RATIO

    def decertify(out: HighsOutcome) -> None:
        stats["milp/decertified_unscalable"] = 1.0
        labels["milp/certificate"] = "declined"
        labels["milp/bound_provenance"] = "root-ns" if out.root_bound is not None else "none"
        why = (
            f"an entry on an unbounded column is {open_ratio:.3g} of its row's largest "
            f"(below {UNSCALABLE_OPEN_RATIO:.3g}); HiGHS's MIP certificate is not "
            "trusted on such models (#1295)"
        )
        if out.status == "infeasible":
            if labels.get("milp/infeasible_provenance") == "farkas-root-lp":
                return
            out.status, out.gap_certified, out.bound = "error", False, None
            out.message = f"HiGHS reported infeasible, unverified: {why}"
            return
        if out.status not in ("optimal", "feasible", "time_limit", "node_limit", "iteration_limit"):
            return
        if out.status == "optimal":
            out.status = "feasible"
        out.gap_certified = False
        out.bound = out.root_bound
        if out.bound is not None and out.objective is not None:
            out.bound = min(out.bound, out.objective)
        out.message = f"gap left uncertified: {why}"

    def done(out: HighsOutcome) -> HighsOutcome:
        out.wall_time = time.perf_counter() - t0
        if unscalable:
            decertify(out)
        out.stats = {**stats, **out.stats}
        out.labels = {**labels, **out.labels}
        return out

    rem = remaining()
    if rem is not None and rem <= 0.0:
        return done(HighsOutcome("time_limit", message="MILP time budget exhausted"))
    if stop is not None and stop.should_stop():
        return done(HighsOutcome("node_limit", message="MILP solve stopped before it ran"))
    opts: list[tuple[str, Any]] = [
        ("mip_rel_gap", float(gap_tolerance)),
        ("mip_abs_gap", 1e-6 if abs_gap_tolerance is None else float(abs_gap_tolerance)),
        ("mip_max_nodes", int(min(max(int(max_nodes), 0), _MAX_NODES_CAP))),
        ("mip_feasibility_tolerance", float(feasibility_tolerance)),
        ("primal_feasibility_tolerance", 1e-7),
        # #1634: HiGHS's parallel-column presolve fixes integers on an absolute
        # cost-tie test that bad coefficient ratios defeat; see the constant.
        ("presolve_rule_off", int(MILP_PRESOLVE_RULE_OFF)),
    ]
    if not presolve:
        opts.append(("presolve", "off"))
    if rem is not None:
        opts.append(("time_limit", float(rem)))
    h = _new_highs(highspy, opts)
    stats["highs/version"] = _version_number(h)
    # HiGHS MIP on the finite default ±9.999e19 box returns false kInfeasible. Measured
    # on adversarial MILPs, replaying the route's own standard form: 5 of 6 labelled
    # infeasible solve to optimal with that box at ±inf (one 6-column model: 4.0, as
    # with ±1e9), the sixth returns an undecided status instead of a false label.
    # HiGHS is handed the relaxation with those bounds open. That keeps an infeasible
    # label and a dual bound valid for ``sf``, and every incumbent is still verified
    # against the declared box below.
    huge_lo, huge_hi = _huge_box(sf)
    if huge_lo.any() or huge_hi.any():
        stats["milp/huge_box_relaxed"] = 1.0
    # HiGHS gets ``obj_const`` so ``mip_rel_gap`` is measured on the objective this
    # route publishes (#1536); both values read back below therefore include it.
    # #1617: an entry HiGHS would drop on the way in is absorbed into its row's range
    # instead -- a relaxation of ``sf``, so HiGHS's infeasible label and tree bound stay
    # valid for ``sf`` (see :func:`_absorb_tiny_entries`).
    sf_pass, row_lo, row_hi, n_tiny = _absorb_tiny_entries(_relax_huge_box(sf, huge_lo, huge_hi))
    if n_tiny:
        stats["milp/tiny_entries_absorbed"] = float(n_tiny)
    # #1733: HiGHS sees the logical columns as row bounds; see _eliminate_logicals.
    rf: Optional[_RowForm] = None
    if row_form is True or (row_form is None and _row_form_enabled()):
        if row_form is None and stats["highs/version"] < ROW_FORM_MIN_HIGHS:
            stats["milp/row_form_skipped_old_highs"] = 1.0
        else:
            sf_pass, row_lo, row_hi, rf = _eliminate_logicals(sf_pass, row_lo, row_hi, n_struct)
            if rf is not None:
                stats["milp/logicals_as_row_bounds"] = float(rf.cols.size)
    pass_st, pass_why = _pass_model(
        h,
        highspy,
        sf_pass,
        integer=True,
        offset=sf.obj_const,
        row_bounds=(row_lo, row_hi) if n_tiny or rf is not None else None,
    )
    if pass_why:
        # No MILP certificate is re-derivable from ``sf`` (HiGHS's infeasible label and
        # tree bound are trusted as-is), so a model HiGHS changed on the way in -- or
        # refused -- gets no answer from it.
        return done(HighsOutcome("error", message=pass_why))

    seeded = False
    if initial_point is not None:
        seed = complete_seed(sf, initial_point, sf.n if n_struct is None else int(n_struct))
        if seed is None:
            stats["milp/seed_unusable"] = 1.0
        else:
            sol = highspy.HighsSolution()
            sol.col_value = seed if rf is None else seed[rf.keep]
            if h.setSolution(sol) != highspy.HighsStatus.kOk:
                logger.warning("HiGHS rejected the MILP start; solving without it")
                stats["milp/seed_rejected"] = 1.0
            else:
                seeded = True

    if stop is not None:
        stop.attach(h, highspy)
    run_st = run_checked(h)  # #2221: highspy >= 1.16 swallows a callback's exception
    name = _status_name(h)
    info = h.getInfo()
    if seeded and name == "kOptimal" and not np.isfinite(float(info.mip_dual_bound)):
        # #1920: handed a start, HiGHS's presolve can accept it and stop with
        # ``kOptimal`` at 0 nodes and NO dual bound -- the search that produces a
        # bound never ran. A certificate with nothing behind it is not one: measured
        # on a fixed-input piecewise-linear MILP (test_nonlinear_to_pwl), the route
        # then certified ``optimal`` with ``bound=None`` and Model.solve published it
        # uncertified with no bound at all. The same solve is re-run cold, so the
        # outcome is whatever the route's own checks make of HiGHS's unseeded answer.
        rem = remaining()
        cold = _solve_milp_std(
            sf,
            time_limit=rem,
            gap_tolerance=gap_tolerance,
            abs_gap_tolerance=abs_gap_tolerance,
            max_nodes=max_nodes,
            initial_point=None,
            n_struct=n_struct,
            root_check=root_check,
            presolve=presolve,
            feasibility_tolerance=feasibility_tolerance,
            row_form=row_form,
            stop=stop,
        )
        cold.stats["milp/seeded_optimal_without_bound"] = 1.0
        cold.wall_time = time.perf_counter() - t0
        return cold
    if stop is not None and name == "kInterrupt":
        stats["milp/stopped_by_peer"] = 1.0
    stats["lp/iters"] = float(info.simplex_iteration_count)
    stats["lp/driver_nodes"] = float(info.mip_node_count)
    nodes = int(info.mip_node_count)
    if run_st == highspy.HighsStatus.kError:
        return done(
            HighsOutcome(
                "error", message=f"HiGHS run() error ({name})", highs_status=name, node_count=nodes
            )
        )

    x = None
    obj = None
    repaired_why: Optional[str] = None
    if info.primal_solution_status == highspy.SolutionStatus.kSolutionStatusFeasible:
        x = np.asarray(h.getSolution().col_value, dtype=np.float64)
        if rf is not None:
            x = _lift_logicals(x, sf, rf)
        why = readback_problem(x, sf) or feasibility_problem(x, sf, check_integrality=True)
        if why:
            # The point is unusable, but the question may still be decidable: a
            # verified Farkas ray of the LP relaxation proves the MILP infeasible
            # (the huge-box case, where HiGHS's own arithmetic cancelled a violation).
            root = solve_lp_std(sf, time_limit=remaining())
            stats["milp/root_check_ran"] = 1.0
            stats["milp/root_lp_iters"] = root.stats.get("lp/iters", 0.0)
            if root.status == "infeasible":
                labels["milp/infeasible_provenance"] = "farkas-root-lp"
                stats["milp/infeasible_provenance_farkas"] = 1.0
                return done(
                    HighsOutcome(
                        "infeasible", gap_certified=True, highs_status=name, node_count=nodes,
                        message=f"HiGHS MILP incumbent ({name}) refused: {why}",
                    )
                )  # fmt: skip
            repaired = _repair_refused_incumbent(sf, x, root, remaining(), stats)
            # #1654: HiGHS's tree accepts an integer column within its
            # ``mip_feasibility_tolerance`` of integral, so on a big-M row ``x <= M z``
            # a binary read back at ``1 - 9e-7`` buys ``9e-7 * M`` of slack, and the
            # integral realisation the route verifies (#1380) violates the row by that
            # much. The point is refused, rightly -- but the integer assignment it
            # carries is still a candidate: the LP over those integers, re-verified on
            # ``sf``, is a genuine feasible point, and it replaces the refused one.
            # HiGHS's tree bound does not rest on the refused point (a node closed on
            # a near-integral LP point closed at that LP's value, a relaxation of the
            # node), so it goes through every check below exactly as an ordinary
            # incumbent's would; the gap is re-tested on the repaired objective.
            if repaired is None:
                return done(
                    HighsOutcome(
                        "error", message=f"HiGHS MILP incumbent ({name}): {why}",
                        highs_status=name, node_count=nodes,
                    )
                )  # fmt: skip
            x, obj = repaired
            repaired_why = why
            labels["milp/incumbent_repaired"] = why
        else:
            # #1750: publish the point the verifier tested -- its integral
            # realisation (#1380) -- and its objective. HiGHS reads a binary back
            # within its MIP feasibility tolerance of integral (8e-8 on the issue's
            # facility location), and the objective of that fractional point
            # (136.99999884 for an all-integer 137) leaked into the published
            # objective and from there into epsilon-constraint bounds. On the row
            # form the eliminated logicals are re-derived from the snapped columns,
            # so the rows hold exactly; that point is adopted only if it verifies.
            x = _snapped_incumbent(x, sf, rf)
            obj = float(sf.c @ x) + sf.obj_const
            h_obj = float(info.objective_function_value)  # includes the passed offset
            mismatch = abs(obj - h_obj)
            stats["milp/objective_mismatch"] = mismatch
            if mismatch > 1e-6 * (1.0 + abs(obj)):
                logger.warning(
                    "HiGHS MILP objective %.12g differs from the recomputed %.12g", h_obj, obj
                )

    raw = float(info.mip_dual_bound)  # includes the passed offset
    bound = raw if np.isfinite(raw) else None
    out = HighsOutcome("error", x=x, objective=obj, highs_status=name, node_count=nodes)
    out.iterations = int(info.simplex_iteration_count)

    if name == "kOptimal":
        if x is None:
            out.message = "HiGHS reported optimal without a primal solution"
            return done(out)
        out.status, out.gap_certified = "optimal", True
    elif name == "kInfeasible":
        out.status, out.gap_certified = "infeasible", True
        labels["milp/infeasible_provenance"] = "highs"
        stats["milp/infeasible_provenance_highs"] = 1.0
    elif name in ("kUnbounded", "kUnboundedOrInfeasible"):
        pass  # decided on the LP relaxation below
    elif name in _LIMIT_STATUSES:
        if x is not None:
            out.status = "feasible"
        else:
            out.status = {"kTimeLimit": "time_limit", "kIterationLimit": "iteration_limit"}.get(
                name, "node_limit"
            )
    else:
        out.message = f"HiGHS MILP status {name}"
        return done(out)
    if bound is not None and obj is not None:
        bound = min(bound, obj)
    out.bound = (
        bound
        if out.status in ("optimal", "feasible", "time_limit", "node_limit", "iteration_limit")
        else None
    )
    if repaired_why is not None and out.status == "optimal":
        # #1654: kOptimal closed HiGHS's gap on the REFUSED point's objective; the
        # repaired point may sit above it, so the stop rule is asked again.
        gap_kw = {"abs_gap_tolerance": abs_gap_tolerance, "gap_tolerance": gap_tolerance}
        if out.bound is None or not _gap_closed(float(obj), float(out.bound), gap_kw):  # type: ignore[arg-type]
            out.status, out.gap_certified = "feasible", False
            labels["milp/certificate"] = "declined"
        out.message = (
            f"HiGHS MILP incumbent ({name}) refused ({repaired_why}); reporting the "
            "fixed-integer LP over its integers, verified on the model (#1654)"
        )

    def decertify_root_check(why: str) -> None:
        """Strip the certificate from a result whose NS-safe root check did not
        settle — whether it was skipped for want of budget (#1309) or ran and came
        back inconclusive (#1320). Both are the same fact: the safety net that
        exists to catch a tree bound (or an infeasibility claim) already wrong at
        the root (#1295) produced no verdict, so nothing here is certified.

        Every field that reads as a certificate is made consistent (#1320 part 2),
        mirroring the #1295 ``decertify``: kOptimal keeps its incumbent as an
        honest uncertified ``feasible``; kInfeasible has no incumbent to fall back
        on and becomes ``error``; and the unchecked tree bound gives way to the
        NS-safe root bound — ``None`` here, since the check is exactly what did not
        produce one, which in turn leaves ``gap``/``bound_valid`` empty rather than
        a proven-looking zero gap. The label demotes the route's own wording from
        "verified" to "unverified".
        """
        if not out.gap_certified:
            return
        out.message = f"HiGHS MILP {name}: {why}, so this result cannot be certified"
        out.gap_certified = False
        out.status = "feasible" if out.x is not None else "error"
        out.bound = out.root_bound
        if out.bound is not None and out.objective is not None:
            out.bound = min(out.bound, out.objective)
        labels["milp/certificate"] = "declined"
        labels["milp/bound_provenance"] = "root-ns" if out.bound is not None else "none"

    def _refutation_check(out: HighsOutcome, lp: HighsOutcome) -> bool:
        """#1509: hold the reported bound against every VERIFIED point in hand.

        The root cross-check above only compares two numbers, and the #1410 dual
        check only asks whether HiGHS's LP arithmetic certifies an LP. Neither can see
        a tree whose MIP presolve/propagation cut the optimum off: on the #1509
        surrogate the root LP, its duals, and every scaling ratio are clean, HiGHS
        still certifies ``9000012.455`` while ``9e6`` is feasible -- and the root LP
        point itself is that feasible ``9e6`` point.

        A bound above a verified feasible point is false by definition, so the check
        is "no verified point lies below the bound", over the points available at an
        LP's cost: the root LP point (already solved); the NS-safe LP over the
        incumbent's own integer assignment (a ``kOptimal`` incumbent must be optimal
        for its own integers, and that LP never enters HiGHS's MIP presolve); and,
        when the root LP point is fractional, the same LP over its rounding. Every
        candidate passes the incumbent verifier before it counts as evidence.

        This is a falsifier, not a proof: it catches a false bound whenever one of
        those points lies below it, which on the 180-instance #1509 family was every
        one of the 60 false certificates. A false bound with no such point in reach
        is not caught, and the route's standing there is what it was before.

        Returns ``False`` when ``out`` was decertified for want of a verdict and the
        caller should stop; ``True`` otherwise (refuted results are repaired in place).
        """
        if out.bound is None:  # the only call site runs this check with a bound
            raise RuntimeError("#1509 refutation check called without a reported bound")
        cands: list[tuple[np.ndarray, float]] = []
        # #2151: where each candidate came from; "own-integers" is the LP over the
        # incumbent's own integer assignment (read by :func:`_reseed_refuted`).
        kinds: list[str] = []
        # #2221: the root LP point is re-derived over its own integers before it counts,
        # as the cross point is (#1733). Raw, it is a tolerance, not a point: on a big-M
        # 1e10 sequencing model (test_1920) highspy 1.16's root LP vertex verifies at
        # 11.0 on ``sf`` -- the verifier's row tolerance is relative, and the 1e10 rows
        # absorb a violation of 8 in the model -- while the LP over its integers gives
        # the true optimum 31.0. Taken raw it refuted HiGHS's correct bound 31, declined
        # the #1654 certificate and was published as the incumbent. Only the RE-DERIVED
        # point counts: when the fixed-integer LP gives none (no time left, or no
        # verified point) the raw vertex is dropped, not kept, since it is the same
        # tolerance point that would refute the bound and be published.
        root_pt = None
        if lp.status == "optimal":
            root_rederived: list = []
            raw_root = _rederived_point(
                sf, lp.x, remaining(), stats, root_rederived, stat_prefix="milp/root_point"
            )
            if not sf.int_idx.size:
                root_pt = raw_root  # no integers to re-derive: the vertex is the point
            elif root_rederived:
                root_pt = root_rederived[0]
            else:
                stats["milp/root_point_dropped"] = 1.0
        if root_pt is not None:
            cands.append(root_pt)
            kinds.append("root-lp")
        if out.x is not None and sf.int_idx.size:
            rem_fx = remaining()
            if rem_fx is not None and rem_fx <= 0.0:
                stats["milp/fixed_int_check_skipped"] = 1.0
                decertify_root_check("no time budget left to run the fixed-integer LP check")
                return False
            fx = _fixed_integer_lp(sf, out.x, rem_fx)
            stats["milp/fixed_int_check_ran"] = 1.0
            pt = _verified_mip_point(sf, fx.x) if fx.status == "optimal" else None
            fpt = _fixed_integer_lp_cannot_refute(sf, fx, float(out.bound)) if pt is None else None
            if fpt is not None:
                # #2183: the LP did not close its own NS gap, so it is not known to be
                # optimal, but its NS-safe bound already lies within the refutation
                # yardstick of the reported MILP bound. Every point on this integer
                # assignment has an objective >= that bound, so none of them can
                # refute the reported bound. That is a rigorous verdict. The
                # optimal-LP arm accepts exactly these cases too: its optimum v >= ns
                # passes the margin test whenever ns does. The LP point is verified,
                # so it may still improve the incumbent (#2151). It is NOT the
                # LP optimum, so it stays out of #1612 (``milp/fixed_int_objective``),
                # #1733 (rederivation) and the own-integers tight re-solve, all of
                # which assume one.
                #
                # Why the unclosed NS gap no longer counts against HiGHS's MILP bound
                # (#1320's "numerical trouble on this matrix"): that rule exists because
                # an unsettled check is not a passed one, and this check is settled. Its
                # only question is whether a point on this assignment refutes the bound,
                # and the NS bound answers it rigorously whatever its own gap. Whether
                # HiGHS's arithmetic on this matrix certifies the LPs it solves is the
                # #1410 root-dual check's question. That check has already run and passed
                # before this point; otherwise ``done`` would have returned. Measured on
                # med_term (Linux, highspy 1.15.1): root dual violation 7.5e-17. The
                # fixed LP's 0.00139 gap is NS round-off: reduced costs of 1e-14..1e-15
                # charged against 1e20 sentinel upper bounds give 5.0e6 over the declared
                # box, and the exact dual correction leaves 0.00139. The same LP
                # re-solved later in that solve (the cross-checks) returns ``optimal``,
                # with an FBBT-box gap of 4.3e-7 at the identical objective.
                stats["milp/fixed_int_check_bounded"] = 1.0
                stats["milp/fixed_int_ns_bound"] = float(fx.bound)  # type: ignore[arg-type]
                cands.append(fpt)
                kinds.append("own-integers-bounded")
            elif pt is None:
                # The LP over a verified incumbent's own integers is feasible (the
                # incumbent is a point of it), so a non-verdict here is numerical
                # trouble on this matrix -- the #1320 rule: an unsettled check is not
                # a passed one.
                stats["milp/fixed_int_check_inconclusive"] = 1.0
                decertify_root_check(
                    f"the fixed-integer LP check was inconclusive (LP {fx.status}: {fx.message})"
                )
                return False
            else:
                cands.append(pt)
                kinds.append("own-integers")
                # #1612: the incumbent's own integers, re-optimised by a separate LP; the
                # distance from HiGHS's objective is what its feasibility tolerance bought
                # (read by :func:`_tighten_feasibility_artefact`).
                stats["milp/fixed_int_objective"] = float(pt[1])
                # #1733: when HiGHS's objective beats the LP over its own integers by no more
                # than the equality yardstick, the difference is row tolerance HiGHS spent
                # on the objective, not a better point; publish the LP's point. Only where
                # #1612 would leave the pair alone (the gap still closes with that
                # difference charged twice), so its tight re-solve is untouched. Measured
                # on test_piecewise's incremental graph (HiGHS random_seed 16): y published
                # 1.0e-6 above f(x) on the row form; the LP point is exact.
                delta = float(pt[1]) - float(out.objective) if out.objective is not None else 0.0
                gap_kw = {"abs_gap_tolerance": abs_gap_tolerance, "gap_tolerance": gap_tolerance}
                if (
                    0.0 < delta <= CERT_ABS + CERT_REL * abs(float(pt[1]))
                    and out.bound is not None
                    and _gap_closed(float(pt[1]) + delta, float(out.bound), gap_kw)
                ):
                    out.x, out.objective = pt
                    stats["milp/incumbent_rederived"] = float(delta)
        if root_pt is None and lp.status == "optimal" and lp.x is not None and sf.int_idx.size:
            # The root LP point is not itself integer-feasible: its rounding, with the
            # continuous part re-optimised, is the other point an LP buys. Measured on
            # the #1509 family, HiGHS's own integers can be the wrong ones (a gap-limit
            # stop whose bound is above the optimum) while the root LP sits within
            # 1.2e-5 of the optimal assignment. A failed or infeasible rounding is no
            # evidence either way, so it is simply not a candidate.
            rem_rd = remaining()
            if rem_rd is None or rem_rd > 0.0:
                rd = _fixed_integer_lp(sf, lp.x, rem_rd)
                stats["milp/rounded_root_check_ran"] = 1.0
                pt = _verified_mip_point(sf, rd.x) if rd.status == "optimal" else None
                if pt is not None:
                    cands.append(pt)
                    kinds.append("rounded-root")
        if not cands:
            return True
        i_best = min(range(len(cands)), key=lambda i: cands[i][1])
        best_x, best = cands[i_best]
        assert out.bound is not None
        margin = out.bound - best
        stats["milp/refutation_margin"] = float(margin)
        # The yardstick the route already uses to call an LP objective equal to its
        # NS bound (CERT_ABS + CERT_REL*|v|): a point below the bound by more than
        # that is a contradiction, not round-off.
        if margin <= CERT_ABS + CERT_REL * abs(out.bound):
            # #2151: within the yardstick the bound stands, but a verified point
            # BETTER than HiGHS's incumbent is still a better point. Leaving it out
            # published HiGHS's worse objective with a bound above the verified one,
            # and the #1537 E repair later moved the incumbent to that point while
            # keeping the bound. Measured on a neuron permutation of the issue's net,
            # the published bound was then 2.7e-7 ABOVE the published objective. The
            # better point is published, and the bound never exceeds it.
            if out.objective is not None and best < out.objective:
                stats["milp/incumbent_improved_by_check"] = float(out.objective - best)
                out.x, out.objective = best_x, best
                out.bound = min(out.bound, best)
            return True
        stats["milp/certificate_refuted"] = 1.0
        labels["milp/highs_certificate"] = "refuted"
        labels["milp/refuted_by"] = kinds[i_best]
        # #2151: the trigger reads this field, which no merge copies from another solve.
        out.refuted_by = kinds[i_best]
        was = out.bound
        if out.objective is None or best < out.objective:
            out.x, out.objective = best_x, best
            stats["milp/incumbent_from_refutation"] = 1.0
        # HiGHS's tree bound is now known false, so nothing it derived stands; the
        # NS-safe root bound is the only bound left, and it certifies the gap only if
        # it closes it by the route's own convergence test (the HiGHS stop rule).
        rb = out.root_bound
        out.bound = None if rb is None else min(rb, out.objective)
        labels["milp/bound_provenance"] = "root-ns" if out.bound is not None else "none"
        closed = False
        if out.bound is not None:
            gap = max(0.0, out.objective - out.bound)
            closed = gap <= (1e-6 if abs_gap_tolerance is None else abs_gap_tolerance) or (
                gap / max(abs(out.objective), abs(out.bound), 1e-10) <= gap_tolerance
            )
        out.gap_certified = closed
        out.status = "optimal" if closed else "feasible"
        if not closed:
            labels["milp/certificate"] = "declined"
        out.message = (
            f"HiGHS MILP {name}: bound {was:.12g} refuted by a verified point of "
            f"objective {best:.12g} (#1509); reporting the NS-safe root bound"
        )
        logger.warning("HiGHS MILP route: %s", out.message)
        return True

    # Root LP relaxation, NS-safe: supplies root_bound, decides an unbounded-or-
    # infeasible label, upgrades an infeasible claim to a Farkas proof, and catches a
    # tree bound that is already wrong at the root (§3.2.5).
    need_root = root_check or name in ("kUnbounded", "kUnboundedOrInfeasible")
    rem = remaining()
    if not need_root:
        return done(out)
    if rem is not None and rem <= 0.0:
        stats["milp/root_check_skipped"] = 1.0
        if name in ("kUnbounded", "kUnboundedOrInfeasible"):
            out.status, out.message = "error", f"{name} and no budget left to decide it"
        else:
            decertify_root_check("no time budget left to run the NS-safe root cross-check")
        return done(out)
    t_root = time.perf_counter()
    lp = solve_lp_std(sf, time_limit=rem)
    out.root_time = time.perf_counter() - t_root
    stats["milp/root_check_ran"] = 1.0
    stats["milp/root_lp_iters"] = lp.stats.get("lp/iters", 0.0)

    if name in ("kUnbounded", "kUnboundedOrInfeasible"):
        if lp.status == "infeasible":
            out.status, out.gap_certified, out.bound = "infeasible", True, None
            labels["milp/infeasible_provenance"] = "farkas-root-lp"
            stats["milp/infeasible_provenance_farkas"] = 1.0
            return done(out)
        if lp.status == "unbounded":
            # A verified integer-feasible point plus a verified recession direction
            # of the relaxation (rational data: Meyer) -> the MILP is unbounded.
            #
            # #1339 follow-up: HiGHS reports ``kUnbounded`` / ``kUnboundedOrInfeasible``
            # with NO incumbent, so the point Meyer's theorem needs was simply
            # missing and a genuinely unbounded MILP came back ``error``. It is not
            # missing because it is hard to get -- it is missing because nobody asked
            # for it. Asking is the same move #1337 makes one branch below: the
            # question here is only "is the INTEGER system nonempty?", and the
            # objective is exactly what stops HiGHS answering it, so drop the
            # objective and re-solve. Meyer then applies in full:
            # ``rec(conv(S)) = rec(P)`` for rational data with ``S`` nonempty, so an
            # improving recession direction of the relaxation is one of the integer
            # hull too.
            if x is None:
                x = _integer_feasible_point(sf, remaining(), stats)
            if x is not None:
                out.x = x
                out.status = "unbounded"
                labels["milp/unbounded_provenance"] = "meyer-ray-plus-integer-point"
                return done(out)
            if stats.get("milp/unbounded_feasibility_probe_infeasible"):
                # The probe did not merely fail to find a point -- it PROVED there is
                # none, which decides the ``OrInfeasible`` half outright.
                out.status, out.gap_certified, out.bound = "infeasible", True, None
                labels["milp/infeasible_provenance"] = "integer-feasibility-probe"
                return done(out)
        out.status = "error"
        out.message = f"HiGHS MILP {name}; root LP relaxation {lp.status}: {lp.message}"
        return done(out)

    if lp.status == "infeasible":
        if out.status == "infeasible":
            labels["milp/infeasible_provenance"] = "farkas-root-lp"
            stats["milp/infeasible_provenance_farkas"] = 1.0
            return done(out)
        out.status, out.gap_certified = "error", False
        out.message = "root LP relaxation is Farkas-infeasible but HiGHS returned a MILP point"
        return done(out)
    if lp.status in ("optimal", "feasible") and lp.bound is not None:
        out.root_bound = lp.bound
        if out.status == "infeasible":
            return done(out)
        stats["milp/root_ns_bound"] = float(lp.bound)
        if out.bound is not None and lp.bound > out.bound + 1e-6 * (1.0 + abs(out.bound)):
            if not _tree_below_root_repair_enabled():
                out.status, out.gap_certified = "error", False
                out.message = (
                    f"tree bound {out.bound:.12g} below the safe root bound {lp.bound:.12g}: "
                    "the MILP HiGHS solved is not the model's relaxation"
                )
                return done(out)
            if _repair_tree_below_root(
                sf,
                out,
                float(lp.bound),
                labels,
                stats,
                {"abs_gap_tolerance": abs_gap_tolerance, "gap_tolerance": gap_tolerance},
                remaining(),
            ):
                return done(out)
        # #1410: the cross-check above compares two NUMBERS and so only catches a tree
        # bound that is already wrong at the root. The failure it misses is the opposite
        # shape: a root bound that is perfectly valid while HiGHS prunes the true optimum
        # deeper in the tree, returning a bound ABOVE it. That cannot be caught by any
        # comparison of the root bound to the tree bound -- but it can be caught by asking
        # whether HiGHS's arithmetic on this matrix produces a certificate at all. If the
        # root LP's own primal/dual pair is not dual-feasible in unscaled doubles, every
        # LP HiGHS solves in the tree is suspect, and the tree's bound is not a
        # certificate. Measured: 7.87e-17 on well-scaled LPs, 1.0 on the #1410 instance,
        # where UNSCALABLE_OPEN_RATIO missed by a factor of 1.43 (1.366e-6 vs 9.537e-7).
        if lp.x is not None and lp.row_dual is not None:
            dual_viol = box_dual_violation(sf, lp.x, lp.row_dual)
            dual_tol = dual_violation_tolerance(sf)
            # The value the gate below tests, so a trip is visible in the stats.
            stats["milp/root_dual_violation"] = dual_viol
            # #2300: the same test with the scale floored at the LP's own magnitude.
            # Reported only, never gated: it does not read 1.0 on a round-off slack
            # dual (in-house engine duals), but it understates real violations (#2309:
            # 6 of 84 wrong root pairs read below tolerance on it).
            stats["milp/root_dual_violation_scaled"] = box_dual_violation(
                sf, lp.x, lp.row_dual, problem_scale_floor=True
            )
            if dual_viol > dual_tol:
                # #1612: the per-column relative test is a sufficient condition, not
                # the question. The question is whether HiGHS's own pair certifies the
                # root LP, and that is decided rigorously by charging every violated
                # reduced cost over the declared box (NS): if the safe bound from
                # HiGHS's duals meets its own primal objective within the route's LP
                # certificate yardstick, the LP is provably solved to that tolerance --
                # in objective units, the units the MILP gap is certified in -- and the
                # violation was round-off. On #1410 the same gap is 0.0221: HiGHS
                # mis-solved the LP, and that is still refused.
                ns_gap = root_pair_ns_gap(sf, lp.x, lp.row_dual)
                lp_obj = float(sf.c @ lp.x) + sf.obj_const
                ns_thr = CERT_ABS + CERT_REL * abs(lp_obj)
                stats["milp/root_dual_ns_gap"] = float("inf") if ns_gap is None else ns_gap
                if ns_gap is not None and ns_gap <= ns_thr:
                    stats["milp/root_dual_certified_by_ns"] = 1.0
                else:
                    stats["milp/root_dual_unverified"] = 1.0
                    gap_txt = "unbounded (-inf NS bound)" if ns_gap is None else f"{ns_gap:.3g}"
                    decertify_root_check(
                        f"the root LP's own primal/dual pair is dual-infeasible by "
                        f"{dual_viol:.3g} relative (round-off bound {dual_tol:.3g}) and "
                        f"its NS-safe duality gap is {gap_txt} (yardstick {ns_thr:.3g}), "
                        f"so HiGHS's arithmetic on this matrix does not certify the LPs "
                        f"it solves in the tree"
                    )
                    return done(out)
        if out.bound is None and out.status != "optimal":
            # No tree bound yet (limit hit before the root finished): the NS root
            # bound is a valid one, so report it rather than nothing.
            out.bound = lp.bound if obj is None else min(lp.bound, obj)
            stats["milp/bound_from_root_ns"] = 1.0
        if out.bound is not None and not _refutation_check(out, lp):
            return done(out)
    else:
        # The check RAN but settled nothing (``solve_lp_std`` hit its own time
        # limit, or errored — a kUnknown / sentinel-magnitude readback refusal).
        # #1309 applied "a certificate whose safety net never ran is not a
        # certificate" only to the skip branch; an inconclusive run is the same
        # fact and gets the same downgrade (#1320 part 1).
        #
        # #1337: unless what defeated the check was the OBJECTIVE rather than
        # anything about feasibility. On a purely INTEGRAL infeasibility the
        # relaxation is perfectly happy — ``2x == 1`` relaxes to ``x = 0.5`` — and
        # if the objective is also unbounded there (``min −y`` over
        # ``y ∈ [0, 1e20]``) the root LP comes back ``unbounded``, which lands here
        # and decertifies a correct ``infeasible`` into ``error``. But the question
        # this branch asks of a kInfeasible claim is only ever "is the relaxation
        # feasible?", and an unbounded objective says nothing about that. So ask it
        # without one: same LP, same box, zero objective.
        #
        # The verdict is held to exactly the standard the ordinary path already
        # uses, not a weaker one — a Farkas-infeasible relaxation proves the MILP
        # empty, and a feasible relaxation leaves the kInfeasible claim standing
        # precisely as the ``lp.status in ("optimal", "feasible")`` branch above
        # already does. Anything else still decertifies.
        _settled = False
        if out.status == "infeasible" and out.gap_certified:
            _rem2 = remaining()
            if _rem2 is None or _rem2 > 0.0:
                stats["milp/root_check_feasibility_only"] = 1.0
                feas = solve_lp_std(
                    dataclasses.replace(sf, c=np.zeros(sf.n, dtype=np.float64), obj_const=0.0),
                    time_limit=_rem2,
                )
                if feas.status == "infeasible":
                    # Stronger than needed: the relaxation itself is empty.
                    labels["milp/infeasible_provenance"] = "farkas-root-lp"
                    stats["milp/infeasible_provenance_farkas"] = 1.0
                    _settled = True
                elif feas.status in ("optimal", "feasible"):
                    labels["milp/infeasible_provenance"] = "highs-root-feasible"
                    _settled = True
        if not _settled:
            stats["milp/root_check_inconclusive"] = 1.0
            decertify_root_check(
                f"the NS-safe root cross-check was inconclusive (root LP {lp.status}: {lp.message})"
            )
    return done(out)


# ─────────────────────────────────────────────────────────────
# Matrix-form LP contract (``lp_simplex.solve_lp`` signature)
# ─────────────────────────────────────────────────────────────


def solve_lp(
    c, A_ub=None, b_ub=None, A_eq=None, b_eq=None, bounds=None, time_limit=None, engine=None
):
    """``min cᵀx s.t. A_ub x <= b_ub, A_eq x = b_eq`` returning an ``LPResult``.

    Used for relaxation-dual recovery. Inequality rows get a nonnegative logical, so
    each row dual is ``∂obj/∂b`` of the row as passed -- the HiGHS convention
    ``_lp_qp_unpack_duals`` expects. ``OPTIMAL`` only for a certified outcome.
    """
    from discopt.solvers import LPResult, SolveStatus
    from discopt.solvers.milp_simplex import _marshal_col_bounds

    c = np.asarray(c, dtype=np.float64).ravel()
    n = c.shape[0]
    xl, xu = _marshal_col_bounds(bounds, n)
    blocks, rhs = [], []
    n_ub = 0
    if A_ub is not None and b_ub is not None:
        a = sp.csr_matrix(A_ub, dtype=np.float64)
        n_ub = a.shape[0]
        blocks.append(sp.hstack([a, sp.identity(n_ub, format="csr")]))
        rhs.append(np.asarray(b_ub, dtype=np.float64).ravel())
    if A_eq is not None and b_eq is not None:
        a = sp.csr_matrix(A_eq, dtype=np.float64)
        blocks.append(sp.hstack([a, sp.csr_matrix((a.shape[0], n_ub))]))
        rhs.append(np.asarray(b_eq, dtype=np.float64).ravel())
    A = sp.vstack(blocks, format="csc") if blocks else sp.csc_matrix((0, n + n_ub))
    b = np.concatenate(rhs) if rhs else np.zeros(0)
    sf = StdForm.from_arrays(
        np.concatenate([c, np.zeros(n_ub)]),
        A,
        b,
        np.concatenate([xl, np.zeros(n_ub)]),
        np.concatenate([xu, np.full(n_ub, INF)]),
    )
    out = solve_lp_std(sf, time_limit=time_limit, engine=engine)
    status = {
        "optimal": SolveStatus.OPTIMAL,
        "infeasible": SolveStatus.INFEASIBLE,
        "unbounded": SolveStatus.UNBOUNDED,
        "time_limit": SolveStatus.TIME_LIMIT,
        "iteration_limit": SolveStatus.ITERATION_LIMIT,
    }.get(out.status, SolveStatus.ERROR)
    return LPResult(
        status=status,
        x=None if out.x is None else out.x[:n],
        objective=out.objective,
        dual_values=out.row_dual,
        reduced_costs=None if out.col_dual is None else out.col_dual[:n],
        iterations=int(out.stats.get("lp/iters", 0)),
        wall_time=out.wall_time,
    )
