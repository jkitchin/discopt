"""Candidate generation: map discovered structure to decomposition candidates.

Each :class:`CandidateGenerator` inspects the :class:`StructureReport` and, when
applicable, proposes one or more :class:`Candidate` decompositions. Generators
are the extensibility seam of Phase 2: a new method is a new generator plus (in
a later phase) a scoring rule, touching no analysis code.

The generators run cheap-first (the cascade of design doc §5.1) and their output
is de-duplicated. Ranking is *not* done here — every applicable candidate is
returned, including the monolithic ``NONE`` baseline, for scoring/selection to
order later.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from discopt.decomposition.advisor.analyzer import StructureReport
from discopt.decomposition.advisor.types import Candidate, ElementView, MethodKind, Soundness
from discopt.decomposition.structure import DecompositionStructure, detect_decomposition


@runtime_checkable
class CandidateGenerator(Protocol):
    """Proposes decomposition candidates from a model and its structure report."""

    name: str

    def applicable(self, report: StructureReport) -> bool:
        """Cheap gate: could this generator produce anything for *report*?"""
        ...

    def generate(self, model, report: StructureReport) -> list[Candidate]:
        """Produce candidates (possibly empty) for *model*."""
        ...


class MonolithicGenerator:
    """Always proposes the no-decomposition baseline.

    Keeping ``NONE`` in the candidate set guarantees the ranker always has the
    honest competitor to beat (design doc §6.3): a decomposition must be *better*
    than solving the monolith, not merely feasible.
    """

    name = "monolithic"

    def applicable(self, report: StructureReport) -> bool:
        return True

    def generate(self, model, report: StructureReport) -> list[Candidate]:
        return [
            Candidate(
                method=MethodKind.NONE,
                structure=None,
                provenance="baseline",
                est_soundness=Soundness.PROVEN_EQUIVALENT,
                notes=("solve the model as written",),
            )
        ]


class IndependentBlockGenerator:
    """Block-diagonal models: solve the independent blocks with no coordination."""

    name = "independent-blocks"

    def applicable(self, report: StructureReport) -> bool:
        return report.is_block_diagonal and not report.coupling_constraints

    def generate(self, model, report: StructureReport) -> list[Candidate]:
        structure = detect_decomposition(model)
        return [
            Candidate(
                method=MethodKind.INDEPENDENT_BLOCKS,
                structure=structure,
                provenance=f"connected components ({structure.num_blocks} blocks)",
                est_soundness=Soundness.PROVEN_EQUIVALENT,
                notes=(
                    f"{structure.num_blocks} independent blocks, no coupling",
                    "exact if the objective is separable across blocks",
                ),
            )
        ]


class IntegerProjectionGenerator:
    """Fixing the integer variables exposes independent recourse → Benders.

    This generalizes the shipping default (complicating vars = integer/binary
    vars): it only fires when *removing* those variables actually disconnects the
    model into ≥2 recourse blocks, which is the structural precondition for
    Benders paying off. Nonlinear recourse selects Generalized Benders.
    """

    name = "integer-projection"

    def applicable(self, report: StructureReport) -> bool:
        return report.integer_localizes

    def generate(self, model, report: StructureReport) -> list[Candidate]:
        structure = detect_decomposition(model)
        if not structure.complicating_vars:
            return []
        if report.model_is_nonlinear:
            method = MethodKind.GENERALIZED_BENDERS
            soundness = Soundness.UNKNOWN
            notes = (
                f"fixing {len(structure.complicating_vars)} integer vars exposes "
                f"{report.blocks_after_integer_projection} recourse blocks",
                "nonlinear recourse → GBD; exact only if subproblems are convex "
                "(checked during scoring)",
            )
        else:
            method = MethodKind.BENDERS
            soundness = Soundness.PROVEN_EQUIVALENT
            notes = (
                f"fixing {len(structure.complicating_vars)} integer vars exposes "
                f"{report.blocks_after_integer_projection} recourse blocks",
                "linear recourse → classical Benders (exact)",
            )
        return [
            Candidate(
                method=method,
                structure=structure,
                provenance="integer-variable projection",
                est_soundness=soundness,
                notes=notes,
            )
        ]


class OuterApproximationGenerator:
    """A convex MINLP → Outer Approximation (Duran & Grossmann 1986).

    On a *convex* MINLP, OA's per-constraint linearizations dominate GBD's
    aggregated single cut, so OA typically needs fewer major iterations. This
    generator fires on a nonlinear model with integer variables whose recourse
    the convexity classifier accepts as convex, and proposes OA as a
    proven-equivalent alternative that outranks GBD in scoring. Nonconvex models
    are left to GBD's heuristic mode.
    """

    name = "outer-approximation"

    def applicable(self, report: StructureReport) -> bool:
        return report.model_is_nonlinear and report.num_integer > 0

    def generate(self, model, report: StructureReport) -> list[Candidate]:
        from discopt._relax.convexity import classify_oa_cut_convexity

        try:
            conv = classify_oa_cut_convexity(model)
            is_convex = conv.objective_is_convex and all(conv.constraint_mask)
        except Exception:  # noqa: BLE001 - a classifier failure just skips OA
            return []
        if not is_convex:
            return []
        # Reuse the integer-projection structure so scoring sees the same block
        # structure as GBD; dispatch routes OA to the whole-model solver.
        structure = detect_decomposition(model)
        return [
            Candidate(
                method=MethodKind.OUTER_APPROXIMATION,
                structure=structure,
                provenance="convex-MINLP outer approximation",
                est_soundness=Soundness.PROVEN_EQUIVALENT,
                notes=(
                    "convex MINLP: OA per-constraint cuts dominate GBD's aggregated "
                    "cut (Duran & Grossmann 1986), usually fewer iterations",
                    "exact for convex models (recourse verified convex)",
                ),
            )
        ]


class CouplingGenerator:
    """A few coupling constraints link otherwise-independent blocks → Lagrangian.

    Dualizing the coupling rows separates the model into blocks solvable in
    parallel and yields a valid dual bound. Fires on annotated or bridge-detected
    coupling.
    """

    name = "coupling"

    def applicable(self, report: StructureReport) -> bool:
        return bool(report.coupling_constraints)

    def generate(self, model, report: StructureReport) -> list[Candidate]:
        structure = detect_decomposition(model)
        if not structure.coupling_constraints:
            return []
        provenance = "user annotations" if report.has_annotations else "bridge-constraint scan"
        return [
            Candidate(
                method=MethodKind.LAGRANGIAN,
                structure=structure,
                provenance=provenance,
                est_soundness=Soundness.RELAXATION,
                notes=(
                    f"{len(structure.coupling_constraints)} coupling constraint(s) "
                    f"dualized; {structure.num_blocks} blocks",
                    "yields a valid dual bound; primal recovery may need extra work",
                ),
            )
        ]


# ── element-level generators ───────────────────────────────────
#
# Each fires only where its array-level counterpart is blind for reasons of
# *granularity*: the array view treats each array variable as one vertex, so
# scenarios sharing an array read as one block. Where the array view already
# sees the structure, these stay silent, so every candidate the array-level
# generators produce -- and every recommendation built on them -- is unchanged.


def _element_view(
    model,
    *,
    drop_cols=(),
    drop_model_constraints=(),
    separator_fraction: float = 0.0,
    coupling_density: float = 0.0,
) -> ElementView:
    """The constraint-bearing blocks of the element graph after removals."""
    import numpy as np

    from discopt.decomposition.graph.element import ElementGraph

    graph = ElementGraph.from_model(model)
    drop_cols = np.asarray(drop_cols, dtype=np.int64)
    dropped_cons = set(int(i) for i in drop_model_constraints)
    drop_rows = [
        i
        for i in range(graph.num_rows)
        if graph.con_model_index[int(graph.row_con[i])] in dropped_cons
    ]
    block_of, _ = graph.components(drop_cols=drop_cols, drop_rows=drop_rows)
    dropped_rows = set(drop_rows)
    bearing: dict[int, None] = {}
    for i, clique in enumerate(graph.row_cliques):
        if i in dropped_rows:
            continue
        kept = [b for b in block_of[clique].tolist() if b >= 0]
        if kept:
            bearing.setdefault(kept[0], None)
    cols_of: dict[int, list[int]] = {b: [] for b in bearing}
    for j, b in enumerate(block_of.tolist()):
        if b in cols_of:
            cols_of[b].append(j)
    blocks = [tuple(cols_of[b]) for b in sorted(cols_of, key=lambda b: cols_of[b][0])]
    return ElementView(
        block_columns=tuple(blocks),
        block_labels=tuple(tuple(graph.col_label(j) for j in blk) for blk in blocks),
        separator_fraction=separator_fraction,
        coupling_density=coupling_density,
    )


class ElementIndependentBlockGenerator:
    """Independent blocks the array view merges (they share an array variable)."""

    name = "independent-blocks-element"

    def applicable(self, report: StructureReport) -> bool:
        return (
            not report.is_block_diagonal
            and not report.coupling_constraints
            and (report.element_blocks or 0) >= 2
        )

    def generate(self, model, report: StructureReport) -> list[Candidate]:
        view = _element_view(model)
        if view.num_blocks < 2:
            return []
        return [
            Candidate(
                method=MethodKind.INDEPENDENT_BLOCKS,
                structure=detect_decomposition(model),
                provenance=f"element-level connected components ({view.num_blocks} blocks)",
                est_soundness=Soundness.PROVEN_EQUIVALENT,
                notes=(
                    f"{view.num_blocks} independent blocks that share array variables",
                    "solved as one model (the per-block parallel solve is Phase 6)",
                ),
                element_view=view,
            )
        ]


class ElementIntegerProjectionGenerator:
    """Fixing the integers splits the recourse element by element → Benders.

    The array-level generator asks the same question on array vertices, where
    a recourse array shared by every scenario never splits. Benders itself
    already partitions its recourse into element-level blocks (multicut), so
    the candidate needs no new driver: the structure is the shipping default
    (complicating = integer variables).
    """

    name = "integer-projection-element"

    def applicable(self, report: StructureReport) -> bool:
        return (
            report.num_integer > 0
            and not report.integer_localizes
            and (report.element_blocks_after_integer_projection or 0) >= 2
        )

    def generate(self, model, report: StructureReport) -> list[Candidate]:
        from discopt.decomposition.advisor.analyzer import integer_columns
        from discopt.decomposition.graph.element import ElementGraph

        structure = detect_decomposition(model)
        if not structure.complicating_vars:
            return []
        graph = ElementGraph.from_model(model)
        int_cols = integer_columns(model, graph)
        view = _element_view(
            model,
            drop_cols=int_cols,
            separator_fraction=(int_cols.size / graph.num_cols) if graph.num_cols else 0.0,
            coupling_density=report.coupling_density,
        )
        if view.num_blocks < 2:
            return []
        if report.model_is_nonlinear:
            method, soundness = MethodKind.GENERALIZED_BENDERS, Soundness.UNKNOWN
            kind = "nonlinear recourse → GBD; exact only if subproblems are convex"
        else:
            method, soundness = MethodKind.BENDERS, Soundness.PROVEN_EQUIVALENT
            kind = "linear recourse → classical Benders (exact)"
        return [
            Candidate(
                method=method,
                structure=structure,
                provenance="integer-variable projection (element level)",
                est_soundness=soundness,
                notes=(
                    f"fixing {int_cols.size} integer column(s) exposes {view.num_blocks} "
                    "recourse blocks that share array variables",
                    kind,
                ),
                element_view=view,
            )
        ]


class ElementCouplingGenerator:
    """Rows that couple *elements* of shared arrays → Lagrangian.

    Fires only when the array-level bridge scan ran and found nothing; where it
    was truncated by its budget the element scan's extra finds are a budget
    effect, not hidden structure, and adopting them would change routing on
    models the array view handles today. Linear models only: the Lagrangian
    driver extracts a linear model and refuses anything else.
    """

    name = "coupling-element"

    def applicable(self, report: StructureReport) -> bool:
        return (
            not report.coupling_constraints
            and not report.coupling_scan_truncated
            and not report.model_is_nonlinear
            and bool(report.element_coupling_constraints)
        )

    def generate(self, model, report: StructureReport) -> list[Candidate]:
        coupling = list(report.element_coupling_constraints)
        structure = detect_decomposition(model, coupling=coupling)
        m = report.num_constraints
        view = _element_view(
            model,
            drop_model_constraints=coupling,
            coupling_density=(len(coupling) / m) if m else 0.0,
        )
        if view.num_blocks < 2:
            return []
        return [
            Candidate(
                method=MethodKind.LAGRANGIAN,
                structure=structure,
                provenance="element-level bridge-constraint scan",
                est_soundness=Soundness.RELAXATION,
                notes=(
                    f"{len(coupling)} coupling constraint(s) dualized; "
                    f"{view.num_blocks} blocks that share array variables",
                    "yields a valid dual bound; primal recovery may need extra work",
                ),
                element_view=view,
            )
        ]


#: Default generator cascade, cheap-first (design doc §5.1).
DEFAULT_GENERATORS: tuple[CandidateGenerator, ...] = (
    MonolithicGenerator(),
    IndependentBlockGenerator(),
    IntegerProjectionGenerator(),
    OuterApproximationGenerator(),
    CouplingGenerator(),
    ElementIndependentBlockGenerator(),
    ElementIntegerProjectionGenerator(),
    ElementCouplingGenerator(),
)
"""The cascade every advisor runs.

A ``SeparatorGenerator`` -- candidates from the partitioning program in
:mod:`discopt.decomposition.graph.separator` -- was opt-in here and has been
retired (CLAUDE.md §5): on two-stage stochastic LPs it recommended Benders
decompositions slower than the monolithic LP (0.17-0.55x before its own
12-66 s search), and on a mixed-integer family it was break-even end to end.
The program itself remains as an explicit tool, ``find_separators`` plus
``DecompositionStructure.master_columns``; ``docs/design/decomposition-advisor.md``
§4.1 records the panels."""


def _dedup_key(cand: Candidate) -> tuple:
    """Identity of a candidate for de-duplication: method + partition signature."""
    s: DecompositionStructure | None = cand.structure
    if s is None:
        return (cand.method,)
    return (
        cand.method,
        tuple(sorted(s.complicating_vars)),
        tuple(sorted(s.coupling_constraints)),
        cand.element_view is not None,
    )


def generate_candidates(
    model,
    report: StructureReport,
    generators: tuple[CandidateGenerator, ...] = DEFAULT_GENERATORS,
) -> list[Candidate]:
    """Run the generator cascade and return de-duplicated candidates.

    Order follows the cascade (monolithic baseline first, then cheap structural
    detectors); duplicates from different generators collapse to the
    first-produced one. No ranking is applied.
    """
    out: list[Candidate] = []
    seen: set[tuple] = set()
    for gen in generators:
        if not gen.applicable(report):
            continue
        for cand in gen.generate(model, report):
            key = _dedup_key(cand)
            if key in seen:
                continue
            seen.add(key)
            out.append(cand)
    return out


__all__ = [
    "DEFAULT_GENERATORS",
    "CandidateGenerator",
    "CouplingGenerator",
    "ElementCouplingGenerator",
    "ElementIndependentBlockGenerator",
    "ElementIntegerProjectionGenerator",
    "IndependentBlockGenerator",
    "IntegerProjectionGenerator",
    "MonolithicGenerator",
    "generate_candidates",
]
