"""Classical Benders decomposition solver (v1: linear (MI)LP recourse).

Algorithm (minimization, internally)::

    min  c_x^T x + c_y^T y
    s.t. master-only rows           A_m x <= r_m
         coupling/recourse rows     A_x x + A_y y <= r          (after <= canonicalization)
         x integer-or-continuous (first stage), y continuous (recourse)

Master:  min c_x^T x + eta   s.t. A_m x <= r_m  +  accumulated Benders cuts.
Subproblem at x̂:  min c_y^T y  s.t. A_y y <= r - A_x x̂.

- Feasible subproblem → **optimality cut** ``eta >= lam^T(r - A_x x) + bt``.
- Infeasible subproblem → **feasibility cut** ``lam_f^T(r - A_x x) + bt_f <= 0``
  from a slack-penalized always-feasible LP, excluding x̂.

Every cut is the **complete LP dual objective** as an affine function of the
master variables: the row-dual term ``lam^T(r - A_x x)`` plus the variable
reduced-cost term ``bt = sum_j rc_j·(lb_j if rc_j>0 else ub_j)``. By LP weak
duality this is a lower bound on the recourse value for *every* master point and
*any* dual-feasible ``(lam, rc)``, so the cut is a valid global underestimator.
This is robust to two failure modes that simpler anchors have: a recourse solve
returning a slightly *suboptimal* primal (anchoring at that primal would
over-cut), and the row duals alone being an *incomplete* dual when a variable
bound is active (the ``rc`` term restores the missing contribution).

Both the master and the recourse-dual generator are pinned to the **exact-vertex**
engines (the Rust simplex B&B / simplex), falling back to POUNCE only where the
binding is unavailable — HiGHS-free either way. #986 retracts the claim this
docstring used to make, that the weak-duality argument above makes the solver
sound on POUNCE's interior-point duals: weak duality needs the returned point to
*be* dual-feasible, and an interior-point method reaches ``c - A^T lam - rc = 0``
only to its convergence tolerance, so its anchor can exceed the recourse value it
underestimates (measured worst ``D - Q = 1.391725e-07``). The master objective is
a rigorous lower bound only when the engines producing it are exact.

A *nonlinear* model is routed to Generalized Benders (:mod:`.gbd`), which
handles a convex-NLP recourse subproblem with KKT-multiplier cuts.
"""

from __future__ import annotations

import logging
import time
import warnings
from dataclasses import dataclass

import numpy as np

from discopt.decomposition._linear import (
    extract_linear,
    first_nonlinear_reason,
    relative_gap,
    solution_dict,
)
from discopt.decomposition.structure import (
    DecompositionStructure,
    detect_decomposition,
    flat_bounds,
)
from discopt.modeling.core import (
    Model,
    SolveResult,
    VarType,
)
from discopt.solvers import SolveStatus
from discopt.solvers.lp_backend import names_decomposition_route

logger = logging.getLogger(__name__)

# A valid global lower bound on the recourse cost, used as the master ``eta``
# floor so the master is bounded before any optimality cut is generated. The
# master LB stays rigorous as long as the true recourse cost is >= this value.
_ETA_FLOOR = -1e12
_BIG = 1e20


@dataclass
class BendersConfig:
    """Configuration for the Benders solver."""

    time_limit: float = 3600.0
    gap_tolerance: float = 1e-4
    # One Benders cut is added per iteration, so 100 is far too few for real
    # instances; runtime stays bounded by ``time_limit`` regardless (T0.4).
    max_iterations: int = 500
    prefer_pounce: bool = False
    feas_tol: float = 1e-6
    eta_floor: float = _ETA_FLOOR
    # Multicut: give each independent recourse block its own eta variable and
    # cut (T1.3). Reduces to the classic single-cut solver when the recourse does
    # not separate (one block). ``backend`` runs the per-block recourse solves
    # sequentially or on a thread pool.
    multicut: bool = True
    backend: str = "sequential"
    # Separation-point stabilization (T2.2): "inout" separates cuts at an
    # interior point x_sep = alpha*x* + (1-alpha)*x_center in addition to the
    # cut at x* (which still drives the incumbent and guarantees progress), so
    # correctness is unchanged and only the cut set is enriched. "none" is the
    # classic Kelley separation.
    stabilization: str = "none"
    stab_alpha: float = 0.5
    # Cut management (T2.3): drop an optimality cut whose slack has stayed large
    # for this many consecutive master solves (feasibility cuts are kept forever).
    cut_purge_after: int = 20
    cut_slack_tol: float = 1e-3


def _model_is_linear(model: Model) -> bool:
    """True iff every constraint body and the objective are linear.

    Used to route between classical Benders (linear recourse LP) and Generalized
    Benders (convex-NLP recourse). The witness is :func:`extract_linear` itself
    (#1657), so a linear MILP spelled with array sums (``dm.sum(x[i, :])``,
    ``dm.sum(c * x)``, ``c @ x``) is recognised as linear exactly when the
    classical-Benders extractor can take it apart.
    """
    return first_nonlinear_reason(model) is None


# ── Column partition ──────────────────────────────────────────


@dataclass
class _Partition:
    master_cols: np.ndarray  # int indices into flat vector (first stage)
    sub_cols: np.ndarray  # int indices (recourse)
    master_int: np.ndarray  # bool over master_cols: integer?


def _partition_columns(model: Model, structure: DecompositionStructure) -> _Partition:
    complicating = set(structure.complicating_vars)
    explicit = (
        set(int(j) for j in structure.master_columns)
        if structure.master_columns is not None
        else None
    )
    master_cols: list[int] = []
    sub_cols: list[int] = []
    master_int: list[bool] = []
    off = 0
    for v in model._variables:
        is_int = v.var_type in (VarType.BINARY, VarType.INTEGER)
        for _ in range(v.size):
            is_master = (off in explicit) if explicit is not None else (v.name in complicating)
            if is_master:
                master_cols.append(off)
                master_int.append(is_int)
            else:
                if is_int:
                    raise NotImplementedError(
                        f"Variable {v.name!r} is integer but is in the recourse "
                        "subproblem; Benders v1 requires all integer variables to "
                        "be first-stage (mark them with model.first_stage(...))."
                    )
                sub_cols.append(off)
            off += 1
    if explicit is not None and any(j < 0 or j >= off for j in explicit):
        bad = sorted(j for j in explicit if j < 0 or j >= off)[:5]
        raise ValueError(
            f"master_columns names column(s) {bad} outside the model's {off} columns; "
            "a column index that is out of range would otherwise be silently ignored."
        )
    return _Partition(
        np.array(master_cols, dtype=int),
        np.array(sub_cols, dtype=int),
        np.array(master_int, dtype=bool),
    )


# ── Solver ────────────────────────────────────────────────────


@names_decomposition_route("benders: discopt Benders decomposition")
def solve_benders(
    model: Model,
    *,
    structure: DecompositionStructure | None = None,
    time_limit: float = 3600.0,
    gap_tolerance: float = 1e-4,
    max_iterations: int = 100,
    nlp_solver: str = "pounce",
    config: BendersConfig | None = None,
    **_ignored,
) -> SolveResult:
    """Solve a two-stage (mixed-integer) linear program by Benders decomposition.

    Parameters
    ----------
    model : Model
        Linear-constraint, linear-objective model. Integer variables must be
        first-stage.
    structure : DecompositionStructure, optional
        Decomposition structure; auto-detected when omitted (complicating
        variables default to the integer variables).
    time_limit, gap_tolerance, max_iterations
        Standard termination controls.

    Returns
    -------
    SolveResult
        With a rigorous lower ``bound`` (the master objective) on convergence.
    """
    from discopt.solvers.lp_backend import (
        get_decomposition_master_solver,
        get_exact_dual_lp_solver,
        get_lp_solver,
    )

    cfg = config or BendersConfig(
        time_limit=time_limit,
        gap_tolerance=gap_tolerance,
        max_iterations=max_iterations,
        prefer_pounce=(nlp_solver == "pounce"),
    )
    t0 = time.time()

    # Recourse-LP dual generator. Every Benders cut is built from this solve's
    # duals, and the master objective those cuts define *is* the reported dual
    # ``bound`` — so this is a certificate-producing oracle and gets the exact
    # (vertex) one when it is available, exactly as OBBT/DBBT do (#145, #356).
    #
    # #986: the weak-duality argument that used to justify running this on the
    # POUNCE IPM ("valid for any dual-feasible point") needs the returned point to
    # *be* dual-feasible; an interior-point method satisfies ``c - A^T lam - rc =
    # 0`` only to its convergence tolerance, so its cut anchor ``D`` can sit above
    # the recourse value ``Q`` it is supposed to underestimate, and the cut then
    # over-cuts. Measured on the 148 recourse LPs of 12 seeded two-stage
    # instances, both oracles on identical LP data (290 comparisons): worst dual
    # residual 3.670730e-11 and worst over-cut ``D - Q = 1.391725e-07`` on the
    # IPM, against 0.0 / 0.0 on the exact basis. That is what let the reported
    # ``bound`` sit above the incumbent it certifies once an exact master stopped
    # masking it (+1.052606e-06 worst, over 120 seeded instances).
    #
    # ``get_exact_dual_lp_solver`` returns ``None`` when the Rust simplex binding
    # is unavailable; POUNCE-only installs then keep today's behaviour, with the
    # approximate-dual caveat above.
    dual_lp = get_exact_dual_lp_solver() or get_lp_solver(prefer_pounce=cfg.prefer_pounce)
    # #986: the master is a *linear* MILP, so it is pinned to the exact-vertex
    # simplex B&B and NOT routed by ``nlp_solver``, which selects the engine for
    # the *recourse* subproblem. Reusing it here sent the master to the
    # POUNCE-IPM-backed B&B, whose returned points are interior rather than
    # vertices, and whose objective — which *is* this solver's reported dual
    # ``bound`` — is an analytic-centre value that can drift above the incumbent it
    # certifies. Same conflation and same fix as the GBD master (#977, ``gbd.py``);
    # ``get_milp_solver`` still falls back to POUNCE when the Rust simplex binding
    # is unavailable, so POUNCE-only installs keep working.
    # #1614 D-26: HiGHS when available (an exact-vertex engine, as #986 requires).
    milp, _ = get_decomposition_master_solver()

    # Validate first, as Model.solve does: it canonicalizes the bodies, and the
    # coefficient extraction below walks an un-canonicalized shared sum
    # (``r = r + r`` repeated, #2100) as a tree -- exponential, a hang.
    model.validate()
    if structure is None:
        structure = detect_decomposition(model)

    # Nonlinear objective/constraint -> Generalized Benders (convex-NLP recourse).
    # The witness is the classical extractor itself (#1657): GBD is chosen exactly
    # when ``extract_linear`` cannot take the model apart, and the reason is said
    # out loud so a linear model misread as nonlinear is visible, not silent.
    try:
        lin = extract_linear(model)
    except NotImplementedError as exc:
        from discopt.decomposition.benders.gbd import solve_gbd

        warnings.warn(
            f"decomposition='benders': model not recognised as linear, so using "
            f"Generalized Benders (convex-NLP recourse): {exc}",
            UserWarning,
            stacklevel=2,
        )

        return solve_gbd(
            model,
            structure=structure,
            time_limit=time_limit,
            gap_tolerance=gap_tolerance,
            max_iterations=max_iterations,
            nlp_solver=nlp_solver,
        )

    part = _partition_columns(model, structure)
    mcols, scols = part.master_cols, part.sub_cols
    n_master = len(mcols)
    if n_master == 0:
        raise NotImplementedError(
            "Benders needs at least one first-stage (complicating) variable. "
            "Annotate them with model.first_stage(...), or ensure the model has "
            "integer variables (the default complicating set)."
        )

    lb_all, ub_all = flat_bounds(model)

    # Split rows into master-only and recourse (any nonzero recourse coeff).
    # The recourse LP is a ``<=`` problem, so use the ``<=``-canonical view
    # (equalities expanded, ``>=`` flipped) — identical to the classic row set.
    A_leq, b_leq, _src_leq = lin.rows_leq()
    A_m_rows, b_m_rows = [], []  # master-only, over master cols
    Ax_rows, Ay_rows, r_rows = [], [], []  # recourse: A_x (master), A_y (sub), rhs
    for vec, rhs in zip(A_leq, b_leq):
        sub_part = vec[scols] if len(scols) else np.zeros(0)
        if sub_part.size and np.any(np.abs(sub_part) > 0):
            Ax_rows.append(vec[mcols])
            Ay_rows.append(sub_part)
            r_rows.append(rhs)
        else:
            A_m_rows.append(vec[mcols])
            b_m_rows.append(rhs)

    A_m = np.array(A_m_rows) if A_m_rows else np.zeros((0, n_master))
    b_m = np.array(b_m_rows) if b_m_rows else np.zeros(0)

    c_master = lin.c[mcols]
    master_bounds = [(float(lb_all[i]), float(ub_all[i])) for i in mcols]
    lb_master = np.array([b[0] for b in master_bounds], dtype=np.float64)
    ub_master = np.array([b[1] for b in master_bounds], dtype=np.float64)

    # ── partition the recourse into independent blocks (T1.3 multicut) ──
    # Two sub-variables share a block iff they co-occur in a recourse row; the
    # blocks are the connected components of that graph. Each block gets its own
    # eta and its own cut, so a separable recourse converges in far fewer
    # iterations. With one block this is exactly the classic single-cut solver.
    ny = len(scols)
    if cfg.multicut and ny:
        from discopt.decomposition.graph import kernels

        row_positions = [[int(i) for i in np.nonzero(np.abs(ay) > 0)[0]] for ay in Ay_rows]
        sub_cliques = [pos for pos in row_positions if pos]
        block_of_pos, n_blocks = kernels.connected_components(ny, sub_cliques)
    else:
        row_positions = [[int(i) for i in np.nonzero(np.abs(ay) > 0)[0]] for ay in Ay_rows]
        block_of_pos = [0] * ny
        n_blocks = 1
    n_blocks = max(1, n_blocks)

    pos_of_block: list[list[int]] = [[] for _ in range(n_blocks)]
    for k in range(ny):
        pos_of_block[block_of_pos[k]].append(k)
    rows_of_block: list[list[int]] = [[] for _ in range(n_blocks)]
    for i, pos in enumerate(row_positions):
        b = block_of_pos[pos[0]] if pos else 0
        rows_of_block[b].append(i)

    class _Block:
        __slots__ = ("bid", "cols", "c_sub", "sub_bounds", "A_x", "A_y", "r")

        def __init__(self, bid: int, positions: list[int], row_idx: list[int]):
            self.bid = bid
            self.cols = np.array([scols[k] for k in positions], dtype=int)
            self.c_sub = lin.c[self.cols] if self.cols.size else np.zeros(0)
            self.sub_bounds = [(float(lb_all[j]), float(ub_all[j])) for j in self.cols]
            self.A_x = (
                np.array([Ax_rows[i] for i in row_idx]) if row_idx else np.zeros((0, n_master))
            )
            self.A_y = (
                np.array([Ay_rows[i][positions] for i in row_idx])
                if row_idx
                else np.zeros((0, len(positions)))
            )
            self.r = np.array([r_rows[i] for i in row_idx]) if row_idx else np.zeros(0)

    blocks = [_Block(b, pos_of_block[b], rows_of_block[b]) for b in range(n_blocks)]

    from discopt.decomposition.parallel.comm import select_backend

    comm = select_backend(cfg.backend)

    # Accumulated cuts, each on ``(x, eta_b)``: (block_id, coeff_x, coeff_eta, rhs).
    cut_block: list[int] = []
    cut_x: list[np.ndarray] = []
    cut_eta: list[float] = []
    cut_rhs: list[float] = []

    def _solve_master(with_eta: bool):
        n_eta = n_blocks if with_eta else 0
        ncol = n_master + n_eta
        c = np.zeros(ncol)
        c[:n_master] = c_master
        if with_eta:
            c[n_master:] = 1.0  # min c_x·x + sum_b eta_b
        rows, rhs = [], []
        if A_m.shape[0]:
            pad = np.zeros((A_m.shape[0], ncol))
            pad[:, :n_master] = A_m
            rows.append(pad)
            rhs.append(b_m)
        if with_eta and cut_x:
            cm = np.zeros((len(cut_x), ncol))
            for k in range(len(cut_x)):
                cm[k, :n_master] = cut_x[k]
                cm[k, n_master + cut_block[k]] = cut_eta[k]
            rows.append(cm)
            rhs.append(np.array(cut_rhs))
        A_ub = np.vstack(rows) if rows else None
        b_ub = np.concatenate(rhs) if rhs else None
        bounds = list(master_bounds)
        integrality = np.zeros(ncol, dtype=np.int32)
        integrality[:n_master] = part.master_int.astype(np.int32)
        if with_eta:
            bounds.extend([(cfg.eta_floor, _BIG)] * n_blocks)
        res = milp(
            c,
            A_ub=A_ub,
            b_ub=b_ub,
            bounds=bounds,
            integrality=integrality,
            time_limit=max(1.0, cfg.time_limit - (time.time() - t0)),
            gap_tolerance=cfg.gap_tolerance,
        )
        return res

    def _master_x(res) -> np.ndarray:
        """The first-stage point of a master solve, clamped to its own bounds.

        A MILP engine can return a point that violates the variable bounds it was
        handed by a sub-tolerance amount (measured over these masters: up to
        1.8e-07, and 1.8e-15 on the instance behind #986). ``x_hat`` reaches the
        recourse only through the rhs shift ``r - A_x x_hat``, where each row
        coefficient scales that noise — enough to turn a pair of rows that pin a
        recourse variable to a bound (``y <= a·x``, ``y >= a·x``) into a pair that
        is *mutually inconsistent by ~1e-14*. An exact LP presolve then reports the
        recourse INFEASIBLE at a point where it is feasible, which costs the
        incumbent for that iteration and emits a feasibility cut that cannot
        separate — the loop then stalls out at ``iteration_limit`` with no
        incumbent at all (the three ``test_decomposition_solve_equivalence``
        failures in #986). Clamping kills that noise at its source, which is the
        only defence on a POUNCE-only install: there the recourse LP is solved by
        the IPM, whose presolve is exact enough to reject such a pair of rows.

        Only sub-tolerance noise is repaired silently. A violation beyond the
        repo's declared ``abs=1e-6`` is an engine defect, not noise, and clamping
        it would be a silent approximation — so it is logged with its magnitude.
        """
        x = np.asarray(res.x[:n_master], dtype=np.float64)
        clamped = np.clip(x, lb_master, ub_master)
        worst = float(np.max(np.abs(clamped - x))) if x.size else 0.0
        if worst > 1e-6:
            logger.warning(
                "Benders master returned a point %.6e outside its own variable "
                "bounds; clamping, but this is past the declared abs=1e-6 and "
                "points at the MILP engine rather than at rounding noise.",
                worst,
            )
        return clamped

    def _recourse_block(blk: "_Block", x_hat: np.ndarray):
        """Classify one recourse block's LP at x̂ (kinds as in the single-block
        docstring: ``opt`` / ``unbounded`` / ``infeas`` / ``recourse_fail``)."""
        A_x, A_y, r, sub_bounds, c_sub = blk.A_x, blk.A_y, blk.r, blk.sub_bounds, blk.c_sub
        rhs = r - (A_x @ x_hat if A_x.shape[0] else np.zeros(0))
        res = dual_lp(
            c_sub,
            A_ub=A_y if A_y.shape[0] else None,
            b_ub=rhs if A_y.shape[0] else None,
            bounds=sub_bounds,
        )
        if res.status == SolveStatus.OPTIMAL:
            lam = (
                np.asarray(res.dual_values, dtype=np.float64)
                if res.dual_values is not None
                else np.zeros(A_y.shape[0])
            )
            rc = (
                np.asarray(res.reduced_costs, dtype=np.float64)
                if res.reduced_costs is not None
                else None
            )
            return (
                "opt",
                float(res.objective),
                np.asarray(res.x, dtype=np.float64),
                lam,
                rc,
                sub_bounds,
            )
        if res.status == SolveStatus.UNBOUNDED:
            return "unbounded", None, None, None, None, sub_bounds
        m_rec = A_y.shape[0]
        nyb = len(blk.cols)
        Afeas = np.zeros((m_rec, nyb + m_rec))
        Afeas[:, :nyb] = A_y
        Afeas[:, nyb:] = -np.eye(m_rec)
        c_feas = np.concatenate([np.zeros(nyb), np.ones(m_rec)])
        bnds = list(sub_bounds) + [(0.0, _BIG)] * m_rec
        fres = dual_lp(c_feas, A_ub=Afeas, b_ub=rhs, bounds=bnds)
        if fres.status != SolveStatus.OPTIMAL:
            return "recourse_fail", None, None, None, None, bnds
        v = float(fres.objective) if fres.objective is not None else 0.0
        lam = (
            np.asarray(fres.dual_values, dtype=np.float64)
            if fres.dual_values is not None
            else np.zeros(m_rec)
        )
        rc = (
            np.asarray(fres.reduced_costs, dtype=np.float64)
            if fres.reduced_costs is not None
            else None
        )
        return "infeas", v, None, lam, rc, bnds

    def _recourse_all(x_hat: np.ndarray):
        """Solve every block's recourse at x̂ on the configured backend, in block
        order (deterministic regardless of backend)."""
        return comm.map(blocks, lambda blk: _recourse_block(blk, x_hat))

    def _dual_const(blk: "_Block", lam, rc, col_bounds) -> float:
        """The y-independent part of the *complete* LP dual objective,
        ``lam^T r + sum_j rc_j * (lb_j if rc_j>0 else ub_j)``.

        By LP weak duality the full dual objective ``D(y) = lam^T(r - A_x y) +
        bound_terms`` is a lower bound on the recourse value ``Q(y)`` for *every*
        master point y and *any* dual-feasible (lam, rc) — so a cut anchored at
        ``D`` is always a valid global underestimator. This is robust to two
        failure modes a naive anchor has: (1) an interior-point recourse solve
        returns a slightly *suboptimal* primal ``Q`` (anchoring there would
        over-cut), and (2) the row duals alone are an *incomplete* dual when a
        variable bound is active (the ``rc`` term restores the missing
        contribution).

        A bound at the ``_BIG`` open sentinel (or any ``|bound| >= _BIG``) is
        treated as infinite and skipped: ``np.isfinite(1e20)`` is ``True``, so a
        tiny reduced-cost noise at a sentinel-bounded column (e.g. a feasibility
        slack's ``_BIG`` upper bound) would otherwise inject a ``rc * 1e20``
        term and corrupt the cut constant.
        """
        r = blk.r
        d = float(lam @ r) if lam.size and r.size else 0.0
        if rc is not None:
            for j, rcj in enumerate(rc):
                if rcj > 0:
                    lbj = col_bounds[j][0]
                    if np.isfinite(lbj) and abs(lbj) < _BIG:
                        d += rcj * lbj
                elif rcj < 0:
                    ubj = col_bounds[j][1]
                    if np.isfinite(ubj) and abs(ubj) < _BIG:
                        d += rcj * ubj
        return d

    def _add_opt_cut(blk: "_Block", lam, rc, col_bounds):
        # Optimality cut on this block's eta = the complete LP dual objective:
        #     eta_b >= lam^T(r - A_x y) + bound_terms = const + s^T y,
        # with s = -A_x^T lam. Valid for any dual-feasible (lam, rc) by weak
        # duality.  s^T x - eta_b <= -const.
        s = -(blk.A_x.T @ lam) if blk.A_x.shape[0] else np.zeros(n_master)
        const = _dual_const(blk, lam, rc, col_bounds)
        cut_block.append(blk.bid)
        cut_x.append(s.copy())
        cut_eta.append(-1.0)
        cut_rhs.append(-const)
        return blk.bid, s, -1.0, -const

    def _add_feas_cut(blk: "_Block", lam, rc, col_bounds):
        # Feasibility cut for this block: the min-infeasibility dual objective
        #     v_D(y) = lam^T(r - A_x y) + bound_terms <= 0  (excludes ŷ).
        s = -(blk.A_x.T @ lam) if blk.A_x.shape[0] else np.zeros(n_master)
        const = _dual_const(blk, lam, rc, col_bounds)
        cut_block.append(blk.bid)
        cut_x.append(s.copy())
        cut_eta.append(0.0)
        cut_rhs.append(-const)
        return blk.bid, s, 0.0, -const

    def _cut_separates(cut, x_hat, eta_vec) -> bool:
        # A cut ``s·x + eta_coef·eta_b <= rhs`` separates (x̂, η̂_b) iff violated
        # there beyond tolerance. A cut that does not separate makes no progress.
        bid, s, eta_coef, rhs = cut
        eta_b = float(eta_vec[bid]) if bid < len(eta_vec) else -np.inf
        lhs = float(s @ x_hat) + eta_coef * eta_b
        return bool(lhs > rhs + cfg.feas_tol)

    # ── initialize: feasible master point (no eta) ──
    init = _solve_master(with_eta=False)
    if init.status == SolveStatus.INFEASIBLE:
        return SolveResult(status="infeasible", wall_time=time.time() - t0, gap_certified=True)
    if init.status != SolveStatus.OPTIMAL or init.x is None:
        # Say why: an unbounded first-stage variable (bounds at the 1e20
        # sentinel) leaves this recourse-free master unbounded, which classical
        # Benders cannot start from. It used to return a bare "error".
        names = []
        master_set = set(mcols.tolist())
        off = 0
        for v in model._variables:
            for k in range(v.size):
                j = off + k
                if j in master_set and (abs(lb_all[j]) >= 1e19 or abs(ub_all[j]) >= 1e19):
                    names.append(v.name if v.size == 1 else f"{v.name}[{k}]")
            off += v.size
        why = f"the initial master (first stage only) returned {init.status.value}" + (
            f"; first-stage variable(s) {names[:5]} are unbounded, and classical "
            "Benders needs a bounded first stage -- bound them, or keep them out "
            "of the master"
            if names
            else ""
        )
        return SolveResult(status="error", wall_time=time.time() - t0, error=why)
    x_hat = _master_x(init)

    results = _recourse_all(x_hat)
    if any(r is not None and r[0] == "recourse_fail" for r in results):
        results = _recourse_all(x_hat)  # retry once
        if any(r is not None and r[0] == "recourse_fail" for r in results):
            logger.warning("Benders recourse solve failed twice at the initial point.")
            return SolveResult(status="error", wall_time=time.time() - t0)
    for r in results:
        if r[0] == "unbounded":
            return SolveResult(status="unbounded", wall_time=time.time() - t0)
    for blk, res in zip(blocks, results):
        kind = res[0]
        if kind == "opt":
            _add_opt_cut(blk, res[3], res[4], res[5])
        elif kind == "infeas":
            _add_feas_cut(blk, res[3], res[4], res[5])

    best_ub = np.inf
    # #1611 D-29: the best master dual bound seen over the run. Every master
    # solve's bound is a valid lower bound (cuts are valid underestimators), but
    # purging stale cuts (T2.3) WEAKENS the master, so the bound of a later -- in
    # particular the final -- master solve can sit below one already proved. The
    # loop used to certify ``optimal`` against the pre-purge bound and then report
    # the post-purge one: ``optimal`` with a 2.2e-3 relative gap. Report the best.
    best_lb = -np.inf
    incumbent_full: np.ndarray | None = None
    status = "iteration_limit"
    stall = 0  # consecutive non-separating iterations (T0.4 progress guard)
    x_center: np.ndarray | None = None  # in-out stabilization centre (T2.2)
    cut_streak: list[int] = [0] * len(cut_x)  # per-cut large-slack streak (T2.3)

    def _add_inout_cuts(x_star: np.ndarray):
        """Separate additional cuts at the interior point
        ``x_sep = alpha*x* + (1-alpha)*x_center`` (T2.2). These are extra valid
        global underestimators; the x* cuts already added drive the incumbent and
        guarantee progress, so this only enriches the master."""
        if cfg.stabilization != "inout" or x_center is None or cfg.stab_alpha >= 1.0:
            return
        x_sep = cfg.stab_alpha * x_star + (1.0 - cfg.stab_alpha) * x_center
        sep_results = _recourse_all(x_sep)
        for blk, res in zip(blocks, sep_results):
            if res is None or res[0] in ("recourse_fail", "unbounded"):
                continue  # a fractional x_sep block issue: just skip stabilization
            if res[0] == "opt":
                _add_opt_cut(blk, res[3], res[4], res[5])
            elif res[0] == "infeas":
                _add_feas_cut(blk, res[3], res[4], res[5])

    def _purge_stale_cuts(x_star: np.ndarray, eta_vec: np.ndarray) -> None:
        """Drop optimality cuts whose slack has stayed large for many master
        solves (T2.3); feasibility cuts (eta_coef 0) are kept forever."""
        while len(cut_streak) < len(cut_x):
            cut_streak.append(0)
        keep_idx = []
        for k in range(len(cut_x)):
            slack = cut_rhs[k] - (
                float(cut_x[k] @ x_star) + cut_eta[k] * float(eta_vec[cut_block[k]])
            )
            if slack > cfg.cut_slack_tol:
                cut_streak[k] += 1
            else:
                cut_streak[k] = 0
            drop = cut_eta[k] == -1.0 and cut_streak[k] >= cfg.cut_purge_after
            if not drop:
                keep_idx.append(k)
        if len(keep_idx) != len(cut_x):
            logger.debug("Benders purged %d stale cuts", len(cut_x) - len(keep_idx))
            cut_block[:] = [cut_block[k] for k in keep_idx]
            cut_x[:] = [cut_x[k] for k in keep_idx]
            cut_eta[:] = [cut_eta[k] for k in keep_idx]
            cut_rhs[:] = [cut_rhs[k] for k in keep_idx]
            cut_streak[:] = [cut_streak[k] for k in keep_idx]

    for _it in range(cfg.max_iterations):
        if time.time() - t0 > cfg.time_limit:
            status = "time_limit"
            break
        mres = _solve_master(with_eta=True)
        if mres.status == SolveStatus.INFEASIBLE:
            status = "infeasible"
            best_ub = np.inf
            incumbent_full = None
            break
        if mres.x is None:
            status = "error"
            break
        x_hat = _master_x(mres)
        eta_vec = np.asarray(mres.x[n_master : n_master + n_blocks], dtype=np.float64)
        if x_center is None:
            x_center = x_hat.copy()  # first stabilization centre (T2.2)
        # Only a dual bound is a bound: a limit-hit master's ``objective`` is its
        # incumbent, an *upper* value, and ``best_lb`` keeps whatever enters it.
        if mres.status == SolveStatus.OPTIMAL:
            lb = mres.bound if mres.bound is not None else mres.objective
        else:
            lb = mres.bound
        lower_bound = (float(lb) + lin.c_offset) if lb is not None else None
        if lower_bound is not None and not np.any(eta_vec <= cfg.eta_floor + 1.0):
            # Same eta-floor guard as the final bound below (T0.5): while a
            # block's eta sits on the floor the master value is not a bound.
            best_lb = max(best_lb, lower_bound)

        results = _recourse_all(x_hat)
        if any(r is not None and r[0] == "recourse_fail" for r in results):
            results = _recourse_all(x_hat)  # retry once (T0.3)
            if any(r is not None and r[0] == "recourse_fail" for r in results):
                logger.warning("Benders recourse solve failed twice; stopping.")
                break
        for r in results:
            if r[0] == "unbounded":
                return SolveResult(status="unbounded", wall_time=time.time() - t0)

        # Incumbent: only when every block's recourse is optimal (feasible).
        if all(res[0] == "opt" for res in results):
            total = float(c_master @ x_hat + lin.c_offset)
            x_full = np.zeros(lin.n)
            x_full[mcols] = x_hat
            for blk, res in zip(blocks, results):
                total += res[1]
                if blk.cols.size:
                    x_full[blk.cols] = res[2]
            if total < best_ub:
                best_ub = total
                incumbent_full = x_full
                x_center = x_hat.copy()  # move stabilization centre to incumbent

        # Per-block cuts; track whether any of them separates the master point.
        separated = False
        for blk, res in zip(blocks, results):
            if res[0] == "opt":
                cut = _add_opt_cut(blk, res[3], res[4], res[5])
            else:  # infeas
                cut = _add_feas_cut(blk, res[3], res[4], res[5])
            if _cut_separates(cut, x_hat, eta_vec):
                separated = True

        # In-out: enrich the master with cuts separated at the interior point.
        _add_inout_cuts(x_hat)
        # Cut management: drop long-stale optimality cuts.
        _purge_stale_cuts(x_hat, eta_vec)

        if separated:
            stall = 0
        else:
            stall += 1
            logger.warning(
                "Benders iteration %d added no separating cut "
                "(degenerate or missing duals); stall=%d.",
                _it,
                stall,
            )
            if stall >= 2:
                break

        if np.isfinite(best_ub) and np.isfinite(best_lb):
            gap = relative_gap(best_ub, best_lb)
            if gap <= cfg.gap_tolerance:
                status = "optimal"
                break

    # Final bound = best master lower bound from the last master solve.
    final = _solve_master(with_eta=True)
    bound = None
    if final.status == SolveStatus.OPTIMAL:
        lb = final.bound if final.bound is not None else final.objective
        if lb is not None:
            bound = float(lb) + lin.c_offset
        # The eta floor keeps the master bounded before cuts arrive; if any
        # block's eta still sits on it, that block's recourse is not yet
        # underestimated and the master "bound" is the floor — withhold it (T0.5).
        if final.x is not None and len(final.x) >= n_master + n_blocks:
            eta_final = np.asarray(final.x[n_master : n_master + n_blocks], dtype=np.float64)
            if np.any(eta_final <= cfg.eta_floor + 1.0):
                logger.warning("Benders eta floor still active; withholding bound.")
                bound = None

    if np.isfinite(best_lb):
        bound = best_lb if bound is None else max(bound, best_lb)

    if status == "infeasible":
        return SolveResult(status="infeasible", wall_time=time.time() - t0, gap_certified=True)

    objective = None if not np.isfinite(best_ub) else best_ub
    # The certificate is the reported (objective, bound) pair: ``optimal`` only
    # when that pair closes the gap, never on a bound the result does not carry.
    if status == "optimal" and (
        objective is None or bound is None or relative_gap(objective, bound) > cfg.gap_tolerance
    ):
        status = "iteration_limit"
    # Promote to optimal if the final master bound already meets the incumbent.
    if status == "iteration_limit" and objective is not None and bound is not None:
        if relative_gap(objective, bound) <= cfg.gap_tolerance:
            status = "optimal"

    # Map the internal-minimization values back to the model's sense. For a
    # maximize problem (c was negated), negating swaps the incumbent (a lower
    # bound on the max) and the dual bound (an upper bound on the max) into the
    # reported objective/bound; their gap magnitude is unchanged.
    sense_flip = 1.0 if lin.minimize else -1.0
    reported_obj = None if objective is None else objective * sense_flip
    reported_bound = None if bound is None else bound * sense_flip
    reported_gap: float | None = None
    if reported_obj is not None and reported_bound is not None:
        reported_gap = abs(relative_gap(reported_obj, reported_bound))

    x_dict = solution_dict(model, incumbent_full) if incumbent_full is not None else None

    return SolveResult(
        status=status,
        objective=reported_obj,
        bound=reported_bound,
        gap=reported_gap,
        x=x_dict,
        wall_time=time.time() - t0,
        node_count=0,
        gap_certified=(status == "optimal"),
    )
