"""Build the POUNCE AD tape from the Rust expression arena instead of the Python DAG.

Measured motivation (#1215): at foundation scale (100k rows) the tape build is
**59% of the whole build -> solve-ready pipeline**, and **93-94% of that is
:mod:`discopt._nl_expr_compiler` walking the Python expression DAG**
(57.9-64.6 us/row) while POUNCE's own ``build_nl_problem`` is 4.1-4.4 us/row and
flat. ``model_to_repr`` has *already* walked the same structure into a typed Rust
arena moments earlier, so the Python walk is a second pass over data that is
already in a form a machine can scan.

``PyModelRepr.tape_program()`` returns that arena as six flat numpy arrays. The
arena is append-only, so a child's ``ExprId`` is always lower than its parent's:
lowering is a single forward **array scan** with a ``cache[i]`` table -- no
recursion, no ``id()``-keyed memo, and no exponential blow-up on shared
subtrees.

Why this is allowed to be silent-fallback rather than silent-substitute
----------------------------------------------------------------------

A tape is the derivative source for the whole NLP path. A tape that is merely
*plausible* is worse than no tape: it yields wrong gradients, hence wrong
incumbents, hence a wrong certificate (CLAUDE.md §1). So this module never
guesses:

* ``tape_program`` emits ``OP_UNSUPPORTED`` -- never a skip -- for every arena
  node the flat encoding does not cover (array variables, matmul, axis sums,
  constant arrays, shaped parameters, non-integer indexing, ``MathFunc``\\ s
  outside the mapped set). Unsupportedness propagates up through every parent.
* :func:`try_build_arena_tape` returns ``None`` -- not a partial tape -- if the
  objective or *any* constraint root is unsupported, if the model carries
  builder-resident rows (whose arena order differs from the Python order, see
  below), or if the arena's flat variable offsets disagree with the model's.
  The caller then walks the Python DAG exactly as before.

Bit-identity, not approximate agreement
---------------------------------------

The emission rules below mirror :mod:`discopt._nl_expr_compiler` node for node,
including its additive-chain flattening: a maximal ``+``/``-`` chain of at least
:data:`~discopt._nl_expr_compiler._FLATTEN_MIN_TERMS` leaves becomes one n-ary
``E.sum`` in *left-to-right leaf order*, and a shorter chain keeps its original
binary nesting. That threshold is imported rather than repeated so the two paths
cannot drift. Matching it is not cosmetic: emitting a binary ``+`` chain where
the Python path emits ``E.sum`` would rebuild the depth-N nesting that
``NlExpr.max_depth`` refuses at 10 000 terms, and flattening where Python does
not would reassociate the sum (``a+(b+c)`` is not ``(a+b)+c`` in IEEE).

Row order
---------

``model_to_repr`` clones the builder's constraint vector first and appends the
expression-path rows after it (``expr_bindings.rs``), whereas the evaluator
enumerates ``(*model._constraints, *model._builder_linear_constraints())`` --
the opposite order. Rather than reorder on an invariant that is only true today,
this module refuses any model carrying builder rows, so arena index ``i`` is
``model._constraints[i]`` by construction. Builder rows are the linear
fast-construction path and are cheap to lower on the Python side anyway.
"""

from __future__ import annotations

import logging
import math
import os
from typing import Any, Optional

import numpy as np

from discopt._nl_expr_compiler import _FLATTEN_MIN_TERMS, _pow, _sqrt
from discopt.export._common import has_builder_only_constraint_rows

# Opcodes -- must track `crates/discopt-python/src/expr_bindings.rs::tape_program`.
OP_UNSUPPORTED = 0
OP_CONST = 1
OP_VAR = 2
OP_ADD = 3
OP_SUB = 4
OP_MUL = 5
OP_DIV = 6
OP_POW = 7
OP_NEG = 8
OP_ABS = 9
OP_SUMOVER = 10
OP_FUNC_BASE = 20

#: ``math_func_code`` order in ``expr_bindings.rs``. Code 99 is that function's
#: catch-all for a ``MathFunc`` it does not map; it is deliberately absent here so
#: it resolves to "unsupported" rather than to some neighbouring function.
# MathFunc index -> the NlExpr method of the same meaning. Every name here must
# be a REAL method on `pounce.NlExpr`: the scan calls it through `getattr`, so a
# name that does not exist raises `AttributeError` mid-solve instead of falling
# back. `test_1215_arena_tape_func_table.py` asserts the whole table against the
# live class, which is how the `log2` entry below was caught.
#
# `Log2` (index 2) is deliberately absent: NlExpr has `log` and `log10` but no
# `log2`, so it is lowered in the scan the same way the Python compiler lowers
# it. Indices past the end (Acos, Tanh, Erf, ...) are simply not lowered here --
# `.get()` returns None and the model falls back to the Python DAG path.
_FUNC_LOG2 = 2
#: ``Sqrt`` is lowered through ``_nl_expr_compiler._sqrt``, not the bare method.
_FUNC_SQRT = 4

_FUNC_METHOD = {
    0: "exp",
    1: "log",
    3: "log10",
    4: "sqrt",
    5: "sin",
    6: "cos",
    7: "tan",
    8: "atan",
    9: "sinh",
    10: "cosh",
    11: "asin",
}

_LOG = logging.getLogger(__name__)

_ENV = "DISCOPT_ARENA_TAPE"


def arena_tape_enabled() -> bool:
    """Whether the arena lowering is used. ``DISCOPT_ARENA_TAPE=0`` opts out.

    Read at call time, not import time, so a test can flip it without reloading.
    The legacy Python-DAG path stays intact and is still the fallback for every
    model this lowering refuses, so the opt-out is a switch between two live
    paths, not a dead flag.
    """
    return os.environ.get(_ENV, "1") not in ("0", "false", "False")


def _num(obj: Any, attr: str) -> Any:
    """Read a ``PyModelRepr`` field that may be exposed as a property or a method."""
    v = getattr(obj, attr)
    return v() if callable(v) else v


class _Program:
    """The six flat arrays of the arena's tape encoding, n-ary operands sliced out.

    Built either from ``tape_program()`` (one slot per arena node; refuses array
    bodies) or from ``tape_program_expanded()`` (fully scalar, array bodies fanned
    out in Rust). Both emit the same opcodes and the same
    operands-have-lower-indices invariant, so :func:`lower` serves both.
    """

    __slots__ = ("op", "a", "b", "k", "_args_flat", "_args_ptr", "n")

    def __init__(self, arrays: Any) -> None:
        op, a, b, k, args_flat, args_ptr = arrays
        self.op = np.asarray(op)
        self.a = np.asarray(a)
        self.b = np.asarray(b)
        self.k = np.asarray(k)
        self._args_flat = np.asarray(args_flat)
        self._args_ptr = np.asarray(args_ptr)
        self.n = int(self.op.shape[0])

    def args(self, i: int) -> np.ndarray:
        return self._args_flat[self._args_ptr[i] : self._args_ptr[i + 1]]


def _chain_leaves(prog: _Program, root: int) -> Optional[list[tuple[int, int]]]:
    """Signed leaves of the maximal ``+``/``-`` chain at *root*, left-to-right.

    The exact analogue of :func:`discopt._nl_expr_compiler._additive_chain`,
    including its ``None`` return for a chain shorter than
    :data:`_FLATTEN_MIN_TERMS` (so the caller falls through to ordinary binary
    lowering) and its explicit stack -- the shape being flattened is precisely
    the one deep enough to overflow a recursive walk.
    """
    out = _signed_leaves(prog, root)
    if len(out) < _FLATTEN_MIN_TERMS:
        return None
    return out


def _signed_leaves(prog: _Program, root: int) -> list[tuple[int, int]]:
    """Every signed leaf of the ``+``/``-`` tree at *root*, left-to-right.

    :func:`_chain_leaves` without its length threshold: a lone non-sum root is
    one leaf with sign ``+1``.
    """
    op, a, b = prog.op, prog.a, prog.b
    out: list[tuple[int, int]] = []
    stack: list[tuple[int, int]] = [(root, 1)]
    while stack:
        nid, sign = stack.pop()
        o = op[nid]
        if o == OP_ADD or o == OP_SUB:
            rsign = sign if o == OP_ADD else -sign
            # push right first so the left subtree pops (and so lowers) first
            stack.append((int(b[nid]), rsign))
            stack.append((int(a[nid]), sign))
        else:
            out.append((sign, int(nid)))
    return out


def _affine_leaf(prog: _Program, leaf: int) -> Optional[tuple[int, float]]:
    """``(slot, coefficient)`` when *leaf* is ``x``, ``-x``, ``c*x`` or ``x*c``.

    Deliberately not ``x/c``: ``x/c`` and ``(1/c)*x`` differ in the last bit,
    and the split this feeds is admitted only where it is bit-identical.
    """
    op, a, b, k = prog.op, prog.a, prog.b, prog.k
    o = op[leaf]
    if o == OP_VAR:
        return int(k[leaf]), 1.0
    if o == OP_NEG and op[a[leaf]] == OP_VAR:
        return int(k[a[leaf]]), -1.0
    if o == OP_MUL:
        lhs, rhs = int(a[leaf]), int(b[leaf])
        if op[lhs] == OP_CONST and op[rhs] == OP_VAR:
            return int(k[rhs]), float(k[lhs])
        if op[lhs] == OP_VAR and op[rhs] == OP_CONST:
            return int(k[lhs]), float(k[rhs])
    return None


def _linear_row(prog: _Program, root: int) -> Optional[tuple[list[int], list[float], float]]:
    """``(slots, coefficients, constant)`` when the row at *root* is affine, else ``None``.

    Admitted shape (#2293): a ``+``/``-`` tree whose leaves are all affine
    (:func:`_affine_leaf`), optionally followed by ONE trailing nonzero constant
    leaf and then any number of zero constants. The
    shape is chosen so that handing the leaves to POUNCE as the row's linear
    segment evaluates **bit-identically** to taping them:

    * The tape sums a row's summands left to right from ``0.0``; the linear
      segment sums ``c * x`` in the same order. ``c * x`` equals what the tape
      computes for each leaf exactly: ``1*x`` is ``x``, ``-1*x`` is ``-x``, and
      ``(-c)*x`` is ``-(c*x)``, because IEEE negation is exact.
    * A trailing constant ``c`` stays as the row's expression, so the row is
      ``c + (a + b + ...)`` where the tape computed ``(a + b + ...) + c`` -- one
      addition, and IEEE addition is commutative. A constant anywhere *else*
      would reassociate the sum, so such a row is not split.
    * The Jacobian entries are the coefficients either way, accumulated in the
      same order, and the rows contribute nothing to the Hessian.

    Mixed rows (some leaf nonlinear) are left whole: splitting them would
    reassociate the sum, which is a bound-changing change, not this one.
    ``test_2293_linear_rows.py`` checks the bit-identity on the evaluator.
    """
    leaves = _signed_leaves(prog, root)
    # Trailing zero constants first -- every body ends in one, the ``- rhs`` the
    # modelling layer appends with ``rhs = 0``. Adding a zero is exact (it can
    # only turn a ``-0.0`` result into ``+0.0``, which compares equal).
    while len(leaves) > 1 and prog.op[leaves[-1][1]] == OP_CONST and prog.k[leaves[-1][1]] == 0.0:
        leaves.pop()
    constant = 0.0
    if prog.op[leaves[-1][1]] == OP_CONST:
        sign, leaf = leaves.pop()
        constant = float(prog.k[leaf]) if sign > 0 else -float(prog.k[leaf])
    slots: list[int] = []
    coefs: list[float] = []
    for sign, leaf in leaves:
        term = _affine_leaf(prog, leaf)
        if term is None:
            return None
        slots.append(term[0])
        coefs.append(term[1] if sign > 0 else -term[1])
    return slots, coefs, constant


#: Node budget for one structural-equality test in :func:`_arena_sum_of_squares`.
#: Square bases are small in practice; a larger one is declared "not a square",
#: which keeps the edge-honest ``sqrt`` -- the behaviour before #1933.
_STRUCT_EQ_BUDGET = 4096


def _arena_struct_eq(prog: _Program, x: int, y: int) -> bool:
    """Structural equality of two arena subtrees (same ops, constants, variables)."""
    op, a, b, k = prog.op, prog.a, prog.b, prog.k
    stack = [(x, y)]
    budget = _STRUCT_EQ_BUDGET
    while stack:
        p, q = stack.pop()
        if p == q:
            continue
        budget -= 1
        if budget < 0:
            return False
        o = op[p]
        if o != op[q] or o == OP_UNSUPPORTED:
            return False
        if o in (OP_CONST, OP_VAR):
            if k[p] != k[q]:
                return False
            continue
        if o == OP_SUMOVER:
            tp, tq = prog.args(p), prog.args(q)
            if tp.shape != tq.shape:
                return False
            stack.extend(zip(tp.tolist(), tq.tolist()))
            continue
        if (a[p] < 0) != (a[q] < 0) or (b[p] < 0) != (b[q] < 0):
            return False
        if a[p] >= 0:
            stack.append((int(a[p]), int(a[q])))
        if b[p] >= 0:
            stack.append((int(b[p]), int(b[q])))
    return True


def _arena_sum_of_squares(prog: _Program, root: int) -> bool:
    """The arena analogue of :func:`discopt._nl_expr_compiler._is_sum_of_squares`.

    A nonnegatively weighted sum of ``b**2`` / ``b*b`` terms plus constants ``>= 0``,
    through ``+``/``-``/``neg`` chains and n-ary sums. The two must decide alike so
    the arena and the Python-DAG path build the same tape for ``sqrt``.
    """
    op, a, b, k = prog.op, prog.a, prog.b, prog.k

    def const(i: int) -> Optional[float]:
        return float(k[i]) if op[i] == OP_CONST else None

    def square(i: int) -> bool:
        if op[i] == OP_POW:
            return const(int(b[i])) == 2.0
        return op[i] == OP_MUL and _arena_struct_eq(prog, int(a[i]), int(b[i]))

    stack: list[tuple[int, float]] = [(root, 1.0)]
    while stack:
        i, sign = stack.pop()
        o = op[i]
        if o == OP_ADD or o == OP_SUB:
            stack.append((int(a[i]), sign))
            stack.append((int(b[i]), sign if o == OP_ADD else -sign))
            continue
        if o == OP_NEG:
            stack.append((int(a[i]), -sign))
            continue
        if o == OP_SUMOVER:
            stack.extend((int(t), sign) for t in prog.args(i))
            continue
        c = const(i)
        if c is not None:
            if not sign * c >= 0.0:  # also rejects NaN
                return False
            continue
        if o == OP_MUL:
            cl, cr = const(int(a[i])), const(int(b[i]))
            if cl is not None and square(int(b[i])):
                if not sign * cl >= 0.0:
                    return False
                continue
            if cr is not None and square(int(a[i])):
                if not sign * cr >= 0.0:
                    return False
                continue
        if sign > 0.0 and square(i):
            continue
        return False
    return True


def _mark_needed(prog: _Program, roots: Any) -> tuple[np.ndarray, dict[int, list[tuple[int, int]]]]:
    """The backward pass of :func:`lower`: which nodes are materialised, and the chains.

    Walks *backwards* from the roots marking which nodes are actually reachable
    and, at each additive chain root, recording its flattened leaves and marking
    those (not the chain's interior nodes) as needed -- mirroring
    ``_nl_expr_compiler._children``, which descends straight to a chain's leaves
    so the interiors are never lowered. Because a child's id is always below its
    parent's, one backward sweep suffices.
    """
    n = prog.n
    op, a, b = prog.op, prog.a, prog.b

    needed = np.zeros(n, dtype=bool)
    chains: dict[int, list[tuple[int, int]]] = {}
    for r in roots:
        needed[r] = True

    for i in range(n - 1, -1, -1):
        if not needed[i]:
            continue
        o = op[i]
        if o == OP_ADD or o == OP_SUB:
            ch = _chain_leaves(prog, i)
            if ch is not None:
                chains[i] = ch
                for _, leaf in ch:
                    needed[leaf] = True
                continue
        if a[i] >= 0:
            needed[a[i]] = True
        if b[i] >= 0:
            needed[b[i]] = True
        if o == OP_SUMOVER:
            for t in prog.args(i):
                needed[t] = True
    return needed, chains


def _lower_node(
    prog: _Program, i: int, chains: dict[int, list[tuple[int, int]]], cache: list, E: Any
) -> None:
    """The forward step of :func:`lower` for one needed node: set ``cache[i]``.

    Leaves ``cache[i]`` as ``None`` where the node is unsupported. Every operand
    it reads has a lower id and must already be in ``cache``.
    """
    op, a, b, k = prog.op, prog.a, prog.b, prog.k
    o = int(op[i])

    if o == OP_UNSUPPORTED:
        return
    if o == OP_CONST:
        cache[i] = E.const_(float(k[i]))
        return
    if o == OP_VAR:
        cache[i] = E.var(int(k[i]))
        return

    ch = chains.get(i)
    if ch is not None:
        # A separate flag rather than re-using `parts` as its own "dropped"
        # sentinel: one unsupported leaf drops the whole chain, and a list
        # that is sometimes `None` is both harder to read and untypeable.
        parts: list[Any] = []
        complete = True
        for sign, leaf in ch:
            p = cache[leaf]
            if p is None:
                complete = False
                break
            parts.append(p if sign > 0 else -p)
        if complete:
            cache[i] = E.sum(parts)
        return

    if o == OP_SUMOVER:
        terms = [cache[t] for t in prog.args(i)]
        if any(t is None for t in terms):
            return
        # Same degenerate-arity rules as `_nl_expr_compiler`: a sum over no
        # terms is the constant 0, a sum over one term is that term.
        if not terms:
            cache[i] = E.const_(0.0)
        elif len(terms) == 1:
            cache[i] = terms[0]
        else:
            cache[i] = E.sum(terms)
        return

    if o in (OP_NEG, OP_ABS):
        arg = cache[a[i]]
        if arg is None:
            return
        cache[i] = -arg if o == OP_NEG else abs(arg)
        return

    if o >= OP_FUNC_BASE:
        fidx = o - OP_FUNC_BASE
        arg = cache[a[i]]
        if arg is None:
            return
        if fidx == _FUNC_LOG2:
            # Exactly the form `_nl_expr_compiler` uses, because the two
            # paths must build the same tape: `log(a) * (1/ln 2)`.
            cache[i] = E.log(arg) * E.const_(1.0 / math.log(2.0))
            return
        if fidx == _FUNC_SQRT:
            # Same edge-honest form as `_nl_expr_compiler._sqrt` (#1491), and
            # the same norm exception for a sum of squares (#1933).
            if _arena_sum_of_squares(prog, int(a[i])):
                cache[i] = E.sqrt(arg)
            else:
                cache[i] = _sqrt(E, arg)
            return
        method = _FUNC_METHOD.get(fidx)
        if method is None:
            return
        cache[i] = getattr(arg, method)()
        return

    lhs, rhs = cache[a[i]], cache[b[i]]
    if lhs is None or rhs is None:
        return
    if o == OP_ADD:
        cache[i] = lhs + rhs
    elif o == OP_SUB:
        cache[i] = lhs - rhs
    elif o == OP_MUL:
        cache[i] = lhs * rhs
    elif o == OP_DIV:
        cache[i] = lhs / rhs
    elif o == OP_POW:
        cache[i] = _pow(E, lhs, rhs)


def lower(prog: _Program, roots: list[int], E: Any) -> list:
    """Lower the arena to a ``cache`` of tape nodes, ``None`` where unsupported.

    Two passes. The first (:func:`_mark_needed`) walks *backwards* from the
    roots marking which nodes are reachable and recording each additive chain's
    flattened leaves. The second walks *forwards* and materialises each needed
    node (:func:`_lower_node`); every operand it reads has a lower id and so is
    already in ``cache``.
    """
    needed, chains = _mark_needed(prog, roots)
    cache: list = [None] * prog.n
    for i in np.flatnonzero(needed).tolist():
        _lower_node(prog, i, chains, cache, E)
    return cache


def _offsets_agree(repr_: Any, model: Any) -> bool:
    """True if the arena's flat variable slots match the evaluator's ordering.

    ``E.var(slot)`` uses the slot ``tape_program`` resolved from the arena's own
    block offsets, while the evaluator's ``x`` vector is ``model._variables`` in
    declaration order. A disagreement would alias one variable onto another --
    wrong derivatives with no error -- so it is checked rather than assumed, and
    a mismatch falls back instead of raising: the Python path is still correct
    for such a model.
    """
    shapes = _num(repr_, "var_shapes")
    names = _num(repr_, "var_names")
    if len(shapes) != len(model._variables) or len(names) != len(model._variables):
        return False
    for sh, nm, var in zip(shapes, names, model._variables):
        size = int(np.prod(sh)) if len(sh) else 1
        # Size alone would not catch a PERMUTATION of equally-sized blocks, which
        # is the aliasing this guard exists to prevent, so the block name is
        # checked too.
        if size != int(var.size) or str(nm) != str(var.name):
            return False
    return True


def try_build_arena_tape(model: Any, E: Any) -> Optional[tuple[Any, list]]:
    """``(objective_node, constraint_nodes)`` from the arena, or ``None`` to fall back.

    ``None`` is returned -- never a partial or approximate tape -- when the model
    carries builder-resident rows (row-order mismatch, see the module docstring),
    when the arena's variable slots disagree with the evaluator's ordering, or
    when the objective or any constraint root reaches an unsupported arena node.

    The objective is returned *unnegated*; the caller applies the maximise
    negation exactly as it does on the Python path.
    """
    built = _build_arena_tape(model, E, split_linear=False)
    return None if built is None else (built[0], built[1])


#: CSR triple ``(indptr, indices, data)`` of every row's linear segment.
LinearCSR = tuple[np.ndarray, np.ndarray, np.ndarray]


def try_build_arena_tape_split(model: Any, E: Any) -> Optional[tuple[Any, list, LinearCSR]]:
    """:func:`try_build_arena_tape`, with affine rows handed back as coefficients.

    Returns ``(objective_node, constraint_nodes, linear_csr)``. A row
    :func:`_linear_row` admits contributes its leaves to ``linear_csr`` and a
    plain ``float`` (its trailing constant, usually ``0.0``) to
    ``constraint_nodes`` in place of a tape node; every other row is lowered
    exactly as :func:`try_build_arena_tape` lowers it, with an empty CSR row.

    This is for POUNCE's ``build_nl_problem(..., con_linear=linear_csr)``, which
    stores a linear segment as ``(var, coef)`` pairs with no expression tree and
    no AD tape. #2293 measured a three-term linear row at ~600 B of problem plus
    ~600 B of transient ``NlExpr`` nodes taped, against ~270 B passed this way.
    The admitted rows evaluate bit-identically either way (see
    :func:`_linear_row`), so the choice is a memory decision, not a numerical one.
    """
    built = _build_arena_tape(model, E, split_linear=True)
    if built is None or built[2] is None:
        return None
    return built[0], built[1], built[2]


def _arena_inputs(
    model: Any, *, split_linear: bool
) -> Optional[tuple[_Program, int, list[int], dict[int, tuple[list[int], list[float], float]]]]:
    """``(prog, objective id, constraint ids, linear rows)``, or ``None`` to fall back.

    Everything :func:`_build_arena_tape` decides before it lowers a node; shared
    with :func:`try_plan_chunked_arena_tape` so the two refuse the same models.
    """
    if not arena_tape_enabled():
        return None
    # Builder rows would land ahead of the expression rows in the arena while the
    # evaluator enumerates them after -- refuse rather than reorder.
    #
    # Asked in O(1) off `_builder_linear_blocks`. The obvious spelling,
    # `if model._builder_linear_constraints():`, MATERIALISES ONE `Constraint`
    # OBJECT PER ROW to answer a yes/no question; the same line in the `.nl`
    # writer's refusal measured at 7.12 us/row on a 20 000-row model, against 9.4
    # for the writer it was guarding (performance-plan.md §52).
    if has_builder_only_constraint_rows(model):
        return None
    if getattr(model, "_objective", None) is None:
        return None
    # A builder-resident objective (`add_linear_objective`) is folded into the
    # arena's objective root, but the evaluator lowers `model._objective.expression`
    # alone. Taking the arena root for such a model would silently OPTIMISE A
    # DIFFERENT FUNCTION, so refuse instead.
    from discopt.export._common import builder_objective

    if builder_objective(model) is not None:
        return None

    from discopt._repr_cache import readonly_model_repr

    try:
        repr_ = readonly_model_repr(model)  # only queried below
    except Exception as exc:  # noqa: BLE001 -- see below; deliberately broad
        # "This model has no arena representation" is how `convert_expr` reports
        # several distinct cases, each with its own exception type and wording:
        # `TypeError: Unknown expression type: CustomCall` for an opaque callable,
        # `ValueError: Unknown MathFunc: centropy` for an operator the core IR
        # does not carry, and more as the modelling layer grows. An allowlist of
        # message substrings was tried first and was wrong within one test run --
        # it caught the CustomCall wording and let `centropy` escape, turning a
        # model that used to solve into a crash.
        #
        # This is not a swallowed error (§7). Before this module existed the
        # evaluator never called `model_to_repr` at all, so a failure here is not
        # a regression being hidden -- it is new information about a model the
        # Python walk below still lowers correctly. And nothing is suppressed:
        # the solve path calls `model_to_repr` again, unguarded, so a genuine
        # defect in it still surfaces there with its own traceback. What is
        # caught is only this speculative attempt.
        #
        # `Exception`, not `BaseException`: a pyo3 `PanicException` derives from
        # `BaseException` and must keep propagating.
        _LOG.debug("arena tape declined; model_to_repr refused: %s: %s", type(exc).__name__, exc)
        return None
    if not _offsets_agree(repr_, model):
        return None

    con_ids = [int(c) for c in _num(repr_, "constraint_ids")]
    # One arena row per expression constraint: an array-valued body is ONE arena
    # node and MANY tape rows, so a count mismatch means the fan-out this path
    # cannot do is required. (Such a body also roots at an unsupported node, but
    # the count is checked first so the refusal names the real reason.)
    from discopt.modeling.core import Constraint

    expr_cons = [c for c in model._constraints if isinstance(c, Constraint)]
    if len(con_ids) != len(expr_cons):
        return None

    obj_id = int(_num(repr_, "objective_id"))
    prog = _Program(repr_.tape_program())
    if obj_id < 0 or obj_id >= prog.n:
        return None
    if any(cid < 0 or cid >= prog.n for cid in con_ids):
        return None

    linear: dict[int, tuple[list[int], list[float], float]] = {}
    if split_linear:
        for row, cid in enumerate(con_ids):
            lin = _linear_row(prog, cid)
            if lin is not None:
                linear[row] = lin
    return prog, obj_id, con_ids, linear


def _linear_csr(rows: range, linear: dict[int, tuple[list[int], list[float], float]]) -> LinearCSR:
    """The CSR triple of *rows*' linear segments, local to those rows."""
    lo = rows.start
    indptr = np.zeros(len(rows) + 1, dtype=np.int64)
    for row in rows:
        lin = linear.get(row)
        if lin is not None:
            indptr[row - lo + 1] = len(lin[0])
    np.cumsum(indptr, out=indptr)
    indices = np.empty(int(indptr[-1]), dtype=np.int64)
    data = np.empty(int(indptr[-1]), dtype=np.float64)
    for row in rows:
        lin = linear.get(row)
        if lin is not None:
            indices[indptr[row - lo] : indptr[row - lo + 1]] = lin[0]
            data[indptr[row - lo] : indptr[row - lo + 1]] = lin[1]
    return indptr, indices, data


def _build_arena_tape(
    model: Any, E: Any, *, split_linear: bool
) -> Optional[tuple[Any, list, Optional[LinearCSR]]]:
    inputs = _arena_inputs(model, split_linear=split_linear)
    if inputs is None:
        return None
    prog, obj_id, con_ids, linear = inputs

    # A split row's leaves are not lowered unless something else reaches them,
    # so the `NlExpr` nodes they would have cost are never built (#2293).
    taped_ids = [cid for row, cid in enumerate(con_ids) if row not in linear]
    cache = lower(prog, [obj_id, *taped_ids], E)
    obj = cache[obj_id]
    if obj is None:
        return None
    cons: list[Any] = []
    for row, cid in enumerate(con_ids):
        lin = linear.get(row)
        cons.append(cache[cid] if lin is None else lin[2])
    if any(c is None for c in cons):
        return None
    if not split_linear:
        return obj, cons, None
    return obj, cons, _linear_csr(range(len(con_ids)), linear)


# ---------------------------------------------------------------------------
# Chunked lowering for `pounce.NlProblemBuilder` (#2324)
# ---------------------------------------------------------------------------

#: Arena opcodes a POUNCE row can be built from and still be one the quadratic
#: recognizer keeps as its own per-row tree (``polynomial_ops_only`` in
#: ``pounce-py/src/nl_expr.rs``). A superset of what POUNCE keeps, which is the
#: safe direction: see :func:`plan_chunks`.
_POLY_OPS = frozenset(
    {OP_CONST, OP_VAR, OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_POW, OP_NEG, OP_SUMOVER}
)

#: Rows per chunk the planner aims for. A chunk is cut at the first admissible
#: boundary at or after this many rows. pounce#1263 measured one 28-row step per
#: chunk and 28 steps per chunk within 1% of each other, so the size is not
#: sensitive; it bounds how much ``NlExpr`` is alive at once.
CHUNK_ROWS = 1024


def _operand_csr(
    prog: _Program, needed: np.ndarray, chains: dict[int, list[tuple[int, int]]]
) -> tuple[np.ndarray, np.ndarray]:
    """``(ptr, idx)``: each needed node's operands as :func:`_lower_node` reads them.

    A chain root's operands are its flattened leaves; a sum's are its terms; a
    unary or function node reads ``a``; a binary node reads ``a`` and ``b``; a
    leaf or unsupported node reads nothing. Only what lowering reads is an edge:
    an edge the tape does not have would be counted as a reference POUNCE never
    sees (:func:`plan_chunks`). Repeats are kept. Built with numpy except for the
    chains, which are already Python lists.
    """
    n = prog.n
    op, a, b = prog.op, prog.a, prog.b
    chain_ids = np.fromiter(chains.keys(), dtype=np.int64, count=len(chains))
    is_chain = np.zeros(n, dtype=bool)
    is_chain[chain_ids] = True
    is_sum = needed & (op == OP_SUMOVER)
    plain = needed & ~is_chain & ~is_sum & ~np.isin(op, (OP_CONST, OP_VAR, OP_UNSUPPORTED))
    reads_a = plain & (a >= 0)
    reads_b = plain & ~np.isin(op, (OP_NEG, OP_ABS)) & (op < OP_FUNC_BASE) & (b >= 0)
    sum_len = np.diff(prog._args_ptr).astype(np.int64)

    cnt = reads_a.astype(np.int64) + reads_b
    cnt[is_sum] = sum_len[is_sum]
    if len(chains):
        cnt[chain_ids] = [len(ch) for ch in chains.values()]
    ptr = np.zeros(n + 1, dtype=np.int64)
    np.cumsum(cnt, out=ptr[1:])
    idx = np.empty(int(ptr[-1]), dtype=np.int64)

    ia = np.flatnonzero(reads_a)
    idx[ptr[ia]] = a[ia]
    ib = np.flatnonzero(reads_b)
    idx[ptr[ib] + reads_a[ib]] = b[ib]
    s = np.flatnonzero(is_sum)
    lens = sum_len[s]
    total = int(lens.sum())
    if total:
        within = np.arange(total, dtype=np.int64) - np.repeat(np.cumsum(lens) - lens, lens)
        idx[np.repeat(ptr[s], lens) + within] = prog._args_flat[
            np.repeat(prog._args_ptr[s], lens) + within
        ]
    for i, ch in chains.items():
        idx[ptr[i] : ptr[i + 1]] = [leaf for _, leaf in ch]
    return ptr, idx


def plan_chunks(
    prog: _Program,
    obj_id: int,
    con_ids: list[int],
    linear: dict[int, Any],
    target_rows: int = CHUNK_ROWS,
    marked: Optional[tuple[np.ndarray, dict[int, list[tuple[int, int]]]]] = None,
) -> Optional[tuple[list[range], np.ndarray, np.ndarray]]:
    """Cut the rows into chunks that ``NlProblemBuilder`` builds exactly as one call does.

    Returns ``(chunks, first_row, last_row)`` -- the chunks as contiguous row
    ranges, and per arena node the first and last row reaching it (``len(con_ids)``
    standing for the objective, ``-1`` for a node nothing reaches) -- or ``None``
    when no cut into two or more is exact, and the caller builds with one
    ``build_nl_problem``. The sweeps run in Rust
    (``discopt_core::tape_plan::plan_chunks``); this function decides what they
    sweep.

    **Why a cut can change the problem.** POUNCE shares a subexpression (one
    copied body, which its hybrid tape may promote into the shared-CSE prelude)
    when it counts two references to it. ``build_nl_problem`` counts over every
    row; the builder's ``Materializer`` counts per chunk and reuses a body an
    earlier chunk shared. So a body one call shares is inlined by the builder
    when its references straddle chunks and the first chunk that reaches it
    reaches it only once -- and then POUNCE's Hessian moves in the last bits
    (measured: 4.7e-15 relative on ``test_2324_chunked_build``'s deep fixture
    cut one row a chunk, with values and Jacobian unchanged). A bound-neutral
    change must not move the Hessian (CLAUDE.md §5), so such a cut is never
    taken.

    **The rule.** For every non-leaf node ``v`` that POUNCE could count twice
    model-wide, the chunk holding the first row that reaches ``v`` must already
    count two references to it. The counts bracket POUNCE's from the safe side:

    * *model-wide* (upper): distinct parent nodes from any row or the objective,
      plus one per row whose root ``v`` is. POUNCE counts per operand slot and
      re-counts below a row's sum spine, but an extra count of that kind only
      ever comes from a parent this already counts, or from a node above that
      is itself counted twice and so is held to the rule.
    * *in the first chunk* (lower): distinct parents reached from rows that
      POUNCE certainly materialises through its shared maps -- rows reaching an
      operation outside :data:`_POLY_OPS`. A row POUNCE's quadratic recognizer
      keeps as its own tree is copied with a private map and counts nothing;
      which polynomial rows it keeps is not decided here, so none of them is
      counted. Root references are not counted either: POUNCE does not count a
      row's root as a reference to it.

    Var and constant nodes are cloned into each operand by ``NlExpr`` and never
    shared, so they are exempt.

    **The objective** is materialised by ``build`` after every chunk, while one
    call counts it with the rows. A node it shares with the rows is therefore
    held to the rule within the rows alone; if the rows cannot satisfy it, no
    chunking is exact and ``None`` is returned.

    **The cut.** For a node that violates the rule at row granularity, the rows
    from its first reach to the row of its second counted parent must share a
    chunk. Merging chunks only adds references to a chunk's count, so the union
    of those intervals satisfies every node at once and so does any coarsening of
    it; the chunks are then grown to ``target_rows`` at the admissible
    boundaries.
    """
    from discopt._rust import tape_chunk_plan

    if marked is None:
        taped = [cid for row, cid in enumerate(con_ids) if row not in linear]
        marked = _mark_needed(prog, [obj_id, *taped])
    needed, chains = marked
    ptr, idx = _operand_csr(prog, needed, chains)
    poly = np.isin(prog.op, tuple(_POLY_OPS))
    leaf = np.isin(prog.op, (OP_CONST, OP_VAR))
    row_root = np.asarray(con_ids, dtype=np.int64)
    if linear:
        row_root[np.fromiter(linear.keys(), dtype=np.int64, count=len(linear))] = -1
    starts, first_row, last_row = tape_chunk_plan(
        ptr, idx, poly, leaf, row_root, int(obj_id), int(target_rows)
    )
    del ptr, idx, poly, leaf
    if len(starts) < 3:
        return None
    st = starts.tolist()
    return [range(st[c], st[c + 1]) for c in range(len(st) - 1)], first_row, last_row


class ArenaDeclined(Exception):
    """A chunked arena lowering met an unsupported node; build nothing from it."""


class ArenaPrepared:
    """What :func:`try_build_arena_tape_split` decides before lowering, kept for reuse.

    :func:`prepare_arena_tape` computes it once; :meth:`plan` and
    :meth:`lower_split` both start from it, so a model the planner does not cut
    is lowered without repeating the arena walk, the linear-row scan or the
    reachability sweep.
    """

    __slots__ = ("prog", "obj_id", "con_ids", "linear", "marked")

    def __init__(
        self,
        prog: _Program,
        obj_id: int,
        con_ids: list[int],
        linear: dict[int, tuple[list[int], list[float], float]],
    ) -> None:
        self.prog = prog
        self.obj_id = obj_id
        self.con_ids = con_ids
        self.linear = linear
        taped = [cid for row, cid in enumerate(con_ids) if row not in linear]
        self.marked = _mark_needed(prog, [obj_id, *taped])

    @property
    def n_rows(self) -> int:
        return len(self.con_ids)

    @property
    def n_taped(self) -> int:
        return len(self.con_ids) - len(self.linear)

    def lower_split(self, E: Any) -> Optional[tuple[Any, list, LinearCSR]]:
        """:func:`try_build_arena_tape_split`'s result, from the prepared state."""
        needed, chains = self.marked
        cache: list = [None] * self.prog.n
        for i in np.flatnonzero(needed).tolist():
            _lower_node(self.prog, i, chains, cache, E)
        obj = cache[self.obj_id]
        if obj is None:
            return None
        cons: list[Any] = []
        for row, cid in enumerate(self.con_ids):
            lin = self.linear.get(row)
            cons.append(cache[cid] if lin is None else lin[2])
        if any(c is None for c in cons):
            return None
        return obj, cons, _linear_csr(range(len(self.con_ids)), self.linear)

    def plan(self, E: Any, target_rows: int = CHUNK_ROWS) -> Optional["ChunkedArenaTape"]:
        """A :class:`ChunkedArenaTape`, or ``None`` where no exact cut exists."""
        planned = plan_chunks(
            self.prog, self.obj_id, self.con_ids, self.linear, target_rows, self.marked
        )
        if planned is None:
            return None
        chunks, first_row, last_row = planned
        return ChunkedArenaTape(self, chunks, first_row, last_row, E)


def prepare_arena_tape(model: Any) -> Optional[ArenaPrepared]:
    """:class:`ArenaPrepared` for *model* with linear rows split, or ``None`` to fall back."""
    inputs = _arena_inputs(model, split_linear=True)
    return None if inputs is None else ArenaPrepared(*inputs)


class ChunkedArenaTape:
    """The arena lowering of :func:`try_build_arena_tape_split`, one chunk at a time.

    :meth:`chunks` yields ``(rows, linear_csr)`` per planned chunk, lowering
    only the nodes that chunk is the first to reach and dropping, once the
    chunk has been yielded, every node no later chunk (or the objective)
    reaches. A node a later chunk still needs -- a parameter's ``exp(p_j)`` --
    stays in the cache, so the later chunk gets the same ``NlExpr`` object, as
    one lowering would hand it. :meth:`objective` lowers what is left. The
    rows, the objective and the CSR are exactly those
    :func:`try_build_arena_tape_split` returns, cut at :attr:`plan`.

    Raises :class:`ArenaDeclined` where the one-shot lowering would return
    ``None``; the caller discards whatever it built from earlier chunks.
    """

    def __init__(
        self,
        prep: ArenaPrepared,
        plan: list[range],
        first_row: np.ndarray,
        last_row: np.ndarray,
        E: Any,
    ) -> None:
        self.prep = prep
        self.plan = plan
        self.n_rows = prep.n_rows
        self._E = E
        # Chunk of each node's first and last reach; the objective is chunk K.
        starts = np.asarray([r.start for r in plan], dtype=np.int64)
        reached = np.flatnonzero(first_row >= 0)
        cf = np.searchsorted(starts, first_row[reached], side="right") - 1
        cl = np.searchsorted(starts, last_row[reached], side="right") - 1
        K = len(plan)
        cf[first_row[reached] >= self.n_rows] = K
        cl[last_row[reached] >= self.n_rows] = K
        order = np.lexsort((reached, cf))
        self._by_first = reached[order]
        self._first_bounds = np.searchsorted(cf[order], np.arange(K + 2))
        order = np.argsort(cl, kind="stable")
        self._by_last = reached[order]
        self._last_bounds = np.searchsorted(cl[order], np.arange(K + 2))
        self._objective: Any = None
        self._consumed = False
        self._done = False

    def chunks(self) -> Any:
        if self._consumed:
            raise RuntimeError("ChunkedArenaTape.chunks() may be consumed once")
        self._consumed = True
        prep, plan = self.prep, self.plan
        prog, linear, con_ids = prep.prog, prep.linear, prep.con_ids
        chains = prep.marked[1]
        by_first, fb = self._by_first, self._first_bounds
        by_last, lb = self._by_last, self._last_bounds
        cache: list = [None] * prog.n
        E = self._E
        for c, rows in enumerate(plan):
            for i in by_first[fb[c] : fb[c + 1]].tolist():
                _lower_node(prog, i, chains, cache, E)
            out: list[Any] = []
            for row in rows:
                lin = linear.get(row)
                if lin is not None:
                    out.append(lin[2])
                    continue
                node = cache[con_ids[row]]
                if node is None:
                    raise ArenaDeclined(f"row {row} reaches an unsupported arena node")
                out.append(node)
            yield out, _linear_csr(rows, linear)
            del out
            for i in by_last[lb[c] : lb[c + 1]].tolist():
                cache[i] = None
        K = len(plan)
        for i in by_first[fb[K] : fb[K + 1]].tolist():
            _lower_node(prog, i, chains, cache, E)
        obj = cache[prep.obj_id]
        if obj is None:
            raise ArenaDeclined("the objective reaches an unsupported arena node")
        self._objective = obj
        self._done = True

    def objective(self) -> Any:
        """The objective's tape node, unnegated; valid once :meth:`chunks` is exhausted."""
        if not self._done:
            raise RuntimeError("ChunkedArenaTape.objective() before every chunk was consumed")
        obj, self._objective = self._objective, None
        return obj


def try_build_expanded_tape(model: Any, E: Any) -> Optional[tuple[Any, list, list[int]]]:
    r"""``(objective, constraint rows, rows-per-constraint)`` from ``expand``, or ``None``.

    **This is the verification harness for** ``discopt_core::expand``\ **, not a
    production lowering path.** Nothing in the solve path calls it, deliberately.

    It exists because `expand` -- the Rust fan-out of an array-valued body into N
    scalar rows -- is written for the ``.nl`` writer, whose consumer is Rust, and
    its correctness has to be provable from Python. Lowering its output to POUNCE
    nodes here lets `issue1215_expanded_tape_differential.py` compare objective,
    gradient, every constraint value and the full Jacobian against the Python DAG
    walk, and pin the ROW ORDER, which a tolerance check on values alone would
    not catch.

    It is not used for the tape because it is **1.77x slower** there, measured:
    ``_nl_expr_compiler`` lowers array-at-a-time -- 242 ``_lower_uncached`` calls
    for 20 000 rows -- and lets numpy's ``frompyfunc`` create the per-element
    POUNCE nodes in C, whereas an expanded program must be consumed one scalar
    instruction at a time from Python. Routing the tape through here replaces a C
    loop with a Python one. See ``docs/dev/performance-plan.md`` §45.

    ``rows_per_constraint`` is returned rather than assumed: it is what would
    drive ``_constraint_flat_sizes``, which attributes duals, the row map and
    feasibility reports back to the ``Constraint`` each row came from.
    """
    if not arena_tape_enabled():
        return None
    # O(1), for the reason given in `try_build_arena_tape` above.
    if has_builder_only_constraint_rows(model):
        return None
    if getattr(model, "_objective", None) is None:
        return None
    from discopt.export._common import builder_objective

    if builder_objective(model) is not None:
        return None

    from discopt._repr_cache import readonly_model_repr

    try:
        repr_ = readonly_model_repr(model)  # only queried below
    except Exception as exc:  # noqa: BLE001 -- see try_build_arena_tape
        _LOG.debug("expanded tape declined; model_to_repr refused: %s", exc)
        return None
    if not _offsets_agree(repr_, model):
        return None

    try:
        (op, a, b, k, args_flat, args_ptr, obj_root, row_roots, rows_per) = (
            repr_.tape_program_expanded()
        )
    except ValueError as exc:
        # `expand` refuses rather than guessing -- an inexact fan-out is a
        # different model. Fall back to the Python walk, which is unchanged.
        _LOG.debug("expanded tape declined: %s", exc)
        return None

    prog = _Program((op, a, b, k, args_flat, args_ptr))
    roots = [int(obj_root), *(int(r) for r in row_roots)]
    cache = lower(prog, roots, E)
    obj = cache[int(obj_root)]
    if obj is None:
        return None
    cons = [cache[int(r)] for r in row_roots]
    if any(c is None for c in cons):
        return None
    return obj, cons, [int(v) for v in rows_per]
