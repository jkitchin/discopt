"""
discopt.modeling -- Modeling API for Mixed-Integer Nonlinear Programs.

This module provides the classes and functions for building optimization
models: :class:`Model`, :class:`Variable`, :class:`Expression`,
:class:`Constraint`, :class:`SolveResult`, and math functions
(:func:`exp`, :func:`log`, :func:`sin`, :func:`cos`, etc.).

Examples
--------
>>> import discopt.modeling as dm
>>> m = dm.Model("my_problem")
>>> x = m.continuous("x", shape=(3,), lb=0, ub=10)
>>> y = m.binary("y", shape=(2,))
>>> m.minimize(cost @ x + fixed_cost @ y)
>>> m.subject_to(A @ x <= b, name="capacity")
>>> result = m.solve()
"""

from discopt.batch import solve_batch
from discopt.modeling._linear_files import FileColumns, from_lp, from_mps
from discopt.modeling._piecewise import PiecewiseDomainError, PiecewiseLinear
from discopt.modeling._pwl_transform import (
    PWLSkippedTerm,
    PWLTerm,
    PWLTransformation,
    PWLTransformError,
    nonlinear_to_pwl,
)
from discopt.modeling.argmin import (
    argmin,
    argmin_kkt,
    argmin_layer,
)
from discopt.modeling.core import (
    Atan2BranchCutError,
    BooleanVar,
    BooleanVarArray,
    Constraint,
    # Opaque AD-only user function node (for isinstance checks)
    CustomCall,
    DiscontinuousIntrinsicError,
    Disjunct,
    # Disjunction semantics (issue #1124)
    DisjunctionSemantics,
    # Expressions (for isinstance checks, rarely needed)
    Expression,
    LogicalExpression,
    # Model
    Model,
    Parameter,
    SelectorActivation,
    SelectorCardinality,
    # Results
    SolveResult,
    SolveUpdate,
    # Variable types (for isinstance checks, rarely needed)
    Variable,
    VarType,
    acos,
    acosh,
    asin,
    asinh,
    # Logical functions
    at_least,
    at_most,
    atan,
    atan2,
    atanh,
    atleast,
    atmost,
    bulk_construction_gc,
    ceil,
    concatenate,
    cos,
    cosh,
    custom,
    erf,
    exactly,
    # Mathematical functions
    exp,
    floor,
    from_description,
    from_gams,
    from_nl,
    # Import functions
    from_pyomo,
    # Conditional / user-defined function
    if_else,
    land,
    lnot,
    log,
    log1p,
    log2,
    log10,
    lor,
    maximum,
    minimum,
    norm,
    piecewise,
    prod,
    round_,
    sigmoid,
    sign,
    sin,
    sinh,
    softplus,
    sqrt,
    stack,
    # Aggregation
    sum,
    tan,
    tanh,
    trunc,
    udf,
    xlogx,
    xor,
)
from discopt.modeling.core import (
    abs_ as abs,
)
from discopt.modeling.external import (
    ExternalSpec,
    external,
    external_spec,
)
from discopt.modeling.implicit import (
    implicit,
    implicit_full_space,
)
from discopt.modeling.indexed import (
    IndexedConstraint,
    IndexedParam,
    IndexedVar,
    Skip,
)
from discopt.modeling.sets import ProductSet, RangeSet, Set
from discopt.operators import register_function, registered_names
from discopt.serialize import dumps, load, loads

__all__ = [
    "Model",
    "Variable",
    "VarType",
    "Parameter",
    "Expression",
    "Constraint",
    "exp",
    "log",
    "log1p",
    "log2",
    "log10",
    "sqrt",
    "sin",
    "cos",
    "tan",
    "atan",
    "atan2",
    "asin",
    "acos",
    "sinh",
    "cosh",
    "asinh",
    "acosh",
    "atanh",
    "erf",
    "abs",
    "sigmoid",
    "sign",
    "softplus",
    "xlogx",
    # Recognised but unimplemented discontinuous intrinsics: these are
    # exported so the refusal is explicit and documented (issue #1237).
    # Calling one raises DiscontinuousIntrinsicError.
    "floor",
    "ceil",
    "round_",
    "trunc",
    "Atan2BranchCutError",
    "DiscontinuousIntrinsicError",
    "minimum",
    "maximum",
    "if_else",
    "piecewise",
    "PiecewiseDomainError",
    "PiecewiseLinear",
    "nonlinear_to_pwl",
    "PWLTransformation",
    "PWLTransformError",
    "PWLTerm",
    "PWLSkippedTerm",
    "udf",
    "custom",
    "external",
    "external_spec",
    "ExternalSpec",
    "argmin",
    "argmin_kkt",
    "argmin_layer",
    "implicit",
    "implicit_full_space",
    "CustomCall",
    "sum",
    "bulk_construction_gc",
    "prod",
    "norm",
    "concatenate",
    "stack",
    "tanh",
    "SolveResult",
    "solve_batch",
    "register_function",
    "registered_names",
    "SolveUpdate",
    "from_pyomo",
    "from_nl",
    "from_gams",
    "from_mps",
    "from_lp",
    "FileColumns",
    "load",
    "loads",
    "dumps",
    "from_description",
    "BooleanVar",
    "BooleanVarArray",
    "Disjunct",
    "DisjunctionSemantics",
    "SelectorActivation",
    "SelectorCardinality",
    "LogicalExpression",
    "land",
    "lor",
    "lnot",
    "atleast",
    "atmost",
    "at_least",
    "at_most",
    "xor",
    "exactly",
    "Set",
    "RangeSet",
    "ProductSet",
    "IndexedVar",
    "IndexedParam",
    "IndexedConstraint",
    "Skip",
]
