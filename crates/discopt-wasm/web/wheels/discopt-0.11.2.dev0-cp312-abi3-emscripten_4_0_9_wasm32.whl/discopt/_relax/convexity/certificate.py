"""Sound box-local convexity certificate.

The certificate answers the question "is ``f`` convex on the given
box?" with a proof, leveraging:

1. :mod:`interval_ad` for a sound interval enclosure of the Hessian
   over the box.
2. :mod:`eigenvalue` for a sound lower bound on the minimum
   eigenvalue across every concrete Hessian in that enclosure.

If the lower eigenvalue bound is ≥ 0 on the box, ``f`` is convex
there (second-order sufficient condition, Boyd & Vandenberghe §3.1.4).
Symmetrically, an upper bound ≤ 0 proves concavity. Any other
outcome returns ``None`` — a conservative abstention, not a claim
of nonconvexity.

This routine never loosens a verdict from the syntactic walker
:mod:`rules`. Callers combine the two sources by preferring the
syntactic CONVEX/CONCAVE (cheaper) and only falling back to the
certificate when the syntactic walker says UNKNOWN.

References
----------
Boyd, Vandenberghe (2004), *Convex Optimization*, §3.1.4.
Adjiman, Dallwig, Floudas, Neumaier (1998), "αBB — I. Theoretical
  advances," Comput. Chem. Eng. — the interval-Hessian foundation
  this certificate operationalises.
"""

from __future__ import annotations

import contextlib
import contextvars
import logging
import os
import time
from typing import Iterator, Optional

import numpy as np

from discopt.modeling.core import Constraint, Expression, Model

from .eigenvalue import (
    gershgorin_certifies_nsd,
    gershgorin_certifies_psd,
    psd_2x2_sufficient,
    psd_decision_slack,
)
from .interval import Interval
from .interval_ad import _flat_size, interval_hessian
from .lattice import Curvature

logger = logging.getLogger(__name__)

# The slack for accepting "λ_min ≥ 0" despite floating-point slop lives in
# ``eigenvalue.psd_decision_slack`` and scales with the Hessian's magnitude
# (#1397). It was an absolute ``_PSD_TOL = 1e-10`` here, on the reasoning that
# "the interval Hessian already outward-rounds, so genuine zero eigenvalues may
# appear as small negatives; a very tight tolerance suffices" — true, except that
# "small" is relative to ‖H‖. The outward rounding widens by O(u·‖H‖), so at
# ‖H‖ ~ 1e12 a genuine zero eigenvalue appears as ~-1e-4 and the certificate was
# silently lost; and at ‖H‖ ~ 1e-2 an absolute 1e-10 admitted a relative
# nonconvexity of 1e-8. Both directions are measured in ``psd_decision_slack``.


def _qp_exact_convexity_enabled() -> bool:
    """Whether the exact QP/MIQP objective-Hessian convexity route is active.

    **Default ON** with a ``DISCOPT_QP_EXACT_CONVEXITY=0`` opt-out, graduated by
    the issue-#936 differential panel (see that issue and
    ``docs/dev/certification-gap-plan.md``).

    The route certifies the objective of a model the *problem classifier* proves
    to be a QP/MIQP (exactly-quadratic objective over a polyhedron) from the
    exact Hessian the classifier's own extractor already produces, instead of
    asking the scalar interval-Hessian walker — which cannot even parse the
    vectorized / indexed-summation modeling API, so no model written that way
    could ever be certified convex.
    """
    return os.environ.get("DISCOPT_QP_EXACT_CONVEXITY", "1").strip().lower() not in (
        "0",
        "false",
        "no",
        "off",
    )


def _convex_charge_enabled() -> bool:
    """Whether a solve may accept a QP objective as "convex up to a charge" (#1682).

    **Default ON** (graduated on introduction; opt-out ``DISCOPT_CONVEX_CHARGE=0``
    restores the strict #1679 refusal). The CLAUDE.md §5 panel is recorded in
    ``docs/dev/flag-retirement-audit.md``: over 299 corpus QP/MIQP instances only 5
    (QPLIB 10046/10048/10050/10056/10066) trigger it; on those plus the #1682
    Gram least-squares example, 2 reps x 60 s interleaved, certified 0/6 -> 3/6,
    every bound tightened and none above its reference optimum, 0 violations.

    When :func:`~.eigenvalue.psd_certified` cannot prove the objective Hessian
    ``Q`` PSD -- the float Gram matrix ``2 K'K`` of a rank-deficient ``K`` is
    indefinite in exact arithmetic at ``lambda_min ~ -1e-14`` (#1679) -- the
    exact-QP route may still accept it, inside a solve only, when
    :func:`~.eigenvalue.rigorous_psd_shift` proves ``lambda_min(Q) >= -delta`` and
    the charge ``delta/2 * D**2`` over the bounded box of the quadratic variables
    is at most :data:`CONVEX_CHARGE_ABS_TOL_FRACTION` of the solve's absolute gap
    tolerance. The solve then subtracts the charge from its published bound
    (``solver._apply_convexity_charge``). See :func:`quadratic_objective_charge`.
    """
    return os.environ.get("DISCOPT_CONVEX_CHARGE", "1").strip().lower() not in (
        "0",
        "false",
        "no",
        "off",
    )


#: A charge is accepted only when it is at most this fraction of the solve's
#: absolute gap tolerance, so subtracting it from the published bound leaves the
#: certificate room to close (#1682). The published pair is re-judged after the
#: subtraction (``solver._refuse_unclosed_published_pair``) either way.
CONVEX_CHARGE_ABS_TOL_FRACTION = 0.1

#: A bound at or beyond this magnitude is the solver's effective infinity
#: (``DEFAULT_VARIABLE_BOUND = 9.999e19``; the LP layer's ``1e20`` sentinel).
_CHARGE_INF_BOUND = 1e19

#: Relative/absolute widening of every box width in the charge's diameter, so a
#: point the solver returns up to this far outside its bounds is still covered.
_CHARGE_BOX_SLACK = 1e-6


class ConvexityChargeScope:
    """Per-solve record of accepted convexity charges (#1682).

    Created by ``solver._stamp_layer_timing`` for each ``solve_model`` call;
    ``abs_gap_tol`` is filled in by ``solve_model`` once resolved. ``charges`` maps
    ``id(model)`` to the largest charge accepted for that model object -- the same
    model re-classified (a nested solve clears the memo) is not double counted;
    distinct models (reformulations) add up, which can only over-subtract.
    """

    __slots__ = ("abs_gap_tol", "charges")

    def __init__(self) -> None:
        self.abs_gap_tol: Optional[float] = None
        self.charges: dict[int, float] = {}

    def record(self, model: Model, charge: float) -> None:
        key = id(model)
        self.charges[key] = max(self.charges.get(key, 0.0), float(charge))

    @property
    def total(self) -> float:
        return float(sum(self.charges.values()))


#: The active solve's charge scope, or ``None`` outside a solve. A ContextVar so
#: the large-stack worker of ``_scoped_deep_recursion`` (which runs on a COPY of
#: the caller's context) shares the same mutable scope object.
_CHARGE_SCOPE: contextvars.ContextVar[Optional[ConvexityChargeScope]] = contextvars.ContextVar(
    "discopt_convexity_charge_scope", default=None
)


@contextlib.contextmanager
def convexity_charge_scope() -> Iterator[ConvexityChargeScope]:
    """Open a fresh charge scope for one solve; nested solves get their own.

    On exit a nested scope's charges are also merged (per-model maximum) into the
    enclosing scope: the outer solve may reuse a convexity verdict memoized while
    the nested solve ran, and must then still subtract the charge. If the outer
    result was built from the nested (already charged) bound, that subtracts the
    charge twice -- an over-subtraction, which is sound.
    """
    parent = _CHARGE_SCOPE.get()
    scope = ConvexityChargeScope()
    token = _CHARGE_SCOPE.set(scope)
    try:
        yield scope
    finally:
        _CHARGE_SCOPE.reset(token)
        if parent is not None:
            for key, charge in scope.charges.items():
                parent.charges[key] = max(parent.charges.get(key, 0.0), charge)


def set_charge_scope_abs_gap_tol(abs_gap_tol: float) -> None:
    """Tell the active scope (if any) the solve's absolute gap tolerance."""
    scope = _CHARGE_SCOPE.get()
    if scope is not None:
        scope.abs_gap_tol = float(abs_gap_tol)


def quadratic_objective_charge(hessian: np.ndarray, x_l, x_u) -> Optional[float]:
    """Rigorous charge for treating ``1/2 x'Qx + c'x`` as convex on a box (#1682).

    Let ``S`` be the symmetric part of ``hessian`` restricted to its active
    (nonzero) rows, ``lambda_min(S) >= -delta`` proved by
    :func:`~.eigenvalue.rigorous_psd_shift`, and ``F`` any feasible set inside the
    box ``[l, u]`` of those variables. For any ``x_hat`` and ``y`` in the box, the
    quadratic is its own second-order Taylor expansion:

        ``f(y) = f(x_hat) + grad f(x_hat)'(y - x_hat) + 1/2 (y - x_hat)' S (y - x_hat)
               >= f(x_hat) + grad f(x_hat)'(y - x_hat) - delta/2 ||y - x_hat||^2
               >= [f(x_hat) + grad f(x_hat)'(y - x_hat)] - delta/2 D^2``

    with ``D^2 = sum_j (u_j - l_j)^2`` over the active variables (inactive ones do
    not enter the quadratic term). The bracket is exactly the first-order model a
    convex method's lower bound rests on: at an exact KKT point over polyhedral
    ``F`` it is ``>= f(x_hat)`` for every ``y in F``; at the approximate point a
    solver returns it is ``>= f(x_hat) - eps(x_hat)``, ``eps`` the same first-order
    (Frank-Wolfe) residual the convex path already has to account for on a
    genuinely convex objective, and a linearization cut or a Lagrangian
    linearization bound is the same bracket again. So every lower bound the convex
    machinery derives on ``F`` -- or on any node's sub-box, which only shrinks
    ``D`` -- overstates the true one by at most ``delta/2 D^2`` beyond what it
    would on a convex objective, and subtracting that charge from the published
    bound makes it valid again.

    Each width is widened by ``2 * 1e-6 * (1 + |l_j| + |u_j|)`` so a returned point
    up to that far outside its bounds is covered, and the result is doubled as a
    margin for the rounding in computing ``D^2`` itself.

    Returns ``None`` -- no acceptance -- when an active variable is unbounded
    (``|bound| >= 1e19``) or no shift is proved.
    """
    from .eigenvalue import rigorous_psd_shift

    Q = np.asarray(hessian, dtype=np.float64)
    S = 0.5 * (Q + Q.T)
    active = np.flatnonzero(np.any(S != 0.0, axis=1))
    if active.size == 0:
        return 0.0
    lo = np.asarray(x_l, dtype=np.float64).ravel()
    hi = np.asarray(x_u, dtype=np.float64).ravel()
    if lo.size != Q.shape[0] or hi.size != Q.shape[0]:
        return None
    lo, hi = lo[active], hi[active]
    if not (np.all(np.isfinite(lo)) and np.all(np.isfinite(hi))):
        return None
    if np.any(np.abs(lo) >= _CHARGE_INF_BOUND) or np.any(np.abs(hi) >= _CHARGE_INF_BOUND):
        return None
    delta = rigorous_psd_shift(S[np.ix_(active, active)])
    if delta is None:
        return None
    width = np.maximum(hi - lo, 0.0) + 2.0 * _CHARGE_BOX_SLACK * (1.0 + np.abs(lo) + np.abs(hi))
    charge = 2.0 * 0.5 * float(delta) * float(np.sum(width * width))
    return charge if np.isfinite(charge) else None


def _oa_convexity_certificate_enabled() -> bool:
    """Whether OA's cut classifier consults the convexity certificates (#1352).

    Governs :func:`~.rules.classify_oa_cut_convexity` for the callers that take
    its default (OA, LP/NLP-BB/GOA, GDPopt-LOA, GBD, the decomposition advisor
    and IR reformulation). When on, those callers get the same certificate path
    the solver's dispatch classifier (``classify_model(use_certificate=True)``)
    runs: the interval-Hessian certificate plus the exact QP/MIQP
    objective-Hessian route. Without it, a convex quadratic written with
    ``dm.sum(...)`` is routed to OA as certified convex and OA then disables its
    master lower-bound updates and objective cuts on it, fails to certify, and
    falls back to the spatial path.

    It governs the per-row cut mask as well: a constraint the certificate proves
    convex gets OA cuts (``classify_constraint(..., use_certificate=...)``).

    **Default ON** (graduated in #1360 under CLAUDE.md §5); opt out with
    ``DISCOPT_OA_CONVEXITY_CERTIFICATE=0`` (also ``false``/``no``/``off``), which
    restores the legacy syntactic verdict. Proving an objective convex turns on
    OA's objective cuts and master lower-bound updates, so this is
    bound-changing; without it OA cannot certify an objective the syntactic rules miss.

    Retraction: an earlier version of this docstring recorded the flag as "not
    net-positive, re-run once #1355 is fixed". That panel ran before OA's master
    gap window and fixed-NLP tolerance were made scale-aware (#1352); the stall
    it measured was those two defects, not the certificate. The graduation panel
    and the explicit-OA measurement are recorded in docs/dev/performance-plan.md
    §73; the default solve does not route a certificate-only objective to OA
    (``solver._objective_syntactically_convex``), so this changes the callers above
    when invoked explicitly, not the default solve's routing.
    """
    return os.environ.get("DISCOPT_OA_CONVEXITY_CERTIFICATE", "1").strip().lower() not in (
        "0",
        "false",
        "no",
        "off",
    )


# Size cap for the exact QP convexity route. ``numpy.linalg.eigvalsh`` on a dense
# symmetric matrix measured (this container, load average 0.25, min of 3):
# n=1000 -> 0.052 s, n=2000 -> 0.331 s (sd 0.008), n=4000 -> 2.47 s. Classification
# is a *dispatch* step inside the solver's time budget, so no dense eigensolve
# runs above n=2000 rather than spending seconds to prove convexity. Abstaining
# routes to the sound spatial path, so the cap is a performance guard, never a
# soundness one. It also bounds the dense materialisation: 2000**2 float64 is
# 32 MB, well under the extractor's own 256 MB dense-Q budget (#863). #1809: it
# bounds the dense work only. A larger Hessian is still proved by the exact sparse
# elimination in ``psd_certified``, on its active (original-variable) rows.
_QP_EXACT_CONVEXITY_MAX_N = 2000


def _builder_hessian_certain_unproved(model: Model) -> bool:
    """True only when the proof is *certain* to return "not proved" (#1809 review).

    Read from the ``add_quadratic_objective`` block, before any classification or
    extraction. The builder's Hessian is ``S = triu(Q) + triu(Q, 1)'`` (only the
    upper triangle is read, so no two entries are summed and none can cancel;
    ``add_quadratic_objective`` stores a symmetric ``Q`` since #1818, so ``S == Q``), and
    ``extract_qp_data`` returns exactly ``+S`` (minimize) or ``-S`` (maximize)
    embedded at the variable's columns with a zero slack block --
    ``test_builder_prediction_matches_extracted_hessian`` pins that. ``psd_certified``
    on it then sees the same pattern: ``n`` active rows and ``nnz`` nonzeros. With
    ``n`` above the cap the dense route is never taken; with ``nnz`` above
    ``PSD_CERT_SPARSE_ROW_NNZ * n`` the exact elimination is not tried; and with
    ``n > eig_max_n`` no eigensolve runs, so the verdict is "not proved". Any other
    shape -- an expression objective, a non-canonical CSR -- is not predicted.
    """
    import scipy.sparse as sp

    from .eigenvalue import PSD_CERT_SPARSE_ROW_NNZ

    obj = getattr(model, "_objective", None)
    blk = getattr(model, "_builder_quadratic_objective", None)
    if blk is None or not getattr(obj, "_is_placeholder", False):
        return False
    Q = blk[0]
    if not sp.isspmatrix_csr(Q) or not Q.has_canonical_format:
        return False
    n = Q.shape[0]
    rows = np.repeat(np.arange(n), np.diff(Q.indptr))
    upper = (Q.indices >= rows) & (Q.data != 0.0)
    r, c = rows[upper], Q.indices[upper]
    nnz = int(r.size + np.count_nonzero(r != c))
    active = np.zeros(n, dtype=bool)
    active[r] = True
    active[c] = True
    n_active = int(np.count_nonzero(active))
    return n_active > _QP_EXACT_CONVEXITY_MAX_N and nnz > PSD_CERT_SPARSE_ROW_NNZ * n_active


def certify_quadratic_objective_convex(model: Model, *, deadline: Optional[float] = None) -> bool:
    """Prove a QP/MIQP objective convex from its exact Hessian, or return ``False``.

    ``True`` means *proven*: the model's objective, in the solver's minimize
    form, has a positive-semidefinite Hessian, so the objective is convex
    everywhere. ``False`` means "not proven" — an abstention, never a claim of
    nonconvexity — and the caller must keep whatever verdict it already had.

    Why this is rigorous (issue #936). ``classify_problem`` returns ``QP``/``MIQP``
    only when the Rust structure detector reports *every* constraint linear AND
    the objective quadratic. On that branch the objective is *exactly* quadratic,
    so its Hessian is a constant matrix — there is no enclosure and no box
    dependence, and an exact symmetric-eigenvalue test on it is a global
    convexity proof valid on every sub-box. A flag-gated sibling,
    ``_certify_quadratic_psd``, made the identical argument from
    ``quadratic_form.extract_quadratic``; #1388 retired it with
    ``DISCOPT_PSD_QFORM``, and this default-ON route is what remains.
    ``extract_qp_data`` walks the model through the Rust
    repr / algebraic / autodiff ladder and handles the vectorized API, whereas
    ``quadratic_form.extract_quadratic`` (and the scalar interval-Hessian walker
    behind :func:`certify_convex`) does not — which is why a convex QP written
    with ``dm.sum(...)`` over array variables was certified by no route at all
    and fell through to spatial McCormick B&B, where it does not converge.

    ``extract_qp_data`` already returns the *minimize-form* data (it negates
    ``Q``/``c`` for a maximization objective), so a PSD verdict here answers the
    question the caller actually has — "does the objective admit the convex
    path?" — for both senses without a further sign flip.

    Slack columns are handled by the same argument: the extractor appends slack
    variables for inequality rows and pads ``Q`` with a zero block, and a
    principal submatrix of a PSD matrix is PSD, so PSD on the padded Hessian
    implies PSD on the original-variable Hessian. The padding can only make the
    test *harder* to pass, never wrongly pass it.

    Args:
        model: The model to certify.
        deadline: Optional ``time.perf_counter()`` timestamp. Crossing it makes
            this abstain (return ``False``) rather than start the work.
    """
    if not _qp_exact_convexity_enabled():
        return False
    if getattr(model, "_objective", None) is None:
        return False
    if deadline is not None and time.perf_counter() > deadline:
        return False

    # #1809: no size gate before extraction. The old one refused ``n + m > 2000``,
    # which left a sparse convex QP of 2500 variables uncertified and on spatial
    # B&B, where it does not converge. The cap now bounds only the dense work below.
    n_flat = sum(v.size for v in model._variables)
    if n_flat == 0:
        return False
    # ... but a builder Hessian the proof below is certain to abstain on is refused
    # here, before ``classify_problem`` and ``extract_qp_data`` (measured 4.8 s and
    # 4.7 s on a dense n=2100 builder QP, for the same False).
    if _builder_hessian_certain_unproved(model):
        return False

    # #1520: no except. Every step declines by return value: ``classify_problem``
    # falls back to NLP/MINLP itself, ``extract_qp_data``'s rungs absorb their own
    # declines, and the shape/size guards below return False. The old blanket
    # handler answered "not convex" (the sound direction) for any exception, so a
    # defect in the extractor was indistinguishable from a non-convex objective.
    from discopt._relax.problem_classifier import (
        ProblemClass,
        classify_problem,
        dense_Q,
        extract_qp_data,
    )

    problem_class = classify_problem(model)
    if problem_class not in (ProblemClass.QP, ProblemClass.MIQP):
        return False
    if deadline is not None and time.perf_counter() > deadline:
        return False
    qd = extract_qp_data(model)
    if deadline is not None and time.perf_counter() > deadline:
        return False
    quad = qd.Q
    # ``.shape`` is available on both dense arrays and scipy sparse matrices.
    shape = getattr(quad, "shape", None)
    if shape is None or len(shape) != 2 or shape[0] != shape[1]:
        return False
    from .eigenvalue import psd_certified

    if shape[0] > _QP_EXACT_CONVEXITY_MAX_N:
        # #1809: too large to densify, which is not too large to prove. The
        # extractor pads ``Q`` with a zero block for slack columns; a zero row adds
        # only a zero eigenvalue, so ``psd_certified`` drops those rows and decides
        # PSD on the original-variable block exactly. A sparse block is decided by
        # the exact rational elimination (a proof, no tolerance); the dense
        # eigensolve runs only if at most the cap's worth of rows remain active.
        # The #1682 charge needs the dense Hessian and is not tried at this size.
        return psd_certified(quad, eig_max_n=_QP_EXACT_CONVEXITY_MAX_N)
    hessian = dense_Q(quad)

    # #1679: a PROOF, the same predicate the ``solver="pounce"`` route certifies a
    # QP with (``convex_ipm_pounce.certify_psd``). ``quadratic_is_psd`` -- used here
    # before -- accepts ``lambda_min >= -slack``, "PSD to within roundoff", which
    # admitted the float Gram matrix ``2 K'K`` of a rank-deficient least-squares
    # model although ``exact_psd`` refutes it (lambda_min ~ -1e-14). The objective
    # is then "not proven convex" here; its structural sum-of-squares spelling is
    # still proven by the DCP walker, which does not go through this matrix.
    if psd_certified(hessian):
        return True
    # #1682: "convex up to a charge", inside a solve only (the scope's owner
    # subtracts the charge from the published bound; ``Model.convexity()`` and
    # every caller outside a solve keep the strict proof).
    scope = _CHARGE_SCOPE.get()
    if scope is None or scope.abs_gap_tol is None or not _convex_charge_enabled():
        return False
    charge = quadratic_objective_charge(hessian, qd.x_l, qd.x_u)
    if charge is None or charge > CONVEX_CHARGE_ABS_TOL_FRACTION * scope.abs_gap_tol:
        return False
    scope.record(model, charge)
    logger.info(
        "QP objective accepted as convex up to a charge of %.3g (#1682); the solve "
        "subtracts it from the published bound.",
        charge,
    )
    return True


def certify_convex(
    expr: Expression,
    model: Model,
    box: Optional[dict] = None,
) -> Optional[Curvature]:
    """Return a sound convex/concave verdict or ``None``.

    Args:
        expr: A scalar expression.
        model: The model defining the variable layout.
        box: Optional ``{Variable: Interval}`` overriding declared
            bounds — used when the caller has a tighter box from
            FBBT or branching than the model's static declaration.

    Returns:
        * ``Curvature.CONVEX`` if the interval Hessian is provably
          PSD on the box.
        * ``Curvature.CONCAVE`` if the interval Hessian is provably
          NSD on the box.
        * ``None`` if neither test succeeds (indefinite, unsupported
          atoms, or a looseness failure in Gershgorin). Returning
          ``None`` is a deliberate abstention — the caller must treat
          the expression as non-convex.
    """
    # Exact PSD-on-Q fast path (Phase 4 item 3, flag default-OFF). When a
    try:
        # Over the expression's support: the rows and columns outside it are exact
        # zeros, whose Gershgorin bounds (0 against a slack of 0) never decide a
        # verdict, so restricting to the support decides exactly as the n x n form
        # does -- without its O(n^2) memory (10.8 GB per bound on a 36804-column
        # model).
        ad = interval_hessian(expr, model, box=box, compact=True)
    except ValueError:
        # Expressions referencing array variables directly are not
        # supported by v1; abstain rather than guess. Also catches
        # ``IntervalHessianTooLarge`` (a ValueError subclass) raised when the
        # body's DAG exceeds the interval-Hessian node budget (#654): abstaining
        # to the caller's spatial/looser path is sound.
        return None

    hess = ad.hess
    if not (np.all(np.isfinite(hess.lo)) and np.all(np.isfinite(hess.hi))):
        return None

    # Structural rank-1 PSD fast path. When the AD walker has attached
    # a ``Rank1Factor`` with nonneg coefficient, the Hessian equals
    # ``c · v vᵀ`` pointwise (sound by construction) and is therefore
    # PSD on the entire box even when the entry-wise interval matrix
    # is too loose for Gershgorin to certify.
    rank1 = ad.rank1_factor
    if rank1 is not None and np.all(np.isfinite(rank1.c.lo)):
        # ``c >= 0`` decided against the arithmetic that produced ``c``, not
        # against an absolute constant (#1397): the Hessian is ``c·v vᵀ``, so a
        # coefficient of magnitude 1e12 carries ~1e-4 of rounding and one of
        # magnitude 1e-12 carries ~1e-28.
        c_slack = psd_decision_slack(
            float(np.max(np.maximum(np.abs(rank1.c.lo), np.abs(rank1.c.hi))))
        )
        if np.all(rank1.c.lo >= -c_slack):
            return Curvature.CONVEX

    # 2×2 sufficient PSD test (Sylvester) — useful when the interval
    # Hessian is tight enough that Gershgorin's row-sum loosening
    # would cross zero but the determinant proof still holds.
    # Only on a two-variable model, as before compaction: a 2x2 support of a
    # larger model is Gershgorin's to decide, so verdicts are unchanged.
    if hess.lo.shape == (2, 2) and _flat_size(model) == 2 and psd_2x2_sufficient(hess):
        return Curvature.CONVEX

    # Gershgorin's bounds are rigorous (outward-rounded), so the only slack the
    # verdict needs is the widening that outward rounding itself introduced,
    # which is O(u·‖H_i‖) for row i — scaled by each row's OWN magnitude, not
    # an absolute constant (#1397) and not the whole matrix's norm (#1673 B4:
    # a 5e17 row licensed an exact -2 on another row as PSD).
    if gershgorin_certifies_psd(hess):
        return Curvature.CONVEX

    if gershgorin_certifies_nsd(hess):
        return Curvature.CONCAVE

    return None


def _oa_convexity_subdivision_enabled() -> bool:
    """Whether OA's cut classifier retries an abstained row by box subdivision (#2054).

    Governs the subdivision fallback in :func:`~.rules.classify_oa_cut_convexity`:
    a row whose body the whole-box interval Hessian cannot certify is retried by
    :func:`certify_convex_subdivided`, and a row it proves convex gets OA cuts.

    **Default ON** (graduated in #2054 under CLAUDE.md §5); opt out with
    ``DISCOPT_OA_CONVEXITY_SUBDIVISION=0`` (also ``false``/``no``/``off``), which
    restores the whole-box verdict exactly. Bound-changing: a newly certified row
    adds OA cuts to the master. Sound by construction -- PSD on every piece of a
    cover of the box is PSD on the box.

    Graduation panel (``docs/dev/data/2054-reactor-panel/``, 2026-10-30): 40
    synthetic reactor-choice GDPs (30 convex-row models, 10 negative controls with
    a nonconvex disjunct row), 30 s, arms interleaved, independent DP oracle,
    every incumbent re-verified. Cert-clean: 0 failures over 320 solves (115
    optimal objectives, 320 bounds, 320 incumbents checked). Under
    ``gdp_method="loa"``: certified 13 -> 18, 0 lost; on the 13 both certify,
    LOA iterations 83 -> 47 and wall 133.5 -> 65.6 s; on the 22 neither
    certifies, the bound is tighter on 22, looser on 0. In-repo MINLPLib corpus
    (74 ``.nl``): 0 rows change, so OA is unchanged there; classification costs
    +3.3 s in total (nvs05 +0.8 s), paid only when an OA-family route runs.
    """
    return os.environ.get("DISCOPT_OA_CONVEXITY_SUBDIVISION", "1").strip().lower() not in (
        "0",
        "false",
        "no",
        "off",
    )


def _oa_convexity_taylor_enabled() -> bool:
    """Whether :func:`certify_convex_subdivided` tries a Taylor-form test first (#2062).

    On a row whose curvature depends on one variable ``t``, each piece is first
    tested with a Taylor form of ``f''`` about the piece midpoint with a Lagrange
    remainder (:func:`~.interval_jet.second_derivative_enclosure`), which removes
    the dependency loss of the natural interval Hessian at order ``w**K`` in the
    piece width instead of ``w``. Only when that abstains does the interval-Hessian
    bisection of #2054 run, so every row #2054 certifies is still certified.

    Bound-changing (a newly certified row gets OA cuts); sound by construction
    (Taylor's theorem with interval-enclosed coefficients, outward rounding).

    **Default ON since #2062** (CLAUDE.md section 5 panel,
    ``docs/dev/data/2062-pfr-rows-panel/``): 40 PFR/CSTR reactor-choice GDPs
    (10 negative controls), 30 s, interleaved, independent DP+SLSQP oracle --
    0 failures over 160 solves; under ``gdp_method="loa"`` certified 20 -> 25 with
    0 lost, LOA iterations 93 -> 48 and wall 254 -> 113 s where both certify, total
    wall 775 -> 524 s; neutral under big-M (that route does not read the OA mask).
    In-repo corpus (74 ``.nl``): 0 masks change, and ``Model.solve()`` OFF vs ON
    settles identically wherever node counts are deterministic.
    Opt-out ``DISCOPT_OA_CONVEXITY_TAYLOR=0`` (also ``false``/``no``/``off``).
    """
    return os.environ.get("DISCOPT_OA_CONVEXITY_TAYLOR", "1").strip().lower() not in (
        "0",
        "false",
        "no",
        "off",
    )


def _certify_univariate_taylor(
    expr: Expression,
    model: Model,
    var,
    lo: float,
    hi: float,
    *,
    max_pieces: int,
    deadline: Optional[float],
) -> Optional[Curvature]:
    """Certify ``expr``'s curvature in the scalar ``var`` on ``[lo, hi]``, or ``None`` (#2062).

    The caller guarantees the interval Hessian of ``expr`` has a single nonzero
    entry, ``d2f/dvar2`` (every other variable enters with no curvature), so the
    Hessian is PSD exactly where that entry is nonnegative. Pieces are bisected
    breadth-first and tested a whole level at a time in one vectorised jet walk.

    A piece whose enclosure is ``>= 0`` is convex, ``<= 0`` concave; a piece with
    both (``f'' = 0`` there) is compatible with either. The verdict is returned
    only when every piece of the cover is decided and all agree; mixed verdicts,
    a jet outside its atom table, an exhausted ``max_pieces`` (counted per piece
    tested) or a passed ``deadline`` return ``None``.
    """
    from .interval_jet import JetAbstain, second_derivative_enclosure

    pend_lo = np.array([lo], dtype=np.float64)
    pend_hi = np.array([hi], dtype=np.float64)
    tested = 0
    convex_seen = concave_seen = False
    while pend_lo.size:
        if tested + pend_lo.size > max_pieces:
            return None
        if deadline is not None and time.perf_counter() >= deadline:
            return None
        tested += pend_lo.size
        try:
            enc_lo, enc_hi = second_derivative_enclosure(expr, var, {}, pend_lo, pend_hi)
        except JetAbstain:
            return None
        with np.errstate(invalid="ignore"):
            convex = enc_lo >= 0.0
            concave = enc_hi <= 0.0
        convex_seen |= bool(np.any(convex & ~concave))
        concave_seen |= bool(np.any(concave & ~convex))
        if convex_seen and concave_seen:
            return None
        open_ = ~(convex | concave)
        a, b = pend_lo[open_], pend_hi[open_]
        mid = 0.5 * (a + b)
        if not bool(np.all((a < mid) & (mid < b))):
            return None
        pend_lo = np.concatenate([a, mid])
        pend_hi = np.concatenate([mid, b])
    if concave_seen:
        return Curvature.CONCAVE
    # Every piece convex, or ``f'' = 0`` on all of them (affine: convex too).
    return Curvature.CONVEX


#: Most interval-Hessian walks one :func:`certify_convex_subdivided` call makes.
#: On the #2054 reactor rows adaptive bisection needs 31 (PFR) and 59 (two CSTRs),
#: against 16 and 32 uniform pieces; past the budget the call abstains.
_SUBDIVISION_MAX_PIECES = 128
#: Most variables a row's Hessian may depend on for subdivision to be tried. A
#: cover of a ``d``-dimensional box at width ``w`` costs ``(1/w)**d`` pieces, so
#: the method is a univariate/bivariate tool; anything wider abstains at once.
_SUBDIVISION_MAX_DIMS = 2


def certify_convex_subdivided(
    expr: Expression,
    model: Model,
    *,
    max_pieces: int = _SUBDIVISION_MAX_PIECES,
    max_dims: int = _SUBDIVISION_MAX_DIMS,
    deadline: Optional[float] = None,
) -> Optional[Curvature]:
    """:func:`certify_convex` over a cover of the declared box, or ``None`` (#2054).

    The whole-box interval Hessian treats every occurrence of a variable as
    independent, so on a wide box it can enclose negative curvature that no
    point has: ``1/(exp(a*t) - 1)`` and the two-CSTR rational row of #2054 are
    convex on ``t in [0.25, 4]`` and abstain there. On narrower boxes the
    enclosure tightens, so the box is bisected -- adaptively, only the pieces
    that abstain, along the widest of the variables the Hessian depends on --
    until every piece is certified with the *same* curvature.

    Sound: a twice-differentiable function whose Hessian is PSD at every point
    of a convex set is convex on it, and the pieces cover the box, so a CONVEX
    verdict on each piece is PSD everywhere (likewise NSD for CONCAVE). A piece
    certified with the other curvature, an unbounded split variable, a support
    wider than ``max_dims``, an array variable, an exhausted ``max_pieces`` or a
    passed ``deadline`` each abstain with ``None``; abstaining is never a claim
    of nonconvexity.

    With ``DISCOPT_OA_CONVEXITY_TAYLOR`` (default ON) and a single curved variable, the cover
    is first tried with the Taylor-form test of :func:`_certify_univariate_taylor`
    (#2062), whose enclosure of ``f''`` tightens at order ``w**K`` instead of
    ``w``; when it abstains, the interval-Hessian bisection above runs as before.
    """
    from discopt.export._common import variable_flat_offsets
    from discopt.modeling.core import Variable

    try:
        ad = interval_hessian(expr, model, compact=True)
    except ValueError:
        return None
    support = ad.support
    if support is None:
        return None
    hess = ad.hess
    curved = (hess.lo != 0.0) | (hess.hi != 0.0)
    rows = np.flatnonzero(curved.any(axis=1))
    if rows.size == 0 or rows.size > max_dims:
        return None
    offsets = variable_flat_offsets(model)
    by_offset = {offsets[id(v)]: v for v in model._variables}
    split: list[Variable] = []
    for j in rows.tolist():
        var = by_offset.get(int(support[j]))
        if var is None or var.shape != ():
            return None
        lo, hi = float(np.asarray(var.lb).reshape(())), float(np.asarray(var.ub).reshape(()))
        if not (np.isfinite(lo) and np.isfinite(hi) and abs(lo) < 1e15 and abs(hi) < 1e15):
            return None
        if hi <= lo:
            return None
        split.append(var)

    start = {
        v: (float(np.asarray(v.lb).reshape(())), float(np.asarray(v.ub).reshape(()))) for v in split
    }
    if len(split) == 1 and _oa_convexity_taylor_enabled():
        # #2062: one curved variable -- try the Taylor form of f'' first.
        (v0,) = split
        verdict = _certify_univariate_taylor(
            expr, model, v0, *start[v0], max_pieces=max_pieces, deadline=deadline
        )
        if verdict is not None:
            return verdict
    work: list[dict] = [start]
    target: Optional[Curvature] = None
    walks = 0
    while work:
        if walks >= max_pieces or (deadline is not None and time.perf_counter() >= deadline):
            return None
        piece = work.pop()
        walks += 1
        verdict = certify_convex(
            expr,
            model,
            box={v: Interval(np.array(a), np.array(b)) for v, (a, b) in piece.items()},
        )
        if verdict is None:
            # Bisect the widest split variable, relative to its declared width.
            v = max(split, key=lambda u: (piece[u][1] - piece[u][0]) / (start[u][1] - start[u][0]))
            a, b = piece[v]
            mid = 0.5 * (a + b)
            if not (a < mid < b):
                return None
            work.append({**piece, v: (mid, b)})
            work.append({**piece, v: (a, mid)})
            continue
        if target is None:
            target = verdict
        elif verdict != target:
            return None
    return target


def refresh_convex_mask(
    model: Model,
    root_mask: list[bool],
    node_lb: np.ndarray,
    node_ub: np.ndarray,
) -> list[bool]:
    """Re-run the certificate against a B&B node's tightened bounds.

    For every constraint already proven convex at the root, the entry
    stays ``True`` (the node box is a subset of the root box and
    soundness propagates). For every constraint still ``False``, the
    certificate is consulted on the node box; when it proves the body
    convex in the sense implied by the constraint direction, the entry
    flips to ``True``.

    Returns a new list without mutating ``root_mask``. Falls back to
    returning the original mask unchanged if ``model`` or the bounds
    are shape-incompatible — the caller must remain functional even
    when the refresh cannot run.

    This function only ever tightens the mask. It never flips a
    ``True`` entry to ``False``, preserving the soundness invariant
    required by the solver's OA-cut and αBB-skip gates.
    """
    n_vars = sum(v.size for v in model._variables)
    if len(node_lb) != n_vars or len(node_ub) != n_vars:
        return list(root_mask)

    # Skip work when nothing can change — every slot is already True,
    # or there are no constraints at all.
    if not root_mask or all(root_mask):
        return list(root_mask)

    # Build the per-variable box from the node's flat bounds.
    box: dict = {}
    offset = 0
    for v in model._variables:
        size = v.size
        shape = v.shape if v.shape else (1,)
        lb_slice = np.asarray(node_lb[offset : offset + size], dtype=np.float64)
        ub_slice = np.asarray(node_ub[offset : offset + size], dtype=np.float64)
        try:
            box[v] = Interval(lb_slice.reshape(shape), ub_slice.reshape(shape))
        except ValueError:
            # lb > ub somewhere — the node is infeasible; return the
            # root mask unchanged. The caller will discover the
            # infeasibility via its own channels.
            return list(root_mask)
        offset += size

    refreshed = list(root_mask)
    constraint_index = 0
    for c in model._constraints:
        if not isinstance(c, Constraint):
            constraint_index += 1
            continue
        if refreshed[constraint_index]:
            constraint_index += 1
            continue
        # #1520: no except. ``certify_convex`` abstains by returning ``None`` (it
        # absorbs the interval-Hessian's documented ``ValueError`` itself), so an
        # exception here is a defect, not a "not convex" verdict.
        cert = certify_convex(c.body, model, box=box)
        if cert is None:
            constraint_index += 1
            continue
        if c.sense == "<=" and cert == Curvature.CONVEX:
            refreshed[constraint_index] = True
        elif c.sense == ">=" and cert == Curvature.CONCAVE:
            refreshed[constraint_index] = True
        elif c.sense == "==" and cert == Curvature.CONVEX and cert == Curvature.CONCAVE:
            # Equality requires affine; the certificate doesn't return
            # AFFINE, so no tightening is possible here.
            pass
        constraint_index += 1
    return refreshed


__all__ = [
    "ConvexityChargeScope",
    "certify_convex",
    "certify_quadratic_objective_convex",
    "convexity_charge_scope",
    "quadratic_objective_charge",
    "refresh_convex_mask",
    "set_charge_scope_abs_gap_tol",
]
