"""SUSPECT-style convexity / sign propagation over the expression DAG.

This module walks a ``discopt.modeling`` expression tree and assigns a
:class:`~.lattice.ExprInfo` (curvature + sign) to every subexpression
using the disciplined convex programming composition rule
(Grant, Boyd, Ye 2006) combined with sign-aware reasoning about
monotonicity of atoms (SUSPECT; Ceccon, Siirola, Misener 2020).

Soundness invariant
-------------------
A CONVEX or CONCAVE verdict is a mathematical proof, derived only from
rules whose premises are satisfied on the expression's domain. When no
rule applies the walker returns ``Curvature.UNKNOWN`` — never a
speculative classification. Sign information is tightened only when
provable from the expression's bounds or algebraic structure; unknown
signs degrade gracefully without poisoning the curvature verdict.

Rules implemented
-----------------
Leaves: Constant / Parameter / Variable / IndexExpression — AFFINE with
sign derived from value or bounds.

Unary: negation flips curvature and sign; ``abs`` is CONVEX and yields
a NONNEG result.

Binary:

* ``a + b`` — curvature via :func:`combine_sum`, sign via
  :func:`sign_add`.
* ``a - b`` — reduces to ``a + (-b)``.
* ``k * expr`` (constant scalar) — :func:`scale` applied to curvature,
  :func:`sign_mul` applied to sign.
* ``expr * expr`` — curvature UNKNOWN (bilinear); sign is the product
  of the two sign labels.
* ``expr / k`` (constant scalar, nonzero) — behaves as ``(1/k) * expr``.
* ``k / expr`` (constant numerator, argument with strictly known sign)
  — reciprocal rule: ``1/expr`` is convex on a strictly positive
  domain, concave on a strictly negative domain. Scaled by the
  numerator's sign.
* ``a ** p`` (p a literal scalar exponent) — full case analysis on
  parity, magnitude, and base sign (Boyd & Vandenberghe, *Convex
  Optimization*, §3.1.5).

Function calls: the unary atom table (:func:`unary_atom_profile`) is
consulted with the argument's sign to obtain the atom's curvature and
monotonicity; :func:`compose` produces the verdict. ``max`` and
``min`` are handled as sound n-ary extensions (max preserves
convexity, min preserves concavity).

References
----------
Grant, Boyd, Ye (2006), "Disciplined Convex Programming."
Boyd, Vandenberghe (2004), *Convex Optimization*, §3.1.
Ceccon, Siirola, Misener (2020), "SUSPECT," TOP.
"""

from __future__ import annotations

import contextlib
import contextvars
import logging
import os
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Optional, TypeVar, cast

import numpy as np

from discopt.modeling.core import (
    BinaryOp,
    Constant,
    Constraint,
    Expression,
    FunctionCall,
    IndexExpression,
    MatMulExpression,
    Model,
    Parameter,
    SumExpression,
    SumOverExpression,
    UnaryOp,
    Variable,
)

from .lattice import (
    AtomProfile,
    Curvature,
    ExprInfo,
    Monotonicity,
    Sign,
    combine_sum,
    compose,
    is_nonneg,
    is_nonpos,
    is_pos,
    is_strict,
    negate,
    scale,
    sign_add,
    sign_from_bounds,
    sign_from_value,
    sign_mul,
    sign_negate,
    sign_reciprocal,
    unary_atom_profile,
)
from .linear_context import LinearContext, build_linear_context, extract_affine

logger = logging.getLogger(__name__)

_T = TypeVar("_T")

_LINEAR_CONTEXT_KEY = "__linear_context__"

# Deadline (a ``time.perf_counter()`` timestamp) and a shared mutable visit
# counter, stashed in the classification ``cache`` by :func:`classify_model`.
# Checking the deadline inside :func:`classify_expr_info` — not merely between
# constraints — lets a single pathological expression (whose product/quadratic
# pattern matching explores exponentially many transient sub-structures) abort
# promptly rather than blow the solver's whole time budget before search starts.
_DEADLINE_KEY = "__classify_deadline__"
_VISIT_COUNT_KEY = "__classify_visits__"
# perf_counter() is comparatively expensive, so only sample the clock once per
# this many node visits; the counter increment itself is a cheap int add.
_DEADLINE_CHECK_STRIDE = 2048


def _get_linear_context(cache: dict) -> Optional[LinearContext]:
    """Return the cached linear context, if one was stashed."""
    return cache.get(_LINEAR_CONTEXT_KEY) if cache else None


def _refine_sign(
    expr: Expression,
    model: Optional[Model],
    cache: dict,
    current_sign: Sign,
) -> Sign:
    """Tighten ``current_sign`` using the model's linear relaxation.

    Applied at composition sites where the outer atom has a
    restricted domain (``log``, ``sqrt``, ``1/x``, fractional
    powers). Only affine arguments are handled — nonlinear arguments
    would need a general interval walker and are left at their
    syntactic sign. The refinement is monotone: it never loses
    strength (a STRICT ``current_sign`` is returned unchanged), and
    is sound because ``LinearContext.affine_sign`` derives it from a
    proven enclosure over the intersection of the box and the linear
    relaxation.
    """
    if is_strict(current_sign):
        return current_sign
    ctx = _get_linear_context(cache)
    if ctx is None or model is None:
        return current_sign
    aff = extract_affine(expr, model, ctx.n_vars)
    if aff is None:
        return current_sign
    coeffs, const = aff
    # `affine_sign`, not `affine_range`: only the sign is used here, and
    # it skips the LP pair whenever the variable box already settles it
    # (#1053 -- that was 21% of a 60 s solve on `hda`).
    return ctx.affine_sign(coeffs, const)


# ──────────────────────────────────────────────────────────────────────
# Structural memoization
# ──────────────────────────────────────────────────────────────────────
#
# ``from_nl`` reconstruction rebuilds shared subexpressions as *distinct*
# objects, so an ``id(expr)``-keyed cache never hits across structurally
# identical nodes: a DAG materialised as a tree re-classifies the same
# subtrees an exponential number of times (st_e36 produced ~5e5 classify
# calls — and seconds of wall time — for a 2-variable model). The
# structural cache below buckets results by a structural hash and confirms
# every candidate with :func:`patterns._expr_struct_eq` before reuse, so a
# hash collision can only cost a recomputation, never return a wrong
# curvature. This preserves the soundness invariant exactly.

_STRUCT_CACHE_KEY = "__struct_cache__"
_ENTROPY_KEEPALIVE_KEY = "__entropy_keepalive__"
_STRUCT_HASH_KEY = "__struct_hash_cache__"
# Set in the classification ``cache`` while walking the children of a maximal
# polynomial subtree, so descendant polynomial nodes skip the (redundant) whole-
# expression quadratic fallback their ancestor already covers (issue #266).
_UNDER_POLY_KEY = "__under_poly__"
_POLY_PRED_KEY = "__poly_pred_cache__"


def _is_polynomial(expr: Expression, cache: dict) -> bool:
    """Whether ``expr`` is a polynomial in the model variables.

    Conservative: only ``+ - * / **`` over variables/parameters/constants (with
    division by a constant and non-negative-integer powers) count as polynomial;
    any other atom (``exp``/``log``/``sqrt``/``abs``/trig/…) makes it ``False``.
    Memoised per classification by ``id(expr)``.

    Used purely to gate *where* the expensive quadratic-form fallback runs — a
    ``False`` only forgoes that optimisation, never changes a curvature verdict,
    so over-conservatism here is harmless.
    """
    memo = cache.get(_POLY_PRED_KEY)
    if memo is None:
        memo = {}
        cache[_POLY_PRED_KEY] = memo
    return _is_polynomial_impl(expr, memo)


def _is_polynomial_impl(expr: Expression, memo: dict) -> bool:
    eid = id(expr)
    hit = memo.get(eid)
    if hit is not None:
        return cast(bool, hit)
    r: bool
    if isinstance(expr, (Constant, Variable, Parameter)):
        r = True
    elif isinstance(expr, IndexExpression):
        r = _is_polynomial_impl(expr.base, memo)
    elif isinstance(expr, UnaryOp):
        r = expr.op == "neg" and _is_polynomial_impl(expr.operand, memo)
    elif isinstance(expr, BinaryOp):
        if expr.op in ("+", "-", "*"):
            r = _is_polynomial_impl(expr.left, memo) and _is_polynomial_impl(expr.right, memo)
        elif expr.op == "/":
            # Division by a constant scales a polynomial; division by a
            # non-constant is generally not polynomial.
            r = isinstance(expr.right, Constant) and _is_polynomial_impl(expr.left, memo)
        elif expr.op == "**":
            r = (
                isinstance(expr.right, Constant)
                and _is_nonneg_int_constant(expr.right)
                and _is_polynomial_impl(expr.left, memo)
            )
        else:
            r = False
    else:
        # FunctionCall / SumExpression / MatMul / … — not a plain polynomial.
        r = False
    memo[eid] = r
    return r


def _is_nonneg_int_constant(expr: Constant) -> bool:
    # #1520: no except. ``Constant.value`` is always an ndarray (the constructor
    # coerces it), so ``np.asarray`` on it cannot fail.
    v = np.asarray(expr.value)
    if v.ndim != 0:
        return False
    f = float(v)
    return f >= 0.0 and float(int(round(f))) == f


def _hash_index(index: object) -> object:
    """A hashable, structurally-faithful surrogate for an index key."""
    try:
        hash(index)
        return index
    except TypeError:
        pass
    if isinstance(index, slice):
        return ("slice", index.start, index.stop, index.step)
    if isinstance(index, tuple):
        # Mixed subscripts like ``x[1:, 0]`` arrive as a tuple whose elements
        # may themselves be unhashable (slices/arrays); surrogate element-wise.
        return tuple(_hash_index(i) for i in index)
    # #1520: narrowed. ``np.asarray`` refuses a ragged or otherwise
    # non-array-like index with ``ValueError``/``TypeError``; the identity key is
    # then the sound surrogate (it can only make two nodes compare unequal, never
    # equal). Anything else is a defect and propagates.
    try:
        arr = np.asarray(index)
    except (ValueError, TypeError):
        return ("id", id(index))
    if arr.dtype == object:
        # tolist() would smuggle unhashable elements back into the key.
        return ("id", id(index))
    return ("arr", arr.shape, tuple(arr.ravel().tolist()))


def _struct_hash(expr: Expression, hcache: dict) -> int:
    """Structural hash consistent with :func:`patterns._expr_struct_eq`.

    Memoised by ``id(expr)`` so the hash of a tree is computed once per
    object (otherwise the hash itself would re-walk the DAG exponentially).
    Structurally equal expressions hash equally; node types the equality
    checker does not handle are isolated by object identity so they never
    share a bucket (avoiding O(n^2) equality scans).
    """
    hid = id(expr)
    cached = hcache.get(hid)
    if cached is not None:
        return cast(int, cached)
    if isinstance(expr, Constant):
        v = np.asarray(expr.value)
        # Exact values, consistent with the exact equality in ``_expr_struct_eq``
        # (``hash(0.0) == hash(-0.0)`` matches ``0.0 == -0.0``). Rounding to 12
        # places collapsed distinct constants such as +/-4e-13 into one bucket.
        if v.ndim == 0:
            h = hash(("c", float(v)))
        else:
            h = hash(("c", v.shape, tuple(float(t) for t in v.ravel().tolist())))
    elif isinstance(expr, Variable):
        h = hash(("v", expr.name))
    elif isinstance(expr, Parameter):
        h = hash(("p", expr.name))
    elif isinstance(expr, IndexExpression):
        h = hash(("i", _struct_hash(expr.base, hcache), _hash_index(expr.index)))
    elif isinstance(expr, BinaryOp):
        h = hash(("b", expr.op, _struct_hash(expr.left, hcache), _struct_hash(expr.right, hcache)))
    elif isinstance(expr, UnaryOp):
        h = hash(("u", expr.op, _struct_hash(expr.operand, hcache)))
    elif isinstance(expr, SumOverExpression):
        h = hash(("s", tuple(_struct_hash(t, hcache) for t in expr.terms)))
    else:
        # FunctionCall / SumExpression / MatMulExpression / ... are not
        # handled by _expr_struct_eq, so they can never match structurally;
        # isolate each in its own bucket.
        h = hid
    hcache[hid] = h
    return h


# ──────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────


def classify_expr(
    expr: Expression,
    model: Optional[Model] = None,
    _cache: Optional[dict] = None,
) -> Curvature:
    """Return the proven curvature of ``expr``.

    ``Curvature.UNKNOWN`` is a conservative verdict, not a claim of
    nonconvexity; downstream consumers must still treat the result as
    non-convex when no proof is available.
    """
    return classify_expr_info(expr, model, _cache).curvature


def classify_expr_info(
    expr: Expression,
    model: Optional[Model] = None,
    _cache: Optional[dict] = None,
) -> ExprInfo:
    """Internal-detail: return full (curvature, sign) info for ``expr``.

    Exposed so callers (e.g., other detector phases, tests) can reuse
    the sign propagation without re-walking the DAG.
    """
    if _cache is None:
        _cache = {}

    _tick_deadline(_cache)

    eid = id(expr)
    cached = _cache.get(eid)
    if cached is not None:
        return cached  # type: ignore[no-any-return]

    # Classify the whole subtree on an EXPLICIT stack, deepest node first, so
    # this module holds no Python frame per DAG level. ``.nl`` writes an
    # objective as one left-deep ``+`` chain, so DAG depth tracks *model size*:
    # ``squfl015-060``'s objective is 903 levels deep, and at three frames per
    # level (``classify_expr_info``/``_classify_impl``/``_classify_binary``)
    # the recursive form exhausted CPython's 1000-frame default at roughly node
    # 330 — a ``RecursionError`` that aborted the OA path outright (issue #1063).
    #
    # ``_classify_impl`` is unchanged and still calls ``classify_expr_info`` on
    # its children; because the driver builds children first, those calls are
    # memo hits that return without descending.
    _classify_subtree(expr, model, _cache)
    return cast(ExprInfo, _cache[eid])


def _tick_deadline(cache: dict) -> None:
    """Charge one expression visit against the classification deadline.

    Deadline guard: abort a pathological classification (exponential
    transient-subexpression exploration) promptly. Sound because an aborted
    classification reports UNKNOWN, routing the model to the spatial Branch
    and Bound / McCormick relaxation — a valid, if looser, treatment.
    """
    deadline = cache.get(_DEADLINE_KEY)
    if deadline is None:
        return
    counter = cache[_VISIT_COUNT_KEY]
    counter[0] += 1
    if counter[0] % _DEADLINE_CHECK_STRIDE == 0 and time.perf_counter() > deadline:
        raise ConvexityBudgetExceeded(
            f"convexity classification exceeded its time budget after "
            f"{counter[0]} expression visits"
        )


def _classify_children(expr: Expression) -> tuple[Expression, ...]:
    """The sub-expressions classification descends into, in visit order.

    This must stay in sync with the ``classify_expr_info`` call sites in
    ``_classify_impl``/``_classify_binary``/``_classify_function_call``/
    ``_classify_matmul``; it is what lets the driver warm a node's children
    before the node itself. ``IndexExpression`` yields its base only when the
    base is not a ``Variable``, matching the branch in ``_classify_impl`` that
    reads the per-index bound instead of recursing.

    A node type missing here is not a correctness bug — ``_classify_impl``
    still reaches its children, only recursively — but it reintroduces a frame
    chain for that shape, so the coverage is asserted by a test.
    """
    if isinstance(expr, IndexExpression):
        return () if isinstance(expr.base, Variable) else (expr.base,)
    if isinstance(expr, UnaryOp):
        return (expr.operand,)
    if isinstance(expr, BinaryOp):
        return (expr.left, expr.right)
    if isinstance(expr, FunctionCall):
        return tuple(expr.args)
    if isinstance(expr, SumExpression):
        return (expr.operand,)
    if isinstance(expr, SumOverExpression):
        return tuple(expr.terms)
    if isinstance(expr, MatMulExpression):
        return (expr.left, expr.right)
    return ()


def _warm_bottom_up(
    root: Expression,
    memo: dict,
    compute: Callable[[Expression], object],
    tick: Optional[Callable[[], None]] = None,
) -> None:
    """Fill ``memo`` for every node under ``root``, deepest first.

    ``_is_polynomial_impl`` and ``_struct_hash`` are self-recursive over this
    same DAG and memoised by ``id``. Calling them in post-order makes every
    child lookup a hit, so each call returns after one level instead of holding
    a frame per level — the rules themselves are reused verbatim rather than
    re-implemented iteratively, so there is one definition of each.

    ``tick`` charges each computed node against the classification deadline. These
    walks visit the whole DAG before the first ``classify_expr_info`` tick, so
    without it an armed deadline was not polled through them at all (#1757: 20 s
    on QPLIB_2880's 176,410-product objective sum).
    """
    stack: list[tuple[Expression, bool]] = [(root, False)]
    while stack:
        node, expanded = stack.pop()
        if id(node) in memo:
            continue
        if not expanded:
            stack.append((node, True))
            for child in reversed(_classify_children(node)):
                if id(child) not in memo:
                    stack.append((child, False))
            continue
        if tick is not None:
            tick()
        compute(node)


def _classify_shortcut(expr: Expression, cache: dict) -> Optional[ExprInfo]:
    """Reuse a structurally identical node's info, or ``None`` to classify.

    Structural memoization: collapse the exponential re-classification of
    ``from_nl``-rebuilt, structurally-identical-but-distinct nodes. A hash
    collision is resolved by an exact structural-equality check, so reuse
    can never substitute a wrong curvature (see module note above).
    """
    struct_cache = cache.get(_STRUCT_CACHE_KEY)
    if struct_cache is None:
        struct_cache = {}
        cache[_STRUCT_CACHE_KEY] = struct_cache
    hash_cache = cache.get(_STRUCT_HASH_KEY)
    if hash_cache is None:
        hash_cache = {}
        cache[_STRUCT_HASH_KEY] = hash_cache

    from .patterns import _expr_struct_eq

    bucket = struct_cache.get(_struct_hash(expr, hash_cache))
    if bucket is None:
        return None
    for cand_expr, cand_info in bucket:
        if _expr_struct_eq(expr, cand_expr):
            cache[id(expr)] = cand_info
            return cast(ExprInfo, cand_info)
    return None


def _classify_node(
    expr: Expression, model: Optional[Model], cache: dict, under_poly: bool
) -> ExprInfo:
    """Classify one node whose children are already in ``cache``.

    ``under_poly`` is the ancestor context the recursive form kept in
    ``_cache[_UNDER_POLY_KEY]``; the driver carries it on its stack instead.
    """
    # Whole-expression quadratic fallback: when the recursive walker leaves a
    # polynomial at UNKNOWN (e.g. an intermediate bilinear node defeats local
    # reasoning), the full quadratic form may still classify via eigendecomposition
    # of a symmetrised Q. ``quadratic_curvature`` builds Q over *all* model
    # variables and eigendecomposes it (O(N^3)); running it at every node of a deep
    # additive polynomial would cost O(nodes * N^3) and made classification
    # super-linear in model size (issue #266). It is redundant on a node whose
    # ancestor is itself an extractable polynomial — that ancestor's Q already
    # covers this node — so attempt it only at *maximal* polynomial subtrees (a
    # polynomial node with no polynomial ancestor). While classifying the children
    # of such a node, ``_UNDER_POLY_KEY`` is set so descendants skip their own
    # redundant eigendecomposition. Skipping is sound: it can only forgo a
    # convexity proof (-> spatial B&B), never assert a false one.
    maximal_poly = (not under_poly) and model is not None and _is_polynomial(expr, cache)

    # The flag is set for the duration of ``_classify_impl`` so that a child the
    # driver did not pre-warm (a node shape absent from ``_classify_children``)
    # still sees the ancestor context the recursive form gave it. Restoring
    # ``under_poly`` matches both arms of the original: the maximal arm reset the
    # flag to False, which is what ``under_poly`` is whenever ``maximal_poly``.
    cache[_UNDER_POLY_KEY] = under_poly or maximal_poly
    try:
        info = _classify_impl(expr, model, cache)
    finally:
        cache[_UNDER_POLY_KEY] = under_poly

    if maximal_poly and model is not None and info.curvature == Curvature.UNKNOWN:
        from .patterns import quadratic_curvature

        qc = quadratic_curvature(expr, model)
        if qc is not None and qc != Curvature.UNKNOWN:
            info = ExprInfo(qc, info.sign)

    cache[id(expr)] = info
    hash_cache = cache[_STRUCT_HASH_KEY]
    cache[_STRUCT_CACHE_KEY].setdefault(_struct_hash(expr, hash_cache), []).append((expr, info))
    return info


def _classify_subtree(root: Expression, model: Optional[Model], cache: dict) -> None:
    """Populate ``cache[id(root)]`` by classifying ``root``'s DAG bottom-up.

    Visits nodes in exactly the order the recursive form did — the shortcut is
    consulted on the way *down* (so a structural-cache hit still prunes the
    subtree beneath it) and a node is classified on the way back *up*.
    """
    poly_memo = cache.get(_POLY_PRED_KEY)
    if poly_memo is None:
        poly_memo = {}
        cache[_POLY_PRED_KEY] = poly_memo
    hash_cache = cache.get(_STRUCT_HASH_KEY)
    if hash_cache is None:
        hash_cache = {}
        cache[_STRUCT_HASH_KEY] = hash_cache

    # Warm the two self-recursive predicates first: the driver calls both at
    # *expand* time, when descendants are not yet classified, so they would
    # otherwise recurse the full depth on their own.
    tick = (lambda: _tick_deadline(cache)) if cache.get(_DEADLINE_KEY) is not None else None
    _warm_bottom_up(root, poly_memo, lambda n: _is_polynomial_impl(n, poly_memo), tick)
    _warm_bottom_up(root, hash_cache, lambda n: _struct_hash(n, hash_cache), tick)

    # (node, ancestor under_poly context, children already pushed)
    stack: list[tuple[Expression, bool, bool]] = [(root, cache.get(_UNDER_POLY_KEY, False), False)]
    while stack:
        node, under_poly, expanded = stack.pop()
        if id(node) in cache:
            continue
        if expanded:
            _classify_node(node, model, cache, under_poly)
            continue
        if _classify_shortcut(node, cache) is not None:
            continue
        maximal_poly = (not under_poly) and model is not None and _is_polynomial(node, cache)
        child_ctx = under_poly or maximal_poly
        stack.append((node, under_poly, True))
        for child in reversed(_classify_children(node)):
            if id(child) not in cache:
                stack.append((child, child_ctx, False))


# ──────────────────────────────────────────────────────────────────────
# Sign extraction for leaves
# ──────────────────────────────────────────────────────────────────────


def _variable_sign(v: Variable) -> Sign:
    """Conservative sign of every entry of a variable."""
    lb_arr = np.asarray(v.lb)
    ub_arr = np.asarray(v.ub)
    if lb_arr.size == 0:
        return Sign.UNKNOWN
    return sign_from_bounds(float(lb_arr.min()), float(ub_arr.max()))


def _indexed_variable_sign(expr: IndexExpression) -> Sign:
    """Sign of ``var[idx]`` — sharper than the whole-variable bound."""
    if not isinstance(expr.base, Variable):
        return Sign.UNKNOWN
    lb = np.asarray(expr.base.lb)
    ub = np.asarray(expr.base.ub)
    try:
        lb_val = float(np.asarray(lb[expr.index]).min())
        ub_val = float(np.asarray(ub[expr.index]).max())
    except (IndexError, TypeError, ValueError):
        return Sign.UNKNOWN
    return sign_from_bounds(lb_val, ub_val)


# ──────────────────────────────────────────────────────────────────────
# Core dispatcher
# ──────────────────────────────────────────────────────────────────────


def _classify_impl(expr: Expression, model: Optional[Model], cache: dict) -> ExprInfo:
    """Dispatch on expression node type to an :class:`ExprInfo`."""

    # --- Leaves -----------------------------------------------------
    if isinstance(expr, (Constant, Parameter)):
        return ExprInfo(Curvature.AFFINE, sign_from_value(expr.value))

    if isinstance(expr, Variable):
        return ExprInfo(Curvature.AFFINE, _variable_sign(expr))

    if isinstance(expr, IndexExpression):
        # Tighten the sign when the base is a Variable by looking at
        # the per-index bound; otherwise fall back to recursing into
        # the base expression.
        if isinstance(expr.base, Variable):
            return ExprInfo(Curvature.AFFINE, _indexed_variable_sign(expr))
        # A static index into a constant leaf carries the sign of the ELEMENT,
        # which is strictly more information than the whole array's: ``mu[2]``
        # can be provably positive where ``mu`` as a whole is mixed-sign and
        # therefore Sign.UNKNOWN (which is what recursing into the base returns).
        indexed = _const_leaf_value(expr)
        if indexed is not None:
            return ExprInfo(Curvature.AFFINE, sign_from_value(indexed))
        base = classify_expr_info(expr.base, model, cache)
        return base  # indexing preserves curvature and sign info.

    # --- Unary ops --------------------------------------------------
    if isinstance(expr, UnaryOp):
        child = classify_expr_info(expr.operand, model, cache)
        if expr.op == "neg":
            return ExprInfo(negate(child.curvature), sign_negate(child.sign))
        if expr.op == "abs":
            # |x| is convex everywhere; the value is nonneg.
            if child.curvature == Curvature.AFFINE:
                return ExprInfo(Curvature.CONVEX, Sign.NONNEG)
            return ExprInfo(Curvature.UNKNOWN, Sign.NONNEG)
        return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)

    # --- Binary ops -------------------------------------------------
    if isinstance(expr, BinaryOp):
        return _classify_binary(expr, model, cache)

    # --- Function calls --------------------------------------------
    if isinstance(expr, FunctionCall):
        return _classify_function_call(expr, model, cache)

    # --- Aggregations ----------------------------------------------
    if isinstance(expr, SumExpression):
        return classify_expr_info(expr.operand, model, cache)

    if isinstance(expr, SumOverExpression):
        curv: Curvature = Curvature.AFFINE
        s: Sign = Sign.ZERO
        for t in expr.terms:
            t_info = classify_expr_info(t, model, cache)
            curv = combine_sum(curv, t_info.curvature)
            s = sign_add(s, t_info.sign)
            if curv == Curvature.UNKNOWN:
                # We can keep refining the sum's sign but curvature is
                # already lost; still return a best-effort sign.
                return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)
        return ExprInfo(curv, s)

    if isinstance(expr, MatMulExpression):
        return _classify_matmul(expr, model, cache)

    return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)


# ──────────────────────────────────────────────────────────────────────
# Binary ops
# ──────────────────────────────────────────────────────────────────────


def _is_static_index(index: Any) -> bool:
    """Is ``index`` plain numpy indexing data, with nothing symbolic in it?

    An :class:`~discopt.modeling.core.IndexExpression`'s index is whatever was
    written between the brackets; the constructor is deliberately non-raising and
    keeps forms it cannot resolve as lazy nodes. Only an index made of integers,
    slices, ``Ellipsis``, ``None`` and integer/bool arrays resolves to a fixed
    element of a constant's value here and now — anything holding an
    ``Expression`` is refused, because its value is not known at classification
    time and a curvature *proof* may not rest on a guess.
    """
    if isinstance(index, Expression):
        return False
    if isinstance(index, (tuple, list)):
        return all(_is_static_index(i) for i in index)
    if isinstance(index, slice):
        return all(_is_static_index(p) for p in (index.start, index.stop, index.step))
    if isinstance(index, np.ndarray):
        return bool(index.dtype.kind in "iub")
    return isinstance(index, (int, np.integer, bool, np.bool_, type(Ellipsis), type(None)))


def _const_leaf_value(expr: Expression) -> Optional[np.ndarray]:
    """The float64 value of a constant leaf, ``None`` if ``expr`` is not one.

    A constant leaf is a :class:`Constant`, a :class:`Parameter` (fixed for the
    duration of a solve; the classification cache is reset per solve, so a
    re-bound value is re-classified), or a **static index into one** —
    ``mu[3]``, ``L[:, 0]``, ``c[idx]``.

    The indexed case is why this function exists. Writing a coefficient vector as
    one array ``Parameter`` and using ``mu[k] * x[k]`` is the natural spelling,
    and without it the product rule saw two non-constants and fell through to
    UNKNOWN — so a convex model built that way lost its convexity certificate
    and, with it, the single-NLP route (measured on a restricted-equilibrium NLP:
    ``convex=False``/``feasible`` for the array spelling against
    ``convex=True``/``optimal`` for the identical model with scalar parameters).

    The resolution uses numpy's own indexing on the leaf's value, so it agrees
    with what the evaluator will compute by construction, and refuses — returns
    ``None`` — on anything numpy will not resolve, on a symbolic index, and on a
    non-numeric value. Refusing costs a proof; guessing would *make* one.
    """
    if isinstance(expr, (Constant, Parameter)):
        try:
            return np.asarray(expr.value, dtype=np.float64)
        except (TypeError, ValueError):
            return None
    if isinstance(expr, IndexExpression):
        base = _const_leaf_value(expr.base)
        if base is None or not _is_static_index(expr.index):
            return None
        try:
            return np.asarray(base[expr.index], dtype=np.float64)
        except (TypeError, ValueError, IndexError):
            return None
    return None


def _is_scalar_const(expr: Expression) -> bool:
    """True if ``expr`` is a concrete numeric scalar (or a static index into one).

    The ``Constant``/``Parameter`` arm is the pre-existing test, unchanged: this
    predicate is only ever *widened* to the indexed case, never narrowed, so no
    expression that used to pass can start failing (a constant whose value is not
    float64-coercible still answers exactly as it did).
    """
    if isinstance(expr, (Constant, Parameter)):
        return bool(np.asarray(expr.value).ndim == 0)
    val = _const_leaf_value(expr)
    return bool(val is not None and val.ndim == 0)


def _scalar_value(expr: Expression) -> float:
    if isinstance(expr, (Constant, Parameter)):
        return float(np.asarray(expr.value))  # type: ignore[attr-defined]
    val = _const_leaf_value(expr)
    if val is None:  # pragma: no cover - callers gate on _is_scalar_const
        raise TypeError(f"{expr!r} is not a constant leaf")
    return float(val)


def _finite_const_value(expr: Expression) -> Optional[np.ndarray]:
    """The value of a concrete, everywhere-finite constant leaf, or ``None``.

    ``None`` means *this operand supports no scaling verdict at all* — it is not a
    ``Constant``/``Parameter``, its value is not coercible to float64, or it holds
    an ``inf``/``nan``. Kept separate from :func:`_const_scale_sign`'s "no uniform
    sign" answer because the two demand opposite handling: a mixed-sign constant
    still leaves an affine operand affine, whereas a non-finite one must refuse
    outright (a NaN coefficient would otherwise pass through as AFFINE and read as
    a proof). Conflating them made the product rule disagree with
    :func:`_classify_division`, which has always refused non-finite divisors.
    """
    arr = _const_leaf_value(expr)
    if arr is None:
        return None
    if not np.all(np.isfinite(arr)):
        return None
    return arr


def _const_scale_sign(arr: np.ndarray) -> Optional[int]:
    """Curvature-scaling sign of a finite constant factor, scalar **or array**.

    Returns ``+1`` / ``-1`` / ``0`` when every entry is, respectively, nonnegative
    (with at least one positive), nonpositive (with at least one negative), or
    exactly zero — the three cases in which the elementwise product ``c ⊙ f``
    scales *every* entry of ``f``'s curvature by one uniform sign, so
    :func:`~.lattice.scale` applies. Returns ``None`` when the entries MIX signs:
    no single scaling is valid then, though an affine operand still stays affine.

    Entries equal to zero alongside strictly-signed ones do not spoil the
    verdict: ``0 * f`` is affine, hence both convex and concave, so it never
    contradicts the strict entries' direction.

    Callers pass a value already screened by :func:`_finite_const_value`; this
    function answers only the sign question.

    Only 0-d constants used to be recognised (``_is_scalar_const``). That
    dropped the whole *vectorized* modeling surface to UNKNOWN curvature: a
    collocation row is ``h ⊙ (A @ x)`` with ``h`` an array of element widths, so
    every ``discopt.dae`` model classified nonconvex and was routed to spatial
    McCormick B&B, which does not converge on it (#944).
    """
    if np.all(arr == 0.0):
        return 0
    if np.all(arr >= 0.0):
        return 1
    if np.all(arr <= 0.0):
        return -1
    return None


def _const_divisor_info(expr: Expression) -> Optional[int]:
    """Scaling sign of a constant divisor, scalar **or array**.

    Returns ``+1`` when every entry is strictly positive, ``-1`` when every entry
    is strictly negative, and ``0`` when the entries are all nonzero but mixed in
    sign (``1/c`` is then well-defined everywhere but carries no single
    direction). Returns ``None`` — meaning *refuse* — when ``expr`` is not a
    concrete constant, holds a non-finite entry, or holds an entry at or within
    ``1e-30`` of zero, matching the scalar guard this generalises.
    """
    arr = _const_leaf_value(expr)
    if arr is None:
        return None
    if not np.all(np.isfinite(arr)) or np.any(np.abs(arr) <= 1e-30):
        return None
    if np.all(arr > 0.0):
        return 1
    if np.all(arr < 0.0):
        return -1
    return 0


def _classify_binary(expr: BinaryOp, model: Optional[Model], cache: dict) -> ExprInfo:
    left = classify_expr_info(expr.left, model, cache)
    right = classify_expr_info(expr.right, model, cache)

    if expr.op == "+":
        return ExprInfo(
            combine_sum(left.curvature, right.curvature),
            sign_add(left.sign, right.sign),
        )

    if expr.op == "-":
        return ExprInfo(
            combine_sum(left.curvature, negate(right.curvature)),
            sign_add(left.sign, sign_negate(right.sign)),
        )

    if expr.op == "*":
        return _classify_product(expr, left, right, model, cache)

    if expr.op == "/":
        return _classify_division(expr, left, right, model, cache)

    if expr.op == "**":
        if (
            not _is_scalar_const(expr.right)
            and _is_scalar_const(expr.left)
            and power_composition_enabled()
        ):
            return _classify_constant_base_power(expr, right)
        return _classify_power(expr, left, model, cache)

    return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)


def power_composition_enabled() -> bool:
    """``DISCOPT_POWER_COMPOSITION`` gate for the #1868 power rules.

    Covers both: ``c ** f`` with a constant base (:func:`_classify_constant_base_power`)
    and the DCP composition of an integer power with a non-affine base of proven
    sign (in :func:`_classify_power`). Read at call time so a test can flip it per
    solve. Sound either way -- the rules only ever replace an UNKNOWN verdict -- but
    a convexity proof re-routes a whole model (the perspective-composite lesson
    above), so the verdict is bound-changing and was gated per CLAUDE.md section 5.

    **Graduated (default ON, 2026-10-22).** Firing scan over every DAG node of 389
    MINLPLib instances (the 161 flagged convex plus 230 flagged not, <= 200
    vars/cons; the 66 in-repo files included): fires on 7 -- the six
    ``cvxnonsep_pcon*`` and ``hda`` (9 of 4,069 nodes) -- and the OFF arm equals the
    pre-#1868 classifier on every node of all 389. Panel on the 7, flag ON vs OFF,
    120 s, interleaved, load <= 1.5: cert-clean (14 rows, no bound past the MINLPLib
    optimum, every incumbent re-verified by ``verify_point`` on a freshly read model,
    no certificate lost) and net-positive -- certified 3 -> 6 (``pcon20/30/40``
    4.6 s / 37.9 s / 71.8 s, gap open at 120 s OFF), and where both certify
    (``pcon20r/30r/40r``) wall 45.8 s -> 3.6 s, nodes 657 -> 44; ``hda`` identical.
    ``DISCOPT_POWER_COMPOSITION=0`` restores the pre-#1868 classifier.
    """
    return os.environ.get("DISCOPT_POWER_COMPOSITION", "1").strip().lower() not in (
        "0",
        "false",
        "no",
        "off",
        "",
    )


def _classify_constant_base_power(expr: BinaryOp, exponent: ExprInfo) -> ExprInfo:
    """Classify ``c ** f`` for a scalar constant base ``c`` (#1868).

    For ``c > 0`` this is ``exp(f * ln c)``: the ``exp`` rule (convex, nondecreasing)
    composed with the inner ``ln(c) * f``, whose curvature is ``f``'s scaled by the
    sign of ``ln c``. The result is strictly positive. ``c == 1`` is the constant 1.
    ``c <= 0`` is not a real-valued exponential for non-integer ``f`` and abstains.
    Before this rule every ``c ** f`` classified UNKNOWN -- even ``2 ** x``, which is
    ``exp(0.693 x)`` -- so ``cvxnonsep_pcon*`` (convex in MINLPLib, every term a
    ``2 ** (affine)``) were never routed as convex.
    """
    c = _scalar_value(expr.left)
    if not np.isfinite(c) or c <= 0.0:
        return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)
    if c == 1.0:
        return ExprInfo(Curvature.AFFINE, Sign.POS)
    inner = scale(exponent.curvature, 1 if c > 1.0 else -1)
    return ExprInfo(compose(Curvature.CONVEX, Monotonicity.NONDEC, inner), Sign.POS)


def _classify_product(
    expr: BinaryOp,
    left: ExprInfo,
    right: ExprInfo,
    model: Optional[Model],
    cache: dict,
) -> ExprInfo:
    """Classify ``a * b`` with sign-aware curvature."""
    prod_sign = sign_mul(left.sign, right.sign)

    # Constant scaling on either side → curvature scaled by that sign. The
    # constant may be an ARRAY (elementwise / broadcast scaling), not only a
    # 0-d scalar: a uniform entry sign scales the other operand's curvature
    # exactly as a scalar would, and an AFFINE operand survives *any* constant
    # array — including one of mixed sign — because each broadcast entry is
    # ``const * affine`` (#944).
    # A non-finite constant is refused here rather than falling into the
    # mixed-sign branch below: `nan * affine` is not affine in any useful sense,
    # and returning AFFINE for it would emit a *proof* about a broken model. This
    # matches `_classify_division`, which has always refused non-finite divisors.
    for const_side, other in ((expr.left, right), (expr.right, left)):
        arr = _finite_const_value(const_side)
        if arr is None:
            continue
        s = _const_scale_sign(arr)
        if s is not None:
            return ExprInfo(scale(other.curvature, s), prod_sign)
        if other.curvature == Curvature.AFFINE:
            return ExprInfo(Curvature.AFFINE, prod_sign)

    # Square of an affine expression: ``e * e`` with ``e`` affine is convex
    # and nonnegative. Recognising it here (the two operands are the *same*
    # node, so ``expr.left is expr.right``) is both sound and a large speed
    # win: it keeps ``x * x`` out of the whole-expression quadratic fallback,
    # which would otherwise build a dense n×n form and run an O(n³)
    # eigendecomposition on every such product node.
    if expr.left is expr.right and left.curvature == Curvature.AFFINE:
        return ExprInfo(Curvature.CONVEX, Sign.NONNEG)

    # Special product patterns: perspective of exp and weighted
    # geometric mean. See :mod:`patterns` for the preconditions.
    if model is not None:
        from .patterns import classify_perspective_product, classify_product_pattern

        special = classify_product_pattern(expr, model, classify_expr, cache)
        if special is not None:
            return ExprInfo(special, prod_sign)

        # Perspective product ((g/L)**2)*L + affine companions → quad-over-affine.
        special = classify_perspective_product(expr, model, classify_expr, cache)
        if special == Curvature.CONVEX:
            return ExprInfo(Curvature.CONVEX, prod_sign)

        # Entropy-family products (#1616 A-01): ``c*x*log(x)`` IS ``c*entropy(x)``
        # and ``c*x*log(x/y)`` IS ``c*centropy(x, y)``. The solver rewrites these
        # before it classifies (``canonicalize_entropy``); recognising them here,
        # with the same strict matchers and domain guards, makes every caller of
        # the classifier -- ``classify_model`` included -- reach the verdict the
        # solve uses. The intrinsic is classified by its own atom rules, so no
        # new curvature claim is introduced.
        from discopt._relax.factorable_reform import (
            _match_centropy_product,
            _match_entropy_affine_product,
            _match_entropy_product,
        )

        matched = _match_entropy_product(expr, model)
        if matched is None:
            matched = _match_centropy_product(expr, model)
        if matched is None:
            matched = _match_entropy_affine_product(expr, model)
        if matched is not None:
            # Keep the rewritten nodes alive for the cache's lifetime: the cache
            # is keyed by ``id()``, and a freed temporary's id can be reused.
            cache.setdefault(_ENTROPY_KEEPALIVE_KEY, []).append(matched)
            info = classify_expr_info(matched, model, cache)
            if info.curvature != Curvature.UNKNOWN:
                return ExprInfo(info.curvature, prod_sign)

        # Perspective composite (#1617 C-12b): ``g(A1/L, ..., Ak/L) * L``.
        if perspective_composite_enabled():
            persp = _classify_perspective_composite(expr, model, cache)
            if persp is not None:
                return ExprInfo(persp, prod_sign)

    # Bilinear / general product: curvature is UNKNOWN even when both
    # factors share a sign (consider x*y on the positive orthant, whose
    # Hessian has eigenvalues ±1). Sign can still be tightened.
    return ExprInfo(Curvature.UNKNOWN, prod_sign)


def perspective_composite_enabled() -> bool:
    """``DISCOPT_PERSPECTIVE_COMPOSITE`` gate for the perspective-composite rule.

    Read at call time so a test can flip it per solve. See
    :func:`_classify_perspective_composite` and ``docs/dev/flag-retirement-audit.md``.

    **Kept as a documented opt-in (default OFF), CLAUDE.md section 5.** The rule is
    sound (differential and sampling tests in
    ``tests/test_issue_1617_c12b_hull_perspective.py``; 5250 GDP/convexity tests
    pass with it ON) and tightens the root: the #1617 C-12b synthesis witness goes
    from -1898 to the optimum -482.18 at the root, 7 nodes to 1. But a proof of
    convexity re-routes the whole model to NLP-BB, and on the class it fires on
    (48 of MINLPLib's 54 ``*hfsg`` hull instances, ``syn*``/``rsyn*``; 1 in-repo,
    ``syn05hfsg``) the 30 s panel (2026-10-04, one interleaved rep per arm, load
    ~170) certified 36 vs 39 OFF -- 3 gains (``syn30m03``, ``syn40m03``,
    ``rsyn0830m03``) against 6 losses (``rsyn0805m02/m03``, ``rsyn0810m03``,
    ``rsyn0815m03/m04``, ``rsyn0830m02``), shifted-geomean wall 3.48 -> 3.89 s.
    Cert-clean (no bound past a ``minlplib.solu`` optimum in 96 rows) but not
    net-positive. What would change that: consuming the proof for OA cuts on the
    spatial path *without* the NLP-BB route switch, or an NLP-BB that keeps pace
    with the spatial tree on the ``rsyn*m03/m04`` instances.
    """
    if _PERSPECTIVE_PROOF_SCOPE.get():
        return True
    return os.environ.get("DISCOPT_PERSPECTIVE_COMPOSITE", "0").strip().lower() not in (
        "0",
        "false",
        "no",
        "off",
        "",
    )


# #1662: the perspective-composite rule enabled for one caller only. The spatial
# relaxation (``uniform_relax._Builder._dcp``) consumes the proof for OA cuts
# inside this scope; ``classify_model`` and the route decision run outside it, so
# the proof cannot re-route the model to NLP-BB.
_PERSPECTIVE_PROOF_SCOPE: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "discopt_perspective_proof_scope", default=False
)


@contextlib.contextmanager
def perspective_proof_scope(enabled: bool = True):
    """Enable the perspective-composite rule for classifications made inside.

    Callers must not share a ``classify_expr`` cache across the scope boundary:
    a verdict cached inside would leak a proof to a caller outside it.
    """
    token = _PERSPECTIVE_PROOF_SCOPE.set(bool(enabled))
    try:
        yield
    finally:
        _PERSPECTIVE_PROOF_SCOPE.reset(token)


def _reciprocal_numerator(node: Expression, l_expr: Expression) -> Optional[Expression]:
    """``A`` if ``node`` is a ratio ``A / L`` with ``L`` structurally ``l_expr``.

    Two spellings: ``A / L`` as written, and ``L**-1 * A`` (either factor order),
    the form the canonical DAG reconstructs a division into (#1662). Both
    denote the same value, so the perspective identity is unaffected.
    """
    from .patterns import _expr_struct_eq

    if not isinstance(node, BinaryOp):
        return None
    if node.op == "/" and _expr_struct_eq(node.right, l_expr):
        return node.left
    if node.op == "*":
        for recip, num in ((node.left, node.right), (node.right, node.left)):
            if (
                isinstance(recip, BinaryOp)
                and recip.op == "**"
                and isinstance(recip.right, Constant)
                and np.ndim(recip.right.value) == 0
                and float(recip.right.value) == -1.0
                and _expr_struct_eq(recip.left, l_expr)
            ):
                return num
    return None


def _perspective_atoms(
    e_expr: Expression, l_expr: Expression
) -> Optional[list[tuple[Expression, Expression]]]:
    """The ``(A / L, A)`` atoms of ``e_expr``, or ``None`` if a variable sits outside one.

    An atom is a ratio node whose divisor is structurally ``l_expr`` (see
    :func:`_reciprocal_numerator`), paired with its numerator; it is not
    descended into. Any ``Variable`` (or indexed ``Variable``) reached outside an
    atom means ``e_expr`` is not a function of the ratios alone, and the
    perspective identity does not apply. ``Parameter`` leaves are constants.
    """
    atoms: list[tuple[Expression, Expression]] = []
    seen: set[int] = set()
    stack: list[Expression] = [e_expr]
    while stack:
        node = stack.pop()
        if id(node) in seen:
            continue
        seen.add(id(node))
        num = _reciprocal_numerator(node, l_expr)
        if num is not None:
            atoms.append((node, num))
            continue
        if isinstance(node, Variable):
            return None
        if isinstance(node, IndexExpression) and isinstance(node.base, Variable):
            return None
        if isinstance(node, MatMulExpression):
            # Not walked by the atom collector below; refuse rather than guess.
            return None
        stack.extend(_classify_children(node))
    return atoms or None


def _classify_perspective_composite(
    expr: BinaryOp, model: Model, cache: dict
) -> Optional[Curvature]:
    """Curvature of ``E * L`` where ``E = g(A1/L, ..., Ak/L)`` and ``L`` affine > 0.

    The perspective ``L * g(z/L)`` of a function ``g`` convex (concave) in ``z``
    is jointly convex (concave) in ``(z, L)`` on ``L > 0``; composed with the
    affine map ``x -> (A(x), L(x))`` it stays convex (concave). This is the
    shape the GDP hull writes for a nonlinear disjunct body (Furman, Sawaya and
    Grossmann's eps-perspective: ``yhat * g(v / yhat)`` with
    ``yhat = (1 - eps) * y + eps``), which the generic product rule calls
    UNKNOWN because ``v / yhat`` is not convex in ``(v, y)`` -- so a convex
    disjunct became a nonconvex hull row relaxed by McCormick (#1617 C-12b).

    Proof obligations, each checked:

    * ``L`` is affine and provably strictly positive on the box;
    * every variable of ``E`` sits inside a ratio ``A_i / L`` whose divisor is
      structurally ``L`` and whose numerator ``A_i`` is affine;
    * ``E``'s curvature *in the ratios* is classified by the ordinary rules in a
      fresh cache that seeds each ratio as an AFFINE leaf. Sign and domain
      checks inside that pass evaluate the real ratio ``A_i / L`` over the box,
      i.e. an enclosure of the values ``z_i`` actually takes, so a domain-guarded
      atom (``log``, ``sqrt``) is only accepted where ``g`` is defined.

    Returns ``None`` when any obligation fails (conservative).
    """
    from .patterns import _has_positive_lower_bound

    for e_expr, l_expr in ((expr.left, expr.right), (expr.right, expr.left)):
        if classify_expr(l_expr, model, cache) != Curvature.AFFINE:
            continue
        if not _has_positive_lower_bound(l_expr, model):
            continue
        atoms = _perspective_atoms(e_expr, l_expr)
        if atoms is None:
            continue
        seeded: dict = {}
        for key in (_DEADLINE_KEY, _VISIT_COUNT_KEY):
            if key in cache:
                seeded[key] = cache[key]
        ok = True
        for atom, num in atoms:
            if classify_expr(num, model, cache) != Curvature.AFFINE:
                ok = False
                break
            # sign(A / L) = sign(A) since L > 0.
            num_sign = classify_expr_info(num, model, cache).sign
            seeded[id(atom)] = ExprInfo(Curvature.AFFINE, num_sign)
        if not ok:
            continue
        # Keep the seeded atoms alive while their ids key the fresh cache.
        seeded["__perspective_atoms__"] = atoms
        curv = classify_expr_info(e_expr, model, seeded).curvature
        if curv in (Curvature.CONVEX, Curvature.CONCAVE, Curvature.AFFINE):
            return curv
    return None


def _classify_division(
    expr: BinaryOp,
    left: ExprInfo,
    right: ExprInfo,
    model: Optional[Model],
    cache: dict,
) -> ExprInfo:
    """Classify ``a / b``."""
    # Divide by constant: scale by 1/k. As with the product rule, the divisor may
    # be a constant ARRAY (elementwise / broadcast division by, say, a vector of
    # finite-element widths); ``1/c`` then has the same uniform sign as ``c``, so
    # the same scaling applies. Every entry must be bounded away from zero —
    # a single zero entry makes the quotient undefined there (#944).
    if isinstance(expr.right, (Constant, Parameter)) or _const_leaf_value(expr.right) is not None:
        s = _const_divisor_info(expr.right)
        if s is None:
            # Non-finite, or an entry at/near zero: the quotient is undefined or
            # numerically meaningless there. Refuse outright rather than fall
            # through to the reciprocal rule below, whose strict-sign test reads
            # a zero divisor as strictly signed.
            return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)
        if s != 0:
            inv_sign = Sign.POS if s > 0 else Sign.NEG
            return ExprInfo(scale(left.curvature, s), sign_mul(left.sign, inv_sign))
        # Mixed-sign (but everywhere-nonzero) divisor: an affine numerator still
        # divides entrywise to affine; anything else loses its curvature.
        if left.curvature == Curvature.AFFINE:
            return ExprInfo(Curvature.AFFINE, Sign.UNKNOWN)
        return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)

    # Reciprocal with constant numerator and strictly-signed denominator.
    # 1/u is convex + nonincreasing on u>0; concave + nonincreasing on
    # u<0. The DCP composition rule combines this profile with the
    # inner expression's curvature — bypassing it (i.e., trusting the
    # sign alone) would be UNSOUND: e.g., 1/(1 + exp(-x)) has positive
    # denominator but convex inner, so the composite is neither convex
    # nor concave.
    right_sign = right.sign
    if _is_scalar_const(expr.left) and not is_strict(right_sign):
        right_sign = _refine_sign(expr.right, model, cache, right_sign)
    if _is_scalar_const(expr.left) and is_strict(right_sign):
        c = _scalar_value(expr.left)
        recip_curv = Curvature.CONVEX if is_pos(right_sign) else Curvature.CONCAVE
        recip_mono = Monotonicity.NONINC
        composed = compose(recip_curv, recip_mono, right.curvature)
        recip_sign = sign_reciprocal(right_sign)
        if c == 0:
            return ExprInfo(Curvature.AFFINE, Sign.ZERO)
        c_sign = 1 if c > 0 else -1
        return ExprInfo(
            scale(composed, c_sign),
            sign_mul(sign_from_value(c), recip_sign),
        )

    # Collinear linear-fractional quotient (#1611 D-31): an affine numerator that
    # is an exact multiple of the denominator's variable part, ``num = alpha*den
    # + beta``, makes the quotient ``alpha + beta/den`` -- the reciprocal rule
    # above with a constant shift. ``c*F/(F + a)`` (a saturating rate) is the
    # common spelling. A general ratio of two affine forms is only quasi-linear,
    # so the variable parts must agree EXACTLY; any other quotient falls through.
    if (
        model is not None
        and left.curvature == Curvature.AFFINE
        and right.curvature == Curvature.AFFINE
    ):
        lf = _collinear_linear_fractional(expr, model, cache, right.sign)
        if lf is not None:
            return lf

    # Quadratic-over-affine with positive denominator (quad-over-linear).
    if model is not None:
        from .patterns import classify_division_pattern

        special = classify_division_pattern(expr, model, classify_expr, cache)
        if special is not None:
            return ExprInfo(special, Sign.NONNEG)

    # General quotient — no sound curvature verdict.
    return ExprInfo(Curvature.UNKNOWN, sign_mul(left.sign, sign_reciprocal(right.sign)))


def _collinear_linear_fractional(
    expr: BinaryOp, model: Model, cache: dict, den_sign: Sign
) -> Optional[ExprInfo]:
    """Curvature of ``num/den`` when ``num = alpha*den + beta`` exactly (#1611 D-31).

    Then ``num/den = alpha + beta/den`` on a strictly signed ``den``: with
    ``den > 0`` the term ``beta/den`` is convex for ``beta > 0`` and concave for
    ``beta < 0`` (``1/u`` is convex and nonincreasing on ``u > 0``); with
    ``den < 0`` the verdicts swap. ``beta == 0`` gives the constant ``alpha``.
    Returns ``None`` -- no claim -- unless both sides are scalar affine forms,
    the denominator's sign is PROVEN strict, and the numerator's coefficient
    vector equals ``alpha`` times the denominator's bit for bit.
    """
    n_vars = sum(v.size for v in model._variables)
    num = extract_affine(expr.left, model, n_vars)
    den = extract_affine(expr.right, model, n_vars)
    if num is None or den is None:
        return None
    num_c, num_k = num
    den_c, den_k = den
    if not (np.all(np.isfinite(num_c)) and np.all(np.isfinite(den_c))):
        return None
    if not (np.isfinite(num_k) and np.isfinite(den_k)):
        return None
    support = np.flatnonzero(den_c)
    if support.size == 0:
        return None  # constant denominator: the scaling rule's case, not this one
    pivot = int(support[np.argmax(np.abs(den_c[support]))])
    alpha = float(num_c[pivot] / den_c[pivot])
    if not np.array_equal(num_c, alpha * den_c):
        return None
    beta = float(num_k - alpha * den_k)
    if not np.isfinite(beta):
        return None
    sign = den_sign if is_strict(den_sign) else _refine_sign(expr.right, model, cache, den_sign)
    if not is_strict(sign):
        return None
    if beta == 0.0:
        return ExprInfo(Curvature.AFFINE, Sign.UNKNOWN)
    convex = (beta > 0.0) == is_pos(sign)
    return ExprInfo(Curvature.CONVEX if convex else Curvature.CONCAVE, Sign.UNKNOWN)


def _classify_power(
    expr: BinaryOp,
    base: ExprInfo,
    model: Optional[Model],
    cache: dict,
) -> ExprInfo:
    """Classify ``base ** exponent`` for a scalar constant ``exponent``.

    Case analysis follows Boyd & Vandenberghe §3.1.5.
    """
    if not _is_scalar_const(expr.right):
        return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)

    n = _scalar_value(expr.right)
    n_int = int(n)
    # Exact comparisons only (#2191): ``x**(1 - 1e-7)`` is strictly concave, not
    # the affine ``x``; a near-integer exponent takes the fractional rules.
    is_int = n == float(n_int)

    # Tighten base sign when it's needed for a conclusive verdict:
    # fractional exponents and negative exponents both require the
    # base to lie in a known half-line.
    if not is_strict(base.sign) and (
        (is_int and n_int < 0) or (not is_int and (n < 0 or 0 < n < 1 or n > 1))
    ):
        base = ExprInfo(base.curvature, _refine_sign(expr.left, model, cache, base.sign))

    # Trivial exponents.
    if n == 0.0:
        return ExprInfo(Curvature.AFFINE, Sign.POS)  # x^0 = 1
    if n == 1.0:
        return base

    # ``base ** 0.5`` IS ``sqrt(base)`` (#1616 B-20b): give the power spelling the
    # same structural recognisers as the atom -- ``(x**2 + y**2)**0.5`` is the
    # Euclidean norm, CONVEX, which the generic fractional-power rule below (an
    # affine base only) cannot see. Exact ``== 0.5`` only: a nearby exponent is a
    # different function and gets no borrowed verdict.
    if n == 0.5 and model is not None:
        from .patterns import classify_sqrt_pattern

        special = classify_sqrt_pattern(expr.left, model, classify_expr, cache)
        if special == Curvature.CONVEX:
            return ExprInfo(Curvature.CONVEX, Sign.NONNEG)
        if special == Curvature.CONCAVE:
            return ExprInfo(Curvature.CONCAVE, Sign.POS if is_pos(base.sign) else Sign.NONNEG)

    # Even integer power >= 2: convex on all of R for an affine base; sign NONNEG.
    # DCP composition for a non-affine base (#1868): t**n is convex and
    # nondecreasing on t >= 0 and convex and nonincreasing on t <= 0, so a convex
    # NONNEG base or a concave NONPOS base stays convex -- ``(exp(x) + exp(y))**2``.
    # The sign must be proven (lattice sign), never assumed: ``(2**x - 3)**2`` has an
    # inner of unknown sign and stays UNKNOWN (it is nonconvex where 2**x < 1.5).
    if is_int and n_int >= 2 and n_int % 2 == 0:
        if base.curvature == Curvature.AFFINE:
            return ExprInfo(Curvature.CONVEX, Sign.NONNEG)
        if not power_composition_enabled():
            return ExprInfo(Curvature.UNKNOWN, Sign.NONNEG)
        if is_nonneg(base.sign):
            curv = compose(Curvature.CONVEX, Monotonicity.NONDEC, base.curvature)
        elif is_nonpos(base.sign):
            curv = compose(Curvature.CONVEX, Monotonicity.NONINC, base.curvature)
        else:
            curv = Curvature.UNKNOWN
        return ExprInfo(
            Curvature.CONVEX if curv == Curvature.CONVEX else Curvature.UNKNOWN, Sign.NONNEG
        )

    # Odd integer power >=3: sign-dependent curvature, sign inherits base. On t >= 0
    # it is convex nondecreasing, on t <= 0 concave nondecreasing, so the same DCP
    # composition extends both verdicts to a convex/concave base of proven sign.
    if is_int and n_int >= 3 and n_int % 2 == 1:
        out_sign = base.sign  # odd power preserves sign
        if not power_composition_enabled():
            # Pre-#1868: the affine-base verdicts only.
            if base.curvature == Curvature.AFFINE:
                if is_nonneg(base.sign):
                    return ExprInfo(Curvature.CONVEX, out_sign)
                if is_nonpos(base.sign):
                    return ExprInfo(Curvature.CONCAVE, out_sign)
            return ExprInfo(Curvature.UNKNOWN, out_sign)
        if is_nonneg(base.sign):
            if compose(Curvature.CONVEX, Monotonicity.NONDEC, base.curvature) == Curvature.CONVEX:
                return ExprInfo(Curvature.CONVEX, out_sign)
        elif is_nonpos(base.sign):
            if compose(Curvature.CONCAVE, Monotonicity.NONDEC, base.curvature) == Curvature.CONCAVE:
                return ExprInfo(Curvature.CONCAVE, out_sign)
        return ExprInfo(Curvature.UNKNOWN, out_sign)

    # Negative integer exponent — x^(-k) for k a positive integer on a
    # strictly-signed domain. Convex on x>0 for any negative exponent;
    # on x<0 the verdict depends on parity of k.
    if is_int and n_int < 0:
        k = -n_int
        if is_pos(base.sign) and base.curvature == Curvature.AFFINE:
            # x^(-k) = 1/x^k: convex on (0, inf).
            return ExprInfo(Curvature.CONVEX, Sign.POS)
        if base.sign == Sign.NEG and base.curvature == Curvature.AFFINE:
            # Keep only the direct reciprocal verdict here. Higher odd negative
            # powers on negative domains are left to the certificate path so the
            # syntactic classifier does not over-certify sign-sensitive powers.
            if k == 1:
                return ExprInfo(Curvature.CONCAVE, Sign.NEG)
            if k % 2 == 0:
                return ExprInfo(Curvature.CONVEX, Sign.POS)
            return ExprInfo(Curvature.UNKNOWN, Sign.NEG)
        return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)

    # Fractional 0 < n < 1 on nonneg domain: concave; result ≥ 0.
    # DCP composition (#1616): t**n is nondecreasing on t >= 0, so a concave
    # nonneg base stays concave, the same rule ``sqrt`` already applies.
    if 0 < n < 1:
        if is_nonneg(base.sign):
            curv = compose(Curvature.CONCAVE, Monotonicity.NONDEC, base.curvature)
            if curv == Curvature.CONCAVE:
                return ExprInfo(Curvature.CONCAVE, Sign.NONNEG)
        return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)

    # n > 1, non-integer, on nonneg domain: convex; result ≥ 0. t**n is convex
    # and nondecreasing on t >= 0, so a convex nonneg base stays convex (DCP).
    if n > 1:
        if is_nonneg(base.sign):
            curv = compose(Curvature.CONVEX, Monotonicity.NONDEC, base.curvature)
            if curv == Curvature.CONVEX:
                return ExprInfo(Curvature.CONVEX, Sign.NONNEG)
        return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)

    # n < 0 non-integer on strictly positive domain: convex.
    if n < 0 and is_pos(base.sign) and base.curvature == Curvature.AFFINE:
        return ExprInfo(Curvature.CONVEX, Sign.POS)

    return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)


# ──────────────────────────────────────────────────────────────────────
# Function calls
# ──────────────────────────────────────────────────────────────────────


def _classify_function_call(expr: FunctionCall, model: Optional[Model], cache: dict) -> ExprInfo:
    name = expr.func_name

    # n-ary atoms: max / min / sum_of_squares / norm2.
    if name == "max" and len(expr.args) >= 2:
        return _classify_nary_max(expr, model, cache)
    if name == "min" and len(expr.args) >= 2:
        return _classify_nary_min(expr, model, cache)
    if name == "centropy" and len(expr.args) == 2:
        return _classify_centropy(expr, model, cache)

    # Any p-norm ‖·‖_p is convex and nonnegative. The DCP composition rule
    # (convex, nondecreasing-in-each-|arg|) is only sound when the inner
    # expression is *affine*: ‖affine‖_p is convex, but ‖nonconvex‖_p need not
    # be. So classify the (vector) argument and license CONVEX only on an affine
    # argument; otherwise abstain (UNKNOWN), preserving soundness.
    if name.startswith("norm") and len(expr.args) == 1:
        arg_info = classify_expr_info(expr.args[0], model, cache)
        if arg_info.curvature == Curvature.AFFINE:
            return ExprInfo(Curvature.CONVEX, Sign.NONNEG)
        return ExprInfo(Curvature.UNKNOWN, Sign.NONNEG)

    if len(expr.args) != 1:
        return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)

    arg_info = classify_expr_info(expr.args[0], model, cache)
    arg_sign = arg_info.sign
    # Restricted-domain atoms need a strict sign proof on the argument
    # to license the DCP rule. Tighten via the linear relaxation when
    # the syntactic sign alone is too weak.
    # Restricted-domain atoms (log/sqrt + the monotone inverse group, #136)
    # plus the inflect-at-origin atoms whose curvature is sign-split: refining
    # the argument sign via the linear relaxation lets a one-sided box classify.
    _sign_refined_atoms = (
        "log",
        "log2",
        "log10",
        "sqrt",
        "asin",
        "acos",
        "acosh",
        "atanh",
        "log1p",
        "atan",
        "asinh",
        "erf",
        # entropy needs `arg >= 0` to license its CONVEX profile, and the
        # arguments that matter (a site fraction's complement `1 - y`, a
        # normalized fraction) are nonnegative only by the box, never
        # syntactically (#1242).
        "entropy",
    )
    if name in _sign_refined_atoms and not is_strict(arg_sign):
        arg_sign = _refine_sign(expr.args[0], model, cache, arg_sign)
    profile: Optional[AtomProfile] = unary_atom_profile(name, arg_sign)

    # sqrt(x'Qx) with Q PSD is a norm — convex even though the inner
    # quadratic is convex (concave∘convex would fail DCP composition).
    # sqrt(prod base_i^{p_i}) over affine nonneg bases is a weighted
    # geometric mean — concave (geo-mean concavity, e.g. sqrt(x_i x_j)).
    if name == "sqrt" and model is not None:
        from .patterns import classify_sqrt_pattern

        special = classify_sqrt_pattern(expr.args[0], model, classify_expr, cache)
        if special == Curvature.CONVEX:
            return ExprInfo(Curvature.CONVEX, Sign.NONNEG)
        if special == Curvature.CONCAVE:
            # Preserve the sqrt result sign (strict POS on a strictly-positive
            # argument) so an enclosing reciprocal / log composition still
            # applies; falling back to NONNEG would drop that strictness.
            return ExprInfo(Curvature.CONCAVE, _function_result_sign(name, arg_sign))

    if profile is None:
        return ExprInfo(Curvature.UNKNOWN, _function_result_sign(name, arg_sign))

    curv = compose(profile.curvature, profile.monotonicity, arg_info.curvature)
    return ExprInfo(curv, _function_result_sign(name, arg_sign))


def _function_result_sign(name: str, arg_sign: Sign) -> Sign:
    """Best sign for the result of an atom given its argument's sign."""
    if name == "exp":
        return Sign.POS
    if name in ("log", "log2", "log10"):
        # log(x) ≤ 0 iff x ≤ 1, ≥ 0 iff x ≥ 1 — no sign from arg_sign
        # alone without bound comparison to 1; stay UNKNOWN.
        return Sign.UNKNOWN
    if name == "sqrt":
        if is_pos(arg_sign):
            return Sign.POS
        if is_nonneg(arg_sign):
            return Sign.NONNEG
        return Sign.UNKNOWN
    if name == "abs":
        return Sign.NONNEG
    if name == "cosh":
        return Sign.POS
    if name == "sinh":
        return arg_sign
    if name == "tanh":
        return arg_sign
    # Monotone inverse atoms through the origin preserve the argument sign
    # (each is increasing with f(0) = 0): atan, asin, asinh, atanh, erf, log1p.
    if name in ("atan", "asin", "asinh", "atanh", "erf", "log1p"):
        return arg_sign
    # acos / acosh map into a nonnegative range on their domains.
    if name in ("acos", "acosh"):
        return Sign.NONNEG
    return Sign.UNKNOWN


def _classify_nary_max(expr: FunctionCall, model: Optional[Model], cache: dict) -> ExprInfo:
    """``max(a_1, ..., a_n)`` is convex when every argument is convex."""
    curv: Curvature = Curvature.AFFINE
    s = Sign.UNKNOWN
    for i, a in enumerate(expr.args):
        info = classify_expr_info(a, model, cache)
        # For max, convex / affine arguments compose to convex; any
        # concave or unknown argument kills the verdict.
        if info.curvature == Curvature.CONCAVE or info.curvature == Curvature.UNKNOWN:
            curv = Curvature.UNKNOWN
        elif curv != Curvature.UNKNOWN:
            if info.curvature == Curvature.CONVEX:
                curv = Curvature.CONVEX
            elif info.curvature == Curvature.AFFINE and curv == Curvature.AFFINE:
                curv = Curvature.AFFINE
        s = info.sign if i == 0 else _sign_join(s, info.sign)
    if curv == Curvature.AFFINE and len(expr.args) >= 2:
        # #1489: the pointwise max of >= 2 affine functions is CONVEX, not
        # affine (``max(x, -x) = |x|``). Keeping AFFINE let ``max(L) >= c`` and
        # ``max(L) == c`` pass as convex rows. (Identical arguments would make
        # it affine; we do not attempt that refinement — CONVEX is sound.)
        curv = Curvature.CONVEX
    return ExprInfo(curv, s)


def _classify_nary_min(expr: FunctionCall, model: Optional[Model], cache: dict) -> ExprInfo:
    """``min(a_1, ..., a_n)`` is concave when every argument is concave."""
    curv: Curvature = Curvature.AFFINE
    s = Sign.UNKNOWN
    for i, a in enumerate(expr.args):
        info = classify_expr_info(a, model, cache)
        if info.curvature == Curvature.CONVEX or info.curvature == Curvature.UNKNOWN:
            curv = Curvature.UNKNOWN
        elif curv != Curvature.UNKNOWN:
            if info.curvature == Curvature.CONCAVE:
                curv = Curvature.CONCAVE
            elif info.curvature == Curvature.AFFINE and curv == Curvature.AFFINE:
                curv = Curvature.AFFINE
        s = info.sign if i == 0 else _sign_join(s, info.sign)
    if curv == Curvature.AFFINE and len(expr.args) >= 2:
        # #1489: the pointwise min of >= 2 affine functions is CONCAVE, not
        # affine (``min(x, -x) = -|x|``); see ``_classify_nary_max``.
        curv = Curvature.CONCAVE
    return ExprInfo(curv, s)


def _classify_centropy(expr: FunctionCall, model: Optional[Model], cache: dict) -> ExprInfo:
    """``centropy(x, y) = x*log(x/y)`` (relative entropy) is JOINTLY CONVEX on
    ``x >= 0, y > 0`` (Boyd & Vandenberghe §3.2.6 — the relative entropy; its
    Hessian ``[[1/x, -1/y], [-1/y, x/y²]]`` is PSD there). The DCP composition
    rule licenses CONVEX only when both arguments are *affine* (a jointly-convex
    atom composed with affine maps is convex; a nonconvex inner argument is not
    sound), and only when the domain ``x >= 0, y > 0`` is provable over the box.
    Otherwise abstain (UNKNOWN), preserving soundness. This is what makes a
    Gibbs/KL objective ``Σ nᵢ·log(nᵢ / Σnⱼ)`` — affine numerator, affine
    denominator — certify on the convex fast path (issue #207)."""
    x_info = classify_expr_info(expr.args[0], model, cache)
    y_info = classify_expr_info(expr.args[1], model, cache)
    if x_info.curvature != Curvature.AFFINE or y_info.curvature != Curvature.AFFINE:
        return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)
    x_sign = _refine_sign(expr.args[0], model, cache, x_info.sign)
    y_sign = _refine_sign(expr.args[1], model, cache, y_info.sign)
    if is_nonneg(x_sign) and is_pos(y_sign):
        return ExprInfo(Curvature.CONVEX, Sign.UNKNOWN)
    return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)


def _sign_join(a: Sign, b: Sign) -> Sign:
    """Least-upper-bound in the sign lattice (loses information)."""
    if a == b:
        return a
    if is_nonneg(a) and is_nonneg(b):
        return Sign.NONNEG
    if is_nonpos(a) and is_nonpos(b):
        return Sign.NONPOS
    return Sign.UNKNOWN


# ──────────────────────────────────────────────────────────────────────
# Matrix multiplication
# ──────────────────────────────────────────────────────────────────────


def _const_weighted_curvature(weights: np.ndarray, curv: Curvature) -> Curvature:
    """Curvature of a constant-weighted combination of ``curv`` expressions.

    Each output of ``A @ f`` (or ``f @ A``) is ``sum_j a_j f_j``. That keeps
    ``f``'s curvature when every weight is ``>= 0``, flips it when every weight is
    ``<= 0``, and is UNKNOWN for mixed signs unless ``f`` is affine -- an affine
    combination of affine terms is affine whatever the weights.
    """
    if curv == Curvature.AFFINE:
        return Curvature.AFFINE
    if not np.all(np.isfinite(weights)):
        return Curvature.UNKNOWN
    if np.all(weights >= 0.0):
        return curv
    if np.all(weights <= 0.0):
        return negate(curv)
    return Curvature.UNKNOWN


def _quadratic_form_info(
    expr: MatMulExpression, model: Optional[Model], cache: dict
) -> Optional[ExprInfo]:
    """``u @ Q @ u`` for one affine vector ``u`` and a constant square ``Q`` (#1728).

    ``u' Q u = u' S u`` with ``S = (Q + Q')/2``, convex when ``S`` is PSD and
    concave when it is NSD. Both parse orders are recognised:
    ``(u @ Q) @ u`` and ``u @ (Q @ u)``. Semidefiniteness is decided by
    :func:`~.eigenvalue.psd_proved`, which proves or refuses -- never guesses.
    ``None`` when the pattern does not apply.
    """
    if isinstance(expr.left, MatMulExpression):
        u, q_expr, v = expr.left.left, expr.left.right, expr.right
    elif isinstance(expr.right, MatMulExpression):
        u, q_expr, v = expr.left, expr.right.left, expr.right.right
    else:
        return None
    if u is not v:
        return None
    Q = _const_leaf_value(q_expr)
    if Q is None or Q.ndim != 2 or Q.shape[0] != Q.shape[1] or Q.shape[0] == 0:
        return None
    if Q.shape[0] > _QUADFORM_EIG_MAX_N or not np.all(np.isfinite(Q)):
        return None
    shape = getattr(u, "shape", None)
    if shape is None or tuple(shape) != (Q.shape[0],):
        return None
    if classify_expr_info(u, model, cache).curvature != Curvature.AFFINE:
        return None
    from .eigenvalue import psd_proved

    S = 0.5 * (Q + Q.T)
    if psd_proved(S):
        return ExprInfo(Curvature.CONVEX, Sign.NONNEG)
    if psd_proved(-S):
        return ExprInfo(Curvature.CONCAVE, Sign.NONPOS)
    return None


#: Largest ``Q`` the quadratic-form rule runs a dense eigenvalue test on.
_QUADFORM_EIG_MAX_N = 4000


def _classify_matmul(expr: MatMulExpression, model: Optional[Model], cache: dict) -> ExprInfo:
    quad = _quadratic_form_info(expr, model, cache)
    if quad is not None:
        return quad
    left = classify_expr_info(expr.left, model, cache)
    right = classify_expr_info(expr.right, model, cache)
    # A constant operand is a weight matrix on the other operand's entries. The
    # curvature survives only for same-signed weights: this used to return the
    # other side's curvature unconditionally, so ``[-1, -1] @ (x**2)`` (concave)
    # was classified CONVEX -- a false convexity proof, which routes a nonconvex
    # model to the convex fast path (#1728 review).
    lval = _const_leaf_value(expr.left)
    if lval is not None:
        return ExprInfo(_const_weighted_curvature(lval, right.curvature), Sign.UNKNOWN)
    rval = _const_leaf_value(expr.right)
    if rval is not None:
        return ExprInfo(_const_weighted_curvature(rval, left.curvature), Sign.UNKNOWN)
    return ExprInfo(Curvature.UNKNOWN, Sign.UNKNOWN)


# ──────────────────────────────────────────────────────────────────────
# Constraint- and model-level classification
# ──────────────────────────────────────────────────────────────────────


def classify_constraint(
    constraint: Constraint,
    model: Optional[Model] = None,
    _cache: Optional[dict] = None,
    *,
    use_certificate: bool = False,
) -> bool:
    """Return True when ``constraint`` defines a convex feasible set.

    When ``use_certificate`` is set and the syntactic walker fails to
    prove convexity, :func:`~.certificate.certify_convex` is consulted
    as a sound numerical fallback on the root variable box. The
    certificate never contradicts a syntactic CONVEX/CONCAVE verdict —
    it only tightens UNKNOWN cases.
    """
    if _cache is None:
        _cache = {}

    curv = classify_expr(constraint.body, model, _cache)

    syntactic = _constraint_convex_from_curvature(curv, constraint.sense)
    if syntactic:
        return True
    if model is None:
        return False

    # Structural fallback: recognise quadratic-over-affine epigraphs
    # (the MINLPTests ``nlp_cvx_108_*`` family) directly at the
    # constraint level — their convexity is provable from a
    # rearrangement that the expression-level walker cannot see.
    # #1520: no except. The recognizer declines by returning ``None``/``False``
    # (its one extraction step absorbs only ``_NotLinearError``), so an exception
    # is a defect, not an abstention.
    from .patterns import classify_fractional_epigraph_constraint

    frac = classify_fractional_epigraph_constraint(constraint, model)
    if frac is True:
        return True

    if not use_certificate:
        return syntactic

    # Fall back to the sound numerical certificate.
    # #1520: no except. ``certify_convex`` abstains by returning ``None``.
    from .certificate import certify_convex

    cert = certify_convex(constraint.body, model)
    if cert is None:
        return syntactic
    return _constraint_convex_from_curvature(cert, constraint.sense)


def _constraint_convex_from_curvature(curv: Curvature, sense: str) -> bool:
    """Decide constraint convexity given a body curvature and sense."""
    if sense == "<=":
        return curv in (Curvature.CONVEX, Curvature.AFFINE)
    if sense == ">=":
        return curv in (Curvature.CONCAVE, Curvature.AFFINE)
    if sense == "==":
        return curv == Curvature.AFFINE
    return False


class ConvexityBudgetExceeded(Exception):
    """Raised when convexity classification exceeds its wall-clock ``deadline``.

    The classifier is per-constraint eigenvalue-heavy and on large quadratic
    models can take tens of seconds; under a tight solver ``time_limit`` that
    would blow the budget before search even starts. Callers catch this and treat
    the model as convexity-unknown (sound: it routes to the spatial B&B).
    """


# The syntactic curvature walker (``classify_expr_info`` -> ``_classify_impl`` ->
# children) recurses one Python frame per expression node. ``from_nl`` rebuilds a
# sum/product of N terms as a left-deep binary tree of depth ~N, so a large model
# (e.g. pooling problems with thousands of bilinear terms) can exceed CPython's
# default 1000-frame recursion limit and raise ``RecursionError`` mid-classify.
# That is caught upstream and demotes the model to convexity-unknown, which on a
# pure-continuous model routes to a best-effort local NLP that can return
# ``status="error"`` — a silently degraded solve (issue #266). To classify these
# correctly we raise the recursion limit in proportion to model size, but a high
# Python limit can overflow the C stack and hard-crash the process, so the walk
# runs on a worker thread with a large stack. This is gated on model size: the
# common (shallow) case keeps running inline with the default limit.
_DEEP_RECURSION_SIZE_GATE = 700
_DEEP_RECURSION_LIMIT_CAP = 200_000
# 512 MiB: large enough for the deepest MINLPLib expression graphs that drive the
# headroom path (issue #271's whole-solve walk can need a recursion limit of a few
# hundred thousand frames; 256 MiB grazed the C-stack ceiling at that depth).
_DEEP_RECURSION_STACK_BYTES = 512 * 1024 * 1024


def _recursion_headroom_need(model: Model) -> int:
    """Estimate the recursion-limit headroom a model's classification may need.

    Returns 0 when the model is small enough that the default limit is safe.
    The estimate is a deliberate over-approximation (depth is bounded by node
    count); it only affects whether the deep-stack path engages, never the
    classification result.
    """
    size = len(getattr(model, "_constraints", []) or [])
    # #1520: no except. ``Variable.lb`` is always an ndarray, so ``np.size`` cannot
    # fail; the old handler could only hide a defect (and under-counting here turns
    # it into an unexplained RecursionError later).
    size += sum(int(np.size(v.lb)) for v in model._variables)
    if size <= _DEEP_RECURSION_SIZE_GATE:
        return 0
    return min(2000 + 60 * size, _DEEP_RECURSION_LIMIT_CAP)


def _run_with_deep_recursion(fn: Callable[[], _T], *, depth_need: int) -> _T:
    """Run ``fn`` with an enlarged recursion limit + C stack when ``fn`` may recurse
    deeper than the default limit allows.

    When ``depth_need`` does not exceed the current limit, ``fn`` runs inline (no
    thread overhead). Otherwise it runs on a worker thread with a large stack so a
    raised Python recursion limit cannot overflow the C stack and crash the
    process. The recursion limit is restored afterward; exceptions propagate.
    """
    import contextvars
    import threading

    current = sys.getrecursionlimit()
    if depth_need <= current:
        return fn()

    box: dict[str, object] = {}
    # A new thread starts with an EMPTY contextvars context, so anything published
    # for the call — notably the active ``SolverTuning`` (issue #1117) — would be
    # invisible to ``fn`` on the worker and the deep-model path would silently run
    # on env defaults while the shallow path honored the caller. Run ``fn`` inside
    # a copy of this thread's context instead; the copy is discarded on return, so
    # writes made by ``fn`` still cannot leak back here.
    caller_ctx = contextvars.copy_context()

    def _worker() -> None:
        old = sys.getrecursionlimit()
        sys.setrecursionlimit(depth_need)
        try:
            box["value"] = caller_ctx.run(fn)
        except BaseException as exc:  # noqa: BLE001 - re-raised on the caller thread
            box["error"] = exc
        finally:
            sys.setrecursionlimit(old)

    old_stack = threading.stack_size()
    try:
        threading.stack_size(_DEEP_RECURSION_STACK_BYTES)
    except (ValueError, RuntimeError, OverflowError):
        # Platform rejected the requested stack size: fall back to inline with a
        # raised limit. Best effort — may still RecursionError, which is caught
        # upstream and is no worse than before.
        old = sys.getrecursionlimit()
        sys.setrecursionlimit(depth_need)
        try:
            return fn()
        finally:
            sys.setrecursionlimit(old)
    try:
        t = threading.Thread(target=_worker, name="convexity-classify")
        t.start()
        t.join()
    finally:
        try:
            threading.stack_size(old_stack)
        except (ValueError, RuntimeError, OverflowError):
            pass
    if "error" in box:
        raise cast(BaseException, box["error"])
    return cast(_T, box["value"])


def classify_model(
    model: Model, *, use_certificate: bool = False, deadline: float | None = None
) -> tuple[bool, list[bool]]:
    """Classify a model's convexity.

    Returns ``(is_convex, per_constraint_mask)``. ``max f`` is treated
    as ``min -f``, so a maximization objective is "convex" (in the
    global sense — the overall problem is convex) when its body is
    concave or affine.

    When ``use_certificate`` is set, the sound interval-Hessian
    certificate (:func:`~.certificate.certify_convex`) is consulted
    whenever the syntactic walker leaves a constraint or the objective
    unproven. The certificate only tightens UNKNOWN verdicts; it never
    overrides an already-proven CONVEX/CONCAVE, preserving the
    soundness invariant.

    ``deadline`` is an optional ``time.perf_counter()`` timestamp; if the
    per-constraint walk crosses it, :class:`ConvexityBudgetExceeded` is raised so
    the solver can fall back to the spatial path rather than overrun its
    ``time_limit``.

    On large models the syntactic walk can recurse past CPython's default
    recursion limit; the walk runs with size-scaled recursion headroom (see
    :func:`_run_with_deep_recursion`) so deep expression graphs classify instead
    of demoting to convexity-unknown (issue #266).
    """
    obj_convex, mask = classify_model_parts(
        model, use_certificate=use_certificate, deadline=deadline
    )
    return obj_convex and all(mask), mask


def classify_model_parts(
    model: Model, *, use_certificate: bool = False, deadline: float | None = None
) -> tuple[bool, list[bool]]:
    """:func:`classify_model`, returning ``(objective_convex, constraint_mask)``.

    The one walk behind :func:`classify_model`, kept separate so a caller that
    reports *which* part failed (``Model.convexity()``, #1616 A-01) reads the same
    verdicts the solver dispatches on instead of re-deriving them.
    """
    return _run_with_deep_recursion(
        lambda: _classify_model_inner(model, use_certificate=use_certificate, deadline=deadline),
        depth_need=_recursion_headroom_need(model),
    )


def _objective_is_convex(
    model: Model,
    cache: dict,
    *,
    use_certificate: bool,
    exact_qp: bool,
    deadline: float | None = None,
) -> bool:
    """Whether the objective is convex in the optimization sense.

    ``max f`` counts as convex when ``f`` is concave or affine. The single
    definition behind both :func:`classify_model` and
    :func:`classify_oa_cut_convexity`: they used to carry separate copies, the
    #936 exact-QP route was added to only one of them, and a model the solver
    dispatch proved convex then reached OA with its objective cuts disabled
    (#1352).

    Args:
        use_certificate: Consult the sound interval-Hessian certificate when
            the syntactic walker leaves the objective unproven.
        exact_qp: Also consult the exact QP/MIQP objective-Hessian route.
        deadline: Forwarded to the exact-QP route, which abstains past it.
    """
    if model._objective is None:
        return True

    from discopt.modeling.core import ObjectiveSense

    obj_curv = classify_expr(model._objective.expression, model, cache)
    if model._objective.sense == ObjectiveSense.MINIMIZE:
        obj_convex = obj_curv in (Curvature.CONVEX, Curvature.AFFINE)
        need_curv_for_obj = Curvature.CONVEX
    else:
        obj_convex = obj_curv in (Curvature.CONCAVE, Curvature.AFFINE)
        need_curv_for_obj = Curvature.CONCAVE

    if not obj_convex and use_certificate:
        # #1520: no except. ``certify_convex`` abstains by returning ``None``.
        from .certificate import certify_convex

        cert = certify_convex(model._objective.expression, model)
        if cert == need_curv_for_obj:
            obj_convex = True

    if not obj_convex and exact_qp:
        # Exact QP/MIQP objective-Hessian route (#936). The syntactic walker
        # and the scalar interval-Hessian certificate above both work on
        # *scalar* expression DAGs; neither can parse the vectorized /
        # indexed-summation modeling API, so a convex QP written with
        # ``dm.sum(...)`` over array variables was certified convex by no
        # route at all and fell through to spatial McCormick B&B, where it
        # does not converge. When the problem classifier proves the model is
        # a QP/MIQP — an exactly-quadratic objective over a polyhedron — the
        # objective's Hessian is a constant matrix and an exact eigenvalue
        # test on it is a rigorous, box-independent global convexity proof.
        # Consulted last: it only ever upgrades an objective the cheaper
        # routes left unproven, so it can never loosen a verdict.
        from .certificate import certify_quadratic_objective_convex

        if certify_quadratic_objective_convex(model, deadline=deadline):
            obj_convex = True

    return obj_convex


def _classify_model_inner(
    model: Model, *, use_certificate: bool = False, deadline: float | None = None
) -> tuple[bool, list[bool]]:
    import time as _time

    cache: dict = {}
    ctx = build_linear_context(model)
    if ctx is not None:
        cache[_LINEAR_CONTEXT_KEY] = ctx
    if deadline is not None:
        # Stash the deadline + a shared visit counter so classify_expr_info can
        # abort mid-walk (not only between constraints, which is too coarse when
        # a single expression is pathological).
        cache[_DEADLINE_KEY] = deadline
        cache[_VISIT_COUNT_KEY] = [0]

    obj_convex = _objective_is_convex(
        model, cache, use_certificate=use_certificate, exact_qp=use_certificate, deadline=deadline
    )

    constraint_mask: list[bool] = []
    for c in model._constraints:
        if deadline is not None and _time.perf_counter() > deadline:
            raise ConvexityBudgetExceeded(
                f"convexity classification exceeded its time budget after "
                f"{len(constraint_mask)}/{len(model._constraints)} constraints"
            )
        if isinstance(c, Constraint):
            constraint_mask.append(
                classify_constraint(c, model, cache, use_certificate=use_certificate)
            )
        else:
            constraint_mask.append(False)

    return obj_convex, constraint_mask


@dataclass(frozen=True)
class OACutConvexity:
    """Convexity information relevant to globally valid OA cuts."""

    objective_is_convex: bool
    constraint_mask: list[bool]
    #: Rows left unclassified because ``deadline`` passed (counted not convex).
    truncated: int = 0
    #: Rows proved convex only by the box-subdivision certificate (#2054).
    subdivided: int = 0


def classify_oa_cut_convexity(
    model: Model,
    *,
    use_certificate: Optional[bool] = None,
    deadline: Optional[float] = None,
) -> OACutConvexity:
    """Return the convexity information needed to generate sound OA cuts.

    Unlike :func:`classify_model`, the per-constraint mask is retained
    even when the objective is non-convex, so evaluator-based OA cuts
    can still be generated on the convex constraints of a model whose
    objective prevents full convex classification.

    ``use_certificate=None`` (what the OA-family callers pass) follows
    ``DISCOPT_OA_CONVEXITY_CERTIFICATE`` (default ON); an explicit bool is
    honoured as given. With the flag on, the certificate path is the one
    :func:`classify_model` runs for solver dispatch -- interval-Hessian
    certificate plus the #936 exact-QP objective route -- so OA no longer
    disables its objective cuts on a model the dispatch routed to it *because*
    that certificate proved it convex (#1352). With the flag opted out (``=0``) the verdict
    is exactly the pre-#1352 one, including for an explicit ``True``.

    ``deadline`` (a ``time.perf_counter()`` instant, #1775 G4.1): once it passes,
    each remaining row counts as not convex -- it gets no OA cut, which only
    weakens the caller's master and never cuts a feasible point -- and
    ``truncated`` says how many. Measured on kaibel (GDPlib): the full pass took
    over 100 s, all of it before LOA's first master solve. ``None`` classifies
    every row, as before.

    With ``DISCOPT_OA_CONVEXITY_SUBDIVISION`` (default ON since #2054) a row the
    whole-box certificate abstains on is retried by
    :func:`~.certificate.certify_convex_subdivided`, which certifies the
    interval Hessian on every piece of an adaptive cover of the box; ``subdivided``
    counts the rows proved that way (including those the Taylor-form pre-test of
    ``DISCOPT_OA_CONVEXITY_TAYLOR``, default ON since #2062, proves). Only with the
    certificate route on.
    """
    from .certificate import (
        _oa_convexity_certificate_enabled,
        _oa_convexity_subdivision_enabled,
        certify_convex_subdivided,
    )

    certificate_route = _oa_convexity_certificate_enabled()
    if use_certificate is None:
        use_certificate = certificate_route

    cache: dict = {}
    ctx = build_linear_context(model)
    if ctx is not None:
        cache[_LINEAR_CONTEXT_KEY] = ctx

    obj_convex = _objective_is_convex(
        model,
        cache,
        use_certificate=use_certificate,
        exact_qp=use_certificate and certificate_route,
    )

    constraint_mask: list[bool] = []
    truncated = 0
    subdivide = _oa_convexity_subdivision_enabled()
    subdivided = 0
    for c in model._constraints:
        if deadline is not None and time.perf_counter() >= deadline:
            constraint_mask.append(False)
            truncated += isinstance(c, Constraint)
        elif isinstance(c, Constraint):
            convex = classify_constraint(c, model, cache, use_certificate=use_certificate)
            if not convex and use_certificate and subdivide and c.sense in ("<=", ">="):
                # #2054: the whole-box certificate abstained; retry on a cover.
                cert = certify_convex_subdivided(c.body, model, deadline=deadline)
                convex = cert is not None and _constraint_convex_from_curvature(cert, c.sense)
                subdivided += convex
            constraint_mask.append(convex)
        else:
            constraint_mask.append(False)

    return OACutConvexity(
        objective_is_convex=obj_convex,
        constraint_mask=constraint_mask,
        truncated=truncated,
        subdivided=subdivided,
    )


__all__ = [
    "OACutConvexity",
    "classify_expr",
    "classify_expr_info",
    "classify_constraint",
    "classify_model",
    "classify_oa_cut_convexity",
]
