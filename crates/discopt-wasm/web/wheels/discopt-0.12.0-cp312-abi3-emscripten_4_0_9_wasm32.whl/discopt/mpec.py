"""Complementarity / MPEC handler.

Mathematical Programs with Equilibrium Constraints (MPECs) carry complementarity
conditions of the form

    0 <= f(x)  ⊥  g(x) >= 0          (i.e. f >= 0, g >= 0, f·g = 0)

which are nonconvex and violate standard constraint qualifications, so a naive
NLP solve stalls. This module provides the two standard reformulations from the
SOTA rule inventory:

* **Scholtes regularization** — replace ``f·g = 0`` with ``f·g <= t`` and drive
  ``t -> 0`` through a homotopy of *local* NLP solves. Smooth, fast, and the
  workhorse for continuous MPECs.
* **SOS1 / disjunctive** — encode "at most one of ``f``, ``g`` is nonzero"
  exactly with a Special Ordered Set of type 1, solved by the global MINLP
  branch-and-bound. Exact, at the cost of discrete search.

The box-bounded mixed complementarity relation ``F(z) ⊥ z in [l, u]``
(:func:`box_mcp`, :meth:`Model.mcp`) is lowered by every method through the same
NCP emitters: it is split into at most two symmetric pairs on shifted slacks,
``F = w⁺ - w⁻``, ``0 <= w⁺ ⊥ z - l``, ``0 <= w⁻ ⊥ u - z`` (one-sided boxes need
no ``w±``, a free box is ``F = 0``). See :func:`_box_decomposition`.

Both build a standard discopt model, so no solver-core changes are required and
the global optimality machinery is reused unchanged.

Example
-------
>>> import discopt.modeling.core as dm
>>> from discopt.mpec import complementarity, solve_mpec
>>> m = dm.Model("toy")
>>> x = m.continuous("x", lb=0, ub=10)
>>> y = m.continuous("y", lb=0, ub=10)
>>> m.minimize((x - 1) ** 2 + (y - 1) ** 2)
>>> pairs = [complementarity(x, y)]          # 0 <= x ⊥ y >= 0
>>> res = solve_mpec(m, pairs, method="scholtes")
>>> round(res.objective, 3)
1.0
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Optional, cast

import numpy as np

from discopt import status as _status
from discopt.constants import CONSTRAINT_INF
from discopt.modeling.core import Constraint, Expression, Model, Variable

if TYPE_CHECKING:  # pragma: no cover - typing only
    from discopt.modeling.core import SolveResult

__all__ = [
    "Complementarity",
    "ComplementarityProvenanceError",
    "ComplementarityRole",
    "LoweringRecord",
    "box_mcp",
    "carry_complementarities",
    "complementarity",
    "flat_source_indices",
    "generated_rows",
    "reformulate_gdp",
    "reformulate_scholtes",
    "reformulate_sos1",
    "refresh_lowering_bounds",
    "require_all_relations_lowered",
    "RELAXING_METHODS",
    "register_relations",
    "relaxed_relations",
    "resolve_source_variables",
    "source_residuals",
    "source_variables",
    "tighten_complementarity_bounds",
    "unlowered_relations",
    "solve_mpec",
    "solve_mpec_multistart",
    "reformulate_native",
    "native_pair_columns",
    "MultistartRecord",
]

_INF = float("inf")

# A declared bound at or beyond this magnitude is discopt's "unbounded"
# sentinel, not a real bound: ``Model.continuous`` defaults to +/-9.999e19 and
# the LP layer's INF is ``CONSTRAINT_INF`` (1e20). A box relation whose
# complementary variable is left at that default must reduce to the NCP pair
# (l=0, u=+inf), so the sentinel is normalized to an infinity rather than
# compared literally — comparing ``ub == inf`` would classify
# ``m.continuous("a", lb=0)`` as a general box and refuse a model the symmetric
# lowering handles exactly (CLAUDE.md's "INF is the sentinel 1e20" rule).
#
# The threshold is the repo's shared ``CONSTRAINT_INF`` scaled just below the
# default bound, NOT a fourth private copy: it was 1e19, which swallowed a
# genuine finite ``ub=2e19`` and reported it as ``+inf`` (review of #1149,
# LOW 8). Anything strictly below the default sentinel magnitude is now kept as
# the finite bound the user declared.
_UNBOUNDED_SENTINEL = 0.9999 * CONSTRAINT_INF  # 9.999e19 — the declared default


def _normalize_bound(value: float) -> float:
    """Map discopt's unbounded sentinel magnitudes onto true infinities."""
    v = float(value)
    if v >= _UNBOUNDED_SENTINEL:
        return _INF
    if v <= -_UNBOUNDED_SENTINEL:
        return -_INF
    return v


class ComplementarityRole(Enum):
    """Where a complementarity relation came from, and which form it is.

    The role is *provenance*, not a lowering switch: every lowering in this
    module branches on the relation's declared operand bounds, never on the
    role. It exists so a downstream consumer (the source-residual report of
    #1148, a KKT diagnostic) can say *which* relation a residual belongs to
    after the model has been rebuilt several times.

    Attributes
    ----------
    NCP_PAIR : str
        The symmetric nonlinear-complementarity pair ``0 <= f ⊥ g >= 0``.
        Produced by :meth:`Model.complementarity` and by the ``.nl``
        type-5 importer.
    BOX_MCP : str
        The box-bounded mixed-complementarity form: a residual ``F(z)`` paired
        with a variable ``z in [l, u]``. Produced by :meth:`Model.mcp`.
        ``NCP_PAIR`` is the ``l = 0, u = +inf`` special case of it.
    FROM_KKT : str
        Generated by a KKT reformulation of an inner problem — the pairs
        :func:`discopt.bilevel.kkt.build_kkt` emits, one per lower-level
        inequality row. ``parent`` names that row.
    FROM_DISJUNCT : str
        Generated from a disjunct rather than declared by the user; ``parent``
        names the disjunction. Reserved vocabulary with no in-tree producer
        yet, exactly as ``DisjunctionSemantics.OR`` was defined by #1124
        before any lowering emitted it — a caller that generates a pair from a
        disjunct must be able to say so rather than have it read as
        user-declared.
    FROM_ACTIVATION : str
        Generated by an embedded neural network's piecewise-linear activation:
        the ``relu_complementarity`` strategy emits ``0 <= y ⊥ s >= 0`` with
        ``y - s = z`` per unstable ReLU neuron (#2167). ``parent`` names the
        network layer and ``index`` the neuron. Like every role it is provenance
        only; the pair is an ordinary ``(0, inf)`` NCP pair to every lowering.
    """

    NCP_PAIR = "ncp_pair"
    BOX_MCP = "box_mcp"
    FROM_KKT = "from_kkt"
    FROM_DISJUNCT = "from_disjunct"
    FROM_ACTIVATION = "from_activation"


class ComplementarityProvenanceError(RuntimeError):
    """A complementarity relation could not be resolved against a model.

    Raised when a rebuilding pass would carry a relation into a model that no
    longer holds one of its source operand variables — i.e. exactly when the
    relation's provenance has been broken. Never downgraded to a warning, a
    ``None`` return, or a best-effort match on generated variable *names*: the
    whole point of the relation is that a residual computed from it is a
    residual of the *source* condition, and a silently dropped or mis-resolved
    pair makes that measurement meaningless (#1147; CLAUDE.md §6–§7).
    """


@dataclass(eq=False)
class Complementarity:
    """One complementarity relation, with durable provenance to its source.

    In the symmetric NCP form this is ``0 <= f ⊥ g >= 0`` (``f, g >= 0`` and
    ``f·g = 0``). In the box-MCP form (``role`` :attr:`ComplementarityRole.BOX_MCP`)
    ``f`` is a residual ``F(z)`` and ``g`` is a variable ``z`` declared on
    ``[l, u]`` (``g_bounds``), meaning

    * ``z = l``      ⇒ ``F(z) >= 0``
    * ``l < z < u``  ⇒ ``F(z) == 0``
    * ``z = u``      ⇒ ``F(z) <= 0``

    with the NCP pair as the ``l = 0, u = +inf`` special case.

    The object is compared and hashed **by identity** (``eq=False``): a
    relation is a node in the model's IR, not a value. Two structurally
    identical pairs are two relations, and — the reason this matters — a pair
    stays usable as a dict/set key while a rebuilding pass carries it from one
    ``Model`` to the next (#1147). Value equality was never available anyway:
    ``Expression.__eq__`` builds a ``Constraint``, so a field-by-field compare
    would have returned a constraint object rather than a bool.

    Attributes
    ----------
    f, g : Expression
        The **source** operands, over the variables the user declared. They are
        never rewritten by a lowering or a rebuilding pass, so a residual
        computed from them is a residual of the source condition rather than of
        whatever relaxed row the condition was lowered into.
    name : str, optional
        The relation's name; the base name of every row generated from it.
    role : ComplementarityRole
        Where the relation came from — see :class:`ComplementarityRole`.
    f_bounds, g_bounds : tuple of float
        The bounds the *relation* declares on each operand: ``(0, +inf)`` for
        both sides of an NCP pair, ``(-inf, +inf)`` and ``(l, u)`` for a
        box-MCP. These are the relation's own semantics and are deliberately
        not the interval enclosure of the operand, which presolve moves.
    scale : float, optional
        Characteristic magnitude of the relation's residual, for a meaningful
        tolerance when the two operands carry unrelated physical magnitudes
        (a multiplier in 1e-6 against a flow in 1e3). ``None`` means "not
        declared"; :attr:`effective_scale` then derives one from the declared
        bounds.
    parent : str, optional
        Identity of the logical construct that generated the relation (the
        lower-level row for a KKT pair, the disjunction for a disjunct pair).
        ``None`` for a user-declared relation.
    f_shape, g_shape : tuple of int, optional
        Static element shapes of the operands, cached the first time the
        relation is scalarized. ``None`` means "not computed yet", which is
        distinguishable from ``()`` = "scalar".
    index : tuple of int, optional
        For an element of a vector/array relation, its multi-index into the
        parent; ``None`` for a relation that is not an element.
    source : Complementarity, optional
        For an element, the parent relation it came from — so an elementwise
        residual can be attributed back to the declared vector relation.

    Notes
    -----
    Which method lowered the relation is deliberately **not** a field here: it
    is per-model state (see :meth:`mark_lowered` / :meth:`lowering_in`). One
    relation object may be lowered by GDP into one model and by SOS1 into
    another, and a field would hold only whichever ran last, so the first
    model's provenance would stop describing its own rows.
    """

    f: Expression
    g: Expression
    name: Optional[str] = None
    role: ComplementarityRole = ComplementarityRole.NCP_PAIR
    f_bounds: tuple[float, float] = (0.0, _INF)
    g_bounds: tuple[float, float] = (0.0, _INF)
    scale: Optional[float] = None
    parent: Optional[str] = None
    f_shape: Optional[tuple[int, ...]] = None
    g_shape: Optional[tuple[int, ...]] = None
    index: Optional[tuple[int, ...]] = None
    source: Optional["Complementarity"] = None

    # ── provenance queries ──

    @property
    def is_symmetric_nonnegative(self) -> bool:
        """True when the relation is the symmetric pair ``0 <= f ⊥ g >= 0``.

        Read off the **declared bounds**, never off :attr:`role`. Role is
        provenance — ``docs/complementarity_semantics.md`` §3 and
        :class:`ComplementarityRole` both say so — and a lowering that branched
        on it would be steered by a label. ``Complementarity`` is public and
        constructible directly, so a relation with ``g_bounds=(-1, 1)`` and the
        default ``role=NCP_PAIR`` reaches the lowerings; gating on the label let
        that through and emitted ``g >= 0`` against a declared ``lb = -1``,
        certifying a point the relation forbids (review of #1149, HIGH 2).
        """
        return self.f_bounds == (0.0, _INF) and self.g_bounds == (0.0, _INF)

    @property
    def is_box_mcp(self) -> bool:
        """True when the declared bounds are a general box, not the ``[0, inf)`` pair."""
        return not self.is_symmetric_nonnegative

    @property
    def shape(self) -> Optional[tuple[int, ...]]:
        """Element shape of the relation (the broadcast of the two operand shapes).

        ``None`` until the operand shapes have been computed (see
        :meth:`elements`); ``()`` for a scalar relation.
        """
        if self.f_shape is None or self.g_shape is None:
            return None
        if _n_elements(self.f_shape) >= _n_elements(self.g_shape):
            return self.f_shape
        return self.g_shape

    @property
    def effective_scale(self) -> float:
        """The residual scale to use: the declared one, else derived from bounds.

        The derived value is the largest finite magnitude the relation's own
        declared bounds admit (never below 1.0), so a box-MCP on ``z in [0, 1e3]``
        scales its residual tolerance by 1e3 while an unbounded relation keeps
        the absolute tolerance it has today.
        """
        if self.scale is not None:
            return float(self.scale)
        mags = [abs(b) for b in (*self.f_bounds, *self.g_bounds) if np.isfinite(b)]
        return max([1.0, *mags])

    def describe(self) -> str:
        """A short human identification of the relation, for error messages."""
        who = self.name or "<unnamed>"
        if self.index is not None:
            who = f"{who}[{', '.join(str(i) for i in self.index)}]"
        extra = f", parent={self.parent!r}" if self.parent else ""
        return f"complementarity {who!r} (role={self.role.value}{extra})"

    # ── lowering state ──

    def mark_lowered(
        self,
        model: Model,
        method: str,
        rows: Optional[list] = None,
        derived: Optional[list] = None,
    ) -> None:
        """Record that ``model``'s rows already encode this relation.

        Kept per-model on purpose. The same relation object may legitimately be
        lowered into two *different* models (a variant build); what is never
        legitimate is lowering it twice into the *same* model, which silently
        duplicates every generated row. The rebuilding passes propagate this
        mark when they carry a relation forward, so a lowered model's clone is
        not re-lowered either (#1147).

        Both the mark **and the method** live on the model
        (``Model._lowered_complementarities``, an identity map from relation to
        method), not on the relation. The mark lived here as a list of
        ``weakref``s first, which made a ``Model`` carrying a relation
        unpicklable and made ``copy.deepcopy`` silently drop it — so the clone
        then refused to solve. The *method* then stayed behind as a plain field,
        which was the same mistake one level down: lowering one relation by GDP
        into ``m1`` and by SOS1 into ``m2`` left the field reading ``"sos1"``,
        so ``m1``'s provenance no longer described its own disjunctive rows
        (reviews of #1149, HIGH 3 and blocking 2). A relation is shared; what a
        given model did with it is that model's fact.

        ``rows`` are the :class:`~discopt.modeling.core.Constraint` objects the
        lowering just emitted into ``model``, when the caller knows them. They
        let #1148 report the *lowered* residual beside the source one — the two
        differ by orders of magnitude at a Scholtes point, and only a report that
        holds both can show it. ``None`` means "not tracked for this model",
        which is what a rebuilding pass must record: it carries the relation
        forward, but the rows in the rebuilt model are different objects.

        ``derived`` lists the auxiliary bounds the lowering derived from the
        model's other bounds (see :attr:`LoweringRecord.derived`).
        """
        _lowered_map(model)[self] = LoweringRecord(method=method, rows=rows, derived=derived)

    def is_lowered_into(self, model: Model) -> bool:
        """True when ``model`` already carries the rows generated from this relation."""
        return self in getattr(model, "_lowered_complementarities", ())

    def lowering_in(self, model: Model) -> Optional[str]:
        """The method that lowered this relation into ``model``, or ``None``.

        Per-model on purpose — see :meth:`mark_lowered`. Ask the model that
        carries the rows you are reasoning about, never the relation.
        """
        record = getattr(model, "_lowered_complementarities", {}).get(self)
        return None if record is None else record.method

    def rows_in(self, model: Model) -> Optional[list]:
        """The rows this relation generated in ``model``, or ``None`` if untracked.

        ``None`` and ``[]`` are different answers and must stay so: ``[]`` means
        "this lowering emitted no rows", ``None`` means "this model does not know
        which rows came from this relation" — and a lowered-row residual computed
        from ``None`` treated as ``[]`` would report 0.0 for rows it never looked
        at (CLAUDE.md §6).
        """
        record = getattr(model, "_lowered_complementarities", {}).get(self)
        return None if record is None else record.rows

    # ── elementwise view ──

    def elements(self, model: Model) -> list["Complementarity"]:
        """The scalar relations this relation stands for, one per index.

        A scalar relation yields ``[self]``. A vector/array relation yields one
        child per element, each carrying its :attr:`index` and a :attr:`source`
        back-pointer, so an elementwise residual is attributable to the declared
        relation after any number of rebuilding passes.
        """
        return _scalarize_pairs(model, [self])


#: Lowering methods whose rows are a **relaxation** of the relation, not an
#: encoding of it. Scholtes replaces ``f·g = 0`` with ``f·g <= t``, so its rows
#: admit points the relation forbids and a solve over them certifies the
#: *relaxation*. Everything else here (``gdp``, ``sos1``) encodes the relation
#: exactly.
#:
#: This distinction is load-bearing for the solve guard, not bookkeeping. #1148
#: made ``solve_mpec`` record its relations on the model, and a Scholtes run then
#: left the relation marked lowered — so ``require_all_relations_lowered``, whose
#: entire purpose is to catch "a declared relation solved as if absent", *vouched*
#: for a relaxation. Measured on the balanced probe (``max x+y s.t. x==y,
#: 0 <= x ⊥ y >= 0``, true optimum 0): ``solve_mpec(method="scholtes")`` followed
#: by ``model.solve()`` returned ``status='optimal' objective=2.83e-04
#: gap_certified=True`` — a certified optimum strictly better than the true one,
#: straight past the guard (#1158 review, MEDIUM 4).
RELAXING_METHODS = frozenset({"scholtes"})


@dataclass
class LoweringRecord:
    """What one model did with one relation: the method, and the rows it emitted.

    Per-model state, keyed by relation identity in
    ``Model._lowered_complementarities`` — see
    :meth:`Complementarity.mark_lowered` for why neither field may live on the
    relation. ``rows`` is ``None`` when the generated rows are not tracked for
    this model (a rebuilding pass carries the relation forward, but the rebuilt
    model's rows are different objects), and that is deliberately distinct from
    an empty list.
    """

    method: str
    rows: Optional[list] = None
    #: The auxiliary-variable bounds this lowering DERIVED from other bounds of the
    #: model (the split ``w±`` of a two-sided box, an SOS1 aux, a GDP operand
    #: lift), as :class:`DerivedBound` entries. A derived bound is a fact about the
    #: box it was computed over; :func:`refresh_lowering_bounds` recomputes every
    #: one at the solve boundary, so widening a variable after lowering cannot
    #: leave a stale big-M that cuts the optimum (#2061 review, blocker). ``None``
    #: means "not tracked" -- a rebuilding pass, or a model read from a file.
    derived: Optional[list] = field(default=None, compare=False, repr=False)
    #: For a record read from a file (which does not carry ``derived``): the
    #: bounds and parameter values the relation's operands read at load time, as
    #: ``[(leaf, lb, ub)]`` / ``[(param, value)]``. A widening after load cannot be
    #: refreshed, so it is refused (:func:`refresh_lowering_bounds`).
    baseline: Optional[list] = field(default=None, compare=False, repr=False)

    @property
    def is_exact(self) -> bool:
        """True when the rows ENCODE the relation rather than relax it.

        See :data:`RELAXING_METHODS`. Keyed on the method that emitted the rows,
        which is the only thing that knows whether the generated feasible set is
        the relation's own or a superset of it.
        """
        return self.method not in RELAXING_METHODS


def _lowered_map(model: Model) -> dict:
    """The model's identity map ``relation -> lowering record``, created on demand.

    ``getattr``-with-default rather than a bare attribute read: a ``Model``
    built by a code path that bypasses ``__init__`` must not crash here.
    """
    got = getattr(model, "_lowered_complementarities", None)
    if got is None:
        got = {}
        model._lowered_complementarities = got
    return got


def complementarity(
    f: Expression,
    g: Expression,
    name: Optional[str] = None,
    *,
    role: ComplementarityRole = ComplementarityRole.NCP_PAIR,
    scale: Optional[float] = None,
    parent: Optional[str] = None,
) -> Complementarity:
    """Construct a :class:`Complementarity` condition ``0 <= f ⊥ g >= 0``.

    ``role``/``scale``/``parent`` are provenance only (#1147); they change no
    lowering. Use ``role=ComplementarityRole.FROM_KKT`` with ``parent`` naming
    the row when the pair is generated rather than user-declared.
    """
    return Complementarity(f, g, name, role=role, scale=scale, parent=parent)


def box_mcp(
    residual: Expression,
    variable: Expression,
    lb: Optional[float] = None,
    ub: Optional[float] = None,
    name: Optional[str] = None,
    *,
    scale: Optional[float] = None,
    parent: Optional[str] = None,
) -> Complementarity:
    r"""Construct the box-bounded MCP relation ``F(z) ⊥ z in [l, u]``.

    The mixed complementarity problem pairs a residual with a *bounded*
    variable rather than with a second nonnegative expression:

    * ``z = l``      ⇒ ``F(z) >= 0``
    * ``l < z < u``  ⇒ ``F(z) == 0``
    * ``z = u``      ⇒ ``F(z) <= 0``

    ``l = 0, u = +inf`` reduces exactly to the NCP pair ``0 <= F ⊥ z >= 0``,
    and is returned as a :attr:`ComplementarityRole.NCP_PAIR` relation so the
    two forms never diverge on the case they share.

    ``lb``/``ub`` default to the declared bounds of ``variable`` when it is a
    plain scalar :class:`~discopt.modeling.core.Variable`; they are required
    otherwise, since the relation's semantics *are* those bounds and guessing
    them would silently change the condition.

    ``lb``/``ub`` are scalars: every element of a vector relation shares the one
    box. Declare per-element relations for per-element boxes.

    The returned relation is only *recorded*; :meth:`Model.mcp` lowers it on
    declaration, and :func:`reformulate_gdp` / :func:`reformulate_sos1` /
    :func:`solve_mpec` lower a relation built here. Every lowering decomposes the
    box into at most two NCP halves (see :func:`_box_decomposition`, #2058). A
    model carrying a relation no lowering emitted is refused by the solver rather
    than solved with the condition quietly absent (#1147).
    """
    if any(b is not None and np.ndim(b) != 0 for b in (lb, ub)):
        raise ValueError(
            f"box_mcp: lb/ub are scalars; a vector relation uses one box for every "
            f"element (relation {name or '<unnamed>'!r}). Declare per-element relations "
            "for per-element boxes."
        )
    if lb is None or ub is None:
        if not (isinstance(variable, Variable) and variable.size == 1):
            raise ValueError(
                "box_mcp: lb/ub are required unless the complementary side is a plain "
                "scalar Variable whose declared bounds define the box. The relation's "
                "semantics are those bounds, so they are not guessed."
            )
        lb = float(np.min(np.asarray(variable.lb))) if lb is None else lb
        ub = float(np.max(np.asarray(variable.ub))) if ub is None else ub
    lo, hi = _normalize_bound(lb), _normalize_bound(ub)
    if not (lo <= hi):
        who = name or "<unnamed>"
        raise ValueError(f"box_mcp: empty box [{lo:g}, {hi:g}] for relation {who!r}")
    if lo == hi and not np.isfinite(lo):
        who = name or "<unnamed>"
        raise ValueError(
            f"box_mcp: box [{lo:g}, {hi:g}] for relation {who!r} pins the variable at "
            "infinity, which no real value satisfies"
        )
    role = (
        ComplementarityRole.NCP_PAIR if (lo == 0.0 and hi == _INF) else ComplementarityRole.BOX_MCP
    )
    f_bounds = (0.0, _INF) if role is ComplementarityRole.NCP_PAIR else (-_INF, _INF)
    return Complementarity(
        residual,
        variable,
        name,
        role=role,
        f_bounds=f_bounds,
        g_bounds=(lo, hi),
        scale=scale,
        parent=parent,
    )


# ───────────────────────── provenance resolution ──────────────────────────


def _ensure_relation_name(model: Model, pair: Complementarity) -> str:
    """Give ``pair`` a name unique on ``model``, and return it.

    Every row generated from a relation is named from this, so an unnamed
    relation must not reuse a name already in play. The fallback used to be
    ``f"compl{i}"`` with ``i`` counted **within the list handed to the
    lowering** — and ``Model.complementarity`` hands over exactly one relation,
    so two unnamed declarations on the same model both became ``compl0`` and
    emitted ``compl0_f_nonneg`` twice, silently (review of #1149, MEDIUM 4).

    Fixing it here rather than at a call site fixes the class: every lowering
    entry point scalarizes through :func:`_scalarize_pairs`, so the ``.nl``
    importer, ``Model.complementarity``, and a hand-built pair handed to
    ``reformulate_*`` all get a unique name from the same rule.
    """
    if pair.name is not None:
        return pair.name
    taken = {p.name for p in model._complementarities if p.name}
    taken |= {c.name for c in model._constraints if getattr(c, "name", None)}
    k = 0
    while f"compl{k}" in taken or f"compl{k}_f_nonneg" in taken:
        k += 1
    pair.name = f"compl{k}"
    return pair.name


def _n_elements(shape: tuple[int, ...]) -> int:
    return int(np.prod(shape, dtype=np.int64)) if shape else 1


def source_variables(pair: Complementarity) -> list[Variable]:
    """Every :class:`~discopt.modeling.core.Variable` the relation's operands read.

    Traversal is iterative (a ``from_nl`` operand graph is deep enough to blow
    the recursion limit) and returns objects, in first-encounter order — never
    names or indices, which presolve renames and renumbers.

    An expression node this walker does not know how to descend into **raises**
    rather than contributing nothing. A silent miss would leave the resolution
    check below traversing less than the operand actually reads, so it would
    keep reporting "resolved" for a relation whose provenance is in fact broken
    — the probe-that-measures-nothing failure (CLAUDE.md §6).
    """
    out: list[Variable] = []
    for node in _walk_operands(pair):
        if isinstance(node, Variable):
            out.append(node)
    return out


def _walk_operands(pair: Complementarity):
    """Yield every node of the relation's two operand graphs, each exactly once.

    Iterative (a ``from_nl`` operand graph is deep enough to blow the recursion
    limit) and deterministic in first-encounter order. An
    :class:`IndexExpression` yields itself *and* its base, so a caller can see
    both "this variable is read" and "only this element of it is read".
    """
    seen: set[int] = set()
    stack: list[Expression] = [pair.g, pair.f]
    while stack:
        node = stack.pop()
        if id(node) in seen:
            continue
        seen.add(id(node))
        yield node
        stack.extend(_operand_children(pair, node))


def _operand_children(pair: Complementarity, node: Expression) -> tuple:
    """The sub-expressions of ``node``, or ``()`` for a leaf.

    A node type this dispatch does not know **raises** rather than returning
    ``()``. A silent miss would leave resolution traversing less than the
    operand actually reads, so it would keep reporting "resolved" for a relation
    whose provenance is in fact broken (CLAUDE.md §6).
    """
    from discopt.modeling.core import (
        BinaryOp,
        BooleanVar,
        Constant,
        CustomCall,
        FunctionCall,
        IndexExpression,
        MatMulExpression,
        Parameter,
        SumExpression,
        SumOverExpression,
        UnaryOp,
    )

    if isinstance(node, (Variable, Constant, Parameter, BooleanVar)):
        return ()
    if isinstance(node, IndexExpression):
        return (node.base,)
    if isinstance(node, (BinaryOp, MatMulExpression)):
        return (node.right, node.left)
    if isinstance(node, UnaryOp):
        return (node.operand,)
    if isinstance(node, SumExpression):
        return (node.operand,)
    if isinstance(node, SumOverExpression):
        return tuple(reversed(list(node.terms)))
    if isinstance(node, (FunctionCall, CustomCall)):
        return tuple(reversed(list(node.args)))
    raise ComplementarityProvenanceError(
        f"{pair.describe()}: cannot resolve provenance through expression node "
        f"{type(node).__name__!r}. Add it to the operand walker's dispatch — a "
        "node silently skipped here would make every resolution check that "
        "follows report success without having looked at the operand."
    )


def resolve_source_variables(
    model: Model, pair: Complementarity, *, context: str
) -> list[Variable]:
    """Resolve a relation's source variables against ``model``, **by identity**.

    Returns the variables in operand order. Raises
    :class:`ComplementarityProvenanceError` — naming the relation and
    ``context`` (the pass or boundary asking) — when ``model`` does not hold one
    of them. Membership is object identity, never ``name`` or ``_index``:
    presolve/FBBT eliminate and renumber variables, so an index-keyed map is
    stale exactly when it becomes useful, and a name-keyed one matches a
    generated ``_gdp_aux_disj_pair0_0_0`` that is not the source operand at all.
    """
    live = {id(v) for v in model._variables}
    resolved = source_variables(pair)
    missing = [v for v in resolved if id(v) not in live]
    if missing:
        raise ComplementarityProvenanceError(
            f"{context}: {pair.describe()} cannot be resolved against the rebuilt model — "
            f"source variable(s) {', '.join(sorted(v.name for v in missing))} are not present "
            "in it (by object identity). The relation's source operands must survive every "
            "rebuilding pass, or a residual computed from it measures the lowered rows "
            "instead of the source condition. Carry the variable objects forward, or drop "
            "the relation explicitly."
        )
    return resolved


def flat_source_indices(model: Model, pair: Complementarity) -> list[int]:
    """Flat column indices the relation's operands actually read, in ``model``.

    Derived **on demand at the solver boundary**, never persisted on the
    relation: the flat layout changes whenever a pass appends auxiliaries or
    presolve eliminates a column, so an index stored at declaration time is a
    stale answer that still looks like a valid one (#1147 scope item 4).

    Element-accurate for a statically indexed operand: ``x[2] ⊥ y`` over a
    shape-``(3,)`` ``x`` returns the two columns it reads, not all four of
    ``x`` and ``y``. Returning the whole parent variable was an
    over-report — a consumer masking a residual by these indices would touch
    columns the relation never reads (review of #1149, MEDIUM 6).

    An index that cannot be resolved statically (a slice, a computed index)
    falls back to the whole variable. That direction is deliberate: this is a
    *conservative* answer, never a narrower one than the truth, so a consumer
    can rely on the set covering everything the relation reads.
    """
    resolved = resolve_source_variables(model, pair, context="flat_source_indices")
    slots = _read_slots(pair)
    offsets = _target_flat_offsets(model)
    out: list[int] = []
    for v in resolved:
        off = offsets[id(v)]
        elems = slots.get(id(v))
        out.extend(range(off, off + v.size) if elems is None else sorted(off + e for e in elems))
    return out


def _target_flat_offsets(model: Model) -> dict[int, int]:
    """Exclusive prefix sums over ``model._variables``, keyed by variable identity.

    Deliberately not ``Model._flat_var_offset``: that indexes its prefix table by
    ``Variable._index``, which is the variable's position in the model it was
    *declared* on. A relation's operands are shared objects, and a target model
    may hold them in a different order — a two-element ``x`` and a scalar ``y``
    declared in that order but held as ``[y, x]`` resolved to ``[0, 1, 1]``
    instead of the target's true ``[1, 2, 0]``, so a #1148 residual masked by
    those columns would have read the wrong ones (review of #1149, blocking 1).
    The rebuilding passes happen to preserve declaration order, which is why
    ``_flat_var_offset`` is right for them and wrong as a general provenance
    accessor.

    O(n) per call and not memoized: this is a boundary accessor called once per
    relation, and a cache keyed on anything but the live list is how the stale
    answer got here in the first place.
    """
    offsets: dict[int, int] = {}
    off = 0
    for v in model._variables:
        offsets.setdefault(id(v), off)
        off += v.size
    return offsets


def _read_slots(pair: Complementarity) -> dict[int, Optional[set[int]]]:
    """Per-variable element slots the operands read, or ``None`` for "all of it".

    A :class:`IndexExpression` over a variable with a statically resolvable
    integer index contributes only the selected flat element; every other
    appearance of that variable — a bare reference, a slice, a computed index —
    widens it to the whole variable, which is the safe direction (see
    :func:`flat_source_indices`).
    """
    from discopt.modeling.core import IndexExpression

    slots: dict[int, Optional[set[int]]] = {}

    def note(var, elem: Optional[int]) -> None:
        if id(var) in slots and slots[id(var)] is None:
            return  # already widened to the whole variable
        if elem is None:
            slots[id(var)] = None
        else:
            slots.setdefault(id(var), set()).add(elem)  # type: ignore[union-attr]

    # Its own traversal rather than ``_walk_operands``: that walker descends
    # from an ``x[2]`` into its base ``x``, which would then be noted as a bare
    # reference and widen the slot straight back to the whole variable. Here an
    # indexed leaf is consumed WITHOUT descending, so ``x[2]`` contributes one
    # element while a bare ``x`` elsewhere in the same operand still widens it.
    seen: set[int] = set()
    stack: list[Expression] = [pair.g, pair.f]
    while stack:
        node = stack.pop()
        if id(node) in seen:
            continue
        seen.add(id(node))
        if isinstance(node, IndexExpression) and isinstance(node.base, Variable):
            note(node.base, _static_flat_element(node.base, node.index))
            continue
        if isinstance(node, Variable):
            note(node, None)
            continue
        stack.extend(_operand_children(pair, node))
    return slots


def _static_flat_element(var: Variable, index) -> Optional[int]:
    """Flat element number ``var[index]`` selects, or ``None`` when not static."""
    idx = (index,) if isinstance(index, (int, np.integer)) else index
    if not (isinstance(idx, tuple) and idx and all(isinstance(i, (int, np.integer)) for i in idx)):
        return None
    shape = var.shape or (1,)
    if len(idx) != len(shape):
        return None
    try:
        return int(np.ravel_multi_index(tuple(int(i) for i in idx), shape))
    except ValueError:
        return None  # out of range — let the model's own guard report it


def carry_complementarities(src: Model, dst: Model, *, pass_name: str) -> None:
    """Forward ``src``'s complementarity relations onto the rebuilt model ``dst``.

    Every pass that constructs a fresh :class:`~discopt.modeling.core.Model`
    from an existing one must call this. Before #1147 each of them silently
    dropped ``_complementarities``, so after any lowering the only surviving
    trace of a declared pair was its name baked into generated identifiers —
    and a residual probe written against the rebuilt model would have measured
    the relaxed row rather than the source product, printed a small number, and
    been believed.

    The **same relation objects** are forwarded (not copies), so identity-keyed
    provenance holds across any number of passes, and each is checked to resolve
    against ``dst`` first — an unresolvable one raises
    :class:`ComplementarityProvenanceError` rather than being dropped.

    A relation lowered **into ``src``** is marked lowered into ``dst`` with
    ``src``'s method, because ``dst`` was rebuilt from ``src``'s rows and
    therefore already carries the generated ones. The test is
    ``pair.is_lowered_into(src)`` and nothing weaker: keying it on "the relation
    has been lowered somewhere" let an *unlowered* ``src`` sharing a relation
    with some other model hand ``dst`` a lowered mark, so ``dst`` claimed rows
    neither model had and walked straight past the solve guard (review of
    #1149, blocking 2).
    """
    relations = list(src._complementarities)
    if not relations:
        return
    for pair in relations:
        resolve_source_variables(model=dst, pair=pair, context=f"{pass_name}")
        dst._complementarities.append(pair)
        method = pair.lowering_in(src)
        if method is not None:
            # ``rows`` is deliberately left untracked: ``dst`` was rebuilt from
            # ``src``'s rows, so it *carries* the generated rows, but they are
            # different ``Constraint`` objects. Forwarding ``src``'s row list
            # would hand a #1148 residual probe rows that belong to another
            # model — a number that looks like a measurement and is not one.
            pair.mark_lowered(dst, method)


def generated_rows(model: Model, pairs: list[Complementarity]) -> Optional[list]:
    """Every row ``model`` holds that was generated from ``pairs``, or ``None``.

    ``None`` when the rows of **any** relation in ``pairs`` are untracked in
    ``model``: a partial list would let a lowered-row residual report the maximum
    over the rows it happened to know about and read as a complete measurement.
    Rows are tracked by the lowering that emitted them (see
    :class:`LoweringRecord`) and are never reconstructed from generated *names*,
    which a later pass renames.
    """
    out: list = []
    for pair in pairs:
        rows = pair.rows_in(model)
        if rows is None:
            return None
        out.extend(rows)
    return out


def register_relations(model: Model, pairs: list[Complementarity]) -> None:
    """Record ``pairs`` on ``model`` as its declared relations, once each.

    ``Model.complementarity``/``Model.mcp`` do this themselves; a pair built with
    :func:`complementarity` and handed straight to :func:`solve_mpec` was never
    recorded, so ``model._complementarities`` — the durable record every
    rebuilding pass forwards (#1147) — came back **empty** after a solve, and a
    later source-residual query over the model measured nothing at all.

    Membership is object identity, never a structural or name comparison: two
    structurally identical pairs are two relations (see
    :class:`Complementarity`), and ``Expression.__eq__`` builds a ``Constraint``
    rather than returning a bool, so ``pair in list`` would raise before it could
    be wrong.
    """
    known = {id(p) for p in model._complementarities}
    for pair in pairs:
        if id(pair) not in known:
            model._complementarities.append(pair)
            known.add(id(pair))


def unlowered_relations(model: Model) -> list[Complementarity]:
    """Relations recorded on ``model`` whose rows ``model`` does not carry.

    The solver boundary refuses these loudly: a model that *declares* a
    complementarity condition no lowering has emitted would otherwise be solved
    as if the condition were absent, and certified.
    """
    return [p for p in model._complementarities if not p.is_lowered_into(model)]


def relaxed_relations(model: Model) -> list[Complementarity]:
    """Relations whose rows in ``model`` are a **relaxation**, not an encoding.

    Distinct from :func:`unlowered_relations`: the rows are present, they are
    just weaker than the relation. A global solve over them certifies the
    relaxation, which is not the model the user declared — see
    :data:`RELAXING_METHODS` for the measured false certificate this exists to
    stop.
    """
    out = []
    for p in model._complementarities:
        record = getattr(model, "_lowered_complementarities", {}).get(p)
        if record is not None and not record.is_exact:
            out.append(p)
    return out


def require_all_relations_lowered(model: Model, *, context: str) -> None:
    """Refuse to solve a model that declares a relation no lowering emitted.

    Call this at **every** solver entry point, not just the convenient one. The
    guard first lived only in :meth:`Model.solve`, so the four in-tree callers of
    :func:`discopt.solver.solve_model` — the differentiable-solve paths and the
    primal heuristics — went straight past it and certified ``optimal`` on a
    point the declared relation forbids: with ``z in [-1, 1]``, ``max z`` and
    ``mcp(z + 1, z)``, ``solve_model`` returned ``z = 1`` (the MCP's ``z = u``
    branch requires ``F <= 0``; ``F = +2``). That is a CLAUDE.md §1 violation
    with no slack, so the check belongs at the boundary the solver actually
    passes through (review of #1149, HIGH 1).
    """
    if not getattr(model, "_complementarities", None):
        return
    pending = unlowered_relations(model)
    if pending:
        raise NotImplementedError(
            f"{context}: model declares complementarity relation(s) with no lowering: "
            + "; ".join(p.describe() for p in pending)
            + ". Solving would silently drop the condition and certify a point it "
            "forbids. Lower it with Model.complementarity / Model.mcp (which lower on "
            "declaration), or with reformulate_gdp / reformulate_sos1 / solve_mpec on "
            "the relation."
        )
    relaxed = relaxed_relations(model)
    if relaxed:
        # Rows present but WEAKER than the relation. A global solve over them
        # reports a certified optimum of the relaxation, which on the balanced
        # probe is strictly better than the true optimum -- see RELAXING_METHODS.
        # "Has a lowering" was never the right test; "has an EXACT lowering" is.
        methods = sorted({p.lowering_in(model) or "?" for p in relaxed})
        raise NotImplementedError(
            f"{context}: model carries a RELAXATION of complementarity relation(s), not "
            "an encoding of them: "
            + "; ".join(p.describe() for p in relaxed)
            + f" (lowered by {', '.join(methods)}). Those rows admit points the relation "
            "forbids, so a global solve over this model would certify the relaxation "
            "rather than the MPEC. Use discopt.mpec.solve_mpec(..., method='scholtes'), "
            "which returns a LOCAL result that claims no certificate, or lower the "
            "relation exactly with method='gdp' / 'sos1' on a fresh model."
        )


# ─────────────────────────── scalarization ────────────────────────────


def _elem_shape(model: Model, expr: Expression) -> tuple[int, ...]:
    """Static element shape of ``expr`` (``()`` for a scalar) via interval eval."""
    from discopt._relax.convexity.interval_eval import evaluate_interval

    iv = evaluate_interval(expr, model)
    return tuple(int(d) for d in np.asarray(iv.lo).shape)


def _enclosure_of(
    model: Model, expr: Expression, box: Optional[dict] = None
) -> tuple[float, float]:
    """The interval enclosure ``(lo, hi)`` of ``expr``, with discopt's sentinels as infinities.

    The one place every lowering-derived auxiliary bound is computed. A variable on
    its default bounds (``±9.999e19``) is *unbounded*; an enclosure read straight
    off it is a huge but finite number, which a ``np.isfinite`` test passes and a
    big-M then uses as if it were a real bound (#2061 review). Both endpoints go
    through :func:`_normalize_bound`, so such an enclosure reads as infinite here.
    An exception from the interval evaluator propagates; each caller decides what
    an unevaluable operand means for it.
    """
    from discopt._relax.convexity.interval_eval import evaluate_interval

    iv = evaluate_interval(expr, model, box)
    lo = _normalize_bound(float(np.min(np.asarray(iv.lo))))
    hi = _normalize_bound(float(np.max(np.asarray(iv.hi))))
    return lo, hi


def _aux_upper_bound(model: Model, expr: Expression) -> float:
    """Finite upper bound for an SOS1 aux mirroring a nonnegative operand.

    Uses the static interval enclosure of ``expr``; returns ``+inf`` when the
    enclosure is non-finite -- or cannot be computed -- so the SOS1→big-M lowering
    raises its clear "add a finite upper bound" error instead of silently
    fabricating a huge M. The evaluator's exception is not lost: that downstream
    refusal is the loud outcome it maps to.
    """
    try:
        return _enclosure_of(model, expr)[1]
    except Exception:
        return _INF


class DerivedBound:
    """One auxiliary bound a lowering derived from the model's other bounds.

    ``kind`` names the derivation, so :func:`refresh_lowering_bounds` recomputes it
    with the same function that set it:

    * ``"split_pos"`` / ``"split_neg"`` -- ``w⁺ <= max(0, hi F)`` /
      ``w⁻ <= max(0, -lo F)`` of a two-sided box (:func:`_box_decomposition`),
      ``F`` enclosed over the box narrowed by the relation's own ``[l, u]`` on
      ``z`` (``zbox``). A non-finite enclosure is a refusal.
    * ``"sos1_aux"`` -- ``0 <= aux <= hi expr`` (:func:`reformulate_sos1`).
    * ``"gdp_lift"`` -- ``u`` enclosing a nonlinear GDP operand
      (:func:`_gdp_operand`, via ``Model._branch_bounds``).

    Plain attributes, no ``__eq__``: ``copy.deepcopy`` and ``pickle`` carry it with
    the model's own memo, so a clone's entry points at the clone's variables.
    """

    __slots__ = ("var", "expr", "kind", "zbox", "relation")

    def __init__(
        self,
        var: Variable,
        expr: Expression,
        kind: str,
        relation: Complementarity,
        zbox: Optional[tuple] = None,
    ):
        self.var = var
        self.expr = expr
        self.kind = kind
        self.relation = relation
        self.zbox = zbox

    def __getstate__(self):
        return {k: getattr(self, k) for k in self.__slots__}

    def __setstate__(self, state):
        for k, v in state.items():
            setattr(self, k, v)

    def bounds(self, model: Model) -> tuple[float, float]:
        """The ``(lb, ub)`` the lowering would give this aux over the model's current box."""
        if self.kind in ("split_pos", "split_neg"):
            flo, fhi = _split_enclosure(model, self.expr, self.relation, self.zbox)
            return (0.0, max(0.0, fhi)) if self.kind == "split_pos" else (0.0, max(0.0, -flo))
        if self.kind == "sos1_aux":
            return 0.0, _aux_upper_bound(model, self.expr)
        if self.kind == "gdp_lift":
            return model._branch_bounds(self.expr, self.expr)
        raise ValueError(f"unknown derived-bound kind {self.kind!r}")


def _relation_zbox(p: Complementarity, lb: float, ub: float) -> Optional[tuple]:
    """``(variable, flat element or None, l, u)`` when ``p.g`` is one variable element.

    The relation's box ``[l, u]`` constrains ``z`` wherever the relation holds, so
    ``F`` need only be enclosed over ``z``'s declared bounds intersected with it
    (#2061 review). Only a plain variable (or a static element of one) is narrowed;
    any other ``g`` keeps the declared box, which is always sound.
    """
    from discopt.modeling.core import IndexExpression

    g = p.g
    if isinstance(g, Variable) and g.size == 1:
        return (g, None, lb, ub)
    if isinstance(g, IndexExpression) and isinstance(g.base, Variable):
        k = _static_flat_element(g.base, g.index)
        if k is not None:
            return (g.base, k, lb, ub)
    return None


def _zbox_override(zbox: Optional[tuple]) -> Optional[dict]:
    """The ``evaluate_interval`` box override for ``zbox`` at the variable's CURRENT bounds."""
    if zbox is None:
        return None
    from discopt._relax.convexity.interval import Interval

    var, k, lb, ub = zbox
    lo = np.array(np.asarray(var.lb, dtype=np.float64), dtype=np.float64, copy=True)
    hi = np.array(np.asarray(var.ub, dtype=np.float64), dtype=np.float64, copy=True)
    flat_lo, flat_hi = lo.reshape(-1), hi.reshape(-1)
    idx = slice(None) if k is None else k
    nlo = np.maximum(flat_lo[idx], lb)
    nhi = np.minimum(flat_hi[idx], ub)
    if np.any(nlo > nhi):
        # The declared bounds miss the relation's box entirely: the model is
        # infeasible, and the declared box is still a sound enclosure domain.
        return None
    flat_lo[idx], flat_hi[idx] = nlo, nhi
    return {var: Interval(lo, hi)}


def _split_enclosure(
    model: Model, expr: Expression, p: Complementarity, zbox: Optional[tuple]
) -> tuple[float, float]:
    """A finite enclosure of the residual of a two-sided box, or a loud ``ValueError``.

    The split auxiliaries ``w⁺``/``w⁻`` need finite upper bounds for an exact
    big-M/SOS1 encoding. A fabricated bound could cut the optimum, so a non-finite
    enclosure is a refusal. An exception from the interval evaluator is re-raised
    as part of that refusal, with its text (CLAUDE.md §7).
    """
    where = (
        "over the declared box with z restricted to the relation's [l, u]"
        if zbox is not None
        else "over the declared box"
    )
    try:
        lo, hi = _enclosure_of(model, expr, _zbox_override(zbox))
    except Exception as exc:
        raise ValueError(
            f"cannot bound the residual F of {p.describe()} {where}: the interval "
            f"evaluation raised {type(exc).__name__}: {exc}. The split auxiliaries "
            "w+/w- need a finite bound."
        ) from exc
    if not (np.isfinite(lo) and np.isfinite(hi)):
        raise ValueError(
            f"cannot bound the residual F of {p.describe()} {where} (enclosure "
            f"[{lo:g}, {hi:g}]). The split auxiliaries w+/w- of a two-sided box need a "
            "finite bound, and a fabricated big-M could cut the optimum. Declare finite "
            "bounds on the variables F reads."
        )
    return lo, hi


def _set_bounds_if_changed(var: Variable, lo: float, hi: float) -> bool:
    """Rebind ``var``'s box to ``(lo, hi)`` only when it differs; True when it did.

    Assigning an equal box is skipped so an unchanged model's refresh is a no-op
    (the bound-neutral regime, CLAUDE.md §5).
    """
    cur_lo = np.asarray(var.lb, dtype=np.float64)
    cur_hi = np.asarray(var.ub, dtype=np.float64)
    if np.all(cur_lo == lo) and np.all(cur_hi == hi):
        return False
    var.lb = np.full(cur_lo.shape, lo, dtype=np.float64) if cur_lo.ndim else lo
    var.ub = np.full(cur_hi.shape, hi, dtype=np.float64) if cur_hi.ndim else hi
    return True


def _operand_leaves(pair: Complementarity) -> tuple[list, list]:
    """The variables and parameters ``pair``'s operands read, each once."""
    from discopt.modeling.core import Parameter

    vs, ps = [], []
    for node in _walk_operands(pair):
        if isinstance(node, Variable):
            vs.append(node)
        elif isinstance(node, Parameter):
            ps.append(node)
    return vs, ps


def snapshot_lowering_baseline(model: Model) -> None:
    """Record, for each lowering read from a file, the box its derived bounds hold for.

    A saved document carries a lowering's rows and its auxiliaries' bounds, not the
    derivation of those bounds (:attr:`LoweringRecord.derived`). The bounds are
    valid for the box they were computed over, and stay valid when it narrows; a
    widening (or a moved parameter) is what can make one cut the optimum. The
    loader calls this, and :func:`refresh_lowering_bounds` refuses a solve or save
    after such a change.
    """
    for rel, rec in _lowered_map(model).items():
        if rec.derived is not None or rec.method in RELAXING_METHODS:
            continue
        vs, ps = _operand_leaves(rel)
        rec.baseline = [
            (v, np.array(v.lb, dtype=np.float64), np.array(v.ub, dtype=np.float64)) for v in vs
        ] + [(q, np.array(q.value, dtype=np.float64)) for q in ps]


def refresh_lowering_bounds(model: Model, *, context: str) -> int:
    """Recompute every auxiliary bound a lowering derived; return how many changed.

    A lowering that introduces an auxiliary (the split ``w±`` of a two-sided box,
    an SOS1 aux, a GDP operand lift) bounds it from an interval enclosure over the
    model's box *at lowering time*. Widening a variable afterwards -- ``x.ub = 50``
    on a model declared with ``x <= 1`` -- left that bound in place, and the stale
    big-M cut the optimum: ``status=optimal`` at -10 against a true -50 (#2061
    review, blocker). Every solve boundary calls this next to
    :func:`require_all_relations_lowered`, so the aux bounds always enclose the box
    actually being solved. An unchanged model is left exactly as it was.

    A record read from a file carries no derivation; for it, a widened bound or a
    moved parameter on a variable the relation reads is refused here (see
    :func:`snapshot_lowering_baseline`), never solved on bounds that may be stale.
    """
    changed = 0
    for rel, rec in _lowered_map(model).items():
        if rec.derived is not None:
            for d in rec.derived:
                lo, hi = d.bounds(model)
                changed += _set_bounds_if_changed(d.var, lo, hi)
        elif rec.baseline is not None:
            _refuse_widened_baseline(rel, rec.baseline, context)
    return changed


def _refuse_widened_baseline(rel: Complementarity, baseline: list, context: str) -> None:
    for entry in baseline:
        if len(entry) == 3:
            v, lb0, ub0 = entry
            lb, ub = np.asarray(v.lb), np.asarray(v.ub)
            if lb.shape == lb0.shape and not (np.any(lb < lb0) or np.any(ub > ub0)):
                continue
            what = f"variable {v.name!r} was widened"
        else:
            q, val0 = entry
            val = np.asarray(q.value)
            if val.shape == val0.shape and np.array_equal(val, val0):
                continue
            what = f"parameter {q.name!r} changed value"
        raise ValueError(
            f"{context}: {what} after this model was read from a file, and "
            f"{rel.describe()} was lowered before it was saved. The file records the "
            "auxiliary bounds that lowering derived from the box at save time, not how "
            "they were derived, so they may no longer enclose the widened box and "
            "could cut the optimum. Re-declare the relation on a model built in this "
            "session (or narrow the bound back) before solving or saving."
        )


def _index(expr: Expression, shape: tuple[int, ...], k: int) -> Expression:
    """Return element ``k`` (row-major) of a vector/array expression."""
    idx = tuple(int(v) for v in np.unravel_index(k, shape))
    elem = expr[idx[0]] if len(idx) == 1 else expr[idx]
    return cast(Expression, elem)


def _element_of(
    parent: Complementarity,
    f: Expression,
    g: Expression,
    name: str,
    index: Optional[tuple[int, ...]],
) -> Complementarity:
    """One scalar element of ``parent``, inheriting its provenance.

    Role, declared operand bounds, scale and parent identity are properties of
    the *relation*, so every element carries them; ``index`` and ``source``
    record which element of which relation this is, so an elementwise residual
    is attributable back to the declared vector relation (#1147).
    """
    return Complementarity(
        f,
        g,
        name,
        role=parent.role,
        f_bounds=parent.f_bounds,
        g_bounds=parent.g_bounds,
        scale=parent.scale,
        parent=parent.parent,
        f_shape=(),
        g_shape=(),
        index=index,
        source=parent.source if parent.source is not None else parent,
    )


def _scalarize_pairs(model: Model, pairs: list[Complementarity]) -> list[Complementarity]:
    """Expand vector/array complementarity pairs into elementwise scalar pairs.

    ``0 <= f ⊥ g >= 0`` over arrays is complementarity *elementwise*: for every
    index ``i`` independently, ``f_i·g_i = 0`` with ``f_i, g_i >= 0``. A single
    disjunction over the whole vector (``all f == 0`` ∨ ``all g == 0``) is a
    strictly stronger, wrong condition, so every reformulation scalarizes first.

    A scalar side is broadcast against a vector side (e.g. one ``f`` complementary
    to each ``g_i``). Shapes that are neither equal nor scalar-broadcastable are
    rejected loudly rather than silently mis-encoded.

    Each element inherits the parent's provenance and records its own index (see
    :func:`_element_of`), and the parent caches the operand shapes it computed
    here, so :meth:`Complementarity.elements` after a rebuilding pass returns the
    same decomposition without re-deriving it.
    """
    out: list[Complementarity] = []
    for p in pairs:
        tag = _ensure_relation_name(model, p)
        ops = _element_operands(model, p)
        if ops is None:
            # The relation IS its own single element. Returning a fresh child
            # here broke the documented contract *and* the identity-keyed
            # provenance this module advertises: ``elements(m)[0] is pair`` was
            # False, and two calls returned two different objects (review of
            # #1149, LOW 7).
            out.append(p)
            continue
        for k, (fk, gk, idx) in enumerate(ops):
            out.append(_element_of(p, fk, gk, f"{tag}_{k}", idx))
    return out


def _element_operands(model: Model, p: Complementarity) -> Optional[list[tuple]]:
    """``[(f_k, g_k, index)]`` for each element of ``p``, or ``None`` for a scalar relation.

    Names nothing: :func:`_lower_each` validates every relation of a call through
    this before any is named or emitted. Caches the operand shapes on ``p`` (see
    :func:`_scalarize_pairs`).
    """
    fs = p.f_shape if p.f_shape is not None else _elem_shape(model, p.f)
    gs = p.g_shape if p.g_shape is not None else _elem_shape(model, p.g)
    p.f_shape, p.g_shape = fs, gs
    nf = _n_elements(fs)
    ng = _n_elements(gs)
    n = max(nf, ng)
    if n == 1:
        return None
    if nf not in (1, n) or ng not in (1, n):
        raise ValueError(
            f"complementarity {p.name or '<unnamed>'!r} has incompatible operand shapes "
            f"{fs} ⊥ {gs}: sides must have equal element counts, or one side "
            "must be scalar to broadcast."
        )
    shape = fs if nf == n else gs
    ops = []
    for k in range(n):
        fk = p.f if nf == 1 else _index(p.f, fs, k)
        gk = p.g if ng == 1 else _index(p.g, gs, k)
        ops.append((fk, gk, tuple(int(v) for v in np.unravel_index(k, shape))))
    return ops


def _pending(model: Model, pairs: list[Complementarity]) -> list[Complementarity]:
    """The relations in ``pairs`` whose rows ``model`` does not already carry.

    Lowering a relation twice into the *same* model silently duplicates every
    row it generates — a clone of an already-lowered model, or a second
    ``solve`` over the recorded relation set, used to do exactly that. Lowering
    the same relation object into a *different* model is legitimate (a variant
    build) and is left alone, which is why the mark is keyed to the model and
    not to the relation alone (#1147).
    """
    return [p for p in pairs if not p.is_lowered_into(model)]


def _require_not_already_lowered(model: Model, pairs: list[Complementarity]) -> None:
    """Refuse a Scholtes homotopy over relations this model lowered another way (#1446).

    :func:`reformulate_scholtes` skips a relation the model already carries rows
    for (:func:`_pending`), which is right for an idempotent re-lower: the rows
    are already there and are the same rows. For the *homotopy* it is fatal and
    silent. The ``f*g <= t`` row is never emitted, so **nothing in the model
    depends on ``t``**; the continuation then drives a parameter no constraint
    reads, every stage returns the same point, and each is recorded
    ``accepted=True, reason="subsolver converged", certified=True`` because each
    subsolve genuinely did converge -- on the unregularized problem.

    Measured on ``min (x0-2)^2 + (x1-1)^2`` s.t. ``0 <= x0 _|_ x1 >= 0`` over
    ``[0,3]^2``, whose optimum is ``1.0`` at ``(2, 0)``:

    ========================================  =========  ================
    pair built with                           objective  ``x0*x1``
    ========================================  =========  ================
    ``Model.complementarity`` (lowers eagerly)  1.67e-09  **2.0**
    ``mpec.complementarity`` (pure factory)     1.0       2.0e-08
    ========================================  =========  ================

    The first row is not an approximation of the second; it is the answer to a
    different problem, reported as a converged local solve. Hence a refusal
    rather than a silent re-lower or a warning (CLAUDE.md #3).

    :meth:`Model.complementarity` already refuses ``method="scholtes"`` and
    points at :func:`complementarity` + :func:`solve_mpec`. This closes the
    reverse direction: lowered as ``gdp``/``sos1``, then handed to the homotopy.
    """
    clashes = [
        (p, p.lowering_in(model)) for p in pairs if p.lowering_in(model) not in (None, "scholtes")
    ]
    if not clashes:
        return
    names = ", ".join(f"{p.name or '<unnamed>'} (lowered as {method!r})" for p, method in clashes)
    raise ValueError(
        f"solve_mpec(method='scholtes') cannot regularize {len(clashes)} relation(s) "
        f"this model has already lowered another way: {names}. The homotopy's "
        f"'f*g <= t' row is only emitted for a relation it lowers itself, so it "
        f"would drive 't' with no constraint reading it and report the "
        f"UNREGULARIZED answer as a converged local solve (#1446). "
        f"Model.complementarity(...) lowers on the spot -- build the pair with "
        f"discopt.mpec.complementarity(f, g) instead, which records the relation "
        f"without lowering it, and pass it here."
    )


def _box_form(p: Complementarity) -> tuple[float, float]:
    """The validated box ``(l, u)`` of a relation that is not the symmetric pair.

    A box-MCP relation declares its residual **free**, ``f_bounds == (-inf, +inf)``,
    and its complementary side on ``[l, u]``. :class:`Complementarity` is public and
    constructible directly, so any other residual bounds can reach a lowering; no
    lowering here encodes them, and guessing would change the condition. An empty
    box (``l > u``) is refused here too, since a direct construction bypasses the
    check in :func:`box_mcp`.
    """
    if p.f_bounds != (-_INF, _INF):
        lo, hi = p.f_bounds
        raise ValueError(
            f"{p.describe()} declares residual bounds ({lo:g}, {hi:g}) with complementary "
            f"bounds {p.g_bounds}; a box-MCP relation declares its residual free "
            "(-inf, +inf) and the symmetric pair declares (0, +inf) on both sides. No "
            "other form is lowered, and none is guessed."
        )
    lo, hi = _normalize_bound(p.g_bounds[0]), _normalize_bound(p.g_bounds[1])
    if not lo <= hi:
        raise ValueError(f"{p.describe()}: empty box [{lo:g}, {hi:g}]")
    if lo == hi and not np.isfinite(lo):
        # ``l == u == ±inf`` reads as B0 (``l == u``) but pins z at a value no real z
        # takes: the B0 rows ``z >= l``/``z <= u`` are both dropped as infinite, so
        # the relation lowered to NO rows and the solve went on as if it were absent
        # (#2061 review). The box is empty over the reals.
        raise ValueError(
            f"{p.describe()}: box [{lo:g}, {hi:g}] pins the variable at infinity, which no "
            "real value satisfies"
        )
    return lo, hi


def _half(parent: Complementarity, f: Expression, g: Expression, name: str) -> Complementarity:
    """One NCP half ``0 <= f ⊥ g >= 0`` of a box relation's decomposition.

    A lowering internal, not a declared relation: it is not appended to
    ``model._complementarities`` and not marked lowered. The parent's
    :class:`LoweringRecord` covers every row the half emits (see :func:`_lower_each`).
    """
    return Complementarity(
        f,
        g,
        name,
        role=parent.role,
        scale=parent.scale,
        parent=parent.parent,
        f_shape=(),
        g_shape=(),
        index=parent.index,
        source=parent.source if parent.source is not None else parent,
    )


def _shift(z: Expression, lb: float) -> Expression:
    """``z - lb``, or ``z`` itself when ``lb == 0`` (the NCP rows, unchanged)."""
    return z if lb == 0.0 else z - lb


def _validate_relation(model: Model, p: Complementarity) -> Optional[tuple]:
    """Everything about scalar relation ``p`` that can refuse, with no row emitted.

    ``None`` for the symmetric pair (the NCP emitters handle it as they always
    have); for a box, ``(l, u, zbox)`` where ``zbox`` (:func:`_relation_zbox`) is
    the narrowing of ``z`` the split's enclosure of ``F`` uses, and ``False`` when
    the box needs no split (not two-sided, or ``l == u``). The enclosure itself is
    computed here, so a non-finite one refuses before any row is emitted, and
    again at every solve boundary (:func:`refresh_lowering_bounds`).
    """
    if p.is_symmetric_nonnegative:
        return None
    lb, ub = _box_form(p)
    if not (np.isfinite(lb) and np.isfinite(ub) and lb < ub):
        return lb, ub, False
    zbox = _relation_zbox(p, lb, ub)
    _split_enclosure(model, p.f, p, zbox)
    return lb, ub, zbox


def _box_decomposition(
    model: Model,
    p: Complementarity,
    plan: tuple,
    operand_lifts: Optional[list[tuple[Variable, Expression]]],
    derived: list,
    box_rows: set,
) -> list[Complementarity]:
    r"""Emit the box rows of a scalar box-MCP relation; return its NCP halves.

    ``F ⊥ z in [l, u]`` is exactly (``docs/dev/box-mcp-lowering-plan.md`` §2.1 H1):

    ====================  ==========================  ======================================
    case                  rows emitted here           NCP halves returned
    ====================  ==========================  ======================================
    B0 ``l == u``         ``z >= l``, ``z <= u``      none -- ``F`` is free
    B1 both finite        box rows, ``F == w⁺ - w⁻``  ``0 <= w⁺ ⊥ z - l``, ``0 <= w⁻ ⊥ u - z``
    B2 ``u = +inf``       ``z >= l``                  ``0 <= F ⊥ z - l``
    B3 ``l = -inf``       ``z <= u``                  ``0 <= -F ⊥ u - z``
    B4 both infinite      ``F == 0``                  none
    ====================  ==========================  ======================================

    In B1, an interior ``z`` makes both slacks positive, so ``w⁺ = w⁻ = 0`` and
    ``F = 0``; ``z = l < u`` forces ``w⁻ = 0`` so ``F = w⁺ >= 0``; ``z = u`` gives
    ``F = -w⁻ <= 0``. Conversely ``w± = max(±F, 0)`` satisfies every row at an MCP
    point, and the bounds ``w⁺ <= max(0, hi F)``, ``w⁻ <= max(0, -lo F)`` from a
    valid enclosure of ``F`` cut none of them.

    The box rows on ``z`` are emitted even when ``z`` is a variable whose declared
    bounds imply them: the relation's box may be narrower than the variable's, and
    tightening a shared ``Variable`` would mutate state other models hold.

    ``plan`` is :func:`_validate_relation`'s result. :func:`_lower_each` validates
    every element of every relation of a call before emitting any of them, so a
    refused call leaves the model untouched.

    The ``w±`` upper bounds are *derived* from the box, so each is recorded in
    ``derived`` (:class:`DerivedBound`) and recomputed at every solve boundary.
    ``box_rows`` holds the ``(z, l, u)`` whose rows this relation already emitted:
    a vector residual against one scalar ``z`` shares a single box, and its rows
    are written once, not once per element (#2061 review).
    """
    from discopt.modeling.core import maximum

    tag = p.name or "compl"
    lb, ub, zbox = plan
    z, F = p.g, p.f
    key = (id(z), lb, ub)
    if key not in box_rows:
        box_rows.add(key)
        if np.isfinite(lb):
            model.subject_to(z >= lb, name=f"{tag}_z_lb")
        if np.isfinite(ub):
            model.subject_to(z <= ub, name=f"{tag}_z_ub")
    if lb == ub:  # B0
        return []
    if zbox is not False:  # B1
        flo, fhi = _split_enclosure(model, F, p, zbox)
        model._aux_counter += 1
        wp = model.continuous(f"_{tag}_wp_{model._aux_counter}", lb=0.0, ub=max(0.0, fhi))
        model._aux_counter += 1
        wm = model.continuous(f"_{tag}_wm_{model._aux_counter}", lb=0.0, ub=max(0.0, -flo))
        derived.append(DerivedBound(wp, F, "split_pos", p, zbox))
        derived.append(DerivedBound(wm, F, "split_neg", p, zbox))
        model.subject_to(F == wp - wm, name=f"{tag}_split")
        if operand_lifts is not None:
            operand_lifts.append((wp, maximum(F, 0.0)))
            operand_lifts.append((wm, maximum(-F, 0.0)))
        return [_half(p, wp, _shift(z, lb), f"{tag}_lo"), _half(p, wm, ub - z, f"{tag}_hi")]
    if np.isfinite(lb):  # B2
        return [_half(p, F, _shift(z, lb), f"{tag}_lo")]
    if np.isfinite(ub):  # B3
        return [_half(p, -F, ub - z, f"{tag}_hi")]
    model.subject_to(F == 0, name=f"{tag}_eq")  # B4
    return []


def _emit_relation(
    model: Model,
    p: Complementarity,
    plan: Optional[tuple],
    emit_ncp,
    operand_lifts: Optional[list[tuple[Variable, Expression]]],
    derived: list,
    box_rows: set,
) -> None:
    """Lower one validated scalar relation with a method's NCP emitter.

    The symmetric pair (``plan is None``) goes straight to ``emit_ncp``, so the NCP
    path emits exactly the rows it always did. A box relation is decomposed by
    :func:`_box_decomposition` and each half goes to the same ``emit_ncp``. Which
    path is taken is read off the **declared bounds**
    (:attr:`Complementarity.is_symmetric_nonnegative`), never off ``role``.
    """
    if plan is None:
        emit_ncp(p, derived)
        return
    for half in _box_decomposition(model, p, plan, operand_lifts, derived, box_rows):
        emit_ncp(half, derived)


# ─────────────────────────── reformulations ───────────────────────────


def _validate_all(model: Model, todo: list[Complementarity]) -> None:
    """Run every refusal a lowering of ``todo`` can raise, emitting and naming nothing."""
    for parent in todo:
        ops = _element_operands(model, parent)
        if ops is None:
            _validate_relation(model, parent)
            continue
        for fk, gk, idx in ops:
            _validate_relation(model, _element_of(parent, fk, gk, parent.name or "", idx))


def _lower_each(
    model: Model,
    todo: list[Complementarity],
    method: str,
    emit_ncp,
    operand_lifts: Optional[list[tuple[Variable, Expression]]] = None,
) -> None:
    """Lower each relation in turn, recording **that relation's own** rows.

    ``emit_ncp(pair, derived)`` is a method's emitter for one scalar NCP pair; it
    appends a :class:`DerivedBound` to ``derived`` for every auxiliary bound it
    derives from the model's box. Every scalar element of **every relation in
    ``todo``** is validated first (:func:`_validate_relation`) and only then is
    anything emitted, so a call whose k-th relation (or element) refuses leaves
    no rows from the ones before it behind (#2061 review: the first version
    validated per relation, and ``reformulate_gdp(m, [r1, r2])`` with ``r2``
    unbounded left ``r1``'s 18 rows in the model). The rows appended to ``model._constraints``
    between the relation's start and end positions are the rows attributed to it.

    Per relation, not per call. The first version took one slice around the whole
    list and assigned that aggregate to *every* pair, so
    :meth:`Complementarity.rows_in` — documented as "the rows **this relation**
    generated" — returned other relations' rows, and :func:`generated_rows` then
    concatenated the aggregate once per pair: ``3N²`` rows for ``N`` scalar
    relations, so a vector relation with 1000 elements walked ~3M rows instead of
    3000 in the lowered-row residual (#1158 review, MEDIUM 6).

    Rows are identified by *position*, never by matching generated names. Name
    matching is what #1147 removed from provenance resolution and for the same
    reason: a later pass renames, and a prefix match on ``compl0_`` silently picks
    up ``compl0_extra`` from somewhere else.

    Scalarizing one relation at a time also closes a naming hole: two *unnamed*
    relations lowered in a single call were both named before either emitted a
    row, so ``_ensure_relation_name`` saw neither the other's name nor its rows
    and handed out ``compl0`` twice. Emitting between namings makes the second
    lookup see the first's rows.

    A relation whose lowering emits no ``_constraints`` row records an empty list,
    which is a *measured* answer and distinct from the untracked ``None`` a
    rebuilding pass leaves behind.
    """
    _validate_all(model, todo)
    for parent in todo:
        start = len(model._constraints)
        elems = _scalarize_pairs(model, [parent])
        derived: list = []
        box_rows: set = set()
        for elem in elems:
            plan = _validate_relation(model, elem)
            _emit_relation(model, elem, plan, emit_ncp, operand_lifts, derived, box_rows)
        parent.mark_lowered(model, method, list(model._constraints[start:]), derived=derived)


def reformulate_scholtes(model: Model, pairs: list[Complementarity], t) -> None:
    """Add Scholtes constraints ``f >= 0``, ``g >= 0``, ``f·g <= t`` for each pair.

    ``t`` may be a float or a :class:`~discopt.modeling.core.Parameter`; using a
    parameter lets :func:`solve_mpec` drive the homotopy without rebuilding the
    model. Vector/array pairs are complementarity elementwise (each ``f_i·g_i <= t``).

    Relations ``model`` already carries the rows of are skipped, not re-emitted
    (see :func:`_pending`).
    """
    todo = _pending(model, pairs)

    def emit(p: Complementarity, derived: list) -> None:
        tag = p.name
        model.subject_to(p.f >= 0, name=f"{tag}_f_nonneg")
        model.subject_to(p.g >= 0, name=f"{tag}_g_nonneg")
        model.subject_to(p.f * p.g <= t, name=f"{tag}_reg")

    _lower_each(model, todo, "scholtes", emit)


def reformulate_sos1(
    model: Model,
    pairs: list[Complementarity],
    *,
    _operand_lifts: Optional[list[tuple[Variable, Expression]]] = None,
) -> None:
    """Encode each complementarity exactly with an SOS1 set.

    Requires ``f >= 0`` and ``g >= 0`` and that at most one is nonzero. When
    ``f``/``g`` are plain variables they enter the SOS1 set directly; otherwise
    nonnegative auxiliary variables ``af == f``, ``ag == g`` are introduced. Vector/
    array pairs are complementarity elementwise (one SOS1 set per index).

    Relations ``model`` already carries the rows of are skipped, not re-emitted
    (see :func:`_pending`).
    """
    todo = _pending(model, pairs)

    def emit(p: Complementarity, derived: list) -> None:
        tag = p.name
        members: list[Variable] = []
        for side, expr in (("f", p.f), ("g", p.g)):
            if isinstance(expr, Variable) and expr.size == 1:
                model.subject_to(expr >= 0, name=f"{tag}_{side}_nonneg")
                members.append(expr)
            else:
                # Finite ub (from interval enclosure) keeps the SOS1→big-M
                # linking exact; left at inf only when genuinely unbounded, so
                # the downstream check surfaces a clear "add a finite ub" error.
                aux = model.continuous(
                    f"{tag}_{side}_aux", lb=0.0, ub=_aux_upper_bound(model, expr)
                )
                derived.append(DerivedBound(aux, expr, "sos1_aux", p))
                model.subject_to(aux == expr, name=f"{tag}_{side}_link")
                if _operand_lifts is not None:
                    _operand_lifts.append((aux, expr))
                members.append(aux)
        model.sos1(members, name=f"{tag}_sos1")

    _lower_each(model, todo, "sos1", emit, _operand_lifts)


def reformulate_native(model: Model, pairs: list[Complementarity]) -> None:
    """Encode each complementarity exactly as ``f·g <= 0`` over ``f, g >= 0`` (#2167).

    With both operands nonnegative, ``f·g <= 0`` holds exactly when ``f·g = 0``,
    so the rows are an **encoding**, not a relaxation (unlike Scholtes's
    ``f·g <= t``), and no binary or big-M constant is introduced -- the
    encoding is exact on an unbounded box. The global solver relaxes the
    product row with McCormick envelopes over the *node* box; for ``f`` in
    ``[0, u_f]`` and ``g`` in ``[0, u_g]`` the envelope is exactly the triangle
    ``f/u_f + g/u_g <= 1`` (the #245 pair cut, the convex hull of the pair),
    regenerated per node from the node's own bounds, so it is never applied
    outside the subtree whose box produced it.

    With ``DISCOPT_COMPL_BRANCH=1`` the spatial tree also registers each pair and
    splits a violated pair into ``ub(f)=0`` / ``ub(g)=0`` (the native
    complementarity branch) before its ordinary rules. Flag off, the same model
    is solved by ordinary spatial branching on the product row: still exact,
    only the branching order differs.

    Requires every scalar pair to be the symmetric ``(0, inf)`` form with both
    operands **single variable elements whose declared lower bound is >= 0**:
    the dichotomy fixes an operand by its bound, which states ``f = 0`` only for
    such a column. Anything else is refused before any row is emitted; lower it
    with :func:`reformulate_gdp` or :func:`reformulate_sos1` instead.
    """
    todo = _pending(model, pairs)
    offsets = _target_flat_offsets(model)
    bad: list[str] = []
    for p in _scalarize_pairs(model, todo):
        if not p.is_symmetric_nonnegative:
            bad.append(f"{p.describe()}: not the symmetric (0, inf) pair")
            continue
        for side, expr in (("f", p.f), ("g", p.g)):
            if _variable_slot(model, expr, offsets) is None:
                bad.append(f"{p.describe()}: operand {side} is not a single variable element")
                continue
            lo = float(np.min(np.asarray(_operand_leaves_lb(expr))))
            if lo < 0.0:
                bad.append(f"{p.describe()}: operand {side} has declared lb {lo:g} < 0")
    if bad:
        raise ValueError(
            "native complementarity lowering needs each pair to be two single variable "
            "elements declared >= 0 (the branch fixes a side by its bound): "
            + "; ".join(bad)
            + ". Use method='gdp' or 'sos1' for these relations."
        )

    def emit(p: Complementarity, derived: list) -> None:
        tag = p.name
        model.subject_to(p.f >= 0, name=f"{tag}_f_nonneg")
        model.subject_to(p.g >= 0, name=f"{tag}_g_nonneg")
        model.subject_to(p.f * p.g <= 0, name=f"{tag}_native")

    _lower_each(model, todo, "native", emit)


def _operand_leaves_lb(expr: Expression):
    """Declared lower bound of a variable element operand (``Variable`` or ``x[k]``)."""
    from discopt.modeling.core import IndexExpression

    if isinstance(expr, Variable):
        return np.asarray(expr.lb, dtype=np.float64)
    assert isinstance(expr, IndexExpression) and isinstance(expr.base, Variable)
    return np.asarray(expr.base.lb, dtype=np.float64).reshape(expr.base.shape or ())[expr.index]


def native_pair_columns(model: Model) -> list[tuple[int, int]]:
    """``(f_col, g_col)`` for every scalar pair ``model`` lowered with ``"native"``.

    The columns are flat indices in ``model._variables`` order, which is the
    layout the solver's tree uses. Empty when no relation was lowered natively.
    """
    offsets = _target_flat_offsets(model)
    out: list[tuple[int, int]] = []
    native = [p for p in model._complementarities if p.lowering_in(model) == "native"]
    for p in _scalarize_pairs(model, native):
        fc = _variable_slot(model, p.f, offsets)
        gc = _variable_slot(model, p.g, offsets)
        if fc is None or gc is None:
            raise ComplementarityProvenanceError(
                f"{p.describe()} is marked lowered 'native' in this model but its "
                "operands no longer resolve to variable columns"
            )
        out.append((fc, gc))
    return out


def reformulate_gdp(
    model: Model,
    pairs: list[Complementarity],
    *,
    _operand_lifts: Optional[list[tuple[Variable, Expression]]] = None,
) -> None:
    """Encode each complementarity exactly as a disjunction ``(f==0) ∨ (g==0)``.

    With ``f, g >= 0`` this is equivalent to ``f·g == 0``. The disjunction is
    added via :meth:`Model.either_or` and lowered to a big-M model with a
    selector binary by the GDP pass at solve time, so branch-and-bound branches
    on the finite either/or choice and the integrality-aware FBBT can infer one
    side is zero when the other is bounded away from zero (the backward
    complementarity rule).

    Nonlinear operands are lifted into a scalar auxiliary variable
    ``u == expr`` (with finite interval bounds) so the disjunct ``u == 0`` stays
    linear and big-M is exact; plain scalar variables enter the disjunction
    directly. Lifting also keeps the nonlinear part as an ordinary smooth
    equality handled natively by the NLP relaxation — avoiding the perspective
    of a nonlinear equality, whose big-M relaxation is bounded unreliably and
    whose hull form often cannot be linearized.

    Vector/array pairs are complementarity elementwise: each index becomes its own
    ``(f_i==0) ∨ (g_i==0)`` disjunction, not a single all-zero-vector disjunction.

    Relations ``model`` already carries the rows of are skipped, not re-emitted
    (see :func:`_pending`).
    """
    todo = _pending(model, pairs)

    def emit(p: Complementarity, derived: list) -> None:
        # _scalarize_pairs always assigns a name; narrow Optional[str] -> str.
        tag = p.name or "compl"
        fv = _gdp_operand(model, p.f, tag, "f", _operand_lifts, derived, p)
        gv = _gdp_operand(model, p.g, tag, "g", _operand_lifts, derived, p)
        model.subject_to(fv >= 0, name=f"{tag}_f_nonneg")
        model.subject_to(gv >= 0, name=f"{tag}_g_nonneg")
        model.either_or(
            [[_gdp_zero_row(p, fv, tag, "f")], [_gdp_zero_row(p, gv, tag, "g")]], name=tag
        )

    _lower_each(model, todo, "gdp", emit, _operand_lifts)


def _gdp_zero_row(p: Complementarity, operand: Expression, tag: str, side: str) -> Constraint:
    """The disjunct ``operand == 0``, with a hint for an unbounded big-M.

    The GDP pass refuses a disjunct whose body has no finite enclosure, which
    read as ``cannot bound the body of constraint '<unnamed>'`` with no pointer
    back to the relation (#2061 review). The commonest cause is a box relation
    whose ``z`` is declared unbounded: ``[l, u]`` is enforced by rows, and a
    big-M reads only declared variable bounds. The row stays unnamed -- a name is
    written by ``save`` and would change every lowered document -- so the hint
    carries the relation instead. It is session-local (a loaded row has none).
    """
    row = cast(Constraint, operand == 0)
    row._big_m_hint = (  # type: ignore[attr-defined]
        f" This disjunct ({side} == 0) comes from {p.describe()}, lowered with "
        "method='gdp'. A "
        "complementarity's box [l, u] is enforced by rows, which a big-M does not "
        "read: declare finite bounds on the variables of this side (for a box "
        "relation, give z its own lb/ub, e.g. within [l, u])."
    )
    return row


def _gdp_operand(
    model: Model,
    expr: Expression,
    tag: str,
    side: str,
    operand_lifts: Optional[list[tuple[Variable, Expression]]] = None,
    derived: Optional[list] = None,
    pair: Optional[Complementarity] = None,
) -> Expression:
    """Return a linear operand for a GDP complementarity disjunct.

    Linear expressions are used directly; nonlinear bodies are lifted to a
    scalar auxiliary variable with finite interval bounds. Those bounds are
    derived from the model's box, so the lift is recorded in ``derived`` and
    recomputed at every solve boundary (:func:`refresh_lowering_bounds`).
    """
    from discopt._relax.gdp_reformulate import _is_linear

    if _is_linear(expr):
        return expr
    lo, hi = model._branch_bounds(expr, expr)
    model._aux_counter += 1
    u = model.continuous(f"_{tag}_{side}_{model._aux_counter}", lb=lo, ub=hi)
    if derived is not None and pair is not None:
        derived.append(DerivedBound(u, expr, "gdp_lift", pair))
    model.subject_to(u == expr, name=f"{tag}_{side}_lift")
    if operand_lifts is not None:
        operand_lifts.append((u, expr))
    return u


def tighten_complementarity_bounds(model: Model, pairs: list[Complementarity]) -> int:
    """Complementarity bound propagation for plain variable pairs.

    If one side of ``0 <= x ⊥ y >= 0`` is provably strictly positive
    (``lb > 0``), the other side must be zero. Applied only to single-variable
    sides, where the implication is sound and exact. Returns the number of
    variables fixed to zero.

    The partner is fixed by *intersecting* its upper bound with 0 — the lower
    bound is never overwritten. If the partner already carries a strictly
    positive lower bound the complementarity is genuinely infeasible (both sides
    would be > 0); that is surfaced as a ``ValueError`` rather than silently
    collapsing the box to ``[0, 0]`` and hiding the infeasibility (MP-1).

    Raises
    ------
    ValueError
        If a fixed-to-zero partner has a strictly positive declared lower bound,
        i.e. the complementarity pair is infeasible.
    """
    fixed = 0
    for p in pairs:
        if not p.is_symmetric_nonnegative:
            # The implication "one side strictly positive => partner is 0" is a
            # property of the *nonnegative* pair. On a box relation the partner is
            # pinned to a bound of [l, u], not to 0, so applying this rule would
            # fabricate a bound and could cut the solution out of the box. The box
            # generalization is a separate change (plan §10.3 of
            # docs/dev/box-mcp-lowering-plan.md). Keyed to the declared bounds,
            # not to ``role`` (review of #1149, HIGH 2).
            continue
        f_var = p.f if isinstance(p.f, Variable) and p.f.size == 1 else None
        g_var = p.g if isinstance(p.g, Variable) and p.g.size == 1 else None
        if f_var is not None and float(f_var.lb) > 0.0 and g_var is not None:
            _fix_partner_to_zero(g_var, driver=f_var, tag=p.name)
            fixed += 1
        elif g_var is not None and float(g_var.lb) > 0.0 and f_var is not None:
            _fix_partner_to_zero(f_var, driver=g_var, tag=p.name)
            fixed += 1
    return fixed


def _fix_partner_to_zero(partner: Variable, *, driver: Variable, tag: str | None) -> None:
    """Force a complementarity partner to 0 by intersecting its ub with 0.

    ``driver`` is strictly positive (``lb > 0``), so ``0 <= f ⊥ g >= 0`` forces
    ``partner == 0``. Intersect ``partner.ub`` with 0 without touching
    ``partner.lb``; if that lower bound is itself positive the box is empty and
    the pair is infeasible — raise rather than overwrite ``lb`` (MP-1).
    """
    if float(partner.lb) > 0.0:
        raise ValueError(
            f"Complementarity {tag or '<unnamed>'} is infeasible: one side has "
            f"lb={float(driver.lb):g} > 0, forcing the partner to 0, but the partner "
            f"has lb={float(partner.lb):g} > 0 — 0 <= f _|_ g >= 0 cannot hold."
        )
    partner.ub = np.minimum(np.array(partner.ub, dtype=np.float64), 0.0)


# ─────────────────────────────── solve ───────────────────────────────


def _source_snapshot(model: Model) -> tuple[list, dict[int, tuple]]:
    """Freeze what "the source model" means, **before** any lowering runs.

    Returns the model's constraint rows and a copy of every variable's declared
    bounds. Both halves matter and both are easy to get wrong by taking them
    later:

    * the rows, because after a Scholtes lowering the model also holds
      ``f·g <= t`` — measuring "source primal feasibility" against that includes
      the regularized row and stops being a statement about the user's model;
    * the bounds, because a complementarity bound tightening or a presolve moves
      them, and a point is then judged against a box the user never declared.

    Rows are captured as the ``Constraint`` objects themselves (not copies): the
    source expression tree is exactly what #1148 requires the residual to be
    evaluated against.
    """
    from discopt.mpec_report import _model_rows

    rows = _model_rows(model)
    bounds = {
        id(v): (
            np.array(v.lb, dtype=np.float64, copy=True),
            np.array(v.ub, dtype=np.float64, copy=True),
        )
        for v in model._variables
    }
    return rows, bounds


def _report_for(
    model: Model,
    pairs: list[Complementarity],
    snapshot: tuple[Optional[list], Optional[dict[int, tuple]]],
    point_fn,
    *,
    kind: str,
    continuation=None,
    notes: tuple[str, ...] = (),
):
    """Build the #1148 source-residual report for a point, or ``None`` without one.

    A residual that cannot be measured **refuses** — ``evaluate_at_point`` raises
    rather than reporting the midpoint of a widened enclosure, which is the whole
    point of the instrument. But that refusal must not take the *solve* with it:
    ``_report_for`` runs after ``Model.solve`` has already returned a certified
    result, and the report is a reporting layer on top of it. Before this, a model
    with one row the interval evaluator cannot walk (a variable exponent ``u**v``,
    say) turned a completed ``solve_mpec`` call into a ``ValueError`` — and the
    offending row need not have anything to do with the relations, since source
    primal feasibility walks every source row (#1158 review, HIGH 3).

    So the failure is downgraded to ``mpec_report = None`` — but never silently
    (CLAUDE.md §7): it warns, naming the exception. ``None`` means "not measured",
    never "measured clean"; :attr:`SolveResult.mpec_report` says so.
    """
    import warnings

    from discopt.mpec_report import source_residual_report

    rows, bounds = snapshot
    try:
        # ``point_fn`` is a CALLABLE, not a point, so resolving the point happens
        # INSIDE this guard. It used to be an argument expression -- evaluated
        # before the function was entered, so ``_result_point``'s own
        # "result does not carry variable ..." refusal sailed straight past the
        # ``except`` and turned a finished, certified ``Model.solve`` into an
        # exception out of ``solve_mpec``: the very HIGH-3 class this guard exists
        # to close (#1158 review 2, MEDIUM 4).
        point = point_fn() if callable(point_fn) else point_fn
        if point is None:
            return None
        return source_residual_report(
            model,
            pairs,
            point=point,
            kind=kind,
            source_constraints=rows,
            source_bounds=bounds,
            continuation=continuation,
            lowered_rows=generated_rows(model, pairs),
            notes=notes,
        )
    except Exception as exc:  # noqa: BLE001 - reported loudly, never swallowed
        warnings.warn(
            f"solve_mpec: the source-residual report could not be measured "
            f"({type(exc).__name__}: {exc}). The solve result is unaffected and is "
            "returned as-is; result.mpec_report is None, which means NOT MEASURED — "
            "it does not mean the source residuals are clean.",
            RuntimeWarning,
            stacklevel=3,
        )
        return None


def _result_point(model: Model, result):
    """``point_from_flat`` for a solver result's incumbent, or ``None`` if it has none.

    A result with no incumbent legitimately has nothing to measure. A result
    whose ``x`` is a dict *missing* one of the model's variables is a different
    thing entirely — an inconsistency between the result and the model — and
    raises rather than silently producing a report over a partial point.
    """
    from discopt.mpec_report import point_from_flat

    x = getattr(result, "x", None)
    if x is None:
        return None
    if isinstance(x, np.ndarray):
        return point_from_flat(model, x)
    if not x:
        return None
    parts = []
    for v in model._variables:
        if v.name not in x:
            raise ValueError(
                f"solve result does not carry variable {v.name!r}, so a source residual "
                "would be measured at a partial point. Refusing (CLAUDE.md §6)."
            )
        parts.append(np.atleast_1d(np.asarray(x[v.name], dtype=np.float64)).ravel())
    return point_from_flat(model, np.concatenate(parts)) if parts else None


def source_residuals(
    model: Model,
    result,
    *,
    kind: str = "auto",
    source_constraints=None,
    source_bounds=None,
):
    """The #1148 source-residual report for any result over ``model``'s relations.

    :func:`solve_mpec` attaches one automatically; this is the entry point for a
    model whose relations were lowered by :meth:`Model.complementarity` and
    solved with a plain :meth:`Model.solve` — that path returns a certified
    global result, and this says what the *source* relations read at its
    incumbent (§C: validation is performed on the source model, not only on the
    generated NLP; a smoothing tolerance can be small while a truth value near a
    strict predicate boundary has already flipped).

    ``source_constraints``/``source_bounds`` are the pre-lowering snapshot, when
    the caller has one. Without it the report is measured against the model's
    *current* rows and bounds, and says so in its ``notes`` rather than
    presenting a mixed reading as a source one.

    Returns ``None`` when the result carries no incumbent — there is nothing to
    measure, and a report of zeros would read as a clean pass.
    """
    return _report_for(
        model,
        list(model._complementarities),
        (source_constraints, source_bounds)
        if source_constraints is not None
        else (None, source_bounds),
        lambda: _result_point(model, result),
        kind=kind,
    )


def solve_mpec(
    model: Model,
    pairs: list[Complementarity],
    *,
    method: str = "scholtes",
    t0: float = 1.0,
    sigma: float = 0.1,
    t_min: float = 1e-8,
    max_iter: int = 16,
    x0: Optional[np.ndarray] = None,
    nlp_options: Optional[dict] = None,
    residual_kind: str = "auto",
    **solve_kwargs,
) -> "SolveResult":
    """Solve an MPEC by reformulating its complementarity conditions.

    Parameters
    ----------
    model : Model
        Model carrying the objective and any ordinary constraints. It is
        augmented in place with the reformulation constraints.
    pairs : list[Complementarity]
        The complementarity conditions ``0 <= f ⊥ g >= 0``.
    method : {"scholtes", "sos1", "gdp", "native"}
        ``"scholtes"`` runs a homotopy of *local* NLP solves with the
        regularization ``t`` shrinking ``t0 -> t0·sigma -> ...`` until ``t_min``.
        ``"sos1"`` encodes each pair as a Special Ordered Set of type 1 and
        ``"gdp"`` as the exact disjunction ``(f==0) ∨ (g==0)``; both build a
        standard model and call the global MINLP solver (``solve_kwargs``
        forwarded to :meth:`Model.solve`). ``"gdp"`` typically explores far
        fewer nodes than the smooth bilinear encoding. ``"native"`` (#2167) is
        that bilinear encoding, ``f·g <= 0`` over ``f, g >= 0`` (see
        :func:`reformulate_native`): exact, no binaries, and with
        ``DISCOPT_COMPL_BRANCH=1`` the tree branches on the pairs directly.
    residual_kind : str
        Which complementarity residual definition to report; see
        :class:`discopt.mpec_report.ComplementarityKind`. Reporting only — it
        changes no lowering and no solver behaviour.
    initial_solution : dict, optional
        For exact methods, a source-variable warm start forwarded through
        ``solve_kwargs``. Generated operand auxiliaries are evaluated at the
        validated source point. An auxiliary that cannot be evaluated is
        omitted with a warning and receives the usual midpoint default; source
        values and other successfully lifted auxiliaries are retained.

    Returns
    -------
    discopt.modeling.core.SolveResult
        **The same type for all three methods** (#1148 §D). Before this, switching
        one keyword changed the returned type, the type of ``status`` (enum vs.
        str) and whether a certification field existed at all, so no caller could
        write one branch that read a result.

        The global methods return the certified result of :meth:`Model.solve`
        unchanged. The Scholtes arm returns a **local** result:
        ``status="local_optimal"`` for a converged stationary point,
        ``"local_infeasible"`` when no local point was found —
        never ``"infeasible"``, which would publish a stalled continuation as an
        infeasibility proof. A local result carries ``gap_certified=False`` and
        no ``bound``; :class:`~discopt.modeling.core.SolveResult` enforces that.

        Every method attaches ``result.mpec_report``, a
        :class:`~discopt.mpec_report.SourceResidualReport` measured on the
        relations' **source** operands, with the lowered rows' own residual
        beside it. On a Scholtes result it also carries the continuation trace
        (per-stage ``t``, status, accept/reject reason and source residual) and
        the ``sqrt(t)`` accuracy floor, so the achieved source residual is
        reported independently of the final homotopy parameter.
    """
    # The relations become the model's durable record (#1147) before anything is
    # lowered, so ``model._complementarities`` describes the model afterwards and a
    # later ``source_residuals(model, result)`` measures the relations that were
    # actually solved rather than an empty list.
    # Validated first: a relation the lowering will refuse must not be registered
    # on the model on its way to the refusal (#2061 review).
    _validate_all(model, _pending(model, list(pairs) or list(model._complementarities)))
    register_relations(model, list(pairs))
    report_pairs = list(pairs) if pairs else list(model._complementarities)
    snapshot = _source_snapshot(model)

    if method in ("sos1", "gdp", "native"):
        if solve_kwargs.get("stream"):
            # The unified return type is a SolveResult (#1148 §D). ``stream=True``
            # makes ``Model.solve`` return an iterator of updates instead, which
            # carries no place to attach a residual report and would silently make
            # one method's return type differ from the other two again.
            raise ValueError(
                "solve_mpec does not support stream=True: it returns one SolveResult "
                "for every method (#1148). Call Model.solve(stream=True) directly on "
                "the reformulated model if you need the update stream."
            )
        from discopt.transformations import get as _get_transformation

        # Flatten the caller's point while the model still has exactly the
        # source variables.  The exact lowerings below may append continuous
        # operand auxiliaries.  If validation waits until Model.solve, those
        # new columns receive midpoint defaults and the vector is already full
        # width by the time solve-time completion runs (#1528).
        initial_solution = solve_kwargs.get("initial_solution")
        source_point = None
        if initial_solution is not None:
            from discopt.mpec_report import point_from_flat
            from discopt.warm_start import unflatten_solution, validate_initial_solution

            source_x = validate_initial_solution(model, initial_solution)
            source_point = point_from_flat(model, source_x)
            validated = unflatten_solution(model, source_x)
            # Forward clamped/rounded values so Model.solve does not warn twice.
            # Keep omitted variables omitted: explicitly supplying an integer
            # midpoint would make the second validation round that default.
            initial_solution = {v: validated[v] for v in initial_solution}
            solve_kwargs = dict(solve_kwargs)
            solve_kwargs["initial_solution"] = initial_solution

        operand_lifts: list[tuple[Variable, Expression]] = []

        if method == "native":
            _get_transformation("mpec.native").apply(model, pairs=pairs)
        else:
            _get_transformation("mpec.sos1" if method == "sos1" else "mpec.gdp").apply(
                model, pairs=pairs, _operand_lifts=operand_lifts
            )
        if source_point is not None and operand_lifts:
            import warnings

            from discopt.mpec_report import evaluate_at_point

            assert initial_solution is not None  # narrowed with source_point above
            lifted = dict(initial_solution)
            for auxiliary, expression in operand_lifts:
                lift_error = None
                try:
                    value = np.asarray(
                        evaluate_at_point(model, expression, source_point),
                        dtype=np.float64,
                    )
                except Exception as exc:  # noqa: BLE001 - a warm start is only a hint
                    lift_error = f"{auxiliary.name!r}: {type(exc).__name__}: {exc}"
                else:
                    if value.size != auxiliary.size or not np.all(np.isfinite(value)):
                        lift_error = (
                            f"{auxiliary.name!r}: source expression produced shape "
                            f"{value.shape} with {value.size} entries and finite="
                            f"{bool(np.all(np.isfinite(value)))}"
                        )
                    else:
                        lifted[auxiliary] = value.reshape(auxiliary.shape)
                if lift_error is not None:
                    warnings.warn(
                        "solve_mpec could not lift a generated exact-MPEC operand "
                        f"auxiliary ({lift_error}). Using its midpoint default; "
                        "source values and other lifted auxiliaries are retained.",
                        RuntimeWarning,
                        stacklevel=2,
                    )
            solve_kwargs["initial_solution"] = lifted
        result = cast("SolveResult", model.solve(**solve_kwargs))
        result.mpec_report = _report_for(
            model,
            report_pairs,
            snapshot,
            lambda: _result_point(model, result),
            kind=residual_kind,
            notes=(
                f"global method {method!r}: the status and bound are the solver's own "
                "certified result; the residuals below are the SOURCE reading of the "
                "returned incumbent",
            ),
        )
        return result

    if method != "scholtes":
        raise ValueError(
            f"unknown MPEC method {method!r}; use 'scholtes', 'sos1', 'gdp' or 'native'"
        )

    return _solve_scholtes(
        model,
        pairs,
        report_pairs=report_pairs,
        snapshot=snapshot,
        t0=t0,
        sigma=sigma,
        t_min=t_min,
        max_iter=max_iter,
        x0=x0,
        nlp_options=nlp_options,
        residual_kind=residual_kind,
        solve_kwargs=solve_kwargs,
    )


def _solve_scholtes(
    model: Model,
    pairs: list[Complementarity],
    *,
    report_pairs: list[Complementarity],
    snapshot,
    t0: float,
    sigma: float,
    t_min: float,
    max_iter: int,
    x0,
    nlp_options,
    residual_kind: str,
    solve_kwargs: dict,
) -> "SolveResult":
    """The Scholtes regularization homotopy, as a local :class:`SolveResult`.

    The continuation is a sequence of *local* NLP solves on a relaxed problem, so
    nothing it produces is a certificate. What the result reports instead:

    * ``status`` from :mod:`discopt.status` — ``local_optimal`` when a stage
      converged, ``local_infeasible`` when none did. A stalled continuation is
      **not** an infeasibility proof and must never be published as one (#1148 §B);
    * the full continuation trace rather than the final ``t`` alone, so
      "converged at 1e-8" and "stalled at 1e-2" are distinguishable;
    * the achieved **source** complementarity residual, independent of that final
      ``t``, beside the ``sqrt(t)`` accuracy floor the regularization imposes.
    """
    _refuse_scholtes_solve_kwargs(solve_kwargs, "solve_mpec(method='scholtes')")
    t = _lower_scholtes(model, pairs, t0)
    result, _best_x = _scholtes_homotopy(
        model,
        t,
        report_pairs=report_pairs,
        snapshot=snapshot,
        t0=t0,
        sigma=sigma,
        t_min=t_min,
        max_iter=max_iter,
        x0=x0,
        nlp_options=nlp_options,
        residual_kind=residual_kind,
    )
    return result


def _refuse_scholtes_solve_kwargs(solve_kwargs: dict, who: str) -> None:
    """A Scholtes run is local NLP solves; a ``Model.solve`` kwarg would be ignored."""
    if solve_kwargs:
        raise TypeError(
            f"{who} takes no Model.solve keyword arguments "
            f"(got {sorted(solve_kwargs)}). The homotopy is a sequence of local NLP "
            "solves, not a call to the global solver, so a forwarded 'time_limit' or "
            "'validate' would have been accepted and silently ignored."
        )


def _lower_scholtes(model: Model, pairs: list[Complementarity], t0: float):
    """Emit the Scholtes rows for ``pairs`` once; return the ``t`` parameter."""
    _require_not_already_lowered(model, pairs)
    t = model.parameter("_mpec_t", value=t0)
    from discopt.transformations import get as _get_transformation

    _get_transformation("mpec.scholtes").apply(model, pairs=pairs, t=t)
    return t


def _scholtes_homotopy(
    model: Model,
    t,
    *,
    report_pairs: list[Complementarity],
    snapshot,
    t0: float,
    sigma: float,
    t_min: float,
    max_iter: int,
    x0,
    nlp_options,
    residual_kind: str,
    deadline: Optional[float] = None,
) -> "tuple[SolveResult, Optional[np.ndarray]]":
    """One Scholtes continuation from ``x0`` on an already-lowered model.

    ``deadline`` (a ``time.perf_counter()`` value, default ``None`` = none) caps
    the continuation: no stage starts past it, and each stage's NLP gets the
    remaining time as its ``max_wall_time``. ``solve_mpec`` passes none, so its
    behaviour is unchanged; the multistart driver passes its budget (#2167).

    Returns the local :class:`SolveResult` (see :func:`_solve_scholtes`) and the
    reported flat point (``None`` when no stage produced a usable one). Split out
    of :func:`_solve_scholtes` so a multistart driver lowers the relations once
    and runs one continuation per start (#2167); the body is unchanged.
    """
    from discopt._tape_nlp_evaluator import make_evaluator
    from discopt.modeling.core import SolveResult
    from discopt.mpec_report import (
        ContinuationStage,
        ContinuationTrace,
        admitted_residual_scale,
        max_source_complementarity,
        point_from_flat,
    )
    from discopt.solvers import SolveStatus
    from discopt.solvers.nlp_backend import get_nlp_solver

    # Terminal codes whose returned point is worth taking forward. OPTIMAL is a
    # certified local solution; ITERATION_LIMIT covers Ipopt's code 3 stall, which
    # is the expected late-stage outcome of a Scholtes homotopy. INFEASIBLE and
    # ERROR are NOT here: their "point" is wherever restoration stopped and stands
    # for nothing. See the comment at the acceptance test below.
    _USABLE_STAGE_STATUSES = (SolveStatus.OPTIMAL, SolveStatus.ITERATION_LIMIT)

    backend = get_nlp_solver("auto")
    opts = dict(nlp_options) if nlp_options else {}
    opts.setdefault("print_level", 0)

    lb, ub = _flat_bounds(model)
    x_cur = (
        np.clip(np.asarray(x0, dtype=np.float64), lb, ub) if x0 is not None else _midpoint(lb, ub)
    )

    stages: list[ContinuationStage] = []
    residual_failures: list[str] = []
    best_x: Optional[np.ndarray] = None
    best_obj: Optional[float] = None
    best_t: Optional[float] = None
    # Whether the stage that produced ``best_x`` CONVERGED, as opposed to merely
    # handing back the point it stopped at. The reported status turns on this.
    best_certified = False
    termination = "max_iter"
    wall0 = time.perf_counter()
    tv = t0
    for it in range(max_iter):
        if deadline is not None:
            remaining = deadline - time.perf_counter()
            if remaining <= 0.0:
                termination = "time_limit"
                break
            opts["max_wall_time"] = max(1e-3, remaining)
        t.value = np.asarray(tv, dtype=np.float64)
        # Re-request the evaluator so the updated parameter value is compiled in.
        # #1063: the canonical funnel, not the JAX ctor. The cache fingerprint
        # excludes ``Parameter.value`` on purpose, but ``TapeNLPEvaluator``
        # snapshots values and rebuilds when they move, so the homotopy still sees
        # the current ``t``.
        evaluator = make_evaluator(model)
        try:
            stage_result = backend(evaluator, x_cur, options=opts)
        except Exception as e:
            # MP-2: never swallow silently. A first-iteration failure has no
            # point to fall back on — surface it; a later continuation failure
            # keeps the best point found so far (valid at a larger t) and is
            # recorded in the trace rather than erased from it.
            if best_x is None:
                raise RuntimeError(
                    f"MPEC NLP solve failed on the first homotopy iteration (t={tv:g}): {e}"
                ) from e
            stages.append(
                ContinuationStage(
                    iteration=it,
                    t=float(tv),
                    status="error",
                    accepted=False,
                    reason=f"subsolver raised {type(e).__name__}: {e}",
                )
            )
            termination = "subsolver_failure"
            break

        # A stage is USABLE when the subsolver returned a point it stopped at, not
        # only when it reported OPTIMAL. Scholtes subproblems get progressively
        # more degenerate as t -> 0 (MFCQ fails in the limit), so Ipopt code 3
        # (``Search_Direction_Becomes_Too_Small`` -> ITERATION_LIMIT here) at the
        # late, small-t stages is the EXPECTED case, not a failure: this repo's own
        # note on that code says it means the IPM stalled at or near a local
        # solution it cannot certify to tolerance. Accepting only OPTIMAL threw
        # those away, so a run whose t=1e-1 stage converged and whose t=1e-2..1e-8
        # stages stalled reported the t=1e-1 point (source residual ~1e-1) instead
        # of the ~1e-4 one the pre-#1148 code returned -- and a run where every
        # stage stalled returned ``local_infeasible`` with no point at all, having
        # had one in hand (#1158 review 2, MEDIUM 5).
        #
        # ``local_optimal`` still means "a local stationary point"; a stalled-but-
        # usable stage is recorded as such in the trace's ``reason`` and in
        # ``stage_certified``, so the distinction survives rather than being
        # flattened either way.
        certified_stage = stage_result.status is SolveStatus.OPTIMAL
        usable = stage_result.status in _USABLE_STAGE_STATUSES
        has_point = stage_result.x is not None
        converged = certified_stage
        # In MODEL units, like the returned ``SolveResult.objective``. The NLP
        # backend minimises the negation for a MAXIMIZE model, and recording the
        # raw value left ``stages[-1].objective`` and ``result.objective``
        # differing by a sign on every maximize MPEC -- in the very trace schema
        # this slice proposes to share across repositories (#1158 review, LOW 8).
        stage_obj = (
            None if stage_result.objective is None else _model_units(model, stage_result.objective)
        )
        stage_res = None
        if has_point:
            x_cur = np.asarray(stage_result.x, dtype=np.float64)
            try:
                stage_res = max_source_complementarity(
                    model, report_pairs, point_from_flat(model, x_cur), kind=residual_kind
                )
            except Exception as exc:  # noqa: BLE001 - recorded in the trace, never silent
                # Same rule as ``_report_for``: the residual may refuse, and the
                # refusal must not take the SOLVE with it. This call was bare, so
                # one operand the interval evaluator cannot walk aborted the whole
                # homotopy on its first iteration -- strictly worse than the
                # pre-#1148 behaviour (#1158 review 2, MEDIUM 3). The stage records
                # ``source_complementarity=None`` (not measured) and says why.
                stage_res = None
                residual_failures.append(f"{type(exc).__name__}: {exc}")
        # A stage is ACCEPTED only when the subsolver converged. A non-converged
        # iterate is still carried forward as the next warm start (it is the best
        # guess available), but it must not become the reported point: that is the
        # difference between "a local stationary point" and "wherever the solver
        # stopped", and only the first is what ``local_optimal`` claims.
        if usable and has_point:
            best_x, best_obj, best_t = x_cur.copy(), stage_obj, float(tv)
            best_certified = certified_stage
        stages.append(
            ContinuationStage(
                iteration=it,
                t=float(tv),
                status=str(getattr(stage_result.status, "value", stage_result.status)),
                accepted=bool(usable and has_point),
                certified=bool(certified_stage and has_point),
                reason=_stage_reason(converged, has_point, stage_result.status)
                + (
                    f"; source residual not measured ({residual_failures[-1]})"
                    if residual_failures and stage_res is None and has_point
                    else ""
                ),
                objective=stage_obj,
                source_complementarity=stage_res,
            )
        )
        if tv <= t_min:
            termination = "t_min_reached"
            break
        tv = max(tv * sigma, t_min)

    # ``final_t`` is the last t a stage was actually SOLVED at, read off the
    # trace -- not the loop's ``tv``, which the schedule has already advanced one
    # step past the last solve by the time a ``max_iter`` exit is taken
    # (#1158 review, LOW 9).
    last_solved_t = float(stages[-1].t) if stages else None
    final_t = best_t if best_t is not None else last_solved_t
    if termination == "t_min_reached" and best_t is not None and best_t > t_min * (1.0 + 1e-9):
        # The schedule reached t_min, but the point being REPORTED came from an
        # earlier, larger t -- so the run did not converge at the accuracy the
        # final t implies, and ``converged`` must not say it did (#1158 review 2,
        # MEDIUM 5). ``final_t`` already names the t the reported point came from;
        # this keeps the two consistent.
        termination = "t_min_reached_but_best_point_is_from_a_larger_t"
    trace = ContinuationTrace(
        parameter="t",
        stages=tuple(stages),
        final_t=final_t,
        termination_reason=termination,
        admitted_residual_scale=admitted_residual_scale(best_t),
        any_stage_accepted=any(st.accepted for st in stages),
        reported_point_certified=best_certified,
    )
    if residual_failures:
        import warnings

        warnings.warn(
            "solve_mpec: the per-stage source residual could not be measured on "
            f"{len(residual_failures)} homotopy stage(s) ({residual_failures[-1]}). The "
            "continuation was unaffected; those stages report "
            "source_complementarity=None, which means NOT MEASURED.",
            RuntimeWarning,
            stacklevel=3,
        )

    wall = time.perf_counter() - wall0
    if best_x is None:

        def _last_iterate() -> Optional[dict[int, np.ndarray]]:
            # Typed thunk: a conditional between two lambdas types as the first
            # lambda's ``Callable[[], dict]``, which the ``None`` branch violates.
            return point_from_flat(model, x_cur) if stages else None

        # No stage converged. This is "the local solver failed to find a point",
        # NOT an infeasibility proof — publishing it as ``infeasible`` would be a
        # false certificate in the direction nothing downstream checks (#1148 §B).
        return (
            SolveResult(
                status=_status.LOCAL_INFEASIBLE,
                objective=None,
                wall_time=wall,
                gap_certified=False,
                mpec_report=_report_for(
                    model,
                    report_pairs,
                    snapshot,
                    _last_iterate,
                    kind=residual_kind,
                    continuation=trace,
                    notes=(
                        "no homotopy stage converged: the residuals below are measured at "
                        "the last iterate, which is NOT a solution and carries no claim",
                    ),
                ),
            ),
            None,
        )

    from discopt.solver import _unpack_solution

    # ``best_obj`` is already in model units: every stage objective is converted
    # as it is recorded, so the trace and the result cannot disagree.
    objective = best_obj

    # ``local_optimal`` is defined as a local STATIONARY point, so it is reserved
    # for a point a subsolver actually converged to. A stalled iterate is still
    # reported -- it is a warm start, it carries its residuals, and throwing it
    # away is what #1158 review 2 (MEDIUM 5) fixed -- but under the weaker
    # ``local_limit``. Unconditional promotion meant a subsolver allowed zero
    # iterations returned its own starting point as a stationary point, with the
    # generated product row violated by 24 (#1158 review 3, blocking 3). Neither
    # branch carries a bound or certification: a local solve proves nothing about
    # the global problem either way (#1148 §C).
    return (
        SolveResult(
            status=_status.LOCAL_OPTIMAL if best_certified else _status.LOCAL_LIMIT,
            objective=objective,
            # bound stays None: a local solve may contribute an incumbent (after
            # independent feasibility verification) and never a dual bound (#1148 §C).
            x=_unpack_solution(model, best_x),
            wall_time=wall,
            gap_certified=False,
            mpec_report=_report_for(
                model,
                report_pairs,
                snapshot,
                lambda: point_from_flat(model, best_x),
                kind=residual_kind,
                continuation=trace,
            ),
        ),
        best_x,
    )


@dataclass
class MultistartRecord:
    """What one start of :func:`solve_mpec_multistart` produced.

    ``scholtes_status``/``scholtes_objective`` are the continuation's own local
    result. ``polish_status`` is the active-set polish NLP's status (``None`` when
    no polish ran) and ``verified_objective`` the objective
    :func:`~discopt.mpec_report.accept_local_incumbent` vouched for, in model units,
    or ``None`` when the point was refused -- the only number here that may be
    used as an incumbent.
    """

    start: int
    scholtes_status: str
    scholtes_objective: Optional[float]
    polish_status: Optional[str]
    verified_objective: Optional[float]
    wall_time: float
    note: str = ""


def _variable_slot(model: Model, expr: Expression, offsets: dict[int, int]) -> Optional[int]:
    """Flat column of ``expr`` when it is one scalar variable element, else ``None``."""
    from discopt.modeling.core import IndexExpression

    if isinstance(expr, Variable) and expr.size == 1:
        return offsets.get(id(expr))
    if isinstance(expr, IndexExpression) and isinstance(expr.base, Variable):
        k = _static_flat_element(expr.base, expr.index)
        base = offsets.get(id(expr.base))
        if k is not None and base is not None:
            return base + k
    return None


def _active_set_slots(
    model: Model, pairs: list[Complementarity]
) -> Optional[list[tuple[int, int]]]:
    """``(f_col, g_col)`` per scalar pair, or ``None`` if any operand is not a variable.

    The polish fixes one side of every pair to zero by a **bound**, which is only
    an exact statement of ``f = 0`` when ``f`` is a variable element whose declared
    lower bound is 0. A pair over a general expression would need a generated row,
    which this driver does not add; it then skips the polish and says so.
    """
    offsets = _target_flat_offsets(model)
    out = []
    for p in _scalarize_pairs(model, pairs):
        if not p.is_symmetric_nonnegative:
            return None
        fc = _variable_slot(model, p.f, offsets)
        gc = _variable_slot(model, p.g, offsets)
        if fc is None or gc is None:
            return None
        out.append((fc, gc))
    return out


def _polish_active_set(
    model: Model,
    x: np.ndarray,
    slots: list[tuple[int, int]],
    nlp_options: Optional[dict],
):
    """Fix the smaller side of each pair to 0 and re-solve the NLP from ``x``.

    The fixed-side NLP is an ordinary smooth NLP over one piece of the MPEC's
    feasible set, so a point it converges to satisfies every complementarity
    **exactly** (``f = 0`` or ``g = 0`` by bound), not to the ``sqrt(t)`` the
    Scholtes relaxation admits. That is what lets the point pass the source-side
    check of :func:`~discopt.mpec_report.accept_local_incumbent` at its 1e-6
    tolerance. Bounds are overridden on an evaluator proxy; the model's variables
    are never touched. Returns the backend's result (``x`` may be ``None``).
    """
    from discopt._tape_nlp_evaluator import make_evaluator
    from discopt.solver import _BoundOverrideEvaluator
    from discopt.solvers.nlp_backend import get_nlp_solver

    evaluator = make_evaluator(model)
    lb, ub = (np.array(a, dtype=np.float64) for a in evaluator.variable_bounds)
    for fc, gc in slots:
        side = fc if x[fc] <= x[gc] else gc
        if lb[side] > 0.0:
            # The declared box already forbids this side being zero; the other
            # side must be the zero one.
            side = gc if side == fc else fc
        lb[side] = 0.0
        ub[side] = 0.0
    x_start = np.clip(x, lb, ub)
    opts = dict(nlp_options) if nlp_options else {}
    opts.setdefault("print_level", 0)
    backend = get_nlp_solver("auto")
    return backend(_BoundOverrideEvaluator(evaluator, lb, ub), x_start, options=opts)


def solve_mpec_multistart(
    model: Model,
    pairs: list[Complementarity],
    starts,
    *,
    polish: bool = True,
    t0: float = 1e-4,
    sigma: float = 0.1,
    t_min: float = 1e-8,
    max_iter: int = 16,
    nlp_options: Optional[dict] = None,
    residual_kind: str = "auto",
    time_limit: Optional[float] = None,
) -> "SolveResult":
    """Multistart Scholtes: one continuation per start, verified incumbents only (#2167).

    The relations are lowered **once** (Scholtes rows ``f, g >= 0``,
    ``f·g <= t``); each start then runs one continuation
    (:func:`solve_mpec`'s ``method="scholtes"`` homotopy) and, with ``polish``,
    an active-set NLP that fixes the smaller side of every pair to zero. A point
    becomes a candidate incumbent **only** after
    :func:`~discopt.mpec_report.accept_local_incumbent` verifies it -- the source
    relations first, then every row and bound of the model -- so a point that
    sits on the relaxation's ``sqrt(t)`` edge is never reported as a solution.

    Parameters
    ----------
    starts : iterable
        Each entry is an initial point: a ``{Variable: value}`` dict (validated by
        :func:`discopt.warm_start.validate_initial_solution`; omitted variables
        get their midpoint), a flat vector in ``model._variables`` order, or
        ``None`` for the midpoint.
    polish : bool
        Run the active-set polish (default). It applies when every scalar pair
        is a pair of variable elements -- true for ``relu_complementarity`` --
        and is otherwise skipped with a note on each record.
    t0 : float
        First homotopy parameter. Default ``1e-4``, **not** :func:`solve_mpec`'s
        ``1.0``: a start that already satisfies the relations (a forward pass of a
        network) is erased by a loose first stage. Measured on a 4-32-32-1 random
        ReLU net, 10 forward-pass starts (#2167): ``t0=1`` sent all 10 to one
        local point (objective -0.1746); ``t0=1e-2`` and ``1e-4`` kept them apart
        and reached -0.3620 (= ``relu_bigm``'s 120 s incumbent; best of 20 000
        sampled inputs -0.2912), ``1e-4`` in the least wall time (20.8 s vs 26.8 s).
    time_limit : float, optional
        Wall-clock budget for the whole run: no start or homotopy stage begins
        past it, and every NLP solve (stage or polish) is capped by the time that
        remains (POUNCE ``max_wall_time``), so one slow start cannot overrun it by
        a whole continuation. Measured before this cap (#2167 H1): one start on a
        4-256-256-1 net took 367 s against a 120 s budget.

    Returns
    -------
    SolveResult
        **Local, never certified** (``gap_certified=False``, no ``bound``).
        ``status="local_optimal"`` with ``x``/``objective`` the best *verified*
        point; ``"local_infeasible"`` with ``x=None`` when no start produced a
        verified point (not an infeasibility proof). ``result.multistart`` holds
        one :class:`MultistartRecord` per start that ran, and
        ``result.mpec_report`` the source-residual report at the returned point.
    """
    from discopt.modeling.core import SolveResult
    from discopt.mpec_report import accept_local_incumbent, point_from_flat
    from discopt.solver import _unpack_solution

    starts = list(starts)
    if not starts:
        raise ValueError("solve_mpec_multistart needs at least one start")
    pairs = list(pairs)
    _validate_all(model, _pending(model, pairs or list(model._complementarities)))
    register_relations(model, pairs)
    report_pairs = pairs if pairs else list(model._complementarities)
    snapshot = _source_snapshot(model)

    # Validate dict starts while the model still has exactly its source columns.
    from discopt.warm_start import validate_initial_solution

    lb, ub = _flat_bounds(model)
    flat_starts: list[np.ndarray] = []
    for st in starts:
        if st is None:
            flat_starts.append(_midpoint(lb, ub))
        elif isinstance(st, dict):
            flat_starts.append(np.asarray(validate_initial_solution(model, st), dtype=np.float64))
        else:
            arr = np.asarray(st, dtype=np.float64).ravel()
            if arr.shape != lb.shape:
                raise ValueError(
                    f"start has {arr.size} entries; model has {lb.size} variable elements"
                )
            flat_starts.append(arr)

    t = _lower_scholtes(model, pairs, t0)
    slots = _active_set_slots(model, report_pairs) if polish else None
    skip_note = (
        ""
        if not polish or slots is not None
        else "polish skipped: a pair operand is not a single [0, inf) variable element"
    )

    records: list[MultistartRecord] = []
    best_x: Optional[np.ndarray] = None
    best_obj: Optional[float] = None
    sense = 1.0
    from discopt.modeling.core import ObjectiveSense

    if model._objective is not None and model._objective.sense == ObjectiveSense.MAXIMIZE:
        sense = -1.0
    wall0 = time.perf_counter()
    deadline = None if time_limit is None else wall0 + float(time_limit)
    for i, x0 in enumerate(flat_starts):
        if deadline is not None and time.perf_counter() >= deadline:
            break
        ts = time.perf_counter()
        try:
            res, x_sch = _scholtes_homotopy(
                model,
                t,
                report_pairs=report_pairs,
                snapshot=snapshot,
                t0=t0,
                sigma=sigma,
                t_min=t_min,
                max_iter=max_iter,
                x0=x0,
                nlp_options=nlp_options,
                residual_kind=residual_kind,
                deadline=deadline,
            )
        except RuntimeError as exc:
            # A first-stage subsolver failure for THIS start (see the homotopy):
            # recorded, never swallowed, and the next start still runs.
            records.append(
                MultistartRecord(
                    i, "error", None, None, None, time.perf_counter() - ts, note=str(exc)
                )
            )
            continue
        polish_status: Optional[str] = None
        candidates: list[np.ndarray] = []
        note = skip_note
        if x_sch is not None:
            left = None if deadline is None else deadline - time.perf_counter()
            if slots is not None and left is not None and left <= 0.0:
                note = (note + "; " if note else "") + "polish skipped: time limit reached"
            elif slots is not None:
                popts = dict(nlp_options) if nlp_options else {}
                if left is not None:
                    popts["max_wall_time"] = max(1e-3, left)
                pr = _polish_active_set(model, x_sch, slots, popts)
                polish_status = str(getattr(pr.status, "value", pr.status))
                if pr.x is not None:
                    candidates.append(np.asarray(pr.x, dtype=np.float64))
            candidates.append(x_sch)
        verified: Optional[float] = None
        for cand in candidates:
            v = accept_local_incumbent(model, None, x_flat=cand)
            if v is not None:
                verified = float(v)
                if best_obj is None or sense * verified < sense * best_obj:
                    best_obj, best_x = verified, cand.copy()
                break
        records.append(
            MultistartRecord(
                start=i,
                scholtes_status=str(res.status),
                scholtes_objective=res.objective,
                polish_status=polish_status,
                verified_objective=verified,
                wall_time=time.perf_counter() - ts,
                note=note,
            )
        )
    t.value = np.asarray(t_min, dtype=np.float64)
    wall = time.perf_counter() - wall0

    if best_x is None:
        result = SolveResult(
            status=_status.LOCAL_INFEASIBLE,
            objective=None,
            wall_time=wall,
            gap_certified=False,
        )
        result.mpec_report = None
    else:
        point = best_x
        result = SolveResult(
            status=_status.LOCAL_OPTIMAL,
            objective=best_obj,
            x=_unpack_solution(model, point),
            wall_time=wall,
            gap_certified=False,
        )
        result.mpec_report = _report_for(
            model,
            report_pairs,
            snapshot,
            lambda: point_from_flat(model, point),
            kind=residual_kind,
            notes=(
                f"multistart Scholtes: best of {len(records)} start(s); the point was "
                "verified against the source relations and every model row by "
                "accept_local_incumbent. A LOCAL result: no bound, no certificate.",
            ),
        )
    result.multistart = records
    return result


def _stage_reason(certified: bool, has_point: bool, status) -> str:
    """One sentence saying what a homotopy stage produced, and how strong it is."""
    if not has_point:
        return "subsolver returned no point"
    if certified:
        return "subsolver converged"
    code = getattr(status, "value", status)
    return (
        f"subsolver stalled ({code}) at a point it could not certify to tolerance; "
        "kept as an iterate — a usable warm start carrying its residuals — under "
        "'local_limit', which asserts no stationarity"
    )


def _model_units(model: Model, objective: float) -> float:
    """An NLP-backend objective converted to the model's own sense.

    The backend always minimises, negating the objective for a MAXIMIZE model, so
    a raw subsolver value is in *internal* units. One helper, used for both the
    per-stage trace entries and the returned result, so the two cannot drift.
    """
    from discopt.modeling.core import ObjectiveSense

    obj = float(objective)
    if model._objective is not None and model._objective.sense == ObjectiveSense.MAXIMIZE:
        return -obj
    return obj


def _flat_bounds(model: Model) -> tuple[np.ndarray, np.ndarray]:
    lbs, ubs = [], []
    for v in model._variables:
        lbs.append(np.asarray(v.lb).flatten())
        ubs.append(np.asarray(v.ub).flatten())
    return np.concatenate(lbs), np.concatenate(ubs)


def _midpoint(lb: np.ndarray, ub: np.ndarray) -> np.ndarray:
    lo = np.clip(lb, -1e6, 1e6)
    hi = np.clip(ub, -1e6, 1e6)
    return np.asarray(0.5 * (lo + hi), dtype=np.float64)
