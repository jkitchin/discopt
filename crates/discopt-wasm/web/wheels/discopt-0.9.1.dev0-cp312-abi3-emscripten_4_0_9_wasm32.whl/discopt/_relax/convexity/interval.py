"""Sound interval arithmetic with outward rounding.

This module implements the interval arithmetic primitives used by the
box-local convexity certificate. The design goal is **soundness**: an
:class:`Interval` ``[lo, hi]`` returned by any operation must enclose
every possible result of the true computation on any point in its
arguments' intervals, *including* all floating-point roundoff errors.

Soundness is achieved by outward rounding after every arithmetic
operation:

* Lower endpoints are pushed toward ``-inf`` with ``np.nextafter``.
* Upper endpoints are pushed toward ``+inf`` with ``np.nextafter``.

This loses at most one ULP per operation and composes safely — the
resulting enclosure is always conservative. The implementation stays
in plain numpy (no JAX): interval arithmetic does not flow through a
differentiable tracer, and the per-constraint work is small enough
that the JAX overhead is not warranted.

References
----------
Moore, R. E. (1966). *Interval Analysis*. Prentice-Hall.
Neumaier, A. (1990). *Interval Methods for Systems of Equations*.
Cambridge University Press.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Union

import numpy as np

Number = Union[int, float, np.ndarray]


# ──────────────────────────────────────────────────────────────────────
# Outward rounding helpers
# ──────────────────────────────────────────────────────────────────────


def _round_down(x: Number) -> np.ndarray:
    """Push ``x`` one ULP toward ``-inf`` (sound lower bound).

    Accepts a scalar or ndarray; returns the matching shape. Zero and
    finite values are nudged toward -inf; infinities are left alone
    (``nextafter(-inf, -inf) = -inf``).
    """
    return np.nextafter(x, np.float64(-np.inf))


def _round_up(x: Number) -> np.ndarray:
    """Push ``x`` one ULP toward ``+inf`` (sound upper bound)."""
    return np.nextafter(x, np.float64(np.inf))


def _round_down_exact0(x: Number) -> np.ndarray:
    """:func:`_round_down`, but leaving an **exact zero** exactly zero (#957).

    ``nextafter(0.0, -inf)`` is ``-5e-324``. At every other magnitude "one
    ULP" is a negligible *relative* widening; at zero it crosses into the
    subnormal range and manufactures a coefficient ~300 orders of magnitude
    below everything else in the model. That value is still a sound
    enclosure, but it defeats downstream code that reasons about
    *magnitudes* — the motivating case was the coefficient-spread test in
    ``milp_relaxation``, which in its pre-#957 naive
    ``nz.max() / nz.min() > trigger`` form divided by the smallest nonzero
    entry and overflowed to ``inf`` on such a value.

    That consumer is no longer vulnerable, and this sentence used to read as
    though it still were: #957 hardened BOTH ends in one pass, so today
    ``_coefficient_spread_exceeds`` cross-multiplies instead of dividing *and*
    filters entries below ``_SUBNORMAL_FLOOR`` before measuring. The producer-
    side rule below is still worth having — a manufactured ``±5e-324`` is a
    magnitude-reasoning hazard for any consumer, not only that one — but it is
    a general precaution now, not a live bug being patched around, and reading
    it as the latter sends the next person hunting an overflow that cannot
    happen.

    Skipping the nudge is sound **only** where a floating-point result of
    exactly ``0`` implies the exact real result is ``0`` — i.e. where the
    producing operation cannot underflow to zero. That is a property of the
    operation, not of the value, so this variant is strictly opt-in: reach
    for :func:`_round_down`, which is sound unconditionally, unless the call
    site carries the argument for its own operation. ``exp`` is the
    counter-example that makes the distinction real, not theoretical:
    ``fl(exp(-800))`` is ``0.0`` while the exact value is ``3.6e-348 > 0``,
    so ``exp``'s upper endpoint must keep the nudge or the enclosure would
    exclude the true image.
    """
    return np.where(x == 0.0, np.float64(0.0), np.nextafter(x, np.float64(-np.inf)))


def _round_up_exact0(x: Number) -> np.ndarray:
    """:func:`_round_up`, but leaving an **exact zero** exactly zero (#957).

    The upward twin of :func:`_round_down_exact0`; the same opt-in rule and
    the same underflow caveat apply.
    """
    return np.where(x == 0.0, np.float64(0.0), np.nextafter(x, np.float64(np.inf)))


def _nan_corner_to_zero(x: Number) -> np.ndarray:
    """Replace ``NaN`` corner products with ``0``, preserving ±inf (C-36).

    Used by :meth:`Interval.__mul__`, where a NaN corner can arise *only*
    from ``0 * ±∞``, whose interval-convention value is ``0``. ``±inf`` is
    left untouched so genuine unbounded corners still dominate the min/max.
    """
    return np.nan_to_num(x, nan=0.0, posinf=np.inf, neginf=-np.inf)


# ──────────────────────────────────────────────────────────────────────
# Interval
# ──────────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class Interval:
    """Closed real interval ``[lo, hi]`` with numpy-array endpoints.

    Endpoints broadcast against each other and support element-wise
    operations. A degenerate interval ``lo == hi`` is allowed and
    represents a (floating-point) point value. Scalars are accepted
    and normalised to 0-d arrays in ``__post_init__``.
    """

    # ``__post_init__`` normalises both endpoints to contiguous
    # ``float64`` ndarrays. The runtime invariant is that both fields
    # are 0-d or higher ndarrays after construction; the annotation
    # is kept generic so callers can pass Python scalars or 0-d numpy
    # scalars without tripping strict type-checking.
    lo: np.ndarray
    hi: np.ndarray

    def __post_init__(self) -> None:
        # Frozen dataclass: use object.__setattr__ to normalize inputs.
        #
        # This constructor is extremely hot — the interval AD / monotonicity
        # walkers build millions of tiny (mostly 0-d) intervals. The general
        # ``np.broadcast_arrays`` + ``np.ascontiguousarray`` + ``np.any`` path
        # dominates those walks, so the common case (both endpoints already
        # ``float64`` ndarrays of identical shape, which every internal
        # arithmetic result satisfies) takes a fast path that skips the
        # broadcasting machinery entirely. Soundness is unchanged: the
        # ``lo <= hi`` invariant is still validated.
        lo = self.lo
        hi = self.hi
        if type(lo) is not np.ndarray or lo.dtype != np.float64:
            lo = np.asarray(lo, dtype=np.float64)
        if type(hi) is not np.ndarray or hi.dtype != np.float64:
            hi = np.asarray(hi, dtype=np.float64)
        if lo.shape != hi.shape:
            # Differing shapes: broadcast to a common shape once and force
            # contiguity so downstream ops can assume shape agreement.
            lo, hi = np.broadcast_arrays(lo, hi)
            lo = np.ascontiguousarray(lo)
            hi = np.ascontiguousarray(hi)
        if lo.ndim == 0:
            # Scalar fast path: a direct comparison avoids the ``np.any``
            # ufunc-reduction wrapper that otherwise shows up by the million.
            if lo > hi:
                raise ValueError(f"Interval lo > hi: lo={lo}, hi={hi}")
        elif np.any(lo > hi):
            raise ValueError(f"Interval lo > hi: lo={lo}, hi={hi}")
        object.__setattr__(self, "lo", lo)
        object.__setattr__(self, "hi", hi)

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def point(cls, x: Number) -> "Interval":
        """Degenerate interval ``[x, x]`` (exact floating-point point)."""
        arr = np.asarray(x, dtype=np.float64)
        return cls(arr, arr)

    @classmethod
    def from_bounds(cls, lb: Number, ub: Number) -> "Interval":
        """Construct an interval from separate lower and upper bounds."""
        return cls(np.asarray(lb, dtype=np.float64), np.asarray(ub, dtype=np.float64))

    # ------------------------------------------------------------------
    # Basic queries
    # ------------------------------------------------------------------

    @property
    def width(self) -> np.ndarray:
        """Element-wise width ``hi - lo``."""
        # ``_exact0`` (#957): IEEE-754 subtraction of two doubles cannot
        # underflow to a false zero — the exact difference is a multiple of
        # ``2**-1074``, so it is either representable or nonzero-after-rounding.
        # ``fl(hi - lo) == 0`` therefore means the width really is zero.
        return _round_up_exact0(self.hi - self.lo)

    @property
    def mid(self) -> np.ndarray:
        """Element-wise midpoint (no rounding guarantee — diagnostic only)."""
        return 0.5 * (self.lo + self.hi)

    def contains_zero(self) -> np.ndarray:
        """Element-wise test for ``0 ∈ [lo, hi]``."""
        return (self.lo <= 0) & (self.hi >= 0)

    # ------------------------------------------------------------------
    # Arithmetic — always with outward rounding
    # ------------------------------------------------------------------

    def __neg__(self) -> "Interval":
        return Interval(-self.hi, -self.lo)

    def __add__(self, other: Union["Interval", Number]) -> "Interval":
        # ``_exact0`` (#957): see :attr:`width` — a floating-point sum of two
        # doubles is zero only when the exact sum is zero, so there is no
        # underflow for the outward nudge to cover here.
        other = _as_interval(other)
        return Interval(
            _round_down_exact0(self.lo + other.lo), _round_up_exact0(self.hi + other.hi)
        )

    __radd__ = __add__

    def __sub__(self, other: Union["Interval", Number]) -> "Interval":
        other = _as_interval(other)
        return Interval(
            _round_down_exact0(self.lo - other.hi), _round_up_exact0(self.hi - other.lo)
        )

    def __rsub__(self, other: Union["Interval", Number]) -> "Interval":
        return _as_interval(other) - self

    def __mul__(self, other: Union["Interval", Number]) -> "Interval":
        other = _as_interval(other)
        # The four corner products enclose the result on any sign
        # combination; pick element-wise min/max to handle all cases.
        #
        # A finite ``0`` endpoint times an infinite endpoint gives
        # ``0 * ±∞ = NaN`` in IEEE-754, and ``np.minimum``/``np.maximum``
        # then propagate that NaN, collapsing the interval to ``[NaN, NaN]``
        # (C-36). By the interval-multiplication convention the product of a
        # zero factor with any interval — including an unbounded one — is
        # ``0``, so we map those NaN corners to ``0`` before the min/max.
        # NaN can arise here *only* from ``0 * ±∞``; every other operand pair
        # is finite×finite (never NaN) or a genuine ±∞ product, so the
        # substitution never masks a real value. The result stays a rigorous
        # outer enclosure that never excludes a point: ``[0,0]·[−∞,∞] = [0,0]``
        # (correct) while ``[0,5]·[−∞,∞] = [−∞,∞]`` (the ±∞ corners still
        # dominate). Genuine ±∞ corners are left untouched — only NaN is
        # replaced.
        with np.errstate(invalid="ignore"):
            a = self.lo * other.lo
            b = self.lo * other.hi
            c = self.hi * other.lo
            d = self.hi * other.hi
            lo = np.minimum(np.minimum(a, b), np.minimum(c, d))
            hi = np.maximum(np.maximum(a, b), np.maximum(c, d))
            # #723: a NaN corner can arise *only* from ``0 * ±∞`` (every other
            # operand pair is finite×finite or a genuine ±∞ product), and
            # ``np.minimum``/``np.maximum`` propagate it into ``lo``/``hi``. So
            # we detect it on the (already computed) result rather than paying
            # four ``np.nan_to_num`` calls on every multiply — the interval AD /
            # monotonicity walkers build millions of these and the vast majority
            # have finite endpoints, where the cleanup is a no-op. Bound-neutral:
            # on the finite fast path ``_nan_corner_to_zero`` is the identity, so
            # the min/max are identical; only when a NaN actually appears do we
            # redo the corners with the ``0 * ±∞ -> 0`` convention (C-36).
            if bool(np.isnan(lo).any()) or bool(np.isnan(hi).any()):
                a = _nan_corner_to_zero(a)
                b = _nan_corner_to_zero(b)
                c = _nan_corner_to_zero(c)
                d = _nan_corner_to_zero(d)
                lo = np.minimum(np.minimum(a, b), np.minimum(c, d))
                hi = np.maximum(np.maximum(a, b), np.maximum(c, d))
        # #957: an endpoint of exactly ``0`` is either a *genuine* zero — some
        # corner had a zero factor, and ``0 * x`` is exact in IEEE-754,
        # including the ``0 * ±∞ -> 0`` convention applied just above — or an
        # *underflowed* nonzero product (``1e-200 * 1e-200`` flushes to zero
        # with the exact value ~1e-400). Only the second needs the outward
        # nudge; nudging the first manufactures a ±5e-324 subnormal, and
        # ``[0,0] * [-3,7]`` (a very common shape: a zero gradient or Hessian
        # entry) is exactly that case. A corner is an exact zero iff one of its
        # factors is zero, so scanning for a zero corner with two nonzero
        # factors *is* the underflow test. Detect on the already-computed
        # endpoints — the same "pay only when it happens" shape as the NaN
        # cleanup above, since the interval AD / monotonicity walkers build
        # millions of these and the vast majority have no zero endpoint at all.
        if bool(np.any(lo == 0.0)) or bool(np.any(hi == 0.0)):
            underflowed = (
                ((a == 0.0) & (self.lo != 0.0) & (other.lo != 0.0))
                | ((b == 0.0) & (self.lo != 0.0) & (other.hi != 0.0))
                | ((c == 0.0) & (self.hi != 0.0) & (other.lo != 0.0))
                | ((d == 0.0) & (self.hi != 0.0) & (other.hi != 0.0))
            )
            if not bool(np.any(underflowed)):
                return Interval(_round_down_exact0(lo), _round_up_exact0(hi))
        return Interval(_round_down(lo), _round_up(hi))

    __rmul__ = __mul__

    def __truediv__(self, other: Union["Interval", Number]) -> "Interval":
        other = _as_interval(other)
        # Division is only well-defined when 0 is not in the
        # denominator. When it is, return an unbounded enclosure so
        # soundness is preserved — downstream certificate code
        # treats unbounded Hessian entries as UNKNOWN.
        contains = other.contains_zero()
        if np.any(contains):
            inf = np.float64(np.inf)
            return Interval(np.full_like(self.lo, -inf), np.full_like(self.hi, inf))
        inv_lo = 1.0 / other.hi
        inv_hi = 1.0 / other.lo
        # ``_exact0`` (#957): ``1/x`` is zero only for ``x = ±inf``, where the
        # exact reciprocal is zero too — the smallest finite reciprocal,
        # ``1/1.8e308``, is ~5.6e-309, so this division never underflows to a
        # false zero.
        return self * Interval(_round_down_exact0(inv_lo), _round_up_exact0(inv_hi))

    def __rtruediv__(self, other: Union["Interval", Number]) -> "Interval":
        return _as_interval(other) / self

    def __pow__(self, n: int) -> "Interval":
        """Integer power. Sound for ``n >= 0``."""
        if not isinstance(n, (int, np.integer)):
            raise TypeError("Interval power supports integer exponents only")
        if n < 0:
            # x^(-k) = 1 / x^k
            return Interval.point(1.0) / (self**-n)
        if n == 0:
            shape = self.lo.shape
            return Interval(np.ones(shape), np.ones(shape))
        if n == 1:
            return self
        if n == 2:
            # Special-case squaring — tighter than the generic product
            # because the corner products from __mul__ would not use
            # the fact that both factors are the same interval.
            zero_in = self.contains_zero()
            lo_sq = self.lo * self.lo
            hi_sq = self.hi * self.hi
            sq_max = np.maximum(lo_sq, hi_sq)
            sq_min = np.minimum(lo_sq, hi_sq)
            lo = np.where(zero_in, 0.0, sq_min)
            hi = sq_max
            # #957, same rule as ``__mul__``: a squared endpoint is exactly
            # zero either because the endpoint itself was zero (exact) or
            # because the square underflowed. Only the latter needs the nudge,
            # and a *negative* subnormal lower endpoint on a square — which is
            # what the unconditional nudge produces for any box containing
            # zero — is precisely the artifact #957 is about.
            if bool(np.any(lo == 0.0)) or bool(np.any(hi == 0.0)):
                underflowed = ((lo_sq == 0.0) & (self.lo != 0.0)) | (
                    (hi_sq == 0.0) & (self.hi != 0.0)
                )
                if not bool(np.any(underflowed)):
                    return Interval(_round_down_exact0(lo), _round_up_exact0(hi))
            return Interval(_round_down(lo), _round_up(hi))
        # General integer power via repeated squaring; soundness
        # preserved because every op outward-rounds.
        result = self
        for _ in range(n - 1):
            result = result * self
        return result


# ──────────────────────────────────────────────────────────────────────
# Unary elementary functions
# ──────────────────────────────────────────────────────────────────────


def _monotonic_nondec(x: Interval, f) -> Interval:
    """Image of ``x`` under a nondecreasing function ``f``, outward-rounded."""
    # Deliberately the *unconditional* ``_round_down``/``_round_up``, not the
    # ``_exact0`` variants (#957): this wrapper is generic over ``f``, and
    # ``exp`` underflows — ``fl(exp(-800))`` is ``0.0`` while the exact value
    # is ``3.6e-348``, so dropping the nudge here would produce an upper
    # endpoint *below* the true image. Any future atom routed through this
    # wrapper inherits the safe behaviour by default.
    #
    # Wide boxes can intentionally overflow to unbounded enclosures. The
    # certificate code treats non-finite endpoints as an abstention signal, so
    # keep the interval sound without emitting benchmark-visible warnings.
    with np.errstate(over="ignore", invalid="ignore"):
        lo = f(x.lo)
        hi = f(x.hi)
    return Interval(_round_down(lo), _round_up(hi))


def _monotonic_nonincr(x: Interval, f) -> Interval:
    """Image of ``x`` under a nonincreasing function ``f``, outward-rounded."""
    with np.errstate(over="ignore", invalid="ignore"):
        lo = f(x.hi)
        hi = f(x.lo)
    return Interval(_round_down(lo), _round_up(hi))


def _monotonic_nondec_safe(x: Interval, f) -> Interval:
    """Image of ``x`` under a nondecreasing ``f`` restricted to its domain.

    Like :func:`_monotonic_nondec`, but for partial-domain atoms (``asin``,
    ``acosh``, ``atanh``, ``log1p``, …). When an endpoint falls outside the
    natural domain numpy returns ``NaN``; an open-domain asymptote yields
    ``±inf``. Either way the endpoint collapses to a conservative unbounded
    value (``-inf`` for the lower, ``+inf`` for the upper), so the certificate
    soundly abstains instead of trusting an undefined evaluation.
    """
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        lo = _round_down(f(x.lo))
        hi = _round_up(f(x.hi))
    lo = np.where(np.isnan(lo), -np.inf, lo)
    hi = np.where(np.isnan(hi), np.inf, hi)
    return Interval(lo, hi)


def _monotonic_nonincr_safe(x: Interval, f) -> Interval:
    """Image of ``x`` under a nonincreasing ``f`` restricted to its domain.

    The nonincreasing analogue of :func:`_monotonic_nondec_safe` (used by
    ``acos``): the lower endpoint comes from ``f(x.hi)`` and the upper from
    ``f(x.lo)``; out-of-domain ``NaN`` endpoints collapse outward.
    """
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        lo = _round_down(f(x.hi))
        hi = _round_up(f(x.lo))
    lo = np.where(np.isnan(lo), -np.inf, lo)
    hi = np.where(np.isnan(hi), np.inf, hi)
    return Interval(lo, hi)


def exp(x: Interval) -> Interval:
    """Sound enclosure of ``exp([lo, hi])``."""
    return _monotonic_nondec(x, np.exp)


def log(x: Interval) -> Interval:
    """Sound enclosure of ``log([lo, hi])``.

    Domain: requires ``lo > 0``. Returns an unbounded lower endpoint if
    the argument touches zero, preserving soundness (downstream checks
    should then refuse to certify).
    """
    lo = x.lo
    if np.any(lo <= 0):
        # Replace nonpositive parts with -inf to keep the enclosure
        # sound without poisoning well-defined entries.
        with np.errstate(divide="ignore", invalid="ignore"):
            safe_lo = np.where(lo > 0, np.log(np.where(lo > 0, lo, 1.0)), -np.inf)
    else:
        with np.errstate(divide="ignore", invalid="ignore"):
            safe_lo = np.log(lo)
    with np.errstate(divide="ignore", invalid="ignore"):
        hi = np.log(x.hi)
    # ``_exact0`` (#957): ``log`` has no underflow region — ``log(t) == 0``
    # only at ``t == 1``, and the nearest other double, ``1 ± 1.1e-16``, maps
    # to ``±1.1e-16``, nowhere near zero. So a zero endpoint here is exact.
    return Interval(_round_down_exact0(safe_lo), _round_up_exact0(hi))


def sqrt(x: Interval) -> Interval:
    """Sound enclosure of ``sqrt([lo, hi])`` on the nonneg domain."""
    lo = x.lo
    with np.errstate(invalid="ignore"):
        safe_lo = np.where(lo >= 0, np.sqrt(np.where(lo >= 0, lo, 0.0)), -np.inf)
        hi = np.sqrt(x.hi)
    # ``_exact0`` (#957): ``sqrt`` moves toward 1, so it cannot underflow
    # (``sqrt(5e-324)`` is ~2.2e-162); IEEE-754 requires it to be correctly
    # rounded, and ``sqrt(t) == 0`` only for ``t == 0``, where it is exact.
    return Interval(_round_down_exact0(safe_lo), _round_up_exact0(hi))


def absolute(x: Interval) -> Interval:
    """Sound enclosure of ``|[lo, hi]|``."""
    zero_in = x.contains_zero()
    abs_lo = np.abs(x.lo)
    abs_hi = np.abs(x.hi)
    lo = np.where(zero_in, 0.0, np.minimum(abs_lo, abs_hi))
    hi = np.maximum(abs_lo, abs_hi)
    # ``_exact0`` (#957): ``abs`` and min/max are exact operations — they only
    # select and re-sign existing doubles — so a zero endpoint is a real zero.
    # (The unconditional nudge would give ``|[-1, 1]|`` a *negative* lower
    # endpoint, which is the artifact in its most visible form.)
    return Interval(_round_down_exact0(lo), _round_up_exact0(hi))


def tanh(x: Interval) -> Interval:
    """``tanh`` is nondecreasing on all of R."""
    return _monotonic_nondec(x, np.tanh)


def sinh(x: Interval) -> Interval:
    """``sinh`` is nondecreasing on all of R."""
    return _monotonic_nondec(x, np.sinh)


def cosh(x: Interval) -> Interval:
    """``cosh`` has a minimum at 0 and is otherwise monotone.

    Returns an enclosure whose lower endpoint is ``1`` when ``0 ∈ x``
    and the pointwise minimum of ``cosh(lo), cosh(hi)`` otherwise.
    """
    zero_in = x.contains_zero()
    ch_lo = np.cosh(x.lo)
    ch_hi = np.cosh(x.hi)
    lo = np.where(zero_in, 1.0, np.minimum(ch_lo, ch_hi))
    hi = np.maximum(ch_lo, ch_hi)
    return Interval(_round_down(lo), _round_up(hi))


def entropy(x: Interval) -> Interval:
    """``entropy(t) = t*log(t)`` is convex on ``t > 0`` with a single interior
    minimum at ``t = 1/e`` (value ``-1/e``), extended by continuity to
    ``entropy(0) = 0``.

    Convexity gives a tight enclosure: the lower endpoint is ``-1/e`` when the
    minimizer ``1/e`` lies in the box, else the smaller endpoint value; the upper
    endpoint is the larger endpoint value. That reasoning needs only convexity
    and continuity on the CLOSED domain ``[0, inf)``, so a box whose lower end is
    exactly ``0`` is enclosed exactly, using ``f(0) = 0`` -- the limit
    ``t log t -> 0`` as ``t -> 0+`` (#1242). It has to be: an ideal-mixing term
    over site or mole fractions always sits on a box that starts at 0, and the
    previous ``lo > 0`` guard made the certificate abstain on every one of them.

    ``lo < 0`` is genuinely outside the domain and still collapses outward to
    ``[-inf, +inf]``, so the certificate soundly abstains rather than guessing.
    """
    xstar = 1.0 / np.e
    fstar = -1.0 / np.e
    in_domain = x.lo >= 0
    with np.errstate(divide="ignore", invalid="ignore"):
        # ``0 * log(0)`` is ``nan`` in IEEE arithmetic; the continuous extension
        # ``f(0) = 0`` is the value the whole rule rests on, so substitute it
        # explicitly rather than letting a nan propagate into min/max (where it
        # would be silently absorbed by ``np.minimum``'s nan handling).
        f_lo = np.where(x.lo == 0, 0.0, x.lo * np.log(np.where(x.lo == 0, 1.0, x.lo)))
        f_hi = np.where(x.hi == 0, 0.0, x.hi * np.log(np.where(x.hi == 0, 1.0, x.hi)))
    contains_min = (x.lo <= xstar) & (x.hi >= xstar)
    lo = np.where(contains_min, fstar, np.minimum(f_lo, f_hi))
    hi = np.maximum(f_lo, f_hi)
    lo = np.where(in_domain, lo, -np.inf)
    hi = np.where(in_domain, hi, np.inf)
    return Interval(_round_down(lo), _round_up(hi))


def centropy(x: Interval, y: Interval) -> Interval:
    """``centropy(x, y) = x*log(x/y)`` (relative entropy) on ``x >= 0, y > 0``.

    Enclosed soundly (if loosely) via the identity ``centropy = entropy(x) -
    x*log(y)`` composed in interval arithmetic. The ``x -> 0+`` limit of
    ``centropy`` is 0, matching ``entropy``'s continuous extension at 0, so
    ``x.lo == 0`` is inside the domain here too. When the box leaves the domain
    (``x.lo < 0`` or ``y.lo <= 0``) the constituent enclosures collapse to
    ``[-inf, +inf]`` so the certificate soundly abstains.
    """
    return entropy(x) - x * log(y)


def sin(x: Interval) -> Interval:
    """Sound enclosure of ``sin([lo, hi])``.

    Reduces the interval modulo ``2π`` and reasons about the location
    of ``±π/2`` critical points within it. Falls back to the safe
    enclosure ``[-1, 1]`` when the interval is wider than ``2π``.
    """
    return _sinusoid(x, offset=0.0)


def cos(x: Interval) -> Interval:
    """Sound enclosure of ``cos([lo, hi]) = sin([lo + π/2, hi + π/2])``."""
    return _sinusoid(x, offset=np.pi / 2)


def _sinusoid(x: Interval, *, offset: float) -> Interval:
    """Enclosure of ``sin(x + offset)``; used by ``sin`` and ``cos``."""
    two_pi = 2.0 * np.pi
    lo = np.asarray(x.lo + offset, dtype=np.float64)
    hi = np.asarray(x.hi + offset, dtype=np.float64)
    width = hi - lo

    # Wide intervals contain a full period → safe enclosure [-1, 1].
    wide = width >= two_pi

    # Reduce lo modulo 2π into [0, 2π); shift hi by the same amount.
    k = np.floor(lo / two_pi)
    lo_r = lo - k * two_pi
    hi_r = hi - k * two_pi

    sin_lo = np.sin(lo_r)
    sin_hi = np.sin(hi_r)

    # Critical points π/2 + 2πk (maxima = +1) and 3π/2 + 2πk (minima = -1).
    # After reduction, the next maximum after lo_r is at:
    max_pt_1 = np.pi / 2
    max_pt_2 = np.pi / 2 + two_pi
    min_pt_1 = 3 * np.pi / 2
    min_pt_2 = 3 * np.pi / 2 + two_pi

    hits_max = ((lo_r <= max_pt_1) & (max_pt_1 <= hi_r)) | ((lo_r <= max_pt_2) & (max_pt_2 <= hi_r))
    hits_min = ((lo_r <= min_pt_1) & (min_pt_1 <= hi_r)) | ((lo_r <= min_pt_2) & (min_pt_2 <= hi_r))

    lo_candidate = np.minimum(sin_lo, sin_hi)
    hi_candidate = np.maximum(sin_lo, sin_hi)
    lo_out = np.where(hits_min, -1.0, lo_candidate)
    hi_out = np.where(hits_max, 1.0, hi_candidate)

    # Apply the wide-interval fallback everywhere it holds.
    lo_out = np.where(wide, -1.0, lo_out)
    hi_out = np.where(wide, 1.0, hi_out)

    return Interval(_round_down(lo_out), _round_up(hi_out))


def tan(x: Interval) -> Interval:
    """Sound enclosure of ``tan([lo, hi])``.

    ``tan`` has vertical asymptotes at ``π/2 + kπ`` so any interval
    straddling one of these produces an unbounded enclosure. Intervals
    within a single continuous branch are handled by the monotonic
    rule.
    """
    half_pi = np.pi / 2
    pi = np.pi
    lo = np.asarray(x.lo, dtype=np.float64)
    hi = np.asarray(x.hi, dtype=np.float64)

    # Normalize so the branch check is easy: find k such that
    # (lo, hi) ⊂ (−π/2 + kπ, π/2 + kπ).
    k_lo = np.floor((lo + half_pi) / pi)
    k_hi = np.floor((hi + half_pi) / pi)
    same_branch = k_lo == k_hi

    inf = np.float64(np.inf)
    tan_lo = np.tan(lo)
    tan_hi = np.tan(hi)
    out_lo = np.where(same_branch, tan_lo, -inf)
    out_hi = np.where(same_branch, tan_hi, inf)
    return Interval(_round_down(out_lo), _round_up(out_hi))


# ──────────────────────────────────────────────────────────────────────
# Monotone inverse-trig / inverse-hyperbolic / error / log1p atoms
#
# Every atom below is monotone on its (possibly restricted) domain, so a
# sound enclosure is the image of the endpoints — the "easy group" of
# transcendental certification (issue #136).
# ──────────────────────────────────────────────────────────────────────


def atan(x: Interval) -> Interval:
    """``atan`` is nondecreasing on all of R; image in ``(-π/2, π/2)``."""
    return _monotonic_nondec(x, np.arctan)


def asinh(x: Interval) -> Interval:
    """``asinh`` is nondecreasing on all of R."""
    return _monotonic_nondec(x, np.arcsinh)


def erf(x: Interval) -> Interval:
    """``erf`` is nondecreasing on all of R; image in ``(-1, 1)``."""
    from scipy.special import erf as _erf

    return _monotonic_nondec(x, _erf)


def asin(x: Interval) -> Interval:
    """``asin`` is nondecreasing on its domain ``[-1, 1]``."""
    return _monotonic_nondec_safe(x, np.arcsin)


def acos(x: Interval) -> Interval:
    """``acos`` is nonincreasing on its domain ``[-1, 1]``; image ``[0, π]``."""
    return _monotonic_nonincr_safe(x, np.arccos)


def acosh(x: Interval) -> Interval:
    """``acosh`` is nondecreasing on its domain ``[1, ∞)``; image ``[0, ∞)``."""
    return _monotonic_nondec_safe(x, np.arccosh)


def atanh(x: Interval) -> Interval:
    """``atanh`` is nondecreasing on ``(-1, 1)`` with asymptotes at ``±1``."""
    return _monotonic_nondec_safe(x, np.arctanh)


def log1p(x: Interval) -> Interval:
    """``log1p`` is nondecreasing on ``(-1, ∞)`` with an asymptote at ``-1``."""
    return _monotonic_nondec_safe(x, np.log1p)


def sigmoid(x: Interval) -> Interval:
    """``sigmoid`` is nondecreasing on all of R; image in ``(0, 1)``."""
    from scipy.special import expit as _expit

    return _monotonic_nondec(x, _expit)


def softplus(x: Interval) -> Interval:
    """``softplus`` is nondecreasing on all of R; image in ``(0, ∞)``."""
    return _monotonic_nondec(x, lambda v: np.logaddexp(v, 0.0))


# ──────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────


def _as_interval(x) -> Interval:
    """Coerce a scalar / array / Interval to an :class:`Interval`."""
    if isinstance(x, Interval):
        return x
    arr = np.asarray(x, dtype=np.float64)
    return Interval(arr, arr)


__all__ = [
    "Interval",
    "exp",
    "log",
    "sqrt",
    "absolute",
    "sin",
    "cos",
    "tan",
    "sinh",
    "cosh",
    "tanh",
    "atan",
    "asin",
    "acos",
    "asinh",
    "acosh",
    "atanh",
    "erf",
    "log1p",
    "sigmoid",
    "softplus",
]
