"""discopt.estimate -- Model-based parameter estimation.

Estimate unknown parameters from experimental data using weighted
least-squares (or maximum likelihood) formulated as an NLP and solved
with discopt's NLP solvers.

Quick Start
-----------
>>> from discopt.estimate import Experiment, ExperimentModel, estimate_parameters
>>> exp = MyExperiment()
>>> result = estimate_parameters(exp, data, initial_guess={"k": 0.5})
>>> print(result.summary())

See Also
--------
discopt.doe : Optimal design of experiments using the same Experiment
    interface, provided by the standalone ``discopt-doe`` plugin
    (``pip install discopt-doe``).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Union

import numpy as np

import discopt.modeling as dm
from discopt.modeling.core import Expression, Model, Variable

# ─────────────────────────────────────────────────────────────
# Experiment interface
# ─────────────────────────────────────────────────────────────


class ExperimentModel:
    """A discopt Model annotated with DoE / estimation metadata.

    Bundles a discopt Model with labels identifying which parts are
    unknown parameters, design inputs, measured responses, and
    measurement errors.

    Parameters
    ----------
    model : Model
        The underlying discopt optimization model.
    unknown_parameters : dict[str, Variable]
        Parameters to estimate, modeled as Variables with bounds.
    design_inputs : dict[str, Variable]
        Experimental conditions controlled by the experimenter.
    responses : dict[str, Expression]
        Model predictions corresponding to measured quantities.
        Each expression should be a scalar at a given solution point.
    measurement_error : dict[str, float]
        Standard deviation of measurement noise for each response.
        Keys must match ``responses``.

    Raises
    ------
    ValueError
        If response names and measurement_error names don't match.
    """

    def __init__(
        self,
        model: Model,
        unknown_parameters: dict[str, Variable],
        design_inputs: dict[str, Variable],
        responses: dict[str, Expression],
        measurement_error: dict[str, float],
    ):
        # Validate key consistency
        resp_keys = set(responses.keys())
        err_keys = set(measurement_error.keys())
        if resp_keys != err_keys:
            missing = resp_keys - err_keys
            extra = err_keys - resp_keys
            parts = []
            if missing:
                parts.append(f"responses missing error: {missing}")
            if extra:
                parts.append(f"error missing response: {extra}")
            raise ValueError(f"response and measurement_error keys must match. {'; '.join(parts)}")

        self.model = model
        self.unknown_parameters = unknown_parameters
        self.design_inputs = design_inputs
        self.responses = responses
        self.measurement_error = measurement_error

    @property
    def n_parameters(self) -> int:
        """Number of unknown parameters."""
        return len(self.unknown_parameters)

    @property
    def n_responses(self) -> int:
        """Number of measured responses."""
        return len(self.responses)

    @property
    def response_names(self) -> list[str]:
        """Ordered list of response names."""
        return list(self.responses.keys())

    @property
    def parameter_names(self) -> list[str]:
        """Ordered list of unknown parameter names."""
        return list(self.unknown_parameters.keys())


class Experiment:
    """Base class for model-based experiments.

    Subclass this and implement :meth:`create_model` to define your
    experiment. The returned :class:`ExperimentModel` bundles the discopt
    Model together with metadata labeling unknown parameters, design
    inputs, measured responses, and measurement errors.

    Examples
    --------
    >>> class MyExperiment(Experiment):
    ...     def create_model(self, **kwargs):
    ...         m = dm.Model("my_exp")
    ...         k = m.continuous("k", lb=0, ub=10)
    ...         # ... build model ...
    ...         return ExperimentModel(
    ...             model=m,
    ...             unknown_parameters={"k": k},
    ...             design_inputs={},
    ...             responses={"y": k * 2},
    ...             measurement_error={"y": 0.1},
    ...         )
    """

    def create_model(self, **kwargs) -> ExperimentModel:
        r"""Build the experiment model.

        Parameters
        ----------
        \*\*kwargs
            Keyword arguments, typically initial guesses for parameters
            or fixed design conditions.

        Returns
        -------
        ExperimentModel
            Annotated discopt model.
        """
        raise NotImplementedError("Subclass must implement create_model()")


# ─────────────────────────────────────────────────────────────
# Estimation result
# ─────────────────────────────────────────────────────────────


@dataclass
class EstimationResult:
    """Result of parameter estimation.

    Attributes
    ----------
    parameters : dict[str, float]
        Estimated parameter values.
    covariance : numpy.ndarray
        Parameter covariance matrix (inverse of FIM at the solution).
    fim : numpy.ndarray
        Fisher Information Matrix at the estimated parameters.
    objective : float
        Final objective value (weighted sum of squared residuals).
    solve_result : SolveResult
        The underlying discopt solve result.
    parameter_names : list[str]
        Ordered parameter names matching matrix rows/columns.
    n_observations : int
        Number of data points used in the estimation.
    """

    parameters: dict[str, float]
    covariance: np.ndarray
    fim: np.ndarray
    objective: float
    solve_result: dm.SolveResult
    parameter_names: list[str]
    n_observations: int

    @property
    def standard_errors(self) -> dict[str, float]:
        """Standard errors for each parameter (sqrt of covariance diagonal)."""
        se = np.sqrt(np.diag(self.covariance))
        return dict(zip(self.parameter_names, se))

    @property
    def confidence_intervals(self) -> dict[str, tuple[float, float]]:
        """Approximate 95% confidence intervals for each parameter.

        Uses t-distribution with ``n_observations - n_parameters``
        degrees of freedom.
        """
        from scipy.stats import t as t_dist

        n_params = len(self.parameters)
        dof = max(1, self.n_observations - n_params)
        t_val = t_dist.ppf(0.975, df=dof)
        ci = {}
        for i, name in enumerate(self.parameter_names):
            se = np.sqrt(self.covariance[i, i])
            val = self.parameters[name]
            ci[name] = (val - t_val * se, val + t_val * se)
        return ci

    @property
    def correlation_matrix(self) -> np.ndarray:
        """Parameter correlation matrix."""
        d = np.sqrt(np.diag(self.covariance))
        # Avoid division by zero for perfectly determined parameters
        d = np.where(d > 0, d, 1.0)
        return np.asarray(self.covariance / np.outer(d, d))

    def summary(self) -> str:
        """Human-readable estimation summary."""
        lines = ["Parameter Estimation Results", "=" * 50]
        ci = self.confidence_intervals
        se = self.standard_errors
        for name in self.parameter_names:
            val = self.parameters[name]
            lo, hi = ci[name]
            lines.append(f"  {name:>12s} = {val:12.6g}  ± {se[name]:.4g}  [{lo:.4g}, {hi:.4g}]")
        lines.append(f"  {'Objective':>12s} = {self.objective:.6g}")
        lines.append(f"  {'N obs':>12s} = {self.n_observations}")
        det = np.linalg.det(self.fim)
        lines.append(f"  {'FIM det':>12s} = {det:.4g}")
        cond = np.linalg.cond(self.fim)
        lines.append(f"  {'FIM cond':>12s} = {cond:.4g}")
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────
# Main estimation function
# ─────────────────────────────────────────────────────────────


def estimate_parameters(
    experiment: Experiment,
    data: dict[str, Union[float, np.ndarray]],
    *,
    initial_guess: dict[str, float] | None = None,
    fixed_parameters: dict[str, float] | None = None,
    solver_options: dict[str, Any] | None = None,
) -> EstimationResult:
    """Estimate unknown parameters from experimental data.

    Builds a weighted least-squares NLP and solves it:

    .. math::

        \\min_{\\theta} \\sum_i \\left(\\frac{y_i^{obs} - y_i^{model}(\\theta)}{\\sigma_i}\\right)^2

    The returned ``objective`` is this sum, which equals the *deviance*
    (2 x negative log-likelihood, up to a constant) under Gaussian noise.
    Profile likelihood and chi-square-based tests use this convention.

    Parameters
    ----------
    experiment : Experiment
        Experiment definition with :meth:`~Experiment.create_model`.
    data : dict[str, float or numpy.ndarray]
        Observed values for each response. Keys must match response names
        from the ExperimentModel. Scalar or 1-D array values.
    initial_guess : dict[str, float], optional
        Starting values for unknown parameters. Passed as kwargs to
        ``experiment.create_model()``.
    fixed_parameters : dict[str, float], optional
        Parameters to hold fixed during the estimation. After
        ``create_model``, the variable's lower and upper bounds are both
        set to the supplied value so the solver cannot move it. Used
        by ``discopt.doe.profile_likelihood`` (discopt-doe plugin) and useful
        standalone for sub-model fits and one-at-a-time sensitivity
        studies.
    solver_options : dict, optional
        Options passed to the solver. When omitted, estimation uses a local
        continuous NLP solve (``skip_convex_check=True``) rather than global
        spatial branch-and-bound, which is usually inappropriate for
        nonlinear least-squares fitting.

    Returns
    -------
    EstimationResult
        Estimated parameters, covariance, FIM, and diagnostics.

    Raises
    ------
    ValueError
        If data keys don't match response names, or if the solve fails.
    KeyError
        If a name in ``fixed_parameters`` is not an unknown parameter.
    """
    kwargs = dict(initial_guess or {})
    if fixed_parameters:
        # Fixed values take precedence over initial guesses for the same
        # parameter, so create_model starts at the fixed value.
        kwargs.update({k: float(v) for k, v in fixed_parameters.items()})
    em = experiment.create_model(**kwargs)

    if fixed_parameters:
        for name, value in fixed_parameters.items():
            if name not in em.unknown_parameters:
                raise KeyError(
                    f"{name!r} is not an unknown parameter (known: {list(em.unknown_parameters)})"
                )
            var = em.unknown_parameters[name]
            val_arr = np.asarray(float(value), dtype=np.float64)
            if var.shape:
                val_arr = np.full(var.shape, val_arr)
            var.lb = val_arr
            var.ub = val_arr

    # Validate data keys match responses
    resp_keys = set(em.responses.keys())
    data_keys = set(data.keys())
    if not data_keys.issubset(resp_keys):
        raise ValueError(f"Data keys {data_keys - resp_keys} not in response names {resp_keys}")

    # Build weighted least-squares objective
    residual_terms = []
    n_obs = 0
    for name in em.response_names:
        if name not in data:
            continue
        y_obs = np.asarray(data[name], dtype=np.float64)
        y_model = em.responses[name]
        sigma = em.measurement_error[name]

        if y_obs.ndim == 0:
            # Scalar observation
            residual_terms.append(((y_obs.item() - y_model) / sigma) ** 2)
            n_obs += 1
        else:
            # Repeated observations of the same response (e.g. accumulated
            # by sequential_doe across rounds). Each element is an
            # independent measurement and contributes its own residual.
            for val in y_obs.flat:
                residual_terms.append(((float(val) - y_model) / sigma) ** 2)
                n_obs += 1

    if not residual_terms:
        raise ValueError("No data matched any response names")

    em.model.minimize(dm.sum(residual_terms))

    # Solve. Parameter estimation is a local nonlinear least-squares workflow;
    # callers that need certified global optimization can override this.
    effective_solver_options: dict[str, Any] = {"skip_convex_check": True}
    effective_solver_options.update(solver_options or {})
    solve_out = em.model.solve(**effective_solver_options)
    # solve() returns SolveResult (not streaming iterator) by default
    result: dm.SolveResult = solve_out  # type: ignore[assignment]

    if result.status not in ("optimal", "feasible"):
        raise ValueError(f"Estimation solve failed with status: {result.status}")

    # Extract estimated parameters
    params = {}
    for name, var in em.unknown_parameters.items():
        raw = np.asarray(result.value(var))
        params[name] = float(raw.flat[0])

    # Compute FIM at the solution for covariance estimation. Per-response
    # replication counts come from the observed data so that repeated
    # measurements (e.g. accumulated across sequential_doe rounds)
    # contribute proportionally.
    n_reps = np.array(
        [
            max(int(np.atleast_1d(np.asarray(data[name])).size), 1) if name in data else 0
            for name in em.response_names
        ],
        dtype=np.float64,
    )
    fim = _compute_estimation_fim(em, result, n_reps=n_reps)

    # Covariance = FIM^{-1} (with regularization for near-singular FIM)
    try:
        covariance = np.linalg.inv(fim)
    except np.linalg.LinAlgError:
        # Regularize singular FIM
        covariance = np.linalg.pinv(fim)

    return EstimationResult(
        parameters=params,
        covariance=covariance,
        fim=fim,
        objective=result.objective or 0.0,
        solve_result=result,
        parameter_names=em.parameter_names,
        n_observations=n_obs,
    )


def _compute_estimation_fim(
    em: ExperimentModel,
    result: dm.SolveResult,
    n_reps: np.ndarray | None = None,
) -> np.ndarray:
    """Compute Fisher Information Matrix at the estimation solution.

    Uses JAX autodiff to compute the Jacobian dy/dθ, then:
    FIM = J^T (N Σ^{-1}) J

    where N is a diagonal matrix of per-response replication counts
    (ones by default). When the caller has observed the same response
    multiple times under the same design, ``n_reps`` scales the
    information contribution proportionally.

    For estimation, the unknown parameters are Variables, so the Jacobian
    is computed w.r.t. the variable values (not model Parameters).
    """
    import jax
    import jax.numpy as jnp

    from discopt.parametric import (
        compile_expression,
        extract_x_flat,
        flatten_params,
        variable_slices,
    )

    model = em.model
    x_flat = extract_x_flat(result, model)

    # Compile response functions
    # These are functions of x_flat (variables include the unknown params)
    response_fns = []
    for name in em.response_names:
        fn = compile_expression(em.responses[name], model)
        response_fns.append(fn)

    # We need the Jacobian of responses w.r.t. the unknown parameter
    # variables. Since unknown_parameters are Variables in the x_flat vector,
    # we compute d(responses)/d(x_flat) and extract the relevant columns.

    # Find indices of unknown parameter variables in x_flat
    slices = variable_slices(model)
    param_indices: list[int] = []
    for var in em.unknown_parameters.values():
        sl = slices[var.name]
        param_indices.extend(range(sl.start, sl.stop))

    # Build a dummy p_flat (model may or may not have Parameters)
    p_flat = flatten_params(model)

    def response_vector(x_flat_arg):
        return jnp.stack([fn(x_flat_arg, p_flat) for fn in response_fns])

    # Full Jacobian w.r.t. x_flat
    J_full = jax.jacobian(response_vector)(x_flat)
    # shape: (n_responses, n_x_total)

    # Extract columns for unknown parameters only
    J = J_full[:, param_indices]
    # shape: (n_responses, n_unknown_params)

    # Measurement covariance (diagonal)
    sigma = np.array([em.measurement_error[name] for name in em.response_names])
    weights = 1.0 / sigma**2
    if n_reps is not None:
        n_reps = np.asarray(n_reps, dtype=np.float64)
        if n_reps.shape != weights.shape:
            raise ValueError(
                f"n_reps shape {n_reps.shape} does not match n_responses {weights.shape}"
            )
        weights = weights * n_reps
    W = np.diag(weights)

    # FIM = J^T (N Σ^{-1}) J
    fim = np.asarray(J.T @ W @ J)

    return fim
