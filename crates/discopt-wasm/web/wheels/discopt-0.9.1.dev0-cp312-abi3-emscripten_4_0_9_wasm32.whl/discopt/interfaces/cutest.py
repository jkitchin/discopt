"""
CUTEst interface for discopt.

Wraps PyCUTEst to provide:
  - CUTEstProblem: metadata extraction and problem management
  - NLPEvaluatorFromCUTEst: evaluator matching the NLPEvaluator interface
  - Problem discovery helpers: list/filter/load CUTEst problems

PyCUTEst is an optional dependency. Install with:
    pip install discopt[cutest]

Requires gfortran and the CUTEst/SIFDecode libraries.
See https://jfowkes.github.io/pycutest/ for setup instructions.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

try:
    import pycutest  # type: ignore[import-untyped]

    _HAS_PYCUTEST = True
except (ImportError, RuntimeError):
    # RuntimeError is raised by pycutest when CUTEst env vars are not set
    _HAS_PYCUTEST = False


def _require_pycutest() -> None:
    """Raise ImportError with helpful message if pycutest is not installed."""
    if not _HAS_PYCUTEST:
        raise ImportError(
            "pycutest is required for CUTEst support. Install with:\n"
            "  pip install discopt[cutest]\n"
            "Also requires gfortran and CUTEst/SIFDecode libraries.\n"
            "See https://jfowkes.github.io/pycutest/ for setup."
        )


# CUTEst classification codes mapped to pycutest filter strings.
# pycutest.find_problems() expects these full string values.
_OBJECTIVE_TYPES = {
    "N": "none",
    "C": "constant",
    "L": "linear",
    "Q": "quadratic",
    "S": "sum of squares",
    "O": "other",
}

_CONSTRAINT_TYPES = {
    "U": "unconstrained",
    "X": "fixed variables",
    "B": "bounds",
    "N": "network",
    "L": "linear",
    "Q": "quadratic",
    "O": "other",
}


@dataclass
class CUTEstProblemInfo:
    """Metadata about a CUTEst problem, extracted from classification."""

    name: str
    n: int  # number of variables
    m: int  # number of constraints
    objective_type: str  # from classification
    constraint_type: str  # from classification
    regularity: str  # R=regular, I=irregular
    degree: int  # highest degree of derivatives
    is_variable_dimension: bool  # "V" problems allow sifParams to change n
    classification: str  # raw classification string


class CUTEstProblem:
    """
    Wraps a PyCUTEst problem with metadata extraction and evaluator creation.

    Usage:
        prob = CUTEstProblem("ROSENBR")
        info = prob.info
        evaluator = prob.to_evaluator()

        # Or use with discopt's Ipopt solver directly:
        from discopt.solvers.nlp_ipopt import solve_nlp
        result = solve_nlp(evaluator, prob.x0)
    """

    def __init__(self, name: str, sif_params: Optional[dict] = None) -> None:
        _require_pycutest()
        self._name = name
        self._sif_params = sif_params or {}
        self._problem = pycutest.import_problem(name, sifParams=self._sif_params)
        self._info: Optional[CUTEstProblemInfo] = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def problem(self):
        """Access the underlying pycutest problem object."""
        return self._problem

    @property
    def n(self) -> int:
        """Number of variables."""
        return self._problem.n

    @property
    def m(self) -> int:
        """Number of constraints."""
        return self._problem.m

    @property
    def x0(self) -> np.ndarray:
        """Starting point."""
        return self._problem.x0.copy()

    @property
    def bl(self) -> np.ndarray:
        """Variable lower bounds."""
        return self._problem.bl.copy()

    @property
    def bu(self) -> np.ndarray:
        """Variable upper bounds."""
        return self._problem.bu.copy()

    @property
    def cl(self) -> Optional[np.ndarray]:
        """Constraint lower bounds (None if unconstrained)."""
        if self.m == 0:
            return None
        return self._problem.cl.copy()

    @property
    def cu(self) -> Optional[np.ndarray]:
        """Constraint upper bounds (None if unconstrained)."""
        if self.m == 0:
            return None
        return self._problem.cu.copy()

    @property
    def is_eq_cons(self) -> Optional[np.ndarray]:
        """Boolean array: True for equality constraints."""
        if self.m == 0:
            return None
        return self._problem.is_eq_cons.copy()

    @property
    def is_linear_cons(self) -> Optional[np.ndarray]:
        """Boolean array: True for linear constraints."""
        if self.m == 0:
            return None
        return self._problem.is_linear_cons.copy()

    @property
    def info(self) -> CUTEstProblemInfo:
        """Problem metadata from CUTEst classification."""
        if self._info is None:
            self._info = self._extract_info()
        return self._info

    def _extract_info(self) -> CUTEstProblemInfo:
        """Extract metadata using pycutest.problem_properties()."""
        props = pycutest.problem_properties(self._name)

        # problem_properties returns full strings like 'sum of squares', 'unconstrained'
        obj_type = props.get("objective", "other")
        con_type = props.get("constraints", "unconstrained")
        regular = props.get("regular", True)
        degree = props.get("degree", 2)

        # Variable-dimension problems have userN=True
        is_variable_dim = props.get("n", self.n) != self.n

        # Build a classification string from the properties
        classification = f"{obj_type}/{con_type}/d={degree}"

        return CUTEstProblemInfo(
            name=self._name,
            n=self.n,
            m=self.m,
            objective_type=obj_type,
            constraint_type=con_type,
            regularity="R" if regular else "I",
            degree=degree,
            is_variable_dimension=is_variable_dim,
            classification=classification,
        )

    def to_evaluator(self) -> "NLPEvaluatorFromCUTEst":
        """Create an NLP evaluator from this problem."""
        return NLPEvaluatorFromCUTEst(self)

    def to_instance_info(self):
        """Convert to benchmark ``InstanceInfo`` for the benchmark runner.

        ``InstanceInfo`` lives in the **benchmark harness**, not in the installed
        package: it is defined in ``discopt_benchmarks/benchmarks/metrics.py``, and
        ``maturin``'s ``python-source = "python"`` means only ``python/discopt/**``
        enters the wheel. So the top-level ``benchmarks`` module this needs is
        importable from a repo checkout that has installed ``discopt_benchmarks``,
        and from nowhere else.

        Before this guard the bare ``from benchmarks.metrics import ...`` raised a
        naked ``ModuleNotFoundError: No module named 'benchmarks'`` for every
        pip-installed user, which reads as a broken package rather than as a method
        that belongs to the harness (audit 2026-09-20, v0.9.0 release prep). Note
        the near-miss: ``discopt.benchmarks.metrics`` *does* ship, and does **not**
        define ``InstanceInfo`` -- so the import is not a missing ``discopt.``
        prefix, and adding one would fail differently.
        """
        try:
            from benchmarks.metrics import InstanceInfo
        except ImportError as exc:  # pragma: no cover - exercised by the guard test
            raise ImportError(
                "CUTEstProblem.to_instance_info() requires the discopt benchmark "
                "harness, which is not part of the installed discopt package. "
                "Install it from a repo checkout: "
                "`cd discopt_benchmarks && pip install -e '.[dev]'`. "
                "(discopt.benchmarks.metrics is a different module and does not "
                "define InstanceInfo.)"
            ) from exc

        info = self.info
        n_lin = int(np.sum(self.is_linear_cons)) if self.is_linear_cons is not None else 0

        return InstanceInfo(
            name=self._name,
            num_variables=self.n,
            num_constraints=self.m,
            num_integer_vars=0,  # CUTEst is continuous NLP only
            num_binary_vars=0,
            num_continuous_vars=self.n,
            num_nonlinear_constraints=self.m - n_lin,
            problem_class=f"cutest_{info.constraint_type}",
            best_known_objective=None,
            is_convex=None,
            source="cutest",
        )

    def close(self) -> None:
        """Release the compiled problem resources."""
        # pycutest doesn't have an explicit close, but we can help GC
        self._problem = None

    def __repr__(self) -> str:
        return (
            f"CUTEstProblem({self._name!r}, n={self.n}, m={self.m}, "
            f"classification={self.info.classification!r})"
        )


class NLPEvaluatorFromCUTEst:
    """
    NLP evaluator wrapping a CUTEst problem via PyCUTEst callbacks.

    Provides the same interface as NLPEvaluator:
      - evaluate_objective(x) -> float
      - evaluate_gradient(x) -> ndarray
      - evaluate_hessian(x) -> ndarray
      - evaluate_constraints(x) -> ndarray
      - evaluate_jacobian(x) -> ndarray
      - n_variables, n_constraints, variable_bounds

    Uses PyCUTEst's analytic derivatives (not finite differences).
    """

    def __init__(self, cutest_problem: CUTEstProblem) -> None:
        self._prob = cutest_problem
        self._p = cutest_problem.problem
        self._n_variables = cutest_problem.n
        self._n_constraints = cutest_problem.m

    def evaluate_objective(self, x: np.ndarray) -> float:
        """Evaluate objective at x. Returns scalar."""
        x = np.asarray(x, dtype=np.float64)
        return float(self._p.obj(x))

    def evaluate_gradient(self, x: np.ndarray) -> np.ndarray:
        """Evaluate gradient of objective at x. Returns (n,) array."""
        x = np.asarray(x, dtype=np.float64)
        _, g = self._p.obj(x, gradient=True)
        return np.asarray(g, dtype=np.float64)

    def evaluate_hessian(self, x: np.ndarray) -> np.ndarray:
        """Evaluate Hessian of objective at x. Returns (n, n) dense array.

        For constrained problems this returns the objective Hessian only
        (not the Lagrangian Hessian). Use evaluate_lagrangian_hessian()
        for the full Lagrangian Hessian.
        """
        x = np.asarray(x, dtype=np.float64)
        if self._n_constraints > 0:
            # ihess returns objective Hessian for constrained problems
            H = self._p.ihess(x)
        else:
            H = self._p.hess(x)
        return np.asarray(H, dtype=np.float64)

    def evaluate_lagrangian_hessian(
        self, x: np.ndarray, obj_factor: float, lambda_: np.ndarray
    ) -> np.ndarray:
        """Evaluate Hessian of the Lagrangian at (x, lambda). Returns (n, n) dense array.

        H = obj_factor * nabla^2 f(x) + sum_i lambda_i * nabla^2 c_i(x)
        """
        x = np.asarray(x, dtype=np.float64)
        lambda_ = np.asarray(lambda_, dtype=np.float64)
        # pycutest hess(x, v=v) computes nabla^2 f(x) + sum_i v_i * nabla^2 c_i(x)
        # Scale lambda by 1/obj_factor would lose the obj_factor on f, so compute
        # the two parts separately when obj_factor != 1.
        if abs(obj_factor - 1.0) < 1e-15 or self._n_constraints == 0:
            H = self._p.hess(x, v=lambda_) if self._n_constraints > 0 else self._p.hess(x)
            H = obj_factor * H if self._n_constraints == 0 else H
        else:
            # H_obj via ihess (objective-only Hessian for constrained problems)
            H_obj = self._p.ihess(x)
            # H_lag with obj_factor=1: nabla^2 f + sum lambda_i nabla^2 c_i
            H_full = self._p.hess(x, v=lambda_)
            # H_constraints = H_full - H_obj
            H = obj_factor * H_obj + (H_full - H_obj)
        return np.asarray(H, dtype=np.float64)

    def evaluate_constraints(self, x: np.ndarray) -> np.ndarray:
        """Evaluate all constraint bodies at x. Returns (m,) array."""
        if self._n_constraints == 0:
            return np.array([], dtype=np.float64)
        x = np.asarray(x, dtype=np.float64)
        c = self._p.cons(x)
        return np.asarray(c, dtype=np.float64)

    def evaluate_jacobian(self, x: np.ndarray) -> np.ndarray:
        """Evaluate Jacobian of constraints at x. Returns (m, n) dense array."""
        if self._n_constraints == 0:
            return np.empty((0, self._n_variables), dtype=np.float64)
        x = np.asarray(x, dtype=np.float64)
        _, J = self._p.cons(x, gradient=True)
        return np.asarray(J, dtype=np.float64)

    def evaluate_sparse_hessian(
        self, x: np.ndarray, v: Optional[np.ndarray] = None
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Evaluate sparse Hessian of the Lagrangian. Returns (vals, rows, cols).

        For large-scale problems where dense Hessian is prohibitive.
        """
        x = np.asarray(x, dtype=np.float64)
        if self._n_constraints > 0 and v is not None:
            v = np.asarray(v, dtype=np.float64)
            H = self._p.sphess(x, v=v)
        elif self._n_constraints > 0:
            H = self._p.isphess(x)
        else:
            H = self._p.sphess(x)
        # H is scipy.sparse.csc_matrix
        coo = H.tocoo()
        return (
            np.asarray(coo.data, dtype=np.float64),
            np.asarray(coo.row, dtype=np.int32),
            np.asarray(coo.col, dtype=np.int32),
        )

    def evaluate_sparse_jacobian(self, x: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Evaluate sparse Jacobian of constraints. Returns (vals, rows, cols).

        For large-scale problems where dense Jacobian is prohibitive.
        """
        if self._n_constraints == 0:
            return (
                np.array([], dtype=np.float64),
                np.array([], dtype=np.int32),
                np.array([], dtype=np.int32),
            )
        x = np.asarray(x, dtype=np.float64)
        # pycutest's slagjac returns (g, J): the (sparse, 1 x n) objective
        # gradient FIRST, then the m x n constraint Jacobian. Unpacking it the
        # other way round made the Jacobian structure the gradient's pattern --
        # every entry in row 0 -- so each constrained problem was solved with
        # constraints 1..m-1 carrying no derivative (HS71: POUNCE stopped at an
        # infeasible 16.32, Ipopt hit its iteration limit at 45.8; opt 17.014).
        _, J_sparse = self._p.slagjac(x)
        if J_sparse.shape != (self._n_constraints, self._n_variables):
            raise ValueError(
                f"slagjac Jacobian has shape {J_sparse.shape}, expected "
                f"({self._n_constraints}, {self._n_variables})"
            )
        coo = J_sparse.tocoo()
        return (
            np.asarray(coo.data, dtype=np.float64),
            np.asarray(coo.row, dtype=np.int32),
            np.asarray(coo.col, dtype=np.int32),
        )

    def has_sparse_structure(self) -> bool:
        """CUTEst always provides sparse structure."""
        return True

    def jacobian_structure(self) -> tuple[np.ndarray, np.ndarray]:
        """Return fixed Jacobian sparsity as COO (rows, cols)."""
        self._ensure_coo_cache()
        return (self._jac_rows, self._jac_cols)

    def hessian_structure(self) -> tuple[np.ndarray, np.ndarray]:
        """Return fixed lower-triangle Hessian sparsity as COO (rows, cols)."""
        self._ensure_coo_cache()
        return (self._hess_rows, self._hess_cols)

    def evaluate_jacobian_values(self, x: np.ndarray) -> np.ndarray:
        """Return Jacobian values as 1-D array matching jacobian_structure order."""
        self._ensure_coo_cache()
        if self._n_constraints == 0:
            return np.array([], dtype=np.float64)
        # Evaluate dense and extract at cached positions
        J = self.evaluate_jacobian(x)
        return J[self._jac_rows, self._jac_cols].astype(np.float64)

    def evaluate_hessian_values(
        self, x: np.ndarray, obj_factor: float, lambda_: np.ndarray
    ) -> np.ndarray:
        """Return Lagrangian Hessian values as 1-D array matching hessian_structure."""
        self._ensure_coo_cache()
        H = self.evaluate_lagrangian_hessian(x, obj_factor, lambda_)
        return H[self._hess_rows, self._hess_cols].astype(np.float64)

    def _ensure_coo_cache(self) -> None:
        """Lazily probe and cache fixed COO structure from PyCUTEst."""
        if hasattr(self, "_jac_rows"):
            return
        x0 = self._prob.x0
        m = self._n_constraints

        # Jacobian structure: probe at x0
        if m > 0:
            vals, rows, cols = self.evaluate_sparse_jacobian(x0)
            self._jac_rows = np.asarray(rows, dtype=np.intp)
            self._jac_cols = np.asarray(cols, dtype=np.intp)
        else:
            self._jac_rows = np.array([], dtype=np.intp)
            self._jac_cols = np.array([], dtype=np.intp)

        # Hessian structure: probe at x0 with zero multipliers
        lam = np.ones(m, dtype=np.float64) if m > 0 else None
        vals, rows, cols = self.evaluate_sparse_hessian(x0, v=lam)
        rows = np.asarray(rows, dtype=np.intp)
        cols = np.asarray(cols, dtype=np.intp)
        # Keep only lower triangle
        lower_mask = rows >= cols
        self._hess_rows = rows[lower_mask]
        self._hess_cols = cols[lower_mask]

    @property
    def n_variables(self) -> int:
        """Total number of variables."""
        return self._n_variables

    @property
    def n_constraints(self) -> int:
        """Total number of constraints."""
        return self._n_constraints

    @property
    def variable_bounds(self) -> tuple[np.ndarray, np.ndarray]:
        """Returns (lb, ub) arrays of shape (n,) for all variables."""
        return self._prob.bl, self._prob.bu

    @property
    def constraint_bounds(self) -> Optional[tuple[np.ndarray, np.ndarray]]:
        """Returns (cl, cu) arrays of shape (m,) for all constraints, or None."""
        if self._n_constraints == 0:
            return None
        return self._prob.cl, self._prob.cu


# ─────────────────────────────────────────────────────────────
# Problem discovery helpers
# ─────────────────────────────────────────────────────────────


def list_cutest_problems(
    objective: Optional[str] = None,
    constraints: Optional[str] = None,
    regular: Optional[bool] = None,
    max_n: Optional[int] = None,
    max_m: Optional[int] = None,
    userN: Optional[bool] = None,
) -> list[str]:
    """
    List available CUTEst problems matching filter criteria.

    Args:
        objective: Objective type filter (N/C/L/Q/S/O or e.g. "quadratic").
        constraints: Constraint type filter (U/X/B/N/L/Q/O or e.g. "unconstrained").
        regular: If True, only regular problems; if False, only irregular.
        max_n: Maximum number of variables (None = no limit).
        max_m: Maximum number of constraints (None = no limit).
        userN: If True, only variable-dimension problems; if False, exclude them.

    Returns:
        Sorted list of problem names matching all filters.
    """
    _require_pycutest()

    # pycutest.find_problems() expects full strings like 'unconstrained',
    # not CUTEst single-letter codes like 'U'. Map codes to strings.
    if objective is not None and len(objective) == 1:
        objective = _OBJECTIVE_TYPES.get(objective, objective)
    if constraints is not None and len(constraints) == 1:
        constraints = _CONSTRAINT_TYPES.get(constraints, constraints)

    # Build the classification filter for pycutest.find_problems()
    kwargs: dict[str, str | bool] = {}
    if objective is not None:
        kwargs["objective"] = objective
    if constraints is not None:
        kwargs["constraints"] = constraints
    if regular is not None:
        kwargs["regular"] = regular
    if userN is not None:
        kwargs["userN"] = userN

    problems = pycutest.find_problems(**kwargs)

    # Apply dimension filters if specified
    if max_n is not None or max_m is not None:
        filtered = []
        for name in problems:
            try:
                props = pycutest.problem_properties(name)
                n = props.get("n", 0)
                m = props.get("m", 0)
                if max_n is not None and n > max_n:
                    continue
                if max_m is not None and m > max_m:
                    continue
                filtered.append(name)
            except Exception as exc:  # noqa: BLE001 - an unqueryable problem is filtered out
                # Logged: silently dropping problems shrinks a benchmark set
                # without any record that the set is smaller than it looks.
                logger.debug(
                    "CUTEst problem %s not queryable, excluded: %s: %s",
                    name,
                    type(exc).__name__,
                    exc,
                )
                continue
        problems = filtered

    return sorted(problems)


def load_cutest_problem(
    name: str,
    sif_params: Optional[dict] = None,
) -> CUTEstProblem:
    """
    Load a CUTEst problem by name.

    Args:
        name: CUTEst problem name (e.g., "ROSENBR", "HS35").
        sif_params: Optional SIF parameters for variable-dimension problems.

    Returns:
        CUTEstProblem instance.
    """
    _require_pycutest()
    return CUTEstProblem(name, sif_params=sif_params)
