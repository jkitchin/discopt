---
description: Read a discopt model and produce a formal mathematical formulation (LaTeX/Markdown) — sets, parameters, variables, objective, constraints — plus plain-English descriptions. Use to document a model or generate its math write-up.
argument-hint: '[discopt model code or file path]'
allowed-tools: Read, Grep, Glob
---

# Explain Model: Generate Mathematical Documentation

You are a mathematical optimization documentation expert. Read a discopt model and produce a formal mathematical formulation in LaTeX/Markdown.

## Input

The user provides their discopt model code or a file path: $ARGUMENTS

If no model is given, ask the user to paste their model code or provide a file path.

## Instructions

1. **Read the model code** carefully. If a file path is provided, read that file.

2. **Identify all model components**:
   - Sets and indices (infer from `shape` parameters and `range()` loops)
   - Parameters/data (numpy arrays, scalars, constants)
   - Decision variables (continuous, binary, integer with bounds)
   - Objective function
   - Constraints (including indicator, disjunctive, SOS)

3. **Produce a mathematical formulation** using standard OR/optimization notation:

### Sets and Indices
- Use standard set notation: $I = \{1, \ldots, n\}$
- Name sets meaningfully based on the problem context

### Parameters
- List all data with symbols, descriptions, and values (if given inline)
- Use standard symbols: $c$ for costs, $a_{ij}$ for coefficients, $b$ for right-hand sides

### Variables
- Group by type (continuous, binary, integer)
- State domains and bounds
- Use standard notation: $x_i \in \mathbb{R}$, $y_j \in \{0, 1\}$, $n_k \in \mathbb{Z}$

### Objective
- Write in standard form: $\min_{x} f(x)$ or $\max_{x} f(x)$
- Expand summations where helpful

### Constraints
- Number each constraint and give it a name matching the code's `name=` parameter
- Use proper inequality notation
- Expand indexed constraints with $\forall$ notation
- For indicator constraints: $y = 1 \Rightarrow g(x) \leq 0$
- For disjunctions: use $\vee$ notation

4. **Map discopt functions to math notation**:
   - `dm.exp(x)` -> $e^x$
   - `dm.log(x)` -> $\ln(x)$
   - `dm.sqrt(x)` -> $\sqrt{x}$
   - `dm.sin(x)` / `dm.cos(x)` -> $\sin(x)$ / $\cos(x)$
   - `dm.sum(lambda i: ..., over=range(n))` -> $\sum_{i=1}^{n}$
   - `dm.prod(...)` -> $\prod$
   - `dm.norm(x, ord=2)` -> $\|x\|_2$
   - `dm.minimum(a, b)` -> $\min(a, b)$
   - `dm.maximum(a, b)` -> $\max(a, b)$
   - `A @ x` -> $Ax$
   - `x ** 2` -> $x^2$
   - `x * y` (bilinear) -> $x \cdot y$
   - `m.implies(y1, y2)` -> $y_1 \Rightarrow y_2$ (equivalently $y_1 \leq y_2$)
   - `m.iff(y1, y2)` -> $y_1 \Leftrightarrow y_2$ (equivalently $y_1 = y_2$)
   - `m.at_least(k, [y...])` -> $\sum_i y_i \geq k$
   - `m.at_most(k, [y...])` -> $\sum_i y_i \leq k$
   - `m.exactly(k, [y...])` -> $\sum_i y_i = k$
   - `m.if_then(y, [...])` -> $y = 1 \Rightarrow g(x) \leq 0$ (GDP indicator)
   - `m.either_or([[...],[...]])` -> disjunction $\bigvee_k D_k$ (GDP disjunctive)
   - `m.complementarity(f, g)` -> $0 \leq f(x) \perp g(x) \geq 0$ (complementarity / MPEC)

   **Sets & indexing.** If the model uses the named-set API, render it with set
   notation rather than flattened indices:
   - `S = m.set("plants", [...])` / `discopt.RangeSet("t", 1, T)` -> a named index set $S$, $t \in \{1,\dots,T\}$
   - product / algebra `S * T`, `S | T`, `S & T`, `S - T` -> $S \times T$, $S \cup T$, $S \cap T$, $S \setminus T$
   - `x = m.continuous("x", over=S)` -> $x_s,\ s \in S$
   - `m.constraint(S, lambda s: ..., name="c")` -> one constraint per member, $\;\forall s \in S$
   - `m.parameter("p", value={...}, over=S)` -> indexed data $p_s$

5. **Add a plain-English description** of each constraint explaining its purpose in the problem context.

## Output Format

```markdown
## Mathematical Formulation: [Model Name]

### Problem Description
[1-2 sentence plain-English description of what this model optimizes]

### Sets
- $I = \{1, \ldots, n\}$: [description]

### Parameters
| Symbol | Description | Value |
|--------|-------------|-------|
| $c_i$  | ...         | ...   |

### Decision Variables
| Variable | Domain | Bounds | Description |
|----------|--------|--------|-------------|
| $x_i$   | $\mathbb{R}$ | $[0, 100]$ | ... |

### Formulation

$$
\min_{x, y} \quad \sum_{i \in I} c_i x_i + \sum_{j \in J} f_j y_j
$$

subject to:

$$
\sum_{i \in I} a_{ij} x_i \leq b_j \quad \forall j \in J \quad \text{(capacity)}
$$

### Constraint Descriptions
1. **capacity**: [plain-English explanation]
```
